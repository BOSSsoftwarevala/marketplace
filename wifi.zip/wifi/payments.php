<?php include('head.php'); ?>
<body data-active="payments" data-crumbs="Workspace | Payments">
<div class="shell">
<?php include('sidebar.php'); ?>
<div class="main">
<?php include('topbar.php'); ?>
<main class="content">
<section class="hero">
<div class="hero-text">
<span class="eyebrow" id="heroDate">Payment Management</span>
<h1 class="hero-title">Manage <span class="accent">Payments</span></h1>
<p class="hero-sub" id="heroSubText">Track and manage all financial transactions</p>
</div>
<div class="hero-actions">
<button class="btn btn--ghost" onclick="exportPayments()"><svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/></svg> Export</button>
<button class="btn btn--primary" onclick="location.reload()"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg> Refresh</button>
</div>
</section>

<!-- Payment Statistics KPI Grid -->
<section class="kpi-grid" aria-label="Payment metrics">
<article class="kpi-card c-success">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon success"><svg viewBox="0 0 24 24"><path d="M20 12H4M12 4v16"/></svg></div>
<div class="kpi-label">Total Revenue</div>
</div>
</div>
<div class="kpi-value" id="totalRevenue"> 0</div>
<div class="kpi-compare">All time</div>
</article>

<article class="kpi-card c-danger">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon danger"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg></div>
<div class="kpi-label">Today's Revenue</div>
</div>
</div>
<div class="kpi-value" id="todayRevenue"> 0</div>
<div class="kpi-compare" id="todayCount">0 transactions</div>
</article>

<article class="kpi-card c-purple">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon purple"><svg viewBox="0 0 24 24"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg></div>
<div class="kpi-label">Monthly Revenue</div>
</div>
</div>
<div class="kpi-value" id="monthlyRevenue"> 0</div>
<div class="kpi-compare" id="monthlyCount">0 transactions</div>
</article>

<article class="kpi-card c-primary">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon primary"><svg viewBox="0 0 24 24"><path d="M18 20V10M12 20V4M6 20v-4"/></svg></div>
<div class="kpi-label">Success Rate</div>
</div>
</div>
<div class="kpi-value" id="successRate">0%</div>
<div class="kpi-compare">Payment success</div>
</article>
</section>

<!-- Recent Payments Table -->
<section class="col-12 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Transaction List</span>
<h2 class="card-title">Recent Payments</h2>
</div>
<div class="card-actions">
<input type="text" id="searchInput" placeholder="Search by customer..." class="search-input" style="padding: 6px 12px; border-radius: 6px; border: 1px solid var(--border); background: var(--bg);">
<select id="statusFilter" class="status-filter" style="padding: 6px 12px; border-radius: 6px; border: 1px solid var(--border); background: var(--bg);">
<option value="all">All Status</option>
<option value="completed">Completed</option>
<option value="pending">Pending</option>
<option value="failed">Failed</option>
<option value="refunded">Refunded</option>
</select>
</div>
</div>
<div class="table-responsive">
<table class="table">
<thead>
<tr>
<th>ID</th>
<th>Customer</th>
<th>Package</th>
<th>Amount</th>
<th>Status</th>
<th>Date</th>
<th>Receipt</th>
<th>Actions</th>
</tr>
</thead>
<tbody id="paymentsTableBody">
<tr><td colspan="8" class="text-center">Loading payments...</td></tr>
</tbody>
</table>
</div>
<div class="pagination" style="padding: 16px; display: flex; justify-content: space-between; align-items: center;">
<div>Showing <span id="showingStart">0</span> to <span id="showingEnd">0</span> of <span id="totalRecords">0</span> transactions</div>
<div class="pagination-buttons">
<button class="btn btn--small" id="prevPage" onclick="prevPage()" disabled>Previous</button>
<button class="btn btn--small" id="nextPage" onclick="nextPage()" disabled>Next</button>
</div>
</div>
</section>

<!-- View Payment Modal -->
<div id="viewPaymentModal" class="modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
    <div class="modal-content" style="background: white; border-radius: 12px; max-width: 550px; width: 90%; max-height: 90vh; overflow-y: auto; padding: 24px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1);">
        <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h3 style="margin: 0;">Payment Details</h3>
            <button onclick="closeViewModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: #666;">&times;</button>
        </div>
        <div id="paymentDetails" style="max-height: 400px; overflow-y: auto;"></div>
        <div style="margin-top: 20px; display: flex; gap: 10px; justify-content: flex-end;">
            <button onclick="closeViewModal()" class="btn btn--ghost" style="padding: 8px 16px;">Close</button>
        </div>
    </div>
</div>

<!-- Toast Container -->
<div id="toastContainer" style="position: fixed; top: 20px; right: 20px; z-index: 9999;"></div>

</main>
<?php include('footer.php'); ?>
</div>
</div>

<script>
// ============================================
// PAYMENT MANAGEMENT PAGE
// ============================================

// const API_BASE_URL = 'https://shabanetech.top/wifi-api';
// let adminToken = localStorage.getItem('adminToken');
let allPayments = [];
let currentPage = 1;
let totalPages = 1;
let currentFilters = { search: '', status: 'all' };

function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '✗' : type === 'warning' ? '⚠' : 'ℹ'}</div>
        <div class="toast-message">${message}</div>
        <button class="toast-close" onclick="this.parentElement.remove()">×</button>
    `;
    
    container.appendChild(toast);
    
    setTimeout(() => {
        if (toast.parentElement) {
            toast.style.animation = 'slideOut 0.3s ease forwards';
            setTimeout(() => toast.remove(), 300);
        }
    }, 4000);
}

// Add styles
const styles = document.createElement('style');
styles.textContent = `
    .toast {
        display: flex;
        align-items: center;
        gap: 12px;
        background: white;
        border-radius: 8px;
        padding: 12px 16px;
        margin-bottom: 10px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        animation: slideIn 0.3s ease forwards;
        min-width: 280px;
        border-left: 4px solid;
    }
    .toast-success { border-left-color: #10b981; }
    .toast-error { border-left-color: #ef4444; }
    .toast-warning { border-left-color: #f59e0b; }
    .toast-info { border-left-color: #3b82f6; }
    .toast-icon {
        width: 24px;
        height: 24px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        font-size: 14px;
    }
    .toast-success .toast-icon { background: #10b98120; color: #10b981; }
    .toast-error .toast-icon { background: #ef444420; color: #ef4444; }
    .toast-warning .toast-icon { background: #f59e0b20; color: #f59e0b; }
    .toast-info .toast-icon { background: #3b82f620; color: #3b82f6; }
    .toast-message { flex: 1; font-size: 14px; color: #333; }
    .toast-close {
        background: none;
        border: none;
        font-size: 18px;
        cursor: pointer;
        color: #999;
        padding: 0;
        width: 20px;
        height: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .toast-close:hover { color: #666; }
    
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
    .text-center { text-align: center; }
    .table-responsive { overflow-x: auto; }
    .tag { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 500; }
    .t-success { background: #dcfce7; color: #166534; }
    .t-pending { background: #fef3c7; color: #92400e; }
    .t-failed { background: #fee2e2; color: #991b1b; }
    .t-refunded { background: #e0e7ff; color: #3730a3; }
    .btn-icon { background: none; border: none; cursor: pointer; font-size: 18px; padding: 4px 8px; border-radius: 4px; transition: background 0.2s; }
    .btn-icon:hover { background: #f0f0f0; }
    .search-input, .status-filter { margin-left: 8px; }
    .card-actions { display: flex; gap: 8px; }
`;
document.head.appendChild(styles);

async function apiFetch(endpoint, options = {}) {
    if (!adminToken) {
        window.location.href = 'admin_login.html';
        return null;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            ...options,
            headers: {
                'Authorization': `Bearer ${adminToken}`,
                'Content-Type': 'application/json',
                ...options.headers
            }
        });
        
        if (response.status === 401) {
            localStorage.removeItem('adminToken');
            localStorage.removeItem('adminUser');
            window.location.href = 'admin_login.html';
            return null;
        }
        
        const data = await response.json();
        if (!response.ok) {
            throw new Error(data.error || data.message || `HTTP ${response.status}`);
        }
        return data;
    } catch (error) {
        console.error('API Error:', error);
        showToast(error.message || 'API request failed', 'error');
        return null;
    }
}

function formatCurrency(amount) {
    return ' ' + parseFloat(amount || 0).toLocaleString();
}

function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function getStatusClass(status) {
    switch(status) {
        case 'completed': return 't-success';
        case 'pending': return 't-pending';
        case 'failed': return 't-failed';
        case 'refunded': return 't-refunded';
        default: return 't-pending';
    }
}

// Load payment statistics from dashboard stats
async function loadStats() {
    const stats = await apiFetch('/api/admin/dashboard/stats');
    if (stats && stats.success && stats.data && stats.data.payments) {
        const payments = stats.data.payments;
        
        const totalRevenueElem = document.getElementById('totalRevenue');
        const todayRevenueElem = document.getElementById('todayRevenue');
        const todayCountElem = document.getElementById('todayCount');
        const monthlyRevenueElem = document.getElementById('monthlyRevenue');
        const monthlyCountElem = document.getElementById('monthlyCount');
        const successRateElem = document.getElementById('successRate');
        
        if (totalRevenueElem) totalRevenueElem.innerHTML = formatCurrency(payments.total_revenue);
        if (todayRevenueElem) todayRevenueElem.innerHTML = formatCurrency(payments.today?.total || 0);
        if (todayCountElem) todayCountElem.innerHTML = (payments.today?.count || 0) + ' transactions';
        if (monthlyRevenueElem) monthlyRevenueElem.innerHTML = formatCurrency(payments.month?.total || 0);
        if (monthlyCountElem) monthlyCountElem.innerHTML = (payments.month?.count || 0) + ' transactions';
        
        const total = payments.total_count || 0;
        const completed = payments.completed_count || 0;
        const successRate = total > 0 ? Math.round((completed / total) * 100) : 0;
        if (successRateElem) successRateElem.innerHTML = successRate + '%';
    }
}

// Load recent payments from dashboard stats
async function loadPayments() {
    const tbody = document.getElementById('paymentsTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '<tr><td colspan="8" class="text-center">Loading payments...</td></tr>';
    
    // Get recent payments from dashboard stats
    const stats = await apiFetch('/api/admin/dashboard/stats');
    
    if (stats && stats.success && stats.data && stats.data.recent_payments) {
        let payments = stats.data.recent_payments;
        allPayments = payments;
        
        // Apply filters
        let filtered = [...payments];
        
        if (currentFilters.search) {
            const search = currentFilters.search.toLowerCase();
            filtered = filtered.filter(p => 
                (p.fullname && p.fullname.toLowerCase().includes(search)) ||
                (p.username && p.username.toLowerCase().includes(search))
            );
        }
        
        if (currentFilters.status !== 'all') {
            filtered = filtered.filter(p => p.status === currentFilters.status);
        }
        
        const showingStartElem = document.getElementById('showingStart');
        const showingEndElem = document.getElementById('showingEnd');
        const totalRecordsElem = document.getElementById('totalRecords');
        
        if (filtered.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" class="text-center">No payments found</td></tr>';
            if (showingStartElem) showingStartElem.innerHTML = '0';
            if (showingEndElem) showingEndElem.innerHTML = '0';
            if (totalRecordsElem) totalRecordsElem.innerHTML = '0';
        } else {
            tbody.innerHTML = filtered.map(payment => `
                <tr>
                    <td>${payment.id}</td>
                    <td class="cell-name">
                        <strong>${escapeHtml(payment.fullname || payment.customer_name || 'Unknown')}</strong><br>
                        <small>${escapeHtml(payment.username || '')}</small>
                    </td>
                    <td>${escapeHtml(payment.package_name || '-')}</td>
                    <td class="cell-price pos">${formatCurrency(payment.amount)}</td>
                    <td><span class="tag ${getStatusClass(payment.status)}">${payment.status || 'pending'}</span></td>
                    <td class="cell-date">${formatDate(payment.created_at)}</td>
                    <td><small>${escapeHtml(payment.mpesa_receipt || '-')}</small></td>
                    <td>
                        <button class="btn-icon" onclick="viewPayment(${payment.id})" title="View">👁️</button>
                    </td>
                </tr>
            `).join('');
            
            if (showingStartElem) showingStartElem.innerHTML = '1';
            if (showingEndElem) showingEndElem.innerHTML = filtered.length;
            if (totalRecordsElem) totalRecordsElem.innerHTML = filtered.length;
        }
    } else {
        tbody.innerHTML = '<tr><td colspan="8" class="text-center">No payment records found</td></tr>';
        const totalRecordsElem = document.getElementById('totalRecords');
        if (totalRecordsElem) totalRecordsElem.innerHTML = '0';
    }
}

// View payment details
async function viewPayment(id) {
    const payment = allPayments.find(p => p.id == id);
    if (payment) {
        const detailsDiv = document.getElementById('paymentDetails');
        if (detailsDiv) {
            detailsDiv.innerHTML = `
                <div class="payment-info">
                    <p><strong>Transaction ID:</strong> ${payment.id}</p>
                    <p><strong>Customer:</strong> ${escapeHtml(payment.fullname || payment.customer_name)}</p>
                    <p><strong>Username:</strong> ${escapeHtml(payment.username || '-')}</p>
                    <p><strong>Phone:</strong> ${escapeHtml(payment.phone || '-')}</p>
                    <p><strong>Package:</strong> ${escapeHtml(payment.package_name || '-')}</p>
                    <p><strong>Amount:</strong> ${formatCurrency(payment.amount)}</p>
                    <p><strong>Status:</strong> <span class="tag ${getStatusClass(payment.status)}">${payment.status}</span></p>
                    <p><strong>M-Pesa Receipt:</strong> ${escapeHtml(payment.mpesa_receipt || '-')}</p>
                    <p><strong>Date:</strong> ${formatDate(payment.created_at)}</p>
                </div>
            `;
        }
        const modal = document.getElementById('viewPaymentModal');
        if (modal) modal.style.display = 'flex';
    } else {
        showToast('Payment details not available', 'error');
    }
}

function closeViewModal() {
    const modal = document.getElementById('viewPaymentModal');
    if (modal) modal.style.display = 'none';
}

function prevPage() {
    if (currentPage > 1) {
        currentPage--;
        loadPayments();
    }
}

function nextPage() {
    if (currentPage < totalPages) {
        currentPage++;
        loadPayments();
    }
}

// Search and filter
const searchInput = document.getElementById('searchInput');
if (searchInput) {
    searchInput.addEventListener('input', (e) => {
        currentFilters.search = e.target.value;
        currentPage = 1;
        loadPayments();
    });
}

const statusFilter = document.getElementById('statusFilter');
if (statusFilter) {
    statusFilter.addEventListener('change', (e) => {
        currentFilters.status = e.target.value;
        currentPage = 1;
        loadPayments();
    });
}

function exportPayments() {
    showToast('Export feature coming soon!', 'info');
}

// Set current date
const dateElem = document.getElementById('heroDate');
if (dateElem) {
    const date = new Date();
    dateElem.innerHTML = date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
}

// Get admin name
const user = JSON.parse(localStorage.getItem('adminUser') || '{}');
const adminNameElem = document.getElementById('adminName');
if (adminNameElem) {
    if (user.fullname) adminNameElem.innerHTML = user.fullname.split(' ')[0];
    else if (user.username) adminNameElem.innerHTML = user.username;
}

// Check authentication and load data
if (adminToken && adminToken !== 'null' && adminToken.length > 20) {
    loadStats();
    loadPayments();
} else {
    window.location.href = 'admin_login.html';
}

// Close modal when clicking outside
window.onclick = function(event) {
    const viewModal = document.getElementById('viewPaymentModal');
    if (event.target === viewModal) closeViewModal();
}
</script>

<style>
.text-center { text-align: center; }
.cell-name strong { display: block; }
.cell-name small { font-size: 11px; color: #6b7280; }
.cell-price.pos { color: #10b981; font-weight: 600; }
.cell-date { font-size: 12px; color: #6b7280; }
.payment-info p { margin: 8px 0; padding: 8px 0; border-bottom: 1px solid #eee; }
.payment-info p:last-child { border-bottom: none; }
.modal-content::-webkit-scrollbar { width: 8px; }
.modal-content::-webkit-scrollbar-track { background: #f1f1f1; border-radius: 4px; }
.modal-content::-webkit-scrollbar-thumb { background: #c1c1c1; border-radius: 4px; }
</style>
</body>
</html>