<?php include('head.php'); ?>
<body data-active="dashboard" data-crumbs="Workspace | Dashboard">
<div class="shell">
<?php include('sidebar.php'); ?>
<div class="main">
<?php include('topbar.php'); ?>
<main class="content">
<section class="hero">
<div class="hero-text">
<span class="eyebrow" id="heroDate">Thursday · April 23 · 2026</span>
<h1 class="hero-title">Welcome back, <span class="accent" id="adminName">Admin</span></h1>
<p class="hero-sub">Monitor your WiFi billing system: </p>
</div>
<div class="hero-actions">
<button class="btn btn--ghost" onclick="exportData()"><svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/></svg> Export</button>
<button class="btn btn--primary" onclick="refreshData()"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg> Refresh</button>
</div>
</section>

<!-- KPI Grid with Real Data -->
<section class="kpi-grid" aria-label="Key metrics">
<article class="kpi-card c-success">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon success"><svg viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg></div>
<div class="kpi-label">Total Customers</div>
</div>
<span class="kpi-pill up" id="customerTrend">+0%</span>
</div>
<div class="kpi-value" id="totalCustomers">0</div>
<div class="kpi-compare" id="customerCompare">Loading...</div>
</article>

<article class="kpi-card c-danger">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon danger"><svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h8M8 9h2"/></svg></div>
<div class="kpi-label">Active Sessions</div>
</div>
<span class="kpi-pill info" id="sessionTrend">online</span>
</div>
<div class="kpi-value" id="activeSessions">0</div>
<div class="kpi-compare" id="sessionCompare">Currently active</div>
</article>

<article class="kpi-card c-purple">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon purple"><svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8"/></svg></div>
<div class="kpi-label">Active Routers</div>
</div>
<span class="kpi-pill flat" id="routerTrend">online</span>
</div>
<div class="kpi-value" id="activeRouters">0</div>
<div class="kpi-compare" id="routerCompare">Out of total</div>
</article>

<article class="kpi-card c-primary">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon primary"><svg viewBox="0 0 24 24"><path d="M12 20V10M18 20V4M6 20v-4"/></svg></div>
<div class="kpi-label">Today's Revenue</div>
</div>
<span class="kpi-pill up" id="revenueTrend">+0%</span>
</div>
<div class="kpi-value" id="todayRevenue"> 0</div>
<div class="kpi-compare" id="revenueCompare">From payments today</div>
</article>
</section>

<div class="grid">
<!-- Active Sessions Section -->
<section class="col-6 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Network</span>
<h2 class="card-title">Active Sessions</h2>
</div>
<a class="card-action" href="#">Manage <svg viewBox="0 0 24 24"><path d="M5 12h14M13 5l7 7-7 7"/></svg></a>
</div>
<div class="table-responsive">
<table class="table">
<thead>
<tr>
<th>User</th>
<th>Router</th>
<th>Duration</th>
<th>Data Used</th>
</tr>
</thead>
<tbody id="activeSessionsTable">
<tr><td colspan="4" class="text-center">Loading sessions...</td></tr>
</tbody>
</table>
</div>
</section>

<!-- Recent Customers -->
<section class="col-6 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Customers</span>
<h2 class="card-title">Recent Registrations</h2>
</div>
<a class="card-action" href="#">View all <svg viewBox="0 0 24 24"><path d="M5 12h14M13 5l7 7-7 7"/></svg></a>
</div>
<div class="table-responsive">
<table class="table">
<thead>
<tr>
<th>Customer</th>
<th>Package</th>
<th>Status</th>
<th>Date</th>
</tr>
</thead>
<tbody id="recentCustomers">
<tr><td colspan="4" class="text-center">Loading customers...</td></tr>
</tbody>
</table>
</div>
</section>

<!-- Recent Payments -->
<section class="col-6 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Payments</span>
<h2 class="card-title">Recent Transactions</h2>
</div>
<a class="card-action" href="#">View all <svg viewBox="0 0 24 24"><path d="M5 12h14M13 5l7 7-7 7"/></svg></a>
</div>
<div class="table-responsive">
<table class="table">
<thead>
<tr>
<th>Customer</th>
<th>Amount</th>
<th>Status</th>
<th>Date</th>
</tr>
</thead>
<tbody id="recentPayments">
<tr><td colspan="4" class="text-center">Loading payments...</td></tr>
</tbody>
</table>
</div>
</section>

<!-- Package Distribution -->
<section class="col-6 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Packages</span>
<h2 class="card-title">Popular Packages</h2>
</div>
<a class="card-action" href="#">Manage <svg viewBox="0 0 24 24"><path d="M5 12h14M13 5l7 7-7 7"/></svg></a>
</div>
<div id="packageStats" class="package-stats">
Loading package statistics...
</div>
</section>
</div>
<br>

<!-- System Status Card -->
<section class="col-12 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">System</span>
<h2 class="card-title">System Status</h2>
</div>
</div>
<div class="sv-regions" id="systemStatus">
<div class="sv-region">
<div class="sv-region-head"><span class="marker" style="background:var(--success)"></span> Database</div>
<div class="sv-region-value" id="dbStatus">Checking...</div>
<div class="sv-region-bar"><div class="sv-region-bar-fill" id="dbBar" style="width:0%;background:var(--success)"></div></div>
</div>
<div class="sv-region">
<div class="sv-region-head"><span class="marker" style="background:var(--info)"></span> Redis Cache</div>
<div class="sv-region-value" id="redisStatus">Checking...</div>
<div class="sv-region-bar"><div class="sv-region-bar-fill" id="redisBar" style="width:0%;background:var(--info)"></div></div>
</div>
<div class="sv-region">
<div class="sv-region-head"><span class="marker" style="background:var(--purple)"></span> FreeRADIUS</div>
<div class="sv-region-value" id="radiusStatus">Checking...</div>
<div class="sv-region-bar"><div class="sv-region-bar-fill" id="radiusBar" style="width:0%;background:var(--purple)"></div></div>
</div>
</div>
</section>

</main>
<?php include('footer.php'); ?>
</div>
</div>

<script>
// ============================================
// COMPLETE FIXED DASHBOARD SCRIPT
// MATCHES YOUR API DATA STRUCTURE
// ============================================

// API Configuration
// const API_BASE_URL = 'https://shabanetech.top/wifi-api';
// let adminToken = localStorage.getItem('adminToken');

// Helper function for API calls
async function apiFetch(endpoint) {
    if (!adminToken) {
        console.error('No token available');
        return null;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            headers: { 
                'Authorization': `Bearer ${adminToken}`,
                'Content-Type': 'application/json'
            }
        });
        
        if (response.status === 401) {
            localStorage.removeItem('adminToken');
            localStorage.removeItem('adminUser');
            window.location.href = 'signin.html';
            return null;
        }
        
        return await response.json();
    } catch (error) {
        console.error('API Error:', error);
        return null;
    }
}

// Format helpers
function formatCurrency(amount) {
    return ' ' + parseFloat(amount || 0).toLocaleString();
}

function formatDuration(seconds) {
    if (!seconds || seconds === 0) return '0 min';
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
}

function formatMBtoGB(mb) {
    if (!mb || mb === 0) return '0 GB';
    const gb = mb / 1024;
    if (gb >= 1) return gb.toFixed(2) + ' GB';
    return mb.toFixed(0) + ' MB';
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function getRandomColor() {
    const colors = ['#4f46e5', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4'];
    return colors[Math.floor(Math.random() * colors.length)];
}

// Update KPI cards - FIXED to match API structure
function updateKPIs(data) {
    // Customers - using data.customers object
    const totalCustomers = document.getElementById('totalCustomers');
    const customerCompare = document.getElementById('customerCompare');
    if (totalCustomers && data.customers) {
        totalCustomers.innerHTML = (data.customers.total || 0).toLocaleString();
    }
    if (customerCompare && data.customers) {
        customerCompare.innerHTML = `Active: ${data.customers.active || 0}`;
    }
    
    // Routers - using data.routers object
    const activeRouters = document.getElementById('activeRouters');
    const routerCompare = document.getElementById('routerCompare');
    if (activeRouters && data.routers) {
        activeRouters.innerHTML = data.routers.active || '0';
    }
    if (routerCompare && data.routers) {
        routerCompare.innerHTML = `Total: ${data.routers.total || 0}`;
    }
    
    // Sessions - using data.active_sessions
    const activeSessions = document.getElementById('activeSessions');
    const sessionCompare = document.getElementById('sessionCompare');
    if (activeSessions) {
        activeSessions.innerHTML = data.active_sessions || '0';
    }
    if (sessionCompare && data.payments) {
        sessionCompare.innerHTML = `Today: ${data.payments?.today?.count || 0} new`;
    }
    
    // Revenue - using data.payments object
    const todayRevenue = document.getElementById('todayRevenue');
    const revenueCompare = document.getElementById('revenueCompare');
    if (todayRevenue && data.payments) {
        todayRevenue.innerHTML = formatCurrency(data.payments.today?.total || 0);
    }
    if (revenueCompare && data.payments) {
        revenueCompare.innerHTML = `Month: ${formatCurrency(data.payments.month?.total || 0)}`;
    }
    
    // Update trend pills
    const summaryElem = document.getElementById('statsSummary');
    if (summaryElem) {
        summaryElem.innerHTML = `${data.active_sessions || 0} active users, ${data.routers?.active || 0} routers online, ${formatCurrency(data.payments?.today?.total || 0)} today`;
    }
}

// Update active sessions table
function updateActiveSessions(sessions) {
    const tbody = document.getElementById('activeSessionsTable');
    if (!tbody) return;
    
    if (!sessions || sessions.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="text-center">No active sessions</td></tr>';
        return;
    }
    
    tbody.innerHTML = sessions.slice(0, 5).map(session => `
        <tr>
            <td class="cell-name"><strong>${escapeHtml(session.fullname || session.username)}</strong></td>
            <td>${escapeHtml(session.nasipaddress || session.router_name || 'N/A')}</td>
            <td>${formatDuration(session.session_seconds)}</td>
            <td>${formatMBtoGB(session.total_mb)}</td>
        </tr>
    `).join('');
}

// Update recent customers table
function updateRecentCustomers(customers) {
    const tbody = document.getElementById('recentCustomers');
    if (!tbody) return;
    
    if (!customers || customers.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="text-center">No customers found</td></tr>';
        return;
    }
    
    tbody.innerHTML = customers.slice(0, 5).map(customer => `
        <tr>
            <td class="cell-name">
                <strong>${escapeHtml(customer.fullname)}</strong><br>
                <small>${escapeHtml(customer.username)}</small>
            </td>
            <td>${escapeHtml(customer.package_name || 'N/A')}</td>
            <td><span class="tag ${customer.status === 'active' ? 't-new' : 't-unavail'}">${customer.status}</span></td>
            <td class="cell-date">${new Date(customer.created_at).toLocaleDateString()}</td>
        </tr>
    `).join('');
}

// Update recent payments table
function updateRecentPayments(payments) {
    const tbody = document.getElementById('recentPayments');
    if (!tbody) return;
    
    if (!payments || payments.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="text-center">No payments found</td></tr>';
        return;
    }
    
    tbody.innerHTML = payments.slice(0, 5).map(payment => `
        <tr>
            <td class="cell-name"><strong>${escapeHtml(payment.fullname || payment.customer_name)}</strong></td>
            <td class="cell-price pos">${formatCurrency(payment.amount)}</td>
            <td><span class="tag ${payment.status === 'completed' ? 't-new' : 't-unavail'}">${payment.status || 'pending'}</span></td>
            <td class="cell-date">${new Date(payment.created_at).toLocaleDateString()}</td>
        </tr>
    `).join('');
}

// Update package statistics
function updatePackageStats(packages) {
    const container = document.getElementById('packageStats');
    if (!container) return;
    
    if (!packages || packages.length === 0) {
        container.innerHTML = '<div class="text-center">No packages found</div>';
        return;
    }
    
    container.innerHTML = `
        <div class="sv-regions">
            ${packages.slice(0, 4).map((pkg, idx) => `
                <div class="sv-region">
                    <div class="sv-region-head">
                        <span class="marker" style="background:${getRandomColor()}"></span>
                        ${escapeHtml(pkg.package_name)}
                    </div>
                    <div class="sv-region-value">${formatCurrency(pkg.price)}<span class="pct">${pkg.validity_days}d</span></div>
                    <div class="sv-region-bar">
                        <div class="sv-region-bar-fill" style="width:${Math.min(100, (pkg.price / 10000) * 100)}%;background:${getRandomColor()}"></div>
                    </div>
                </div>
            `).join('')}
        </div>
        <div class="sv-divider"></div>
        <div class="sv-radials">
            <div class="sv-radial">
                <div class="sv-radial-text">
                    <div class="sv-radial-name">Total Packages</div>
                    <div class="sv-radial-caption">${packages.length} available</div>
                </div>
            </div>
            <div class="sv-radial">
                <div class="sv-radial-text">
                    <div class="sv-radial-name">Price Range</div>
                    <div class="sv-radial-caption">${formatCurrency(Math.min(...packages.map(p => p.price)))} - ${formatCurrency(Math.max(...packages.map(p => p.price)))}</div>
                </div>
            </div>
        </div>
    `;
}

// Update system status
function updateSystemStatus(services) {
    // Database
    const dbConnected = services.database?.connected;
    const dbStatusElem = document.getElementById('dbStatus');
    const dbBarElem = document.getElementById('dbBar');
    if (dbStatusElem) dbStatusElem.innerHTML = dbConnected ? 'Connected' : 'Disconnected';
    if (dbBarElem) {
        dbBarElem.style.width = dbConnected ? '100%' : '0%';
        dbBarElem.style.background = dbConnected ? 'var(--success)' : 'var(--danger)';
    }
    
    // Redis
    const redisConnected = services.redis === 'connected';
    const redisStatusElem = document.getElementById('redisStatus');
    const redisBarElem = document.getElementById('redisBar');
    if (redisStatusElem) redisStatusElem.innerHTML = redisConnected ? 'Connected' : 'Disconnected';
    if (redisBarElem) {
        redisBarElem.style.width = redisConnected ? '100%' : '0%';
        redisBarElem.style.background = redisConnected ? 'var(--success)' : 'var(--danger)';
    }
    
    // FreeRADIUS
    const radiusEnabled = services.radius === 'enabled';
    const radiusStatusElem = document.getElementById('radiusStatus');
    const radiusBarElem = document.getElementById('radiusBar');
    if (radiusStatusElem) radiusStatusElem.innerHTML = radiusEnabled ? 'Enabled' : 'Disabled';
    if (radiusBarElem) {
        radiusBarElem.style.width = radiusEnabled ? '100%' : '0%';
        radiusBarElem.style.background = radiusEnabled ? 'var(--success)' : 'var(--danger)';
    }
}

// MAIN FUNCTION: Load all dashboard data
async function loadDashboardData() {
    try {
        // 1. Get health status
        const health = await apiFetch('/health');
        if (health && health.services) {
            updateSystemStatus(health.services);
        }
        
        // 2. Get dashboard stats - THIS IS THE MAIN DATA SOURCE
        const stats = await apiFetch('/api/admin/dashboard/stats');
        if (stats && stats.success) {
            // Update KPIs with the correct data structure
            updateKPIs(stats.data);
            
            // Update recent customers from stats
            if (stats.data.recent_customers && stats.data.recent_customers.length > 0) {
                updateRecentCustomers(stats.data.recent_customers);
            }
            
            // Update recent payments from stats
            if (stats.data.recent_payments && stats.data.recent_payments.length > 0) {
                updateRecentPayments(stats.data.recent_payments);
            } else {
                updateRecentPayments([]);
            }
        }
        
        // 3. Get active sessions separately
        const sessions = await apiFetch('/api/radius/sessions/active');
        if (sessions && sessions.success && sessions.data) {
            updateActiveSessions(sessions.data);
        } else {
            updateActiveSessions([]);
        }
        
        // 4. Get packages
        const packages = await apiFetch('/api/packages');
        if (packages && packages.success && packages.data) {
            updatePackageStats(packages.data);
        }
        
        // 5. Get admin name from localStorage
        const user = JSON.parse(localStorage.getItem('adminUser') || '{}');
        const adminNameElem = document.getElementById('adminName');
        if (adminNameElem) {
            if (user.fullname) {
                adminNameElem.innerHTML = user.fullname.split(' ')[0];
            } else if (user.username) {
                adminNameElem.innerHTML = user.username;
            }
        }
        
    } catch (error) {
        console.error('Error loading dashboard:', error);
    }
}

// Refresh function
function refreshData() {
    loadDashboardData();
}

// Export function
function exportData() {
    alert('Export feature coming soon');
}

// Set current date
const dateElem = document.getElementById('heroDate');
if (dateElem) {
    const date = new Date();
    dateElem.innerHTML = date.toLocaleDateString('en-US', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
}

// Check authentication and load data
if (adminToken && adminToken !== 'null' && adminToken.length > 20) {
    loadDashboardData();
    // Auto-refresh every 30 seconds
    setInterval(loadDashboardData, 30000);
} else {
    window.location.href = 'signin.html';
}
</script>

<style>
.text-center { text-align: center; }
.table-responsive { overflow-x: auto; }
.tag { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 500; }
.t-new { background: #dcfce7; color: #166534; }
.t-unavail { background: #fee2e2; color: #991b1b; }
.cell-name strong { display: block; }
.cell-name small { font-size: 11px; color: #6b7280; }
.cell-price.pos { color: #10b981; font-weight: 600; }
.cell-date { color: #6b7280; font-size: 12px; }
.package-stats { padding: 20px; }
</style>
</body>
</html>