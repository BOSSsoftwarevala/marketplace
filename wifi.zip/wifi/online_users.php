<?php include('head.php'); ?>
<body data-active="online_users" data-crumbs="Workspace | Online Users">
<div class="shell">
<?php include('sidebar.php'); ?>
<div class="main">
<?php include('topbar.php'); ?>
<main class="content">
<section class="hero">
<div class="hero-text">
<span class="eyebrow" id="heroDate">Online Users</span>
<h1 class="hero-title">Real-Time <span class="accent">Online Users</span></h1>
<p class="hero-sub" id="heroSubText">Monitor currently active network users and sessions</p>
</div>
<div class="hero-actions">
<button class="btn btn--ghost" onclick="exportData()"><svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/></svg> Export</button>
<button class="btn btn--primary" onclick="refreshData()"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg> Refresh</button>
</div>
</section>

<!-- Online Users Statistics KPI Grid -->
<section class="kpi-grid" aria-label="Online metrics">
<article class="kpi-card c-success">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon success"><svg viewBox="0 0 24 24"><path d="M20 12H4M12 4v16"/></svg></div>
<div class="kpi-label">Online Now</div>
</div>
</div>
<div class="kpi-value" id="onlineNow">0</div>
<div class="kpi-compare">Active sessions</div>
</article>

<article class="kpi-card c-danger">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon danger"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg></div>
<div class="kpi-label">Today's Peak</div>
</div>
</div>
<div class="kpi-value" id="todayPeak">0</div>
<div class="kpi-compare">Highest today</div>
</article>

<article class="kpi-card c-purple">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon purple"><svg viewBox="0 0 24 24"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg></div>
<div class="kpi-label">Total Today</div>
</div>
</div>
<div class="kpi-value" id="totalToday">0</div>
<div class="kpi-compare">Unique users today</div>
</article>

<article class="kpi-card c-primary">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon primary"><svg viewBox="0 0 24 24"><path d="M18 20V10M12 20V4M6 20v-4"/></svg></div>
<div class="kpi-label">Avg Duration</div>
</div>
</div>
<div class="kpi-value" id="avgDuration">0 min</div>
<div class="kpi-compare">Per session</div>
</article>
</section>

<!-- Filter Section -->
<section class="col-12 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Filters</span>
<h2 class="card-title">Search & Filter Online Users</h2>
</div>
</div>
<div class="filter-grid" style="display: flex; gap: 16px; padding: 16px; flex-wrap: wrap; align-items: center;">
<input type="text" id="searchInput" placeholder="Search by username or IP..." class="input" style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
<select id="routerFilter" class="input" style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
<option value="all">All Routers</option>
</select>
<button onclick="applyFilters()" class="btn btn--primary" style="padding: 8px 16px;">Apply Filters</button>
<button onclick="resetFilters()" class="btn btn--ghost" style="padding: 8px 16px;">Reset</button>
</div>
</section>
<br>
<!-- Online Users Table -->
<section class="col-12 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Live Sessions</span>
<h2 class="card-title">Currently Active Users</h2>
</div>
<a class="card-action" href="#" onclick="refreshData(); return false;">Auto-refresh (30s)</a>
</div>
<div class="table-responsive">
<table class="table table-bordered" style="border-collapse: collapse; width: 100%;">
<thead>
<th style="border: 1px solid #ddd; padding: 12px; text-align: left;">#</th>
<th style="border: 1px solid #ddd; padding: 12px; text-align: left;">User</th>
<th style="border: 1px solid #ddd; padding: 12px; text-align: left;">IP Address</th>
<th style="border: 1px solid #ddd; padding: 12px; text-align: left;">Router</th>
<th style="border: 1px solid #ddd; padding: 12px; text-align: left;">Connected Since</th>
<th style="border: 1px solid #ddd; padding: 12px; text-align: left;">Duration</th>
<th style="border: 1px solid #ddd; padding: 12px; text-align: left;">Data Used</th>
<th style="border: 1px solid #ddd; padding: 12px; text-align: left;">Actions</th>
</thead>
<tbody id="onlineUsersTable">
<tr><td colspan="8" style="border: 1px solid #ddd; padding: 12px; text-align: center;">Loading online users...<\/td><\/tr>
</tbody>
</div>
</section>

<!-- Disconnect User Modal -->
<div id="disconnectModal" class="modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
    <div class="modal-content" style="background: white; border-radius: 12px; max-width: 400px; width: 90%; max-height: 90vh; overflow-y: auto; padding: 24px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1);">
        <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h3 style="margin: 0;">Disconnect User</h3>
            <button onclick="closeDisconnectModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: #666;">&times;</button>
        </div>
        <p>Are you sure you want to disconnect this user?</p>
        <p><strong id="disconnectUserName"></strong></p>
        <div style="margin-top: 20px; display: flex; gap: 10px; justify-content: flex-end;">
            <button onclick="closeDisconnectModal()" class="btn btn--ghost" style="padding: 8px 16px;">Cancel</button>
            <button onclick="confirmDisconnect()" class="btn btn--danger" style="padding: 8px 16px; background: #ef4444; color: white; border: none; border-radius: 6px;">Disconnect</button>
        </div>
    </div>
</div>

<!-- Toast Container -->
<div id="toastContainer" style="position: fixed; top: 20px; right: 20px; z-index: 9999;"></div>

</main>
<?php include('footer.php'); ?>
</div>
</div>

<script>
// ============================================
// ONLINE USERS PAGE - REAL-TIME MONITORING
// ============================================

// const API_BASE_URL = 'https://shabanetech.top/wifi-api';
// let adminToken = localStorage.getItem('adminToken');
let onlineUsers = [];
let refreshInterval = null;
let currentFilters = { search: '', router: 'all' };
let pendingDisconnect = null;

function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `<div class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '✗' : 'ℹ'}</div><div class="toast-message">${message}</div><button class="toast-close" onclick="this.parentElement.remove()">×</button>`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}

// Add styles
const styles = document.createElement('style');
styles.textContent = `
    .toast { display: flex; align-items: center; gap: 12px; background: white; border-radius: 8px; padding: 12px 16px; margin-bottom: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); animation: slideIn 0.3s ease forwards; min-width: 280px; border-left: 4px solid; }
    .toast-success { border-left-color: #10b981; }
    .toast-error { border-left-color: #ef4444; }
    .toast-info { border-left-color: #3b82f6; }
    .toast-icon { width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 14px; }
    .toast-success .toast-icon { background: #10b98120; color: #10b981; }
    @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
    .text-center { text-align: center; }
    .table-responsive { overflow-x: auto; }
    .table-bordered { border-collapse: collapse; width: 100%; }
    .table-bordered th, .table-bordered td { border: 1px solid #ddd; padding: 10px 12px; text-align: left; }
    .table-bordered th { background: #f8f9fa; font-weight: 600; }
    .status-online { display: inline-block; width: 10px; height: 10px; border-radius: 50%; background: #10b981; margin-right: 8px; animation: pulse 2s infinite; }
    @keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.5; } 100% { opacity: 1; } }
    .cell-name strong { display: block; }
    .cell-name small { font-size: 11px; color: #6b7280; }
    .btn-danger { background: #ef4444; color: white; border: none; border-radius: 6px; padding: 6px 12px; cursor: pointer; font-size: 12px; }
    .btn-danger:hover { background: #dc2626; }
    .filter-grid { display: flex; gap: 16px; flex-wrap: wrap; align-items: center; }
`;
document.head.appendChild(styles);

async function apiFetch(endpoint, options = {}) {
    if (!adminToken) { window.location.href = 'admin_login.html'; return null; }
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            ...options,
            headers: { 'Authorization': `Bearer ${adminToken}`, 'Content-Type': 'application/json' }
        });
        if (response.status === 401) { localStorage.removeItem('adminToken'); window.location.href = 'admin_login.html'; return null; }
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || data.message);
        return data;
    } catch (error) { 
        console.error('API Error:', error);
        return null;
    }
}

function formatDuration(seconds) {
    if (!seconds) return '0 min';
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
}

function formatBytes(bytes) {
    if (!bytes || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Load routers for filter dropdown
async function loadRouters() {
    const response = await apiFetch('/api/routers');
    if (response && response.success && response.data) {
        const select = document.getElementById('routerFilter');
        if (select && response.data.length > 0) {
            select.innerHTML = '<option value="all">All Routers</option>' + 
                response.data.map(r => `<option value="${r.id}">${escapeHtml(r.router_name)} (${r.ip_address})</option>`).join('');
        }
    }
}

// Load online users statistics
async function loadStats() {
    const stats = await apiFetch('/api/admin/dashboard/stats');
    if (stats && stats.success && stats.data) {
        const data = stats.data;
        document.getElementById('onlineNow').innerHTML = data.active_sessions || 0;
        document.getElementById('todayPeak').innerHTML = data.peak_sessions || data.active_sessions || 0;
        document.getElementById('totalToday').innerHTML = data.unique_users_today || 0;
        document.getElementById('avgDuration').innerHTML = formatDuration(data.avg_session_minutes * 60 || 0);
    }
}

// Load online users
async function loadOnlineUsers() {
    const tbody = document.getElementById('onlineUsersTable');
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="8" style="border: 1px solid #ddd; padding: 12px; text-align: center;">Loading online users...<\/td><\/tr>';
    
    const response = await apiFetch('/api/radius/sessions/active');
    if (response && response.success && response.data) {
        onlineUsers = response.data;
        
        // Apply filters
        let filtered = [...onlineUsers];
        if (currentFilters.search) {
            const search = currentFilters.search.toLowerCase();
            filtered = filtered.filter(u => 
                (u.fullname && u.fullname.toLowerCase().includes(search)) ||
                (u.username && u.username.toLowerCase().includes(search)) ||
                (u.framedipaddress && u.framedipaddress.includes(search))
            );
        }
        if (currentFilters.router !== 'all') {
            filtered = filtered.filter(u => u.router_id == currentFilters.router);
        }
        
        if (filtered.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" style="border: 1px solid #ddd; padding: 12px; text-align: center;">No online users found<\/td><\/tr>';
        } else {
            tbody.innerHTML = filtered.map((user, idx) => `
                <tr>
                    <td style="border: 1px solid #ddd; padding: 10px 12px;">${idx + 1}<\/td>
                    <td style="border: 1px solid #ddd; padding: 10px 12px;">
                        <div class="cell-name">
                            <span class="status-online"></span>
                            <strong>${escapeHtml(user.fullname || user.username)}</strong><br>
                            <small>${escapeHtml(user.username)}</small>
                        </div>
                    <\/td>
                    <td style="border: 1px solid #ddd; padding: 10px 12px;">${escapeHtml(user.framedipaddress || '-')}<\/td>
                    <td style="border: 1px solid #ddd; padding: 10px 12px;">${escapeHtml(user.router_name || user.nasipaddress || '-')}<\/td>
                    <td style="border: 1px solid #ddd; padding: 10px 12px;">${new Date(user.acctstarttime).toLocaleString()}<\/td>
                    <td style="border: 1px solid #ddd; padding: 10px 12px;">${formatDuration(user.session_seconds)}<\/td>
                    <td style="border: 1px solid #ddd; padding: 10px 12px;">${formatBytes((user.total_mb || 0) * 1024 * 1024)}<\/td>
                    <td style="border: 1px solid #ddd; padding: 10px 12px;">
                        <button class="btn-danger" onclick="showDisconnectModal('${escapeHtml(user.username)}', ${user.radacctid || user.id})">Disconnect</button>
                    <\/td>
                </tr>
            `).join('');
        }
    } else {
        tbody.innerHTML = '<tr><td colspan="8" style="border: 1px solid #ddd; padding: 12px; text-align: center;">No online users found<\/td><\/tr>';
    }
}

// Show disconnect modal
function showDisconnectModal(username, sessionId) {
    pendingDisconnect = { username, sessionId };
    document.getElementById('disconnectUserName').innerHTML = username;
    document.getElementById('disconnectModal').style.display = 'flex';
}

function closeDisconnectModal() {
    document.getElementById('disconnectModal').style.display = 'none';
    pendingDisconnect = null;
}

async function confirmDisconnect() {
    if (!pendingDisconnect) return;
    
    const response = await apiFetch(`/api/radius/sessions/${pendingDisconnect.sessionId}`, {
        method: 'DELETE'
    });
    
    closeDisconnectModal();
    
    if (response && response.success) {
        showToast(`User ${pendingDisconnect.username} disconnected successfully!`, 'success');
        refreshData();
    } else {
        showToast(response?.error || 'Failed to disconnect user', 'error');
    }
    pendingDisconnect = null;
}

// Filter functions
function applyFilters() {
    currentFilters.search = document.getElementById('searchInput')?.value || '';
    currentFilters.router = document.getElementById('routerFilter')?.value || 'all';
    loadOnlineUsers();
    showToast('Filters applied', 'info');
}

function resetFilters() {
    const searchInput = document.getElementById('searchInput');
    const routerFilter = document.getElementById('routerFilter');
    if (searchInput) searchInput.value = '';
    if (routerFilter) routerFilter.value = 'all';
    currentFilters = { search: '', router: 'all' };
    loadOnlineUsers();
    showToast('Filters reset', 'info');
}

function refreshData() {
    loadStats();
    loadOnlineUsers();
    showToast('Data refreshed!', 'success');
}

function exportData() {
    if (onlineUsers.length === 0) {
        showToast('No data to export', 'error');
        return;
    }
    
    let csv = 'Username,Full Name,IP Address,Router,Connected Since,Duration,Data Used\n';
    onlineUsers.forEach(user => {
        csv += `"${user.username}","${user.fullname || ''}","${user.framedipaddress || ''}","${user.router_name || ''}","${user.acctstarttime}","${formatDuration(user.session_seconds)}","${formatBytes((user.total_mb || 0) * 1024 * 1024)}"\n`;
    });
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `online_users_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Export completed!', 'success');
}

// Start auto-refresh
function startAutoRefresh() {
    if (refreshInterval) clearInterval(refreshInterval);
    refreshInterval = setInterval(() => {
        loadOnlineUsers();
    }, 30000);
}

// Set current date
const dateElem = document.getElementById('heroDate');
if (dateElem) { 
    const date = new Date();
    dateElem.innerHTML = date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }); 
}

// Get admin name
const user = JSON.parse(localStorage.getItem('adminUser') || '{}');
const adminNameElem = document.getElementById('adminName');
if (adminNameElem) {
    if (user.fullname) adminNameElem.innerHTML = user.fullname.split(' ')[0];
    else if (user.username) adminNameElem.innerHTML = user.username;
}

// Initialize
if (adminToken && adminToken !== 'null' && adminToken.length > 20) {
    loadRouters();
    loadStats();
    loadOnlineUsers();
    startAutoRefresh();
} else {
    window.location.href = 'admin_login.html';
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('disconnectModal');
    if (event.target === modal) closeDisconnectModal();
}
</script>

<style>
.text-center { text-align: center; }
.table-responsive { overflow-x: auto; }
.status-online { display: inline-block; width: 10px; height: 10px; border-radius: 50%; background: #10b981; margin-right: 8px; animation: pulse 2s infinite; }
@keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.5; } 100% { opacity: 1; } }
.cell-name strong { display: block; }
.cell-name small { font-size: 11px; color: #6b7280; }
.btn-danger { background: #ef4444; color: white; border: none; border-radius: 6px; padding: 6px 12px; cursor: pointer; font-size: 12px; transition: background 0.2s; }
.btn-danger:hover { background: #dc2626; }
.filter-grid { display: flex; gap: 16px; flex-wrap: wrap; align-items: center; }
</style>
</body>
</html>