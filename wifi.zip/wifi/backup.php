<?php include('head.php'); ?>
<body data-active="backup" data-crumbs="Workspace | Backup">
<div class="shell">
<?php include('sidebar.php'); ?>
<div class="main">
<?php include('topbar.php'); ?>
<main class="content">
<section class="hero">
<div class="hero-text">
<span class="eyebrow" id="heroDate">Backup Management</span>
<h1 class="hero-title">Database <span class="accent">Backup</span></h1>
<p class="hero-sub" id="heroSubText">Manage database backups, restore points, and system snapshots</p>
</div>
<div class="hero-actions">
<button class="btn btn--primary" onclick="createBackup()"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg> Create Backup</button>
<button class="btn btn--ghost" onclick="refreshBackups()"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg> Refresh</button>
</div>
</section>

<!-- Backup Statistics KPI Grid -->
<section class="kpi-grid" aria-label="Backup metrics">
<article class="kpi-card c-success">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon success"><svg viewBox="0 0 24 24"><path d="M20 12H4M12 4v16"/></svg></div>
<div class="kpi-label">Total Backups</div>
</div>
</div>
<div class="kpi-value" id="totalBackups">0</div>
<div class="kpi-compare">Backup files</div>
</article>

<article class="kpi-card c-danger">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon danger"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg></div>
<div class="kpi-label">Total Size</div>
</div>
</div>
<div class="kpi-value" id="totalSize">0 MB</div>
<div class="kpi-compare">Storage used</div>
</article>

<article class="kpi-card c-purple">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon purple"><svg viewBox="0 0 24 24"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg></div>
<div class="kpi-label">Latest Backup</div>
</div>
</div>
<div class="kpi-value" id="latestBackup" style="font-size="12"">-</div>
<div class="kpi-compare">Last created</div>
</article>

<article class="kpi-card c-primary">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon primary"><svg viewBox="0 0 24 24"><path d="M18 20V10M12 20V4M6 20v-4"/></svg></div>
<div class="kpi-label">Database Size</div>
</div>
</div>
<div class="kpi-value" id="dbSize">0 MB</div>
<div class="kpi-compare">Current DB size</div>
</article>
</section>

<!-- Backups Table -->
<section class="col-12 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Backup List</span>
<h2 class="card-title">Available Backups</h2>
</div>
<div class="card-actions">
<input type="text" id="searchInput" placeholder="Search backups..." class="search-input">
</div>
</div>
<div class="table-responsive">
<table class="table">
<thead>
<th>#</th>
<th>Backup Name</th>
<th>Size</th>
<th>Type</th>
<th>Created</th>
<th>Age</th>
<th>Actions</th>
</thead>
<tbody id="backupsTableBody">
<tr><td colspan="7" class="text-center">Loading backups...<\/td><\/tr>
</tbody>
</div>
<div class="pagination">
<div>Showing <span id="showingStart">0</span> to <span id="showingEnd">0</span> of <span id="totalRecords">0</span> backups</div>
<div class="pagination-buttons">
<button class="btn btn--small" id="prevPage" onclick="prevPage()" disabled>Previous</button>
<button class="btn btn--small" id="nextPage" onclick="nextPage()" disabled>Next</button>
</div>
</div>
</section>

<!-- Create Backup Modal -->
<div id="createBackupModal" class="modal" style="display: none;">
    <div class="modal-content" style="max-width: 450px;">
        <div class="modal-header">
            <h3>Create New Backup</h3>
            <button class="modal-close" onclick="closeCreateModal()">&times;</button>
        </div>
        <form id="backupForm">
            <div class="field">
                <label>Backup Name (Optional)</label>
                <input type="text" id="backup_name" class="input" placeholder="Leave empty for auto-name">
            </div>
            <div class="field">
                <label>Backup Type</label>
                <select id="backup_type" class="input">
                    <option value="full">Full Backup</option>
                    <option value="schema">Schema Only</option>
                    <option value="data">Data Only</option>
                </select>
            </div>
            <div id="formErrors" class="form-errors" style="display: none;"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn--ghost" onclick="closeCreateModal()">Cancel</button>
                <button type="submit" class="btn btn--primary">Create Backup</button>
            </div>
        </form>
    </div>
</div>

<!-- Restore Confirmation Modal -->
<div id="restoreModal" class="modal" style="display: none;">
    <div class="modal-content" style="max-width: 450px;">
        <div class="modal-header">
            <h3>Confirm Restore</h3>
            <button class="modal-close" onclick="closeRestoreModal()">&times;</button>
        </div>
        <p>Are you sure you want to restore this backup?</p>
        <p><strong id="restoreBackupName"></strong></p>
        <p style="color: #ef4444; font-size: 13px;">Warning: This will overwrite current database data!</p>
        <div class="modal-footer">
            <button type="button" class="btn btn--ghost" onclick="closeRestoreModal()">Cancel</button>
            <button type="button" class="btn btn--danger" onclick="confirmRestore()">Restore Backup</button>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div id="deleteModal" class="modal" style="display: none;">
    <div class="modal-content" style="max-width: 400px;">
        <div class="modal-header">
            <h3>Confirm Delete</h3>
            <button class="modal-close" onclick="closeDeleteModal()">&times;</button>
        </div>
        <p>Are you sure you want to delete this backup?</p>
        <p><strong id="deleteBackupName"></strong></p>
        <div class="modal-footer">
            <button type="button" class="btn btn--ghost" onclick="closeDeleteModal()">Cancel</button>
            <button type="button" class="btn btn--danger" onclick="confirmDelete()">Delete Backup</button>
        </div>
    </div>
</div>

<!-- Toast Container -->
<div id="toastContainer"></div>

</main>
<?php include('footer.php'); ?>
</div>
</div>

<style>
.toast-container { position: fixed; top: 20px; right: 20px; z-index: 9999; }
.toast { display: flex; align-items: center; gap: 12px; background: white; border-radius: 8px; padding: 12px 16px; margin-bottom: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); animation: slideIn 0.3s ease forwards; min-width: 280px; border-left: 4px solid; }
.toast-success { border-left-color: #10b981; }.toast-error { border-left-color: #ef4444; }.toast-info { border-left-color: #3b82f6; }
.toast-icon { width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 14px; }
.toast-success .toast-icon { background: #10b98120; color: #10b981; }.toast-error .toast-icon { background: #ef444420; color: #ef4444; }
@keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
.text-center { text-align: center; }.table-responsive { overflow-x: auto; }
.table { width: 100%; border-collapse: collapse; }
.table th, .table td { padding: 12px 16px; text-align: left; border-bottom: 1px solid #e5e7eb; }
.table th { background: #f8f9fa; font-weight: 600; }
.btn-icon { background: none; border: none; cursor: pointer; font-size: 16px; padding: 4px 8px; border-radius: 4px; transition: background 0.2s; }
.btn-icon:hover { background: #f0f0f0; }
.btn-danger { background: #ef4444; color: white; border: none; border-radius: 6px; padding: 8px 16px; cursor: pointer; }
.btn-danger:hover { background: #dc2626; }
.search-input { margin-left: 8px; padding: 6px 12px; border-radius: 6px; border: 1px solid #ddd; width: 250px; }
.card-actions { display: flex; gap: 8px; align-items: center; }
.pagination { padding: 16px; display: flex; justify-content: space-between; align-items: center; }
.pagination-buttons { display: flex; gap: 8px; }
.btn--small { padding: 4px 12px; font-size: 12px; }
.modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center; }
.modal-content { background: white; border-radius: 12px; max-width: 500px; width: 90%; max-height: 90vh; overflow-y: auto; padding: 24px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); }
.modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
.modal-close { background: none; border: none; font-size: 24px; cursor: pointer; color: #666; }
.modal-footer { display: flex; gap: 12px; justify-content: flex-end; margin-top: 20px; }
.field { margin-bottom: 16px; }
.field label { display: block; margin-bottom: 6px; font-weight: 500; }
.field input, .field select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; }
.form-errors { color: #ef4444; font-size: 13px; margin: 16px 0; padding: 10px; background: #fee2e2; border-radius: 6px; }
.btn { padding: 10px 20px; border-radius: 6px; cursor: pointer; font-size: 14px; }
.btn--primary { background: #4f46e5; color: white; border: none; }
.btn--ghost { background: none; border: 1px solid #ddd; color: #333; }
</style>

<script>
// ============================================
// BACKUP MANAGEMENT PAGE - FIXED
// ============================================

// const API_BASE_URL = 'https://shabanetech.top/wifi-api';
// let adminToken = localStorage.getItem('adminToken');
let allBackups = [];
let currentPage = 1;
let itemsPerPage = 10;
let currentFilters = { search: '' };
let currentRestoreBackup = null;
let currentDeleteBackup = null;

function showToast(message, type = 'success') {
    let container = document.getElementById('toastContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toastContainer';
        document.body.appendChild(container);
    }
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `<div class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '✗' : 'ℹ'}</div><div class="toast-message">${message}</div><button class="toast-close" onclick="this.parentElement.remove()">×</button>`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}

async function apiFetch(endpoint, options = {}) {
    if (!adminToken) { 
        window.location.href = 'admin_login.html'; 
        return null; 
    }
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            ...options,
            headers: { 
                'Authorization': `Bearer ${adminToken}`, 
                'Content-Type': 'application/json' 
            }
        });
        if (response.status === 401) { 
            localStorage.removeItem('adminToken'); 
            window.location.href = 'admin_login.html'; 
            return null; 
        }
        const data = await response.json();
        if (!response.ok) { 
            throw new Error(data.error || data.message); 
        }
        return data;
    } catch (error) { 
        console.error('API Error:', error);
        showToast(error.message, 'error');
        return null;
    }
}

function formatFileSize(bytes) {
    if (!bytes || bytes === 0) return '0 B';
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return parseFloat((bytes / Math.pow(1024, i)).toFixed(2)) + ' ' + sizes[i];
}

function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function getTimeAgo(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    const now = new Date();
    const diff = Math.floor((now - date) / 1000);
    
    if (diff < 60) return `${diff} seconds ago`;
    if (diff < 3600) return `${Math.floor(diff / 60)} minutes ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)} hours ago`;
    return `${Math.floor(diff / 86400)} days ago`;
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Load backup statistics
async function loadStats() {
    const response = await apiFetch('/api/backups/stats');
    if (response && response.success && response.data) {
        const data = response.data;
        const totalBackupsElem = document.getElementById('totalBackups');
        const totalSizeElem = document.getElementById('totalSize');
        const latestBackupElem = document.getElementById('latestBackup');
        const dbSizeElem = document.getElementById('dbSize');
        
        if (totalBackupsElem) totalBackupsElem.innerHTML = data.total_backups || 0;
        if (totalSizeElem) totalSizeElem.innerHTML = formatFileSize(data.total_size);
        if (latestBackupElem) latestBackupElem.innerHTML = data.latest_backup || '-';
        if (dbSizeElem) dbSizeElem.innerHTML = formatFileSize(data.database_size);
    }
}

// Load backups list
async function loadBackups() {
    const tbody = document.getElementById('backupsTableBody');
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="7" class="text-center">Loading backups...<\/td><\/tr>';
    
    const response = await apiFetch('/api/backups');
    if (response && response.success && response.data) {
        allBackups = response.data;
        let filtered = [...allBackups];
        
        if (currentFilters.search) {
            const search = currentFilters.search.toLowerCase();
            filtered = filtered.filter(b => b.name.toLowerCase().includes(search));
        }
        
        const total = filtered.length;
        const totalPages = Math.ceil(total / itemsPerPage);
        const start = (currentPage - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        const paginated = filtered.slice(start, end);
        
        if (paginated.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center">No backups found<\/td><\/tr>';
        } else {
            tbody.innerHTML = paginated.map((backup, idx) => `
                <tr>
                    <td>${start + idx + 1}<\/td>
                    <td class="cell-name"><strong>${escapeHtml(backup.name)}<\/strong><\/td>
                    <td class="cell-price pos">${formatFileSize(backup.size)}<\/td>
                    <td><span class="tag ${backup.type === 'full' ? 't-active' : 't-info'}">${backup.type}<\/span><\/td>
                    <td class="cell-date">${formatDate(backup.created_at)}<\/td>
                    <td class="cell-date">${getTimeAgo(backup.created_at)}<\/td>
                    <td>
                        <button class="btn-icon" onclick="downloadBackup('${backup.name.replace(/'/g, "\\'")}')" title="Download">⬇️<\/button>
                        <button class="btn-icon" onclick="restoreBackup('${backup.name.replace(/'/g, "\\'")}')" title="Restore">🔄<\/button>
                        <button class="btn-icon" onclick="deleteBackup('${backup.name.replace(/'/g, "\\'")}')" title="Delete">🗑️<\/button>
                    <\/td>
                </tr>
            `).join('');
        }
        
        const showingStartElem = document.getElementById('showingStart');
        const showingEndElem = document.getElementById('showingEnd');
        const totalRecordsElem = document.getElementById('totalRecords');
        const prevPageElem = document.getElementById('prevPage');
        const nextPageElem = document.getElementById('nextPage');
        
        if (showingStartElem) showingStartElem.innerHTML = total === 0 ? 0 : start + 1;
        if (showingEndElem) showingEndElem.innerHTML = Math.min(end, total);
        if (totalRecordsElem) totalRecordsElem.innerHTML = total;
        if (prevPageElem) prevPageElem.disabled = currentPage <= 1;
        if (nextPageElem) nextPageElem.disabled = currentPage >= totalPages;
    }
}

// Create backup
const backupForm = document.getElementById('backupForm');
if (backupForm) {
    backupForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        let backupName = document.getElementById('backup_name').value.trim();
        const backupType = document.getElementById('backup_type').value;
        
        if (!backupName) {
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            backupName = `${backupType}_backup_${timestamp}`;
        }
        
        const errorDiv = document.getElementById('formErrors');
        if (errorDiv) errorDiv.style.display = 'none';
        
        const submitBtn = e.target.querySelector('button[type="submit"]');
        const originalText = submitBtn ? submitBtn.innerHTML : 'Create Backup';
        if (submitBtn) { submitBtn.innerHTML = 'Creating...'; submitBtn.disabled = true; }
        
        const response = await apiFetch('/api/backups/create', {
            method: 'POST',
            body: JSON.stringify({
                name: backupName,
                type: backupType
            })
        });
        
        if (submitBtn) { submitBtn.innerHTML = originalText; submitBtn.disabled = false; }
        
        if (response && response.success) {
            showToast(`Backup "${backupName}" created successfully!`, 'success');
            closeCreateModal();
            loadBackups();
            loadStats();
            if (backupForm) backupForm.reset();
        } else {
            showToast(response?.error || 'Failed to create backup', 'error');
        }
    });
}

// Download backup
async function downloadBackup(backupName) {
    try {
        window.open(`${API_BASE_URL}/api/backups/download/${encodeURIComponent(backupName)}?token=${adminToken}`, '_blank');
        showToast(`Downloading ${backupName}...`, 'info');
    } catch (error) {
        showToast('Failed to download backup', 'error');
    }
}

// Restore backup
function restoreBackup(backupName) {
    currentRestoreBackup = backupName;
    const restoreNameElem = document.getElementById('restoreBackupName');
    if (restoreNameElem) restoreNameElem.innerHTML = backupName;
    const modal = document.getElementById('restoreModal');
    if (modal) modal.style.display = 'flex';
}

async function confirmRestore() {
    if (!currentRestoreBackup) return;
    
    const response = await apiFetch('/api/backups/restore', {
        method: 'POST',
        body: JSON.stringify({ name: currentRestoreBackup })
    });
    
    closeRestoreModal();
    
    if (response && response.success) {
        showToast(`Backup "${currentRestoreBackup}" restored successfully!`, 'success');
        loadStats();
    } else {
        showToast(response?.error || 'Failed to restore backup', 'error');
    }
    currentRestoreBackup = null;
}

// Delete backup
function deleteBackup(backupName) {
    currentDeleteBackup = backupName;
    const deleteNameElem = document.getElementById('deleteBackupName');
    if (deleteNameElem) deleteNameElem.innerHTML = backupName;
    const modal = document.getElementById('deleteModal');
    if (modal) modal.style.display = 'flex';
}

async function confirmDelete() {
    if (!currentDeleteBackup) return;
    
    const response = await apiFetch(`/api/backups/delete/${encodeURIComponent(currentDeleteBackup)}`, { method: 'DELETE' });
    
    closeDeleteModal();
    
    if (response && response.success) {
        showToast(`Backup "${currentDeleteBackup}" deleted successfully!`, 'success');
        loadBackups();
        loadStats();
    } else {
        showToast(response?.error || 'Failed to delete backup', 'error');
    }
    currentDeleteBackup = null;
}

// Modal functions
function createBackup() {
    const modal = document.getElementById('createBackupModal');
    if (modal) modal.style.display = 'flex';
}

function closeCreateModal() {
    const modal = document.getElementById('createBackupModal');
    if (modal) modal.style.display = 'none';
}

function closeRestoreModal() {
    const modal = document.getElementById('restoreModal');
    if (modal) modal.style.display = 'none';
    currentRestoreBackup = null;
}

function closeDeleteModal() {
    const modal = document.getElementById('deleteModal');
    if (modal) modal.style.display = 'none';
    currentDeleteBackup = null;
}

function refreshBackups() {
    loadBackups();
    loadStats();
    showToast('Backups refreshed!', 'info');
}

// Pagination
function prevPage() { 
    if (currentPage > 1) { 
        currentPage--; 
        loadBackups(); 
    } 
}

function nextPage() { 
    currentPage++; 
    loadBackups(); 
}

// Search
const searchInput = document.getElementById('searchInput');
if (searchInput) {
    searchInput.addEventListener('input', (e) => {
        currentFilters.search = e.target.value;
        currentPage = 1;
        loadBackups();
    });
}

// Set current date
const dateElem = document.getElementById('heroDate');
if (dateElem) { 
    const date = new Date();
    dateElem.innerHTML = date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }); 
}

// Get admin name
const user = JSON.parse(localStorage.getItem('adminUser') || '{}');
const adminNameElem = document.getElementById('adminName');
if (adminNameElem) {
    if (user.fullname) adminNameElem.innerHTML = user.fullname.split(' ')[0];
    else if (user.username) adminNameElem.innerHTML = user.username;
}

// Initialize
if (adminToken && adminToken !== 'null' && adminToken.length > 20) {
    loadStats();
    loadBackups();
} else {
    window.location.href = 'admin_login.html';
}

// Close modals when clicking outside
window.onclick = function(event) {
    const createModal = document.getElementById('createBackupModal');
    const restoreModal = document.getElementById('restoreModal');
    const deleteModal = document.getElementById('deleteModal');
    if (event.target === createModal) closeCreateModal();
    if (event.target === restoreModal) closeRestoreModal();
    if (event.target === deleteModal) closeDeleteModal();
}
</script>
</body>
</html>