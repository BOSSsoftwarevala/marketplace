<?php include('head.php'); ?>
<body data-active="branches" data-crumbs="Workspace | Branches">
<div class="shell">
<?php include('sidebar.php'); ?>
<div class="main">
<?php include('topbar.php'); ?>
<main class="content">
<section class="hero">
<div class="hero-text">
<span class="eyebrow" id="heroDate">Branch Management</span>
<h1 class="hero-title">Manage <span class="accent">Branches</span></h1>
<p class="hero-sub" id="heroSubText">Create, edit, and manage organization branches</p>
</div>
<div class="hero-actions">
<button class="btn btn--ghost" onclick="exportBranches()"><svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/></svg> Export</button>
<button class="btn btn--primary" onclick="showAddBranchModal()"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg> Add Branch</button>
</div>
</section>

<!-- Branch Statistics KPI Grid -->
<section class="kpi-grid" aria-label="Branch metrics">
<article class="kpi-card c-success">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon success"><svg viewBox="0 0 24 24"><path d="M20 12H4M12 4v16"/></svg></div>
<div class="kpi-label">Total Branches</div>
</div>
</div>
<div class="kpi-value" id="totalBranches">0</div>
<div class="kpi-compare">All branches</div>
</article>

<article class="kpi-card c-danger">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon danger"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg></div>
<div class="kpi-label">Active Branches</div>
</div>
</div>
<div class="kpi-value" id="activeBranches">0</div>
<div class="kpi-compare">Currently active</div>
</article>

<article class="kpi-card c-purple">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon purple"><svg viewBox="0 0 24 24"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg></div>
<div class="kpi-label">Inactive</div>
</div>
</div>
<div class="kpi-value" id="inactiveBranches">0</div>
<div class="kpi-compare">Inactive branches</div>
</article>

<article class="kpi-card c-primary">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon primary"><svg viewBox="0 0 24 24"><path d="M18 20V10M12 20V4M6 20v-4"/></svg></div>
<div class="kpi-label">Routers</div>
</div>
</div>
<div class="kpi-value" id="totalRouters">0</div>
<div class="kpi-compare">Assigned routers</div>
</article>
</section>

<!-- Branches Table - No Grid Lines -->
<section class="col-12 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Branch List</span>
<h2 class="card-title">All Branches</h2>
</div>
<div class="card-actions">
<input type="text" id="searchInput" placeholder="Search branches..." class="search-input">
<select id="statusFilter" class="status-filter">
<option value="all">All Status</option>
<option value="active">Active</option>
<option value="inactive">Inactive</option>
</select>
</div>
</div>
<div class="table-responsive">
<table class="table">
<thead>
<th>ID</th>
<th>Branch Name</th>
<th>Location</th>
<th>Status</th>
<th>Routers</th>
<th>Created</th>
<th>Actions</th>
</thead>
<tbody id="branchesTableBody">
<tr><td colspan="7" class="text-center">Loading branches...<\/td><\/tr>
</tbody>
</div>
<div class="pagination">
<div>Showing <span id="showingStart">0</span> to <span id="showingEnd">0</span> of <span id="totalRecords">0</span> branches</div>
<div class="pagination-buttons">
<button class="btn btn--small" id="prevPage" onclick="prevPage()" disabled>Previous</button>
<button class="btn btn--small" id="nextPage" onclick="nextPage()" disabled>Next</button>
</div>
</div>
</section>

<!-- Add/Edit Branch Modal -->
<div id="branchModal" class="modal" style="display: none;">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalTitle">Add New Branch</h3>
            <button class="modal-close" onclick="closeBranchModal()">&times;</button>
        </div>
        <form id="branchForm">
            <input type="hidden" id="branch_id">
            <div class="field">
                <label>Branch Name *</label>
                <input type="text" id="branch_name" class="input" required>
            </div>
            <div class="field">
                <label>Location</label>
                <input type="text" id="location" class="input" placeholder="City, Address">
            </div>
            <div class="field">
                <label>Status</label>
                <select id="status" class="input">
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
            </div>
            <div id="formErrors" class="form-errors" style="display: none;"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn--ghost" onclick="closeBranchModal()">Cancel</button>
                <button type="submit" class="btn btn--primary">Save Branch</button>
            </div>
        </form>
    </div>
</div>

<!-- View Branch Modal -->
<div id="viewBranchModal" class="modal" style="display: none;">
    <div class="modal-content" style="max-width: 450px;">
        <div class="modal-header">
            <h3>Branch Details</h3>
            <button class="modal-close" onclick="closeViewModal()">&times;</button>
        </div>
        <div id="branchDetails" class="branch-details">
            <div class="detail-row">
                <span class="detail-label">ID:</span>
                <span class="detail-value" id="view_id">-</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Branch Name:</span>
                <span class="detail-value" id="view_name">-</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Location:</span>
                <span class="detail-value" id="view_location">-</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Status:</span>
                <span class="detail-value" id="view_status">-</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Routers:</span>
                <span class="detail-value" id="view_routers">0</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Created:</span>
                <span class="detail-value" id="view_created">-</span>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn--ghost" onclick="closeViewModal()">Close</button>
            <button type="button" class="btn btn--primary" onclick="editFromView()">Edit Branch</button>
        </div>
    </div>
</div>

<!-- Toast Container -->
<div id="toastContainer"></div>

</main>
<?php include('footer.php'); ?>
</div>
</div>

<style>
.toast-container { position: fixed; top: 20px; right: 20px; z-index: 9999; }
.toast { display: flex; align-items: center; gap: 12px; background: white; border-radius: 8px; padding: 12px 16px; margin-bottom: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); animation: slideIn 0.3s ease forwards; min-width: 280px; border-left: 4px solid; }
.toast-success { border-left-color: #10b981; }
.toast-error { border-left-color: #ef4444; }
.toast-info { border-left-color: #3b82f6; }
.toast-icon { width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 14px; }
.toast-success .toast-icon { background: #10b98120; color: #10b981; }
.toast-error .toast-icon { background: #ef444420; color: #ef4444; }
.toast-message { flex: 1; font-size: 14px; color: #333; }
.toast-close { background: none; border: none; font-size: 18px; cursor: pointer; color: #999; padding: 0; width: 20px; height: 20px; }
@keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
.text-center { text-align: center; }
.table-responsive { overflow-x: auto; }
.table { width: 100%; border-collapse: collapse; }
.table th, .table td { padding: 12px 16px; text-align: left; border-bottom: 1px solid #e5e7eb; }
.table th { background: #f8f9fa; font-weight: 600; }
.tag { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 500; }
.t-active { background: #dcfce7; color: #166534; }
.t-inactive { background: #fee2e2; color: #991b1b; }
.btn-icon { background: none; border: none; cursor: pointer; font-size: 16px; padding: 4px 8px; border-radius: 4px; transition: background 0.2s; }
.btn-icon:hover { background: #f0f0f0; }
.search-input, .status-filter { margin-left: 8px; padding: 6px 12px; border-radius: 6px; border: 1px solid #ddd; }
.card-actions { display: flex; gap: 8px; align-items: center; }
.pagination { padding: 16px; display: flex; justify-content: space-between; align-items: center; }
.pagination-buttons { display: flex; gap: 8px; }
.btn--small { padding: 4px 12px; font-size: 12px; }
.modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center; }
.modal-content { background: white; border-radius: 12px; max-width: 500px; width: 90%; max-height: 90vh; overflow-y: auto; padding: 24px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); }
.modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
.modal-close { background: none; border: none; font-size: 24px; cursor: pointer; color: #666; }
.modal-footer { display: flex; gap: 12px; justify-content: flex-end; margin-top: 20px; }
.field { margin-bottom: 16px; }
.field label { display: block; margin-bottom: 6px; font-weight: 500; }
.field input, .field select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; }
.form-errors { color: #ef4444; font-size: 13px; margin: 16px 0; padding: 10px; background: #fee2e2; border-radius: 6px; }
.btn { padding: 10px 20px; border-radius: 6px; cursor: pointer; font-size: 14px; }
.btn--primary { background: #4f46e5; color: white; border: none; }
.btn--ghost { background: none; border: 1px solid #ddd; color: #333; }
.detail-row { display: flex; padding: 10px 0; border-bottom: 1px solid #f0f0f0; }
.detail-label { width: 100px; font-weight: 600; color: #666; }
.detail-value { flex: 1; color: #333; }
</style>

<script>
// ============================================
// BRANCH MANAGEMENT PAGE - VIEW IN MODAL
// ============================================

// const API_BASE_URL = 'https://shabanetech.top/wifi-api';
// let adminToken = localStorage.getItem('adminToken');
let allBranches = [];
let currentPage = 1;
let itemsPerPage = 10;
let currentFilters = { search: '', status: 'all' };
let currentViewBranchId = null;

function showToast(message, type = 'success') {
    let container = document.getElementById('toastContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toastContainer';
        document.body.appendChild(container);
    }
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `<div class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '✗' : 'ℹ'}</div><div class="toast-message">${message}</div><button class="toast-close" onclick="this.parentElement.remove()">×</button>`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}

async function apiFetch(endpoint, options = {}) {
    if (!adminToken) { window.location.href = 'admin_login.html'; return null; }
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            ...options,
            headers: { 'Authorization': `Bearer ${adminToken}`, 'Content-Type': 'application/json' }
        });
        if (response.status === 401) { localStorage.removeItem('adminToken'); window.location.href = 'admin_login.html'; return null; }
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || data.message);
        return data;
    } catch (error) { 
        console.error('API Error:', error);
        return null;
    }
}

function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString();
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

async function loadStats() {
    const branches = await apiFetch('/api/branches');
    if (branches && branches.success && branches.data) {
        const total = branches.data.length;
        const active = branches.data.filter(b => b.status === 'active').length;
        const inactive = branches.data.filter(b => b.status === 'inactive').length;
        
        document.getElementById('totalBranches').innerHTML = total;
        document.getElementById('activeBranches').innerHTML = active;
        document.getElementById('inactiveBranches').innerHTML = inactive;
        
        const routers = await apiFetch('/api/routers');
        if (routers && routers.success && routers.data) {
            const routersWithBranch = routers.data.filter(r => r.branch_id).length;
            document.getElementById('totalRouters').innerHTML = routersWithBranch;
        }
    }
}

async function loadBranches() {
    const tbody = document.getElementById('branchesTableBody');
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="7" class="text-center">Loading branches...<\/td><\/tr>';
    
    const response = await apiFetch('/api/branches');
    if (response && response.success && response.data) {
        allBranches = response.data;
        
        let filtered = [...allBranches];
        if (currentFilters.search) {
            const search = currentFilters.search.toLowerCase();
            filtered = filtered.filter(b => 
                b.branch_name.toLowerCase().includes(search) ||
                (b.location && b.location.toLowerCase().includes(search))
            );
        }
        if (currentFilters.status !== 'all') {
            filtered = filtered.filter(b => b.status === currentFilters.status);
        }
        
        const total = filtered.length;
        const totalPages = Math.ceil(total / itemsPerPage);
        const start = (currentPage - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        const paginated = filtered.slice(start, end);
        
        if (paginated.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center">No branches found<\/td><\/tr>';
        } else {
            // Get router counts
            const routers = await apiFetch('/api/routers');
            const routerCounts = {};
            if (routers && routers.success && routers.data) {
                routers.data.forEach(r => {
                    if (r.branch_id) routerCounts[r.branch_id] = (routerCounts[r.branch_id] || 0) + 1;
                });
            }
            
            tbody.innerHTML = paginated.map(branch => `
                <tr>
                    <td>${branch.id}</td>
                    <td><strong>${escapeHtml(branch.branch_name)}</strong></td>
                    <td>${escapeHtml(branch.location || '-')}</td>
                    <td><span class="tag ${branch.status === 'active' ? 't-active' : 't-inactive'}">${branch.status}</span></td>
                    <td>${routerCounts[branch.id] || 0}</td>
                    <td>${formatDate(branch.created_at)}<\/td>
                    <td>
                        <button class="btn-icon" onclick="viewBranch(${branch.id})" title="View">👁️<\/button>
                        <button class="btn-icon" onclick="editBranch(${branch.id})" title="Edit">✏️<\/button>
                        <button class="btn-icon" onclick="deleteBranch(${branch.id})" title="Delete">🗑️<\/button>
                    <\/td>
                </tr>
            `).join('');
        }
        
        document.getElementById('showingStart').innerHTML = total === 0 ? 0 : start + 1;
        document.getElementById('showingEnd').innerHTML = Math.min(end, total);
        document.getElementById('totalRecords').innerHTML = total;
        document.getElementById('prevPage').disabled = currentPage <= 1;
        document.getElementById('nextPage').disabled = currentPage >= totalPages;
    }
}

// View branch in modal
async function viewBranch(id) {
    const response = await apiFetch(`/api/branches/${id}`);
    if (response && response.success && response.data) {
        currentViewBranchId = id;
        const branch = response.data;
        
        // Get router count
        const routers = await apiFetch('/api/routers');
        let routerCount = 0;
        if (routers && routers.success && routers.data) {
            routerCount = routers.data.filter(r => r.branch_id == id).length;
        }
        
        document.getElementById('view_id').innerHTML = branch.id;
        document.getElementById('view_name').innerHTML = escapeHtml(branch.branch_name);
        document.getElementById('view_location').innerHTML = escapeHtml(branch.location || '-');
        document.getElementById('view_status').innerHTML = `<span class="tag ${branch.status === 'active' ? 't-active' : 't-inactive'}">${branch.status}</span>`;
        document.getElementById('view_routers').innerHTML = routerCount;
        document.getElementById('view_created').innerHTML = formatDate(branch.created_at);
        
        document.getElementById('viewBranchModal').style.display = 'flex';
    } else {
        showToast('Could not load branch details', 'error');
    }
}

function editFromView() {
    if (currentViewBranchId) {
        closeViewModal();
        editBranch(currentViewBranchId);
    }
}

// Add/Edit branch form
const branchForm = document.getElementById('branchForm');
if (branchForm) {
    branchForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const branchId = document.getElementById('branch_id').value;
        const branchData = {
            branch_name: document.getElementById('branch_name').value.trim(),
            location: document.getElementById('location').value.trim() || null,
            status: document.getElementById('status').value
        };
        
        const errorDiv = document.getElementById('formErrors');
        if (!branchData.branch_name) {
            if (errorDiv) {
                errorDiv.textContent = 'Branch name is required';
                errorDiv.style.display = 'block';
                setTimeout(() => errorDiv.style.display = 'none', 3000);
            }
            return;
        }
        if (errorDiv) errorDiv.style.display = 'none';
        
        const submitBtn = e.target.querySelector('button[type="submit"]');
        const originalText = submitBtn ? submitBtn.innerHTML : 'Save Branch';
        if (submitBtn) { submitBtn.innerHTML = 'Saving...'; submitBtn.disabled = true; }
        
        let response;
        if (branchId) {
            response = await apiFetch(`/api/branches/${branchId}`, {
                method: 'PUT',
                body: JSON.stringify(branchData)
            });
        } else {
            response = await apiFetch('/api/branches', {
                method: 'POST',
                body: JSON.stringify(branchData)
            });
        }
        
        if (submitBtn) { submitBtn.innerHTML = originalText; submitBtn.disabled = false; }
        
        if (response && response.success) {
            showToast(`Branch ${branchData.branch_name} ${branchId ? 'updated' : 'created'} successfully!`, 'success');
            closeBranchModal();
            loadBranches();
            loadStats();
            if (branchForm) branchForm.reset();
            const branchIdField = document.getElementById('branch_id');
            if (branchIdField) branchIdField.value = '';
        } else {
            showToast(response?.error || 'Failed to save branch', 'error');
        }
    });
}

// Edit branch
window.editBranch = async function(id) {
    const response = await apiFetch(`/api/branches/${id}`);
    if (response && response.success && response.data) {
        const branch = response.data;
        document.getElementById('modalTitle').innerText = 'Edit Branch';
        document.getElementById('branch_id').value = branch.id;
        document.getElementById('branch_name').value = branch.branch_name;
        document.getElementById('location').value = branch.location || '';
        document.getElementById('status').value = branch.status || 'active';
        document.getElementById('branchModal').style.display = 'flex';
    }
}

// Delete branch
window.deleteBranch = async function(id) {
    if (confirm('Are you sure you want to delete this branch?')) {
        const response = await apiFetch(`/api/branches/${id}`, { method: 'DELETE' });
        if (response && response.success) {
            showToast('Branch deleted successfully!', 'success');
            loadBranches();
            loadStats();
        } else {
            showToast(response?.error || 'Failed to delete branch', 'error');
        }
    }
}

function showAddBranchModal() {
    document.getElementById('modalTitle').innerText = 'Add New Branch';
    const form = document.getElementById('branchForm');
    if (form) form.reset();
    const branchIdField = document.getElementById('branch_id');
    if (branchIdField) branchIdField.value = '';
    const statusField = document.getElementById('status');
    if (statusField) statusField.value = 'active';
    document.getElementById('branchModal').style.display = 'flex';
}

function closeBranchModal() {
    document.getElementById('branchModal').style.display = 'none';
}

function closeViewModal() {
    document.getElementById('viewBranchModal').style.display = 'none';
    currentViewBranchId = null;
}

function prevPage() { if (currentPage > 1) { currentPage--; loadBranches(); } }
function nextPage() { currentPage++; loadBranches(); }

const searchInput = document.getElementById('searchInput');
if (searchInput) {
    searchInput.addEventListener('input', (e) => {
        currentFilters.search = e.target.value;
        currentPage = 1;
        loadBranches();
    });
}

const statusFilter = document.getElementById('statusFilter');
if (statusFilter) {
    statusFilter.addEventListener('change', (e) => {
        currentFilters.status = e.target.value;
        currentPage = 1;
        loadBranches();
    });
}

function exportBranches() {
    if (allBranches.length === 0) { showToast('No data to export', 'error'); return; }
    let csv = 'ID,Branch Name,Location,Status,Created\n';
    allBranches.forEach(b => { csv += `"${b.id}","${b.branch_name}","${b.location || ''}","${b.status}","${b.created_at}"\n`; });
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `branches_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Export completed!', 'success');
}

// Set current date
const dateElem = document.getElementById('heroDate');
if (dateElem) { 
    const date = new Date();
    dateElem.innerHTML = date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }); 
}

// Get admin name
const user = JSON.parse(localStorage.getItem('adminUser') || '{}');
const adminNameElem = document.getElementById('adminName');
if (adminNameElem) {
    if (user.fullname) adminNameElem.innerHTML = user.fullname.split(' ')[0];
    else if (user.username) adminNameElem.innerHTML = user.username;
}

// Initialize
if (adminToken && adminToken !== 'null' && adminToken.length > 20) {
    loadStats();
    loadBranches();
} else {
    window.location.href = 'admin_login.html';
}

// Close modals when clicking outside
window.onclick = function(event) {
    const branchModal = document.getElementById('branchModal');
    const viewModal = document.getElementById('viewBranchModal');
    if (event.target === branchModal) closeBranchModal();
    if (event.target === viewModal) closeViewModal();
}
</script>
</body>
</html>