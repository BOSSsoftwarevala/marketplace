CREATE DATABASE wifi_billing;
USE wifi_billing;

-- CUSTOMERS
CREATE TABLE customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fullname VARCHAR(100) NOT NULL,
    phone VARCHAR(20) UNIQUE,
    email VARCHAR(100),
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    package_id INT,
    status ENUM('active','inactive','suspended') DEFAULT 'inactive',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- PACKAGES
CREATE TABLE packages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    package_name VARCHAR(100) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    validity_days INT DEFAULT 1,
    data_limit_mb BIGINT DEFAULT 0,
    upload_speed VARCHAR(20),
    download_speed VARCHAR(20),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- PAYMENTS
CREATE TABLE payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    mpesa_receipt VARCHAR(50) UNIQUE,
    phone VARCHAR(20),
    amount DECIMAL(10,2),
    package_id INT,
    transaction_date DATETIME,
    status ENUM('pending','completed','failed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- VOUCHERS
CREATE TABLE vouchers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    voucher_code VARCHAR(50) UNIQUE NOT NULL,
    package_id INT NOT NULL,
    amount DECIMAL(10,2),
    status ENUM('unused','used','expired') DEFAULT 'unused',
    used_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expiry_date DATETIME
);

-- RESELLERS
CREATE TABLE resellers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fullname VARCHAR(100),
    phone VARCHAR(20),
    email VARCHAR(100),
    username VARCHAR(50) UNIQUE,
    password VARCHAR(255),
    commission_percent DECIMAL(5,2) DEFAULT 10.00,
    balance DECIMAL(10,2) DEFAULT 0.00,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- FREE RADIUS TABLES

CREATE TABLE radcheck (
    id INT(11) NOT NULL AUTO_INCREMENT,
    username VARCHAR(64) NOT NULL DEFAULT '',
    attribute VARCHAR(64) NOT NULL DEFAULT '',
    op CHAR(2) NOT NULL DEFAULT ':=',
    value VARCHAR(253) NOT NULL DEFAULT '',
    PRIMARY KEY (id),
    KEY username (username)
);

CREATE TABLE radreply (
    id INT(11) NOT NULL AUTO_INCREMENT,
    username VARCHAR(64) NOT NULL DEFAULT '',
    attribute VARCHAR(64) NOT NULL DEFAULT '',
    op CHAR(2) NOT NULL DEFAULT '=',
    value VARCHAR(253) NOT NULL DEFAULT '',
    PRIMARY KEY (id),
    KEY username (username)
);

CREATE TABLE radacct (
    radacctid BIGINT(21) NOT NULL AUTO_INCREMENT,
    acctsessionid VARCHAR(64) NOT NULL,
    acctuniqueid VARCHAR(32) NOT NULL,
    username VARCHAR(64) NOT NULL,
    groupname VARCHAR(64) NOT NULL DEFAULT '',
    realm VARCHAR(64) DEFAULT '',
    nasipaddress VARCHAR(15) NOT NULL,
    nasportid VARCHAR(15) DEFAULT NULL,
    nasporttype VARCHAR(32) DEFAULT NULL,
    acctstarttime DATETIME NULL,
    acctupdatetime DATETIME NULL,
    acctstoptime DATETIME NULL,
    acctinterval INT(12) DEFAULT NULL,
    acctsessiontime INT(12) UNSIGNED DEFAULT NULL,
    acctauthentic VARCHAR(32) DEFAULT NULL,
    connectinfo_start VARCHAR(50) DEFAULT NULL,
    connectinfo_stop VARCHAR(50) DEFAULT NULL,
    acctinputoctets BIGINT(20) DEFAULT NULL,
    acctoutputoctets BIGINT(20) DEFAULT NULL,
    calledstationid VARCHAR(50) NOT NULL,
    callingstationid VARCHAR(50) NOT NULL,
    acctterminatecause VARCHAR(32) NOT NULL,
    servicetype VARCHAR(32) DEFAULT NULL,
    framedprotocol VARCHAR(32) DEFAULT NULL,
    framedipaddress VARCHAR(15) NOT NULL,
    PRIMARY KEY (radacctid),
    KEY username (username),
    KEY acctsessionid (acctsessionid)
);

-- SALES BY RESELLERS
CREATE TABLE reseller_sales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reseller_id INT NOT NULL,
    voucher_id INT NOT NULL,
    amount DECIMAL(10,2),
    commission DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- CUSTOMER USAGE
CREATE TABLE customer_usage (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    upload_mb BIGINT DEFAULT 0,
    download_mb BIGINT DEFAULT 0,
    total_mb BIGINT DEFAULT 0,
    session_time INT DEFAULT 0,
    last_update TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- MPESA CALLBACK LOGS
CREATE TABLE mpesa_transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    checkout_request_id VARCHAR(100),
    merchant_request_id VARCHAR(100),
    phone VARCHAR(20),
    amount DECIMAL(10,2),
    mpesa_receipt VARCHAR(50),
    result_code INT,
    result_desc VARCHAR(255),
    transaction_date DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE customers
ADD FOREIGN KEY (package_id)
REFERENCES packages(id);

ALTER TABLE payments
ADD FOREIGN KEY (customer_id)
REFERENCES customers(id);

ALTER TABLE payments
ADD FOREIGN KEY (package_id)
REFERENCES packages(id);

ALTER TABLE vouchers
ADD FOREIGN KEY (package_id)
REFERENCES packages(id);

ALTER TABLE reseller_sales
ADD FOREIGN KEY (reseller_id)
REFERENCES resellers(id);

ALTER TABLE reseller_sales
ADD FOREIGN KEY (voucher_id)
REFERENCES vouchers(id);