<aside class="d-sidebar">
  <div class="brand">
    <div class="brand-logo">
      <svg viewBox="0 0 36 36" xmlns="http://www.w3.org/2000/svg">
        <path fill="#ffffff" d="M14.747 9.125c.527-1.426 1.736-2.573 3.317-2.573c1.643 0 2.792 1.085 3.318 2.573l6.077 16.867c.186.496.248.931.248 1.147c0 1.209-.992 2.046-2.139 2.046c-1.303 0-1.954-.682-2.264-1.611l-.931-2.915h-8.62l-.93 2.884c-.31.961-.961 1.642-2.232 1.642c-1.24 0-2.294-.93-2.294-2.17c0-.496.155-.868.217-1.023l6.233-16.867zm.34 11.256h5.891l-2.883-8.992h-.062l-2.946 8.992z"/>
      </svg>
    </div>
    <div class="brand-text">
      <div class="brand-name">WiFi Billing</div>
      <div class="brand-tag">v2.0 · production</div>
    </div>
  </div>

  <nav class="nav-section">
    <div class="nav-label">Main Navigation</div>
    <a class="nav-link is-active" href="dashboard.php">
      <svg viewBox="0 0 24 24"><path d="M3 12 12 3l9 9"/><path d="M5 10v10h14V10"/></svg>
      <span>Dashboard</span>
    </a>
    <a class="nav-link" href="customers.php">
      <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8"/></svg>
      <span>Customers</span>
      <span class="nav-badge pro">MANAGE</span>
    </a>
    <a class="nav-link" href="packages.php">
      <svg viewBox="0 0 24 24"><path d="M4 4h16v16H4z"/><path d="M8 9h8M8 13h6M8 17h4"/></svg>
      <span>Packages</span>
    </a>
    <a class="nav-link" href="routers.php">
      <svg viewBox="0 0 24 24"><rect x="3" y="8" width="18" height="12" rx="2"/><circle cx="7" cy="14" r="1"/><circle cx="17" cy="14" r="1"/><path d="M9 5h6v3H9z"/></svg>
      <span>Routers</span>
      <span class="nav-badge new">LIVE</span>
    </a>
  </nav>

  <nav class="nav-section">
    <div class="nav-label">Billing & Finance</div>
    <a class="nav-link" href="payments.php">
      <svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>
      <span>Payments</span>
    </a>
    <a class="nav-link" href="vouchers.php">
      <svg viewBox="0 0 24 24"><path d="M20 12v8H4v-8M12 2v10M8 8l4 4 4-4"/><path d="M12 12V2"/></svg>
      <span>Vouchers</span>
      <span class="nav-badge pro">GENERATE</span>
    </a>
    <a class="nav-link" href="mpesa_transactions.php">
      <svg viewBox="0 0 24 24"><path d="M3 10h18M6 6h12M6 18h12M8 14h8"/><circle cx="12" cy="16" r="2"/></svg>
      <span>M-PESA Transactions</span>
    </a>
  </nav>

  <nav class="nav-section">
    <div class="nav-label">Network & Reports</div>
    <a class="nav-link" href="usage_reports.php">
      <svg viewBox="0 0 24 24"><path d="M3 20V4M7 20v-6M11 20v-10M15 20v-4M19 20V8"/></svg>
      <span>Usage Reports</span>
      <span class="nav-badge new">ANALYTICS</span>
    </a>
    <a class="nav-link" href="online_users.php">
      <svg viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
      <span>Online Users</span>
    </a>
    <div class="nav-item-group" data-nav-group>
      <a class="nav-link" href="javascript:void(0)" data-nav-toggle>
        <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg>
        <span>System Settings</span>
        <svg class="chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m9 18 6-6-6-6"/></svg>
      </a>
      <div class="nav-submenu">
        <a href="branches.php">Branches</a>
        <a href="resellers.php">Resellers</a>
        <a href="admin_users.php">Admin Users</a>
        <a href="backup.php">Backup & Restore</a>
      </div>
    </div>
  </nav>

  <div class="sidebar-footer">
    <div class="workspace">
      <div class="workspace-avatar">AD</div>
      <div class="workspace-text">
        <div class="workspace-name">Admin User</div>
        <div class="workspace-role">super admin</div>
      </div>
      <svg class="workspace-chev" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="m7 9 5-5 5 5"/>
        <path d="m7 15 5 5 5-5"/>
      </svg>
    </div>
  </div>
</aside>