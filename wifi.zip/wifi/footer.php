<footer class="d-footer">
  <div>© 2026 · Designed by <a href="https://shabanetech.top" target="_blank" rel="nofollow noopener noreferrer">Shabanetech</a></div>
  <div class="d-footer-meta">
    <span>v4.1.2</span>
    <span>contact 0797101745</span>
  </div>
</footer>