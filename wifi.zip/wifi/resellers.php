<?php include('head.php'); ?>
<body data-active="resellers" data-crumbs="Workspace | Resellers">
<div class="shell">
<?php include('sidebar.php'); ?>
<div class="main">
<?php include('topbar.php'); ?>
<main class="content">
<section class="hero">
<div class="hero-text">
<span class="eyebrow" id="heroDate">Reseller Management</span>
<h1 class="hero-title">Manage <span class="accent">Resellers</span></h1>
<p class="hero-sub" id="heroSubText">Manage resellers, track commissions, and monitor sales</p>
</div>
<div class="hero-actions">
<button class="btn btn--ghost" onclick="exportResellers()"><svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/></svg> Export</button>
<button class="btn btn--primary" onclick="showAddResellerModal()"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg> Add Reseller</button>
</div>
</section>

<!-- Reseller Statistics KPI Grid -->
<section class="kpi-grid" aria-label="Reseller metrics">
<article class="kpi-card c-success"><div class="kpi-top"><div class="kpi-identity"><div class="kpi-icon success"><svg viewBox="0 0 24 24"><path d="M20 12H4M12 4v16"/></svg></div><div class="kpi-label">Total Resellers</div></div></div><div class="kpi-value" id="totalResellers">0</div><div class="kpi-compare">Active resellers</div></article>
<article class="kpi-card c-danger"><div class="kpi-top"><div class="kpi-identity"><div class="kpi-icon danger"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg></div><div class="kpi-label">Total Sales</div></div></div><div class="kpi-value" id="totalSales"> 0</div><div class="kpi-compare">All time</div></article>
<article class="kpi-card c-purple"><div class="kpi-top"><div class="kpi-identity"><div class="kpi-icon purple"><svg viewBox="0 0 24 24"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg></div><div class="kpi-label">Commissions</div></div></div><div class="kpi-value" id="totalCommissions"> 0</div><div class="kpi-compare">Earned commission</div></article>
<article class="kpi-card c-primary"><div class="kpi-top"><div class="kpi-identity"><div class="kpi-icon primary"><svg viewBox="0 0 24 24"><path d="M18 20V10M12 20V4M6 20v-4"/></svg></div><div class="kpi-label">Avg Commission</div></div></div><div class="kpi-value" id="avgCommission">0%</div><div class="kpi-compare">Rate</div></article>
</section>

<!-- Resellers Table -->
<section class="col-12 card">
<div class="card-head"><div class="card-title-wrap"><span class="eyebrow">Reseller List</span><h2 class="card-title">All Resellers</h2></div>
<div class="card-actions">
<input type="text" id="searchInput" placeholder="Search resellers..." class="search-input">
<select id="statusFilter" class="status-filter"><option value="all">All Status</option><option value="active">Active</option><option value="inactive">Inactive</option></select>
</div></div>
<div class="table-responsive">
<table class="table">
<thead><th>ID</th><th>Reseller</th><th>Phone</th><th>Email</th><th>Commission</th><th>Balance</th><th>Status</th><th>Actions</th></thead>
<tbody id="resellersTableBody"><tr><td colspan="8" class="text-center">Loading resellers...</td></tr></tbody>
</div>
<div class="pagination"><div>Showing <span id="showingStart">0</span> to <span id="showingEnd">0</span> of <span id="totalRecords">0</span> resellers</div>
<div class="pagination-buttons"><button class="btn btn--small" id="prevPage" onclick="prevPage()" disabled>Previous</button><button class="btn btn--small" id="nextPage" onclick="nextPage()" disabled>Next</button></div></div>
</section>

<!-- Add/Edit Reseller Modal - TWO COLUMNS -->
<div id="resellerModal" class="modal" style="display: none;">
    <div class="modal-content" style="max-width: 700px;">
        <div class="modal-header"><h3 id="modalTitle">Add New Reseller</h3><button class="modal-close" onclick="closeResellerModal()">&times;</button></div>
        <form id="resellerForm">
            <input type="hidden" id="reseller_id">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                <div>
                    <div class="field"><label>Full Name *</label><input type="text" id="fullname" class="input" required></div>
                    <div class="field"><label>Phone * (10-12 digits)</label><input type="tel" id="phone" class="input" required placeholder="0712345678"></div>
                    <div class="field"><label>Email</label><input type="email" id="email" class="input" placeholder="reseller@example.com"></div>
                </div>
                <div>
                    <div class="field"><label>Username * (3-50 chars)</label><input type="text" id="username" class="input" required></div>
                    <div class="field" id="passwordField"><label>Password <span id="passwordRequired">*</span></label><input type="password" id="password" class="input" minlength="4"></div>
                    <div class="field"><label>Commission (%) * (0-100)</label><input type="number" id="commission_percent" class="input" value="10" min="0" max="100" step="0.01" required></div>
                </div>
            </div>
            <div id="formErrors" class="form-errors" style="display: none;"></div>
            <div class="modal-footer"><button type="button" class="btn btn--ghost" onclick="closeResellerModal()">Cancel</button><button type="submit" class="btn btn--primary">Save Reseller</button></div>
        </form>
    </div>
</div>

<!-- View Reseller Modal - Using data from table -->
<div id="viewResellerModal" class="modal" style="display: none;">
    <div class="modal-content" style="max-width: 500px;">
        <div class="modal-header"><h3>Reseller Details</h3><button class="modal-close" onclick="closeViewModal()">&times;</button></div>
        <div id="resellerDetailsContainer"></div>
        <div class="modal-footer"><button type="button" class="btn btn--ghost" onclick="closeViewModal()">Close</button><button type="button" class="btn btn--primary" onclick="editFromView()">Edit Reseller</button></div>
    </div>
</div>

<!-- Sales History Modal -->
<div id="salesModal" class="modal" style="display: none;">
    <div class="modal-content" style="max-width: 600px;">
        <div class="modal-header"><h3>Sales History</h3><button class="modal-close" onclick="closeSalesModal()">&times;</button></div>
        <div id="salesHistoryContainer"></div>
        <div class="modal-footer"><button type="button" class="btn btn--ghost" onclick="closeSalesModal()">Close</button></div>
    </div>
</div>

<!-- Toast Container -->
<div id="toastContainer"></div>

</main>
<?php include('footer.php'); ?>
</div>
</div>

<style>
.toast-container { position: fixed; top: 20px; right: 20px; z-index: 9999; }
.toast { display: flex; align-items: center; gap: 12px; background: white; border-radius: 8px; padding: 12px 16px; margin-bottom: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); animation: slideIn 0.3s ease forwards; min-width: 280px; border-left: 4px solid; }
.toast-success { border-left-color: #10b981; }.toast-error { border-left-color: #ef4444; }.toast-info { border-left-color: #3b82f6; }
.toast-icon { width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 14px; }
.toast-success .toast-icon { background: #10b98120; color: #10b981; }.toast-error .toast-icon { background: #ef444420; color: #ef4444; }
@keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
.text-center { text-align: center; }.table-responsive { overflow-x: auto; }
.table { width: 100%; border-collapse: collapse; }
.table th, .table td { padding: 12px 16px; text-align: left; border-bottom: 1px solid #e5e7eb; }
.table th { background: #f8f9fa; font-weight: 600; }
.tag { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 500; }
.t-active { background: #dcfce7; color: #166534; }.t-inactive { background: #fee2e2; color: #991b1b; }
.btn-icon { background: none; border: none; cursor: pointer; font-size: 16px; padding: 4px 8px; border-radius: 4px; transition: background 0.2s; }
.btn-icon:hover { background: #f0f0f0; }
.search-input, .status-filter { margin-left: 8px; padding: 6px 12px; border-radius: 6px; border: 1px solid #ddd; }
.card-actions { display: flex; gap: 8px; align-items: center; }
.pagination { padding: 16px; display: flex; justify-content: space-between; align-items: center; }
.pagination-buttons { display: flex; gap: 8px; }
.btn--small { padding: 4px 12px; font-size: 12px; }
.modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center; }
.modal-content { background: white; border-radius: 12px; max-width: 700px; width: 90%; max-height: 90vh; overflow-y: auto; padding: 24px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); }
.modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
.modal-close { background: none; border: none; font-size: 24px; cursor: pointer; color: #666; }
.modal-footer { display: flex; gap: 12px; justify-content: flex-end; margin-top: 20px; }
.field { margin-bottom: 16px; }
.field label { display: block; margin-bottom: 6px; font-weight: 500; }
.field input, .field select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; }
.form-errors { color: #ef4444; font-size: 13px; margin: 16px 0; padding: 10px; background: #fee2e2; border-radius: 6px; }
.btn { padding: 10px 20px; border-radius: 6px; cursor: pointer; font-size: 14px; }
.btn--primary { background: #4f46e5; color: white; border: none; }
.btn--ghost { background: none; border: 1px solid #ddd; color: #333; }
.detail-row { display: flex; padding: 8px 0; border-bottom: 1px solid #f0f0f0; }
.detail-label { width: 100px; font-weight: 600; color: #666; }
.detail-value { flex: 1; color: #333; }
</style>

<script>
// ============================================
// RESELLER MANAGEMENT PAGE - FIXED (NO GET BY ID)
// ============================================

// const API_BASE_URL = 'https://shabanetech.top/wifi-api';
// let adminToken = localStorage.getItem('adminToken');
let allResellers = [];
let currentPage = 1;
let itemsPerPage = 10;
let currentFilters = { search: '', status: 'all' };
let currentViewReseller = null;

function showToast(message, type = 'success') {
    let container = document.getElementById('toastContainer');
    if (!container) { container = document.createElement('div'); container.id = 'toastContainer'; document.body.appendChild(container); }
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `<div class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '✗' : 'ℹ'}</div><div class="toast-message">${message}</div><button class="toast-close" onclick="this.parentElement.remove()">×</button>`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}

async function apiFetch(endpoint, options = {}) {
    if (!adminToken) { window.location.href = 'admin_login.html'; return null; }
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            ...options,
            headers: { 'Authorization': `Bearer ${adminToken}`, 'Content-Type': 'application/json' }
        });
        if (response.status === 401) { localStorage.removeItem('adminToken'); window.location.href = 'admin_login.html'; return null; }
        const data = await response.json();
        if (!response.ok) {
            if (data.details && data.details.length) {
                const errors = data.details.map(d => d.message).join(', ');
                throw new Error(errors);
            }
            throw new Error(data.error || data.message);
        }
        return data;
    } catch (error) { 
        console.error('API Error:', error);
        showToast(error.message, 'error');
        return null;
    }
}

function formatCurrency(amount) { return ' ' + parseFloat(amount || 0).toLocaleString(); }
function formatDate(dateString) { if (!dateString) return '-'; const date = new Date(dateString); return date.toLocaleDateString(); }
function escapeHtml(text) { if (!text) return ''; const div = document.createElement('div'); div.textContent = text; return div.innerHTML; }
function formatPhoneNumber(phone) { return phone.replace(/\D/g, ''); }
function isValidPhone(phone) { const digits = phone.replace(/\D/g, ''); return digits.length >= 10 && digits.length <= 12; }

async function loadStats() {
    const response = await apiFetch('/api/resellers');
    if (response && response.success && response.data) {
        const resellers = response.data;
        const total = resellers.length;
        const active = resellers.filter(r => r.status === 'active').length;
        const totalSales = resellers.reduce((sum, r) => sum + (parseFloat(r.total_sales) || 0), 0);
        const totalCommissions = resellers.reduce((sum, r) => sum + (parseFloat(r.total_commission_earned) || 0), 0);
        const avgCommission = resellers.length > 0 ? resellers.reduce((sum, r) => sum + parseFloat(r.commission_percent || 0), 0) / resellers.length : 0;
        document.getElementById('totalResellers').innerHTML = total;
        document.getElementById('totalSales').innerHTML = formatCurrency(totalSales);
        document.getElementById('totalCommissions').innerHTML = formatCurrency(totalCommissions);
        document.getElementById('avgCommission').innerHTML = avgCommission.toFixed(1) + '%';
    }
}

async function loadResellers() {
    const tbody = document.getElementById('resellersTableBody');
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="8" class="text-center">Loading resellers...</td></tr>';
    const response = await apiFetch('/api/resellers');
    if (response && response.success && response.data) {
        allResellers = response.data;
        let filtered = [...allResellers];
        if (currentFilters.search) {
            const search = currentFilters.search.toLowerCase();
            filtered = filtered.filter(r => (r.fullname && r.fullname.toLowerCase().includes(search)) || (r.username && r.username.toLowerCase().includes(search)) || (r.phone && r.phone.includes(search)));
        }
        if (currentFilters.status !== 'all') filtered = filtered.filter(r => r.status === currentFilters.status);
        const total = filtered.length;
        const totalPages = Math.ceil(total / itemsPerPage);
        const start = (currentPage - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        const paginated = filtered.slice(start, end);
        if (paginated.length === 0) { tbody.innerHTML = '<tr><td colspan="8" class="text-center">No resellers found</td></tr>'; }
        else {
            tbody.innerHTML = paginated.map(r => `<tr><td>${r.id}</td><td class="cell-name"><strong>${escapeHtml(r.fullname)}</strong><br><small>${escapeHtml(r.username)}</small></td><td>${escapeHtml(r.phone || '-')}</td><td>${escapeHtml(r.email || '-')}</td><td class="cell-price pos">${r.commission_percent || 0}%</td><td class="cell-price pos">${formatCurrency(r.balance || 0)}</td><td><span class="tag ${r.status === 'active' ? 't-active' : 't-inactive'}">${r.status}</span></td><td><button class="btn-icon" onclick="viewReseller(${r.id})">👁️</button><button class="btn-icon" onclick="editReseller(${r.id})">✏️</button><button class="btn-icon" onclick="deleteReseller(${r.id})">🗑️</button><button class="btn-icon" onclick="viewSales(${r.id})">📊</button></td></tr>`).join('');
        }
        document.getElementById('showingStart').innerHTML = total === 0 ? 0 : start + 1;
        document.getElementById('showingEnd').innerHTML = Math.min(end, total);
        document.getElementById('totalRecords').innerHTML = total;
        document.getElementById('prevPage').disabled = currentPage <= 1;
        document.getElementById('nextPage').disabled = currentPage >= totalPages;
    }
}

// View reseller - using data from allResellers array
function viewReseller(id) {
    const reseller = allResellers.find(r => r.id === id);
    if (reseller) {
        currentViewReseller = reseller;
        const container = document.getElementById('resellerDetailsContainer');
        if (container) {
            container.innerHTML = `
                <div class="detail-row"><span class="detail-label">ID:</span><span class="detail-value">${reseller.id}</span></div>
                <div class="detail-row"><span class="detail-label">Full Name:</span><span class="detail-value">${escapeHtml(reseller.fullname)}</span></div>
                <div class="detail-row"><span class="detail-label">Username:</span><span class="detail-value">${escapeHtml(reseller.username)}</span></div>
                <div class="detail-row"><span class="detail-label">Phone:</span><span class="detail-value">${escapeHtml(reseller.phone || '-')}</span></div>
                <div class="detail-row"><span class="detail-label">Email:</span><span class="detail-value">${escapeHtml(reseller.email || '-')}</span></div>
                <div class="detail-row"><span class="detail-label">Commission:</span><span class="detail-value">${reseller.commission_percent || 0}%</span></div>
                <div class="detail-row"><span class="detail-label">Balance:</span><span class="detail-value">${formatCurrency(reseller.balance || 0)}</span></div>
                <div class="detail-row"><span class="detail-label">Status:</span><span class="detail-value"><span class="tag ${reseller.status === 'active' ? 't-active' : 't-inactive'}">${reseller.status}</span></span></div>
                <div class="detail-row"><span class="detail-label">Created:</span><span class="detail-value">${formatDate(reseller.created_at)}</span></div>`;
        }
        const modal = document.getElementById('viewResellerModal'); if (modal) modal.style.display = 'flex';
    } else { showToast('Could not load reseller details', 'error'); }
}

function editFromView() { 
    if (currentViewReseller) { 
        closeViewModal(); 
        editReseller(currentViewReseller.id); 
    } 
}

// Edit reseller
async function editReseller(id) {
    const reseller = allResellers.find(r => r.id === id);
    if (reseller) {
        const titleElem = document.getElementById('modalTitle'); if (titleElem) titleElem.innerText = 'Edit Reseller';
        const idField = document.getElementById('reseller_id'); if (idField) idField.value = reseller.id;
        const nameField = document.getElementById('fullname'); if (nameField) nameField.value = reseller.fullname;
        const phoneField = document.getElementById('phone'); if (phoneField) phoneField.value = reseller.phone || '';
        const emailField = document.getElementById('email'); if (emailField) emailField.value = reseller.email || '';
        const usernameField = document.getElementById('username'); if (usernameField) usernameField.value = reseller.username;
        const commissionField = document.getElementById('commission_percent'); if (commissionField) commissionField.value = reseller.commission_percent || 10;
        const passwordField = document.getElementById('password'); if (passwordField) passwordField.value = '';
        const modal = document.getElementById('resellerModal'); if (modal) modal.style.display = 'flex';
    }
}

// Add/Edit reseller form
const resellerForm = document.getElementById('resellerForm');
if (resellerForm) {
    resellerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const resellerId = document.getElementById('reseller_id').value;
        let phone = document.getElementById('phone').value.trim();
        phone = formatPhoneNumber(phone);
        const resellerData = {
            fullname: document.getElementById('fullname').value.trim(),
            phone: phone,
            email: document.getElementById('email').value.trim() || null,
            username: document.getElementById('username').value.trim(),
            commission_percent: parseFloat(document.getElementById('commission_percent').value)
        };
        const password = document.getElementById('password').value;
        if (password) resellerData.password = password;
        const errorDiv = document.getElementById('formErrors');
        if (!resellerData.fullname) { if (errorDiv) { errorDiv.textContent = 'Full name required'; errorDiv.style.display = 'block'; setTimeout(() => { if(errorDiv) errorDiv.style.display = 'none'; }, 3000); } return; }
        if (!resellerData.username) { if (errorDiv) { errorDiv.textContent = 'Username required (3-50 chars)'; errorDiv.style.display = 'block'; setTimeout(() => { if(errorDiv) errorDiv.style.display = 'none'; }, 3000); } return; }
        if (!isValidPhone(resellerData.phone)) { if (errorDiv) { errorDiv.textContent = 'Phone must be 10-12 digits'; errorDiv.style.display = 'block'; setTimeout(() => { if(errorDiv) errorDiv.style.display = 'none'; }, 3000); } return; }
        if (!resellerId && !password) { if (errorDiv) { errorDiv.textContent = 'Password required for new reseller'; errorDiv.style.display = 'block'; setTimeout(() => { if(errorDiv) errorDiv.style.display = 'none'; }, 3000); } return; }
        if (resellerData.commission_percent < 0 || resellerData.commission_percent > 100) { if (errorDiv) { errorDiv.textContent = 'Commission must be 0-100'; errorDiv.style.display = 'block'; setTimeout(() => { if(errorDiv) errorDiv.style.display = 'none'; }, 3000); } return; }
        if (errorDiv) errorDiv.style.display = 'none';
        const submitBtn = e.target.querySelector('button[type="submit"]');
        const originalText = submitBtn ? submitBtn.innerHTML : 'Save Reseller';
        if (submitBtn) { submitBtn.innerHTML = 'Saving...'; submitBtn.disabled = true; }
        let response;
        if (resellerId) { response = await apiFetch(`/api/resellers/${resellerId}`, { method: 'PUT', body: JSON.stringify(resellerData) }); } 
        else { response = await apiFetch('/api/resellers', { method: 'POST', body: JSON.stringify(resellerData) }); }
        if (submitBtn) { submitBtn.innerHTML = originalText; submitBtn.disabled = false; }
        if (response && response.success) {
            showToast(`Reseller ${resellerData.username} ${resellerId ? 'updated' : 'created'} successfully!`, 'success');
            closeResellerModal();
            loadResellers(); loadStats();
            if (resellerForm) resellerForm.reset();
            const resellerIdField = document.getElementById('reseller_id'); if (resellerIdField) resellerIdField.value = '';
        } else { showToast(response?.error || 'Failed to save reseller', 'error'); }
    });
}

async function deleteReseller(id) {
    if (confirm('Are you sure you want to delete this reseller?')) {
        const response = await apiFetch(`/api/resellers/${id}`, { method: 'DELETE' });
        if (response && response.success) { showToast('Reseller deleted successfully!', 'success'); loadResellers(); loadStats(); } 
        else { showToast(response?.error || 'Failed to delete reseller', 'error'); }
    }
}

async function viewSales(id) {
    const response = await apiFetch(`/api/resellers/sales?reseller_id=${id}`);
    const container = document.getElementById('salesHistoryContainer');
    if (!container) return;
    if (response && response.success && response.data && response.data.length > 0) {
        const sales = response.data;
        container.innerHTML = `<table class="table"><thead><th>Voucher</th><th>Amount</th><th>Commission</th><th>Date</th></thead><tbody>${sales.map(s => `<tr><td><small>${escapeHtml(s.voucher_code || '-')}</small></td><td class="cell-price pos">${formatCurrency(s.amount)}</td><td class="cell-price pos">${formatCurrency(s.commission)}</td><td>${formatDate(s.created_at)}</td></tr>`).join('')}</tbody>`;
    } else { container.innerHTML = '<p class="text-center">No sales records found</p>'; }
    const modal = document.getElementById('salesModal'); if (modal) modal.style.display = 'flex';
}

function showAddResellerModal() {
    const titleElem = document.getElementById('modalTitle'); if (titleElem) titleElem.innerText = 'Add New Reseller';
    const form = document.getElementById('resellerForm'); if (form) form.reset();
    const idField = document.getElementById('reseller_id'); if (idField) idField.value = '';
    const commissionField = document.getElementById('commission_percent'); if (commissionField) commissionField.value = '10';
    const modal = document.getElementById('resellerModal'); if (modal) modal.style.display = 'flex';
}

function closeResellerModal() { const modal = document.getElementById('resellerModal'); if (modal) modal.style.display = 'none'; }
function closeViewModal() { const modal = document.getElementById('viewResellerModal'); if (modal) modal.style.display = 'none'; currentViewReseller = null; }
function closeSalesModal() { const modal = document.getElementById('salesModal'); if (modal) modal.style.display = 'none'; }

function prevPage() { if (currentPage > 1) { currentPage--; loadResellers(); } }
function nextPage() { currentPage++; loadResellers(); }

const searchInput = document.getElementById('searchInput');
if (searchInput) { searchInput.addEventListener('input', (e) => { currentFilters.search = e.target.value; currentPage = 1; loadResellers(); }); }
const statusFilter = document.getElementById('statusFilter');
if (statusFilter) { statusFilter.addEventListener('change', (e) => { currentFilters.status = e.target.value; currentPage = 1; loadResellers(); }); }

function exportResellers() {
    if (allResellers.length === 0) { showToast('No data to export', 'error'); return; }
    let csv = 'ID,Full Name,Username,Phone,Email,Commission,Balance,Status\n';
    allResellers.forEach(r => { csv += `"${r.id}","${r.fullname}","${r.username}","${r.phone || ''}","${r.email || ''}","${r.commission_percent || 0}","${r.balance || 0}","${r.status}"\n`; });
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `resellers_${new Date().toISOString().split('T')[0]}.csv`;
    a.click(); URL.revokeObjectURL(url);
    showToast('Export completed!', 'success');
}

const dateElem = document.getElementById('heroDate');
if (dateElem) { const date = new Date(); dateElem.innerHTML = date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }); }

const user = JSON.parse(localStorage.getItem('adminUser') || '{}');
const adminNameElem = document.getElementById('adminName');
if (adminNameElem) {
    if (user.fullname) adminNameElem.innerHTML = user.fullname.split(' ')[0];
    else if (user.username) adminNameElem.innerHTML = user.username;
}

if (adminToken && adminToken !== 'null' && adminToken.length > 20) { loadStats(); loadResellers(); } 
else { window.location.href = 'admin_login.html'; }

window.onclick = function(event) {
    if (event.target === document.getElementById('resellerModal')) closeResellerModal();
    if (event.target === document.getElementById('viewResellerModal')) closeViewModal();
    if (event.target === document.getElementById('salesModal')) closeSalesModal();
}
</script>
</body>
</html>