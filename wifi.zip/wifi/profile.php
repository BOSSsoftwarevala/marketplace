<?php include('head.php'); ?>
<body data-active="profile" data-crumbs="Workspace | Profile">
<div class="shell">
<?php include('sidebar.php'); ?>
<div class="main">
<?php include('topbar.php'); ?>
<main class="content">
<section class="hero">
<div class="hero-text">
<span class="eyebrow" id="heroDate">User Profile</span>
<h1 class="hero-title">My <span class="accent">Profile</span></h1>
<p class="hero-sub" id="heroSubText">Manage your account information and security settings</p>
</div>
<div class="hero-actions">
<button class="btn btn--ghost" onclick="refreshProfile()"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg> Refresh</button>
</div>
</section>

<!-- Profile Information - Two Columns -->
<div class="grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">

<!-- Left Column - Profile Info -->
<div class="left-column">
<section class="col-12 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Personal Information</span>
<h2 class="card-title">Profile Details</h2>
</div>
</div>
<div class="profile-avatar" style="text-align: center; padding: 20px 0;">
<div class="avatar-large" style="width: 100px; height: 100px; background: linear-gradient(135deg, #4f46e5, #7c3aed); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px;">
<span style="font-size: 48px; color: white; font-weight: 600;" id="avatarInitials">AD</span>
</div>
<h2 id="profileFullname">Loading...</h2>
<p class="text-muted" id="profileRole">Administrator</p>
</div>
<div class="profile-info" style="padding: 0 16px 16px;">
<div class="info-row"><span class="info-label">Username:</span><span class="info-value" id="profileUsername">-</span></div>
<div class="info-row"><span class="info-label">Email:</span><span class="info-value" id="profileEmail">-</span></div>
<div class="info-row"><span class="info-label">Phone:</span><span class="info-value" id="profilePhone">-</span></div>
<div class="info-row"><span class="info-label">Member Since:</span><span class="info-value" id="profileCreated">-</span></div>
<div class="info-row"><span class="info-label">Last Login:</span><span class="info-value" id="profileLastLogin">-</span></div>
</div>
</section>

<!-- Account Statistics -->
<section class="col-12 card" style="margin-top: 24px;">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Statistics</span>
<h2 class="card-title">Account Activity</h2>
</div>
</div>
<div class="stats-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; padding: 16px;">
<div class="stat-card" style="text-align: center; padding: 16px; background: #f8f9fa; border-radius: 8px;">
<div class="stat-value" id="totalLogins" style="font-size: 28px; font-weight: 700; color: #4f46e5;">0</div>
<div class="stat-label" style="color: #666; font-size: 12px;">Total Logins</div>
</div>
<div class="stat-card" style="text-align: center; padding: 16px; background: #f8f9fa; border-radius: 8px;">
<div class="stat-value" id="sessionCount" style="font-size: 28px; font-weight: 700; color: #10b981;">0</div>
<div class="stat-label" style="color: #666; font-size: 12px;">Active Sessions</div>
</div>
<div class="stat-card" style="text-align: center; padding: 16px; background: #f8f9fa; border-radius: 8px;">
<div class="stat-value" id="lastActive" style="font-size: 14px; font-weight: 600; color: #f59e0b;">-</div>
<div class="stat-label" style="color: #666; font-size: 12px;">Last Active</div>
</div>
<div class="stat-card" style="text-align: center; padding: 16px; background: #f8f9fa; border-radius: 8px;">
<div class="stat-value" id="accountAge" style="font-size: 14px; font-weight: 600; color: #8b5cf6;">-</div>
<div class="stat-label" style="color: #666; font-size: 12px;">Account Age</div>
</div>
</div>
</section>
</div>

<!-- Right Column - Edit Forms -->
<div class="right-column">
<!-- Edit Profile Form -->
<section class="col-12 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Edit Profile</span>
<h2 class="card-title">Update Information</h2>
</div>
</div>
<form id="profileForm" class="profile-form" style="padding: 16px;">
<div class="field">
<label class="field-label">Full Name</label>
<input type="text" id="fullname" class="input" placeholder="Enter your full name">
</div>
<div class="field">
<label class="field-label">Email Address</label>
<input type="email" id="email" class="input" placeholder="Enter your email">
</div>
<div class="field">
<label class="field-label">Phone Number</label>
<input type="tel" id="phone" class="input" placeholder="Enter your phone number">
</div>
<button type="submit" class="btn btn--primary" style="width: 100%;">Update Profile</button>
<div id="profileFormErrors" class="form-errors" style="display: none;"></div>
</form>
</section>

<!-- Change Password Form -->
<section class="col-12 card" style="margin-top: 24px;">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Security</span>
<h2 class="card-title">Change Password</h2>
</div>
</div>
<form id="passwordForm" class="password-form" style="padding: 16px;">
<div class="field">
<label class="field-label">Current Password</label>
<input type="password" id="current_password" class="input" placeholder="Enter current password">
</div>
<div class="field">
<label class="field-label">New Password</label>
<input type="password" id="new_password" class="input" placeholder="Enter new password (min 6 characters)">
</div>
<div class="field">
<label class="field-label">Confirm New Password</label>
<input type="password" id="confirm_password" class="input" placeholder="Confirm new password">
</div>
<button type="submit" class="btn btn--primary" style="width: 100%;">Change Password</button>
<div id="passwordFormErrors" class="form-errors" style="display: none;"></div>
</form>
</section>

<!-- Session Management -->
<section class="col-12 card" style="margin-top: 24px;">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Sessions</span>
<h2 class="card-title">Active Sessions</h2>
</div>
<button class="btn btn--small" onclick="terminateAllSessions()" style="color: #ef4444;">Terminate All</button>
</div>
<div class="sessions-list" id="sessionsList" style="padding: 16px;">
<p class="text-center">Loading sessions...</p>
</div>
</section>
</div>

</div>

<!-- Activity Log Table -->
<section class="col-12 card" style="margin-top: 24px;">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Activity Log</span>
<h2 class="card-title">Recent Activities</h2>
</div>
</div>
<div class="table-responsive">
<table class="table">
<thead>
<th>Time</th>
<th>Activity</th>
<th>IP Address</th>
<th>User Agent</th>
</thead>
<tbody id="activityTableBody">
<tr><td colspan="4" class="text-center">Loading activities...<\/td><\/tr>
</tbody>
</div>
<div class="pagination" style="padding: 16px; display: flex; justify-content: space-between; align-items: center;">
<div>Showing <span id="showingStart">0</span> to <span id="showingEnd">0</span> of <span id="totalRecords">0</span> activities</div>
<div class="pagination-buttons">
<button class="btn btn--small" id="prevPage" onclick="prevPage()" disabled>Previous</button>
<button class="btn btn--small" id="nextPage" onclick="nextPage()" disabled>Next</button>
</div>
</div>
</section>

<!-- Toast Container -->
<div id="toastContainer"></div>

</main>
<?php include('footer.php'); ?>
</div>
</div>

<style>
.toast-container { position: fixed; top: 20px; right: 20px; z-index: 9999; }
.toast { display: flex; align-items: center; gap: 12px; background: white; border-radius: 8px; padding: 12px 16px; margin-bottom: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); animation: slideIn 0.3s ease forwards; min-width: 280px; border-left: 4px solid; }
.toast-success { border-left-color: #10b981; }.toast-error { border-left-color: #ef4444; }.toast-info { border-left-color: #3b82f6; }
.toast-icon { width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 14px; }
.toast-success .toast-icon { background: #10b98120; color: #10b981; }.toast-error .toast-icon { background: #ef444420; color: #ef4444; }
@keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
.text-center { text-align: center; }
.table-responsive { overflow-x: auto; }
.table { width: 100%; border-collapse: collapse; }
.table th, .table td { padding: 12px 16px; text-align: left; border-bottom: 1px solid #e5e7eb; }
.table th { background: #f8f9fa; font-weight: 600; }
.field { margin-bottom: 16px; }
.field label { display: block; margin-bottom: 6px; font-weight: 500; }
.field input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; }
.form-errors { color: #ef4444; font-size: 13px; margin: 16px 0; padding: 10px; background: #fee2e2; border-radius: 6px; }
.btn { padding: 10px 20px; border-radius: 6px; cursor: pointer; font-size: 14px; }
.btn--primary { background: #4f46e5; color: white; border: none; }
.btn--ghost { background: none; border: 1px solid #ddd; color: #333; }
.btn--small { padding: 4px 12px; font-size: 12px; }
.info-row { display: flex; padding: 10px 0; border-bottom: 1px solid #f0f0f0; }
.info-label { width: 110px; font-weight: 600; color: #666; }
.info-value { flex: 1; color: #333; }
.text-muted { color: #6b7280; font-size: 13px; text-align: center; }
.session-item { display: flex; justify-content: space-between; align-items: center; padding: 12px; border-bottom: 1px solid #f0f0f0; }
.session-item:last-child { border-bottom: none; }
.session-device { display: flex; align-items: center; gap: 12px; }
.session-icon { font-size: 24px; }
.session-info { flex: 1; }
.session-current { background: #dcfce7; border-radius: 8px; margin: 0 0 8px 0; padding: 12px; }
.badge-current { background: #10b981; color: white; padding: 2px 8px; border-radius: 4px; font-size: 10px; margin-left: 8px; }
.terminate-btn { background: none; border: none; cursor: pointer; font-size: 18px; padding: 4px 8px; border-radius: 4px; }
.terminate-btn:hover { background: #fee2e2; }
</style>

<script>
// ============================================
// USER PROFILE PAGE
// ============================================

// const API_BASE_URL = 'https://shabanetech.top/wifi-api';
// let adminToken = localStorage.getItem('adminToken');
let currentUser = null;
let userSessions = [];
let activitiesPage = 1;
let totalActivitiesPages = 1;
let currentSessionId = null;

function showToast(message, type = 'success') {
    let container = document.getElementById('toastContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toastContainer';
        document.body.appendChild(container);
    }
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `<div class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '✗' : 'ℹ'}</div><div class="toast-message">${message}</div><button class="toast-close" onclick="this.parentElement.remove()">×</button>`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}

async function apiFetch(endpoint, options = {}) {
    if (!adminToken) { 
        window.location.href = 'admin_login.html'; 
        return null; 
    }
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            ...options,
            headers: { 
                'Authorization': `Bearer ${adminToken}`, 
                'Content-Type': 'application/json' 
            }
        });
        if (response.status === 401) { 
            localStorage.removeItem('adminToken'); 
            window.location.href = 'admin_login.html'; 
            return null; 
        }
        const data = await response.json();
        if (!response.ok) { 
            throw new Error(data.error || data.message); 
        }
        return data;
    } catch (error) { 
        console.error('API Error:', error);
        showToast(error.message, 'error');
        return null;
    }
}

function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function formatRelativeTime(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    const now = new Date();
    const diff = Math.floor((now - date) / 1000);
    
    if (diff < 60) return 'Just now';
    if (diff < 3600) return `${Math.floor(diff / 60)} minutes ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)} hours ago`;
    return `${Math.floor(diff / 86400)} days ago`;
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Load user profile
async function loadProfile() {
    const user = JSON.parse(localStorage.getItem('adminUser') || '{}');
    
    if (user) {
        currentUser = user;
        const initials = (user.fullname || user.username || 'AD').split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
        document.getElementById('avatarInitials').innerHTML = initials;
        document.getElementById('profileFullname').innerHTML = escapeHtml(user.fullname || user.username);
        document.getElementById('profileUsername').innerHTML = escapeHtml(user.username);
        document.getElementById('profileEmail').innerHTML = escapeHtml(user.email || '-');
        document.getElementById('profilePhone').innerHTML = escapeHtml(user.phone || '-');
        document.getElementById('profileCreated').innerHTML = formatDate(user.created_at);
        document.getElementById('profileLastLogin').innerHTML = formatRelativeTime(user.last_login);
        
        // Update form fields
        document.getElementById('fullname').value = user.fullname || '';
        document.getElementById('email').value = user.email || '';
        document.getElementById('phone').value = user.phone || '';
    }
    
    // Load stats
    await loadStats();
    await loadSessions();
}

// Load user statistics
async function loadStats() {
    const response = await apiFetch('/api/admin/dashboard/stats');
    if (response && response.success && response.data) {
        document.getElementById('totalLogins').innerHTML = response.data.total_logins || 0;
        document.getElementById('sessionCount').innerHTML = response.data.active_sessions || 0;
        document.getElementById('lastActive').innerHTML = formatRelativeTime(response.data.last_active);
        
        // Calculate account age
        if (currentUser && currentUser.created_at) {
            const created = new Date(currentUser.created_at);
            const now = new Date();
            const daysOld = Math.floor((now - created) / (1000 * 60 * 60 * 24));
            document.getElementById('accountAge').innerHTML = `${daysOld} days`;
        }
    }
}

// Load user sessions
async function loadSessions() {
    const container = document.getElementById('sessionsList');
    if (!container) return;
    container.innerHTML = '<p class="text-center">Loading sessions...</p>';
    
    const response = await apiFetch('/api/auth/sessions');
    if (response && response.success && response.data) {
        userSessions = response.data;
        const currentSessionId = response.current_session_id;
        
        if (userSessions.length === 0) {
            container.innerHTML = '<p class="text-center">No active sessions found</p>';
        } else {
            container.innerHTML = userSessions.map(session => `
                <div class="session-item ${session.id === currentSessionId ? 'session-current' : ''}">
                    <div class="session-device">
                        <div class="session-icon">${session.device === 'Mobile' ? '📱' : session.device === 'Tablet' ? '📟' : '💻'}</div>
                        <div class="session-info">
                            <strong>${escapeHtml(session.device || 'Unknown Device')}</strong>
                            <div><small>IP: ${escapeHtml(session.ip || '-')}</small></div>
                            <div><small>Last active: ${formatRelativeTime(session.last_active)}</small></div>
                        </div>
                    </div>
                    ${session.id !== currentSessionId ? 
                        `<button class="terminate-btn" onclick="terminateSession('${session.id}')" title="Terminate Session">🔴</button>` : 
                        '<span class="badge-current">Current Session</span>'
                    }
                </div>
            `).join('');
        }
    }
}

// Terminate a specific session
async function terminateSession(sessionId) {
    if (confirm('Are you sure you want to terminate this session?')) {
        const response = await apiFetch(`/api/auth/sessions/${sessionId}`, { method: 'DELETE' });
        if (response && response.success) {
            showToast('Session terminated successfully', 'success');
            loadSessions();
        } else {
            showToast(response?.error || 'Failed to terminate session', 'error');
        }
    }
}

// Terminate all other sessions
async function terminateAllSessions() {
    if (confirm('Are you sure you want to terminate all other sessions? You will be logged out from all other devices.')) {
        const response = await apiFetch('/api/auth/sessions/terminate-all', { method: 'POST' });
        if (response && response.success) {
            showToast('All other sessions terminated', 'success');
            loadSessions();
        } else {
            showToast(response?.error || 'Failed to terminate sessions', 'error');
        }
    }
}

// Load activity log
async function loadActivities() {
    const tbody = document.getElementById('activityTableBody');
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="4" class="text-center">Loading activities...<\/td><\/tr>';
    
    const response = await apiFetch(`/api/admin/activity-log?page=${activitiesPage}&limit=10`);
    if (response && response.success && response.data) {
        const activities = response.data;
        const pagination = response.pagination;
        
        if (activities.length === 0) {
            tbody.innerHTML = '<tr><td colspan="4" class="text-center">No activities found<\/td><\/tr>';
        } else {
            tbody.innerHTML = activities.map(activity => `
                <tr>
                    <td class="cell-date">${formatDate(activity.created_at)}<\/td>
                    <td><span class="tag t-info">${escapeHtml(activity.action)}<\/span><br><small>${escapeHtml(activity.description || '')}</small><\/td>
                    <td>${escapeHtml(activity.ip || '-')}<\/td>
                    <td><small>${escapeHtml((activity.user_agent || '').substring(0, 50))}${(activity.user_agent || '').length > 50 ? '...' : ''}<\/small><\/td>
                </table>
            `).join('');
        }
        
        if (pagination) {
            document.getElementById('showingStart').innerHTML = ((activitiesPage - 1) * 10) + 1;
            document.getElementById('showingEnd').innerHTML = Math.min(activitiesPage * 10, pagination.total);
            document.getElementById('totalRecords').innerHTML = pagination.total;
            totalActivitiesPages = pagination.pages;
            document.getElementById('prevPage').disabled = activitiesPage <= 1;
            document.getElementById('nextPage').disabled = activitiesPage >= totalActivitiesPages;
        }
    }
}

// Update profile
document.getElementById('profileForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const profileData = {
        fullname: document.getElementById('fullname').value.trim(),
        email: document.getElementById('email').value.trim(),
        phone: document.getElementById('phone').value.trim()
    };
    
    const errorDiv = document.getElementById('profileFormErrors');
    if (!profileData.fullname) {
        errorDiv.textContent = 'Full name is required';
        errorDiv.style.display = 'block';
        setTimeout(() => errorDiv.style.display = 'none', 3000);
        return;
    }
    errorDiv.style.display = 'none';
    
    const submitBtn = e.target.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = 'Updating...';
    submitBtn.disabled = true;
    
    const response = await apiFetch('/api/admin/profile', {
        method: 'PUT',
        body: JSON.stringify(profileData)
    });
    
    submitBtn.innerHTML = originalText;
    submitBtn.disabled = false;
    
    if (response && response.success) {
        showToast('Profile updated successfully!', 'success');
        // Update localStorage
        const user = JSON.parse(localStorage.getItem('adminUser') || '{}');
        user.fullname = profileData.fullname;
        user.email = profileData.email;
        user.phone = profileData.phone;
        localStorage.setItem('adminUser', JSON.stringify(user));
        loadProfile();
    } else {
        showToast(response?.error || 'Failed to update profile', 'error');
    }
});

// Change password
document.getElementById('passwordForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const currentPassword = document.getElementById('current_password').value;
    const newPassword = document.getElementById('new_password').value;
    const confirmPassword = document.getElementById('confirm_password').value;
    
    const errorDiv = document.getElementById('passwordFormErrors');
    
    if (!currentPassword) {
        errorDiv.textContent = 'Current password is required';
        errorDiv.style.display = 'block';
        setTimeout(() => errorDiv.style.display = 'none', 3000);
        return;
    }
    if (!newPassword) {
        errorDiv.textContent = 'New password is required';
        errorDiv.style.display = 'block';
        setTimeout(() => errorDiv.style.display = 'none', 3000);
        return;
    }
    if (newPassword.length < 6) {
        errorDiv.textContent = 'New password must be at least 6 characters';
        errorDiv.style.display = 'block';
        setTimeout(() => errorDiv.style.display = 'none', 3000);
        return;
    }
    if (newPassword !== confirmPassword) {
        errorDiv.textContent = 'Passwords do not match';
        errorDiv.style.display = 'block';
        setTimeout(() => errorDiv.style.display = 'none', 3000);
        return;
    }
    errorDiv.style.display = 'none';
    
    const submitBtn = e.target.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = 'Changing...';
    submitBtn.disabled = true;
    
    const response = await apiFetch('/api/auth/change-password', {
        method: 'POST',
        body: JSON.stringify({
            old_password: currentPassword,
            new_password: newPassword
        })
    });
    
    submitBtn.innerHTML = originalText;
    submitBtn.disabled = false;
    
    if (response && response.success) {
        showToast('Password changed successfully! Please login again.', 'success');
        document.getElementById('passwordForm').reset();
        setTimeout(() => {
            localStorage.removeItem('adminToken');
            localStorage.removeItem('adminUser');
            window.location.href = 'admin_login.html';
        }, 2000);
    } else {
        showToast(response?.error || 'Failed to change password', 'error');
    }
});

// Activity pagination
function prevPage() { if (activitiesPage > 1) { activitiesPage--; loadActivities(); } }
function nextPage() { if (activitiesPage < totalActivitiesPages) { activitiesPage++; loadActivities(); } }

function refreshProfile() {
    loadProfile();
    loadActivities();
    showToast('Profile refreshed!', 'info');
}

// Set current date
const dateElem = document.getElementById('heroDate');
if (dateElem) { 
    const date = new Date();
    dateElem.innerHTML = date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }); 
}

// Get admin name for sidebar
const user = JSON.parse(localStorage.getItem('adminUser') || '{}');
const adminNameElem = document.getElementById('adminName');
if (adminNameElem) {
    if (user.fullname) adminNameElem.innerHTML = user.fullname.split(' ')[0];
    else if (user.username) adminNameElem.innerHTML = user.username;
}

// Initialize
if (adminToken && adminToken !== 'null' && adminToken.length > 20) {
    loadProfile();
    loadActivities();
} else {
    window.location.href = 'admin_login.html';
}
</script>
</body>
</html>