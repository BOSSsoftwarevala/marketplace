<?php include('head.php'); ?>
<body data-active="packages" data-crumbs="Workspace | Packages">
<div class="shell">
<?php include('sidebar.php'); ?>
<div class="main">
<?php include('topbar.php'); ?>
<main class="content">
<section class="hero">
<div class="hero-text">
<span class="eyebrow" id="heroDate">Package Management</span>
<h1 class="hero-title">Manage <span class="accent">Packages</span></h1>
<p class="hero-sub" id="heroSubText">Create, edit, and manage internet service packages</p>
</div>
<div class="hero-actions">
<button class="btn btn--ghost" onclick="exportPackages()"><svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/></svg> Export</button>
<button class="btn btn--primary" onclick="showAddPackageModal()"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg> Add Package</button>
</div>
</section>

<!-- Package Statistics KPI Grid -->
<section class="kpi-grid" aria-label="Package metrics">
<article class="kpi-card c-success">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon success"><svg viewBox="0 0 24 24"><path d="M20 12H4M12 4v16"/></svg></div>
<div class="kpi-label">Total Packages</div>
</div>
</div>
<div class="kpi-value" id="totalPackages">0</div>
<div class="kpi-compare">Available packages</div>
</article>

<article class="kpi-card c-danger">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon danger"><svg viewBox="0 0 24 24"><path d="M12 8v4M12 16h.01"/></svg></div>
<div class="kpi-label">Avg Price</div>
</div>
</div>
<div class="kpi-value" id="avgPrice"> 0</div>
<div class="kpi-compare">Across all packages</div>
</article>

<article class="kpi-card c-purple">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon purple"><svg viewBox="0 0 24 24"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg></div>
<div class="kpi-label">Price Range</div>
</div>
</div>
<div class="kpi-value" id="priceRange"> 0</div>
<div class="kpi-compare">Min - Max</div>
</article>

<article class="kpi-card c-primary">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon primary"><svg viewBox="0 0 24 24"><path d="M12 8v4M12 16h.01"/></svg></div>
<div class="kpi-label">Most Popular</div>
</div>
</div>
<div class="kpi-value" id="mostPopular">-</div>
<div class="kpi-compare">Highest customers</div>
</article>
</section>

<!-- Packages Table -->
<section class="col-12 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Package List</span>
<h2 class="card-title">All Packages</h2>
</div>
<div class="card-actions">
<input type="text" id="searchInput" placeholder="Search packages..." class="search-input" style="padding: 6px 12px; border-radius: 6px; border: 1px solid var(--border); background: var(--bg);">
</div>
</div>
<div class="table-responsive">
<table class="table">
<thead>
<tr>
<th>ID</th>
<th>Package Name</th>
<th>Price</th>
<th>Validity</th>
<th>Data Limit</th>
<th>Speed (Down/Up)</th>
<th>Customers</th>
<th>Actions</th>
</tr>
</thead>
<tbody id="packagesTableBody">
<tr><td colspan="8" class="text-center">Loading packages...</td></tr>
</tbody>
</table>
</div>
</section>

<!-- Toast Container -->
<div id="toastContainer" style="position: fixed; top: 20px; right: 20px; z-index: 9999;"></div>

<!-- Add/Edit Package Modal -->
<div id="packageModal" class="modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
    <div class="modal-content" style="background: white; border-radius: 12px; max-width: 550px; width: 90%; padding: 24px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1);">
        <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h3 style="margin: 0;" id="modalTitle">Add New Package</h3>
            <button onclick="closePackageModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: #666;">&times;</button>
        </div>
        <form id="packageForm">
            <input type="hidden" id="package_id">
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Package Name *</label>
                <input type="text" id="package_name" class="input" required style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Price () *</label>
                <input type="number" id="price" class="input" required step="0.01" style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Validity (Days) *</label>
                <input type="number" id="validity_days" class="input" required style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Data Limit (MB) <small>(0 = Unlimited)</small></label>
                <input type="number" id="data_limit_mb" class="input" value="0" style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Upload Speed</label>
                <input type="text" id="upload_speed" class="input" placeholder="e.g., 1M, 2M, 5M" style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Download Speed</label>
                <input type="text" id="download_speed" class="input" placeholder="e.g., 1M, 2M, 5M" style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Description</label>
                <textarea id="description" class="input" rows="3" style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;"></textarea>
            </div>
            <button type="submit" class="btn btn--primary" style="width: 100%; padding: 10px; background: #4f46e5; color: white; border: none; border-radius: 6px; cursor: pointer;">Save Package</button>
        </form>
    </div>
</div>

<!-- View Package Modal -->
<div id="viewPackageModal" class="modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
    <div class="modal-content" style="background: white; border-radius: 12px; max-width: 500px; width: 90%; padding: 24px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1);">
        <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h3 style="margin: 0;">Package Details</h3>
            <button onclick="closeViewModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: #666;">&times;</button>
        </div>
        <div id="viewPackageDetails" style="max-height: 400px; overflow-y: auto;"></div>
        <div style="margin-top: 20px; display: flex; gap: 10px; justify-content: flex-end;">
            <button onclick="closeViewModal()" class="btn btn--ghost" style="padding: 8px 16px;">Close</button>
            <button onclick="editFromView()" class="btn btn--primary" id="editFromViewBtn" style="padding: 8px 16px;">Edit Package</button>
        </div>
    </div>
</div>

</main>
<?php include('footer.php'); ?>
</div>
</div>

<script>
// ============================================
// PACKAGE MANAGEMENT PAGE WITH TOAST NOTIFICATIONS
// ============================================

// const API_BASE_URL = 'https://shabanetech.top/wifi-api';
// let adminToken = localStorage.getItem('adminToken');
let currentPackages = [];
let currentViewPackage = null;
let currentEditId = null;

// ==================== TOAST NOTIFICATIONS ====================

function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '✗' : type === 'warning' ? '⚠' : 'ℹ'}</div>
        <div class="toast-message">${message}</div>
        <button class="toast-close" onclick="this.parentElement.remove()">×</button>
    `;
    
    container.appendChild(toast);
    
    setTimeout(() => {
        if (toast.parentElement) {
            toast.style.animation = 'slideOut 0.3s ease forwards';
            setTimeout(() => toast.remove(), 300);
        }
    }, 4000);
}

// Add toast styles
const toastStyles = document.createElement('style');
toastStyles.textContent = `
    .toast {
        display: flex;
        align-items: center;
        gap: 12px;
        background: white;
        border-radius: 8px;
        padding: 12px 16px;
        margin-bottom: 10px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        animation: slideIn 0.3s ease forwards;
        min-width: 280px;
        border-left: 4px solid;
    }
    .toast-success { border-left-color: #10b981; }
    .toast-error { border-left-color: #ef4444; }
    .toast-warning { border-left-color: #f59e0b; }
    .toast-info { border-left-color: #3b82f6; }
    .toast-icon {
        width: 24px;
        height: 24px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        font-size: 14px;
    }
    .toast-success .toast-icon { background: #10b98120; color: #10b981; }
    .toast-error .toast-icon { background: #ef444420; color: #ef4444; }
    .toast-warning .toast-icon { background: #f59e0b20; color: #f59e0b; }
    .toast-info .toast-icon { background: #3b82f620; color: #3b82f6; }
    .toast-message { flex: 1; font-size: 14px; color: #333; }
    .toast-close {
        background: none;
        border: none;
        font-size: 18px;
        cursor: pointer;
        color: #999;
        padding: 0;
        width: 20px;
        height: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .toast-close:hover { color: #666; }
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
`;
document.head.appendChild(toastStyles);

// Helper function for API calls
async function apiFetch(endpoint, options = {}) {
    if (!adminToken) {
        window.location.href = 'signin.html';
        return null;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            ...options,
            headers: {
                'Authorization': `Bearer ${adminToken}`,
                'Content-Type': 'application/json',
                ...options.headers
            }
        });
        
        if (response.status === 401) {
            localStorage.removeItem('adminToken');
            localStorage.removeItem('adminUser');
            window.location.href = 'signin.html';
            return null;
        }
        
        return await response.json();
    } catch (error) {
        console.error('API Error:', error);
        return null;
    }
}

// Format helpers
function formatCurrency(amount) {
    return ' ' + parseFloat(amount || 0).toLocaleString();
}

function formatDataLimit(mb) {
    if (!mb || mb === 0) return 'Unlimited';
    const gb = mb / 1024;
    if (gb >= 1) return gb.toFixed(0) + ' GB';
    return mb.toFixed(0) + ' MB';
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Load packages and update stats
async function loadPackages() {
    const tbody = document.getElementById('packagesTableBody');
    tbody.innerHTML = '<tr><td colspan="8" class="text-center">Loading packages...</td></tr>';
    
    const response = await apiFetch('/api/packages');
    
    if (response && response.success && response.data) {
        currentPackages = response.data;
        
        if (currentPackages.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" class="text-center">No packages found</td></tr>';
        } else {
            tbody.innerHTML = currentPackages.map(pkg => `
                <tr>
                    <td>${pkg.id}</td>
                    <td class="cell-name">
                        <strong>${escapeHtml(pkg.package_name)}</strong><br>
                        <small>${escapeHtml(pkg.description || 'No description')}</small>
                    </td>
                    <td class="cell-price pos">${formatCurrency(pkg.price)}</td>
                    <td>${pkg.validity_days} days</td>
                    <td>${formatDataLimit(pkg.data_limit_mb)}</td>
                    <td>${pkg.download_speed || '1M'} / ${pkg.upload_speed || '1M'}</td>
                    <td><span class="tag t-new" id="customerCount_${pkg.id}">-</span></td>
                    <td>
                        <button class="btn-icon" onclick="viewPackage(${pkg.id})" title="View">👁️</button>
                        <button class="btn-icon" onclick="editPackage(${pkg.id})" title="Edit">✏️</button>
                        <button class="btn-icon" onclick="deletePackage(${pkg.id})" title="Delete">🗑️</button>
                    </td>
                </tr>
            `).join('');
        }
        
        // Update KPIs
        updatePackageStats(currentPackages);
        
        // Load customer counts for each package
        await loadCustomerCounts();
    } else {
        tbody.innerHTML = '<tr><td colspan="8" class="text-center">Failed to load packages</td></tr>';
    }
}

// Load customer counts for each package
async function loadCustomerCounts() {
    const customersResponse = await apiFetch('/api/customers');
    if (customersResponse && customersResponse.success && customersResponse.data) {
        const customers = customersResponse.data;
        const packageCounts = {};
        
        customers.forEach(customer => {
            if (customer.package_id) {
                packageCounts[customer.package_id] = (packageCounts[customer.package_id] || 0) + 1;
            }
        });
        
        // Update customer count badges
        for (const pkg of currentPackages) {
            const countSpan = document.getElementById(`customerCount_${pkg.id}`);
            if (countSpan) {
                const count = packageCounts[pkg.id] || 0;
                countSpan.innerHTML = count;
                countSpan.className = `tag ${count > 0 ? 't-new' : 't-unavail'}`;
            }
        }
        
        // Find most popular package
        let mostPopular = null;
        let maxCount = 0;
        for (const [pkgId, count] of Object.entries(packageCounts)) {
            if (count > maxCount) {
                maxCount = count;
                const pkg = currentPackages.find(p => p.id == pkgId);
                mostPopular = pkg;
            }
        }
        
        if (mostPopular) {
            document.getElementById('mostPopular').innerHTML = mostPopular.package_name;
        } else {
            document.getElementById('mostPopular').innerHTML = '-';
        }
    }
}

// Update package statistics
function updatePackageStats(packages) {
    const total = packages.length;
    const totalPrice = packages.reduce((sum, pkg) => sum + parseFloat(pkg.price), 0);
    const avgPrice = total > 0 ? totalPrice / total : 0;
    const minPrice = packages.length > 0 ? Math.min(...packages.map(p => p.price)) : 0;
    const maxPrice = packages.length > 0 ? Math.max(...packages.map(p => p.price)) : 0;
    
    document.getElementById('totalPackages').innerHTML = total;
    document.getElementById('avgPrice').innerHTML = formatCurrency(avgPrice);
    document.getElementById('priceRange').innerHTML = `${formatCurrency(minPrice)} - ${formatCurrency(maxPrice)}`;
}

// Add/Update package
document.getElementById('packageForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const packageId = document.getElementById('package_id').value;
    const packageData = {
        package_name: document.getElementById('package_name').value,
        price: parseFloat(document.getElementById('price').value),
        validity_days: parseInt(document.getElementById('validity_days').value),
        data_limit_mb: parseInt(document.getElementById('data_limit_mb').value) || 0,
        upload_speed: document.getElementById('upload_speed').value || '1M',
        download_speed: document.getElementById('download_speed').value || '1M',
        description: document.getElementById('description').value || null
    };
    
    let response;
    if (packageId) {
        // Update existing package
        response = await apiFetch(`/api/packages/${packageId}`, {
            method: 'PUT',
            body: JSON.stringify(packageData)
        });
    } else {
        // Create new package
        response = await apiFetch('/api/packages', {
            method: 'POST',
            body: JSON.stringify(packageData)
        });
    }
    
    if (response && response.success) {
        showToast(`Package ${packageData.package_name} ${packageId ? 'updated' : 'created'} successfully!`, 'success');
        closePackageModal();
        loadPackages();
        document.getElementById('packageForm').reset();
        document.getElementById('package_id').value = '';
    } else {
        showToast(response?.error || 'Failed to save package', 'error');
    }
});

// View package
async function viewPackage(id) {
    const response = await apiFetch(`/api/packages/${id}`);
    if (response && response.success && response.data) {
        currentViewPackage = response.data;
        const pkg = response.data;
        document.getElementById('viewPackageDetails').innerHTML = `
            <div class="package-info">
                <p><strong>ID:</strong> ${pkg.id}</p>
                <p><strong>Package Name:</strong> ${escapeHtml(pkg.package_name)}</p>
                <p><strong>Price:</strong> ${formatCurrency(pkg.price)}</p>
                <p><strong>Validity:</strong> ${pkg.validity_days} days</p>
                <p><strong>Data Limit:</strong> ${formatDataLimit(pkg.data_limit_mb)}</p>
                <p><strong>Download Speed:</strong> ${pkg.download_speed || '1M'}</p>
                <p><strong>Upload Speed:</strong> ${pkg.upload_speed || '1M'}</p>
                <p><strong>Description:</strong> ${escapeHtml(pkg.description || 'No description')}</p>
                <p><strong>Created:</strong> ${new Date(pkg.created_at).toLocaleString()}</p>
            </div>
        `;
        document.getElementById('viewPackageModal').style.display = 'flex';
    }
}

function editFromView() {
    if (currentViewPackage) {
        closeViewModal();
        editPackage(currentViewPackage.id);
    }
}

// Edit package
async function editPackage(id) {
    const response = await apiFetch(`/api/packages/${id}`);
    if (response && response.success && response.data) {
        const pkg = response.data;
        currentEditId = pkg.id;
        
        document.getElementById('modalTitle').innerText = 'Edit Package';
        document.getElementById('package_id').value = pkg.id;
        document.getElementById('package_name').value = pkg.package_name;
        document.getElementById('price').value = pkg.price;
        document.getElementById('validity_days').value = pkg.validity_days;
        document.getElementById('data_limit_mb').value = pkg.data_limit_mb || 0;
        document.getElementById('upload_speed').value = pkg.upload_speed || '1M';
        document.getElementById('download_speed').value = pkg.download_speed || '1M';
        document.getElementById('description').value = pkg.description || '';
        
        document.getElementById('packageModal').style.display = 'flex';
    }
}

// Delete package
async function deletePackage(id) {
    const pkg = currentPackages.find(p => p.id === id);
    if (!pkg) return;
    
    if (confirm(`Are you sure you want to delete "${pkg.package_name}"? This action cannot be undone.`)) {
        const response = await apiFetch(`/api/packages/${id}`, { method: 'DELETE' });
        if (response && response.success) {
            showToast(`Package "${pkg.package_name}" deleted successfully!`, 'success');
            loadPackages();
        } else {
            showToast(response?.error || 'Failed to delete package', 'error');
        }
    }
}

// Modal functions
function showAddPackageModal() {
    document.getElementById('modalTitle').innerText = 'Add New Package';
    document.getElementById('packageForm').reset();
    document.getElementById('package_id').value = '';
    document.getElementById('packageModal').style.display = 'flex';
}

function closePackageModal() {
    document.getElementById('packageModal').style.display = 'none';
}

function closeViewModal() {
    document.getElementById('viewPackageModal').style.display = 'none';
    currentViewPackage = null;
}

// Search packages
document.getElementById('searchInput')?.addEventListener('input', (e) => {
    const searchTerm = e.target.value.toLowerCase();
    const filtered = currentPackages.filter(pkg => 
        pkg.package_name.toLowerCase().includes(searchTerm) ||
        (pkg.description && pkg.description.toLowerCase().includes(searchTerm))
    );
    
    const tbody = document.getElementById('packagesTableBody');
    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="text-center">No packages found</td></tr>';
    } else {
        tbody.innerHTML = filtered.map(pkg => `
            <tr>
                <td>${pkg.id}</td>
                <td class="cell-name">
                    <strong>${escapeHtml(pkg.package_name)}</strong><br>
                    <small>${escapeHtml(pkg.description || 'No description')}</small>
                </td>
                <td class="cell-price pos">${formatCurrency(pkg.price)}</td>
                <td>${pkg.validity_days} days</td>
                <td>${formatDataLimit(pkg.data_limit_mb)}</td>
                <td>${pkg.download_speed || '1M'} / ${pkg.upload_speed || '1M'}</td>
                <td><span class="tag t-new" id="customerCount_${pkg.id}">-</span></td>
                <td>
                    <button class="btn-icon" onclick="viewPackage(${pkg.id})" title="View">👁️</button>
                    <button class="btn-icon" onclick="editPackage(${pkg.id})" title="Edit">✏️</button>
                    <button class="btn-icon" onclick="deletePackage(${pkg.id})" title="Delete">🗑️</button>
                </td>
            </tr>
        `).join('');
        
        // Reload customer counts for filtered view
        loadCustomerCounts();
    }
});

function exportPackages() {
    showToast('Export feature coming soon!', 'info');
}

// Set current date
const dateElem = document.getElementById('heroDate');
if (dateElem) {
    const date = new Date();
    dateElem.innerHTML = date.toLocaleDateString('en-US', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
}

// Get admin name
const user = JSON.parse(localStorage.getItem('adminUser') || '{}');
const adminNameElem = document.getElementById('adminName');
if (adminNameElem) {
    if (user.fullname) {
        adminNameElem.innerHTML = user.fullname.split(' ')[0];
    } else if (user.username) {
        adminNameElem.innerHTML = user.username;
    }
}

// Check authentication and load data
if (adminToken && adminToken !== 'null' && adminToken.length > 20) {
    loadPackages();
} else {
    window.location.href = 'signin.html';
}

// Close modal when clicking outside
window.onclick = function(event) {
    const packageModal = document.getElementById('packageModal');
    const viewModal = document.getElementById('viewPackageModal');
    if (event.target === packageModal) closePackageModal();
    if (event.target === viewModal) closeViewModal();
}
</script>

<style>
.text-center { text-align: center; }
.table-responsive { overflow-x: auto; }
.tag { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 500; }
.t-new { background: #dcfce7; color: #166534; }
.t-unavail { background: #fee2e2; color: #991b1b; }
.cell-name strong { display: block; }
.cell-name small { font-size: 11px; color: #6b7280; }
.cell-price.pos { color: #10b981; font-weight: 600; }
.btn-icon { background: none; border: none; cursor: pointer; font-size: 18px; padding: 4px 8px; border-radius: 4px; transition: background 0.2s; }
.btn-icon:hover { background: #f0f0f0; }
.search-input { margin-left: 8px; }
.card-actions { display: flex; gap: 8px; }
.package-info p { margin: 8px 0; padding: 8px 0; border-bottom: 1px solid #eee; }
.package-info p:last-child { border-bottom: none; }
</style>
</body>
</html>