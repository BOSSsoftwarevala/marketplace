<?php include('head.php'); ?>
<body data-active="mpesa_transactions" data-crumbs="Workspace | M-PESA Transactions">
<div class="shell">
<?php include('sidebar.php'); ?>
<div class="main">
<?php include('topbar.php'); ?>
<main class="content">
<section class="hero">
<div class="hero-text">
<span class="eyebrow" id="heroDate">M-PESA Transactions</span>
<h1 class="hero-title">Manage <span class="accent">M-PESA</span> Transactions</h1>
<p class="hero-sub" id="heroSubText">Initiate STK Push and track all M-PESA payment transactions</p>
</div>
<div class="hero-actions">
<button class="btn btn--primary" onclick="showStkPushModal()"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg> STK Push</button>
<button class="btn btn--ghost" onclick="exportTransactions()"><svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/></svg> Export</button>
<button class="btn btn--ghost" onclick="refreshData()"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg> Refresh</button>
</div>
</section>

<!-- M-PESA Statistics KPI Grid -->
<section class="kpi-grid" aria-label="M-PESA metrics">
<article class="kpi-card c-success">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon success"><svg viewBox="0 0 24 24"><path d="M20 12H4M12 4v16"/></svg></div>
<div class="kpi-label">Total Transactions</div>
</div>
</div>
<div class="kpi-value" id="totalTransactions">0</div>
<div class="kpi-compare">All time</div>
</article>

<article class="kpi-card c-danger">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon danger"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg></div>
<div class="kpi-label">Total Amount</div>
</div>
</div>
<div class="kpi-value" id="totalAmount"> 0</div>
<div class="kpi-compare">Processed value</div>
</article>

<article class="kpi-card c-purple">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon purple"><svg viewBox="0 0 24 24"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg></div>
<div class="kpi-label">Today's Amount</div>
</div>
</div>
<div class="kpi-value" id="todayAmount"> 0</div>
<div class="kpi-compare" id="todayCount">0 transactions</div>
</article>

<article class="kpi-card c-primary">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon primary"><svg viewBox="0 0 24 24"><path d="M18 20V10M12 20V4M6 20v-4"/></svg></div>
<div class="kpi-label">Success Rate</div>
</div>
</div>
<div class="kpi-value" id="successRate">0%</div>
<div class="kpi-compare">Payment success</div>
</article>
</section>

<!-- Filters Section -->
<section class="col-12 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Filters</span>
<h2 class="card-title">Search & Filter Transactions</h2>
</div>
</div>
<div class="filter-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; padding: 16px;">
<input type="text" id="searchInput" placeholder="Search by customer or receipt..." class="input" style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
<input type="date" id="startDate" class="input" style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
<input type="date" id="endDate" class="input" style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
<select id="statusFilter" class="input" style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
<option value="all">All Status</option>
<option value="completed">Completed</option>
<option value="pending">Pending</option>
<option value="failed">Failed</option>
</select>

<button onclick="applyFilters()" class="btn btn--primary" style="padding: 8px 16px;">Apply Filters</button>
<button onclick="resetFilters()" class="btn btn--ghost" style="padding: 8px 16px;">Reset</button>
</div>
</section>
<br>
<!-- Recent Payments Table -->
<section class="col-12 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Transaction List</span>
<h2 class="card-title">Recent M-PESA Transactions</h2>
</div>
</div>
<div class="table-responsive">
<table class="table">
<thead>
<th>ID</th>
<th>Customer</th>
<th>Phone</th>
<th>Amount</th>
<th>Receipt</th>
<th>Status</th>
<th>Date</th>
<th>Actions</th>
</thead>
<tbody id="transactionsTableBody">
<tr><td colspan="8" class="text-center">Loading transactions...</td></tr>
</tbody>
</table>
</div>
</section>

<!-- STK Push Modal -->
<div id="stkPushModal" class="modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
    <div class="modal-content" style="background: white; border-radius: 12px; max-width: 500px; width: 90%; max-height: 90vh; overflow-y: auto; padding: 24px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1);">
        <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h3 style="margin: 0;">Initiate STK Push</h3>
            <button onclick="closeStkPushModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: #666;">&times;</button>
        </div>
        <form id="stkPushForm">
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Customer *</label>
                <select id="customer_id" class="input" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;">
                    <option value="">Loading customers...</option>
                </select>
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Package *</label>
                <select id="package_id" class="input" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;">
                    <option value="">Loading packages...</option>
                </select>
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Phone Number</label>
                <input type="tel" id="phone" class="input" placeholder="254712345678" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;">
                <small style="color: #666;">Format: 254712345678</small>
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Amount ()</label>
                <input type="number" id="amount" class="input" readonly style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; background: #f5f5f5;">
            </div>
            <div id="stkError" style="color: #ef4444; font-size: 13px; margin-bottom: 16px; display: none; padding: 8px; background: #fee2e2; border-radius: 6px;"></div>
            <button type="submit" class="btn btn--primary" style="width: 100%; padding: 10px; background: #4f46e5; color: white; border: none; border-radius: 6px; cursor: pointer;">Send STK Push</button>
        </form>
    </div>
</div>

<!-- View Transaction Modal -->
<div id="viewTransactionModal" class="modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
    <div class="modal-content" style="background: white; border-radius: 12px; max-width: 550px; width: 90%; max-height: 90vh; overflow-y: auto; padding: 24px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1);">
        <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h3 style="margin: 0;">Transaction Details</h3>
            <button onclick="closeViewModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: #666;">&times;</button>
        </div>
        <div id="transactionDetails" style="max-height: 400px; overflow-y: auto;"></div>
        <div style="margin-top: 20px; display: flex; gap: 10px; justify-content: flex-end;">
            <button onclick="closeViewModal()" class="btn btn--ghost" style="padding: 8px 16px;">Close</button>
        </div>
    </div>
</div>

<!-- Toast Container -->
<div id="toastContainer" style="position: fixed; top: 20px; right: 20px; z-index: 9999;"></div>

</main>
<?php include('footer.php'); ?>
</div>
</div>

<script>
// ============================================
// M-PESA TRANSACTIONS PAGE - FULLY FIXED
// ============================================

// const API_BASE_URL = 'https://shabanetech.top/wifi-api';
// let adminToken = localStorage.getItem('adminToken');
let allTransactions = [];
let currentFilters = { search: '', startDate: '', endDate: '', status: 'all' };

function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `<div class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '✗' : 'ℹ'}</div><div class="toast-message">${message}</div><button class="toast-close" onclick="this.parentElement.remove()">×</button>`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 5000);
}

// Add styles
const styles = document.createElement('style');
styles.textContent = `
    .toast { display: flex; align-items: center; gap: 12px; background: white; border-radius: 8px; padding: 12px 16px; margin-bottom: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); animation: slideIn 0.3s ease forwards; min-width: 280px; border-left: 4px solid; }
    .toast-success { border-left-color: #10b981; }
    .toast-error { border-left-color: #ef4444; }
    .toast-info { border-left-color: #3b82f6; }
    .toast-icon { width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 14px; }
    .toast-success .toast-icon { background: #10b98120; color: #10b981; }
    .toast-error .toast-icon { background: #ef444420; color: #ef4444; }
    @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
    .text-center { text-align: center; }
    .table-responsive { overflow-x: auto; }
    .tag { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 500; }
    .t-success { background: #dcfce7; color: #166534; }
    .t-pending { background: #fef3c7; color: #92400e; }
    .t-failed { background: #fee2e2; color: #991b1b; }
    .btn-icon { background: none; border: none; cursor: pointer; font-size: 18px; padding: 4px 8px; border-radius: 4px; transition: background 0.2s; }
    .btn-icon:hover { background: #f0f0f0; }
    .cell-price.pos { color: #10b981; font-weight: 600; }
    .cell-date { font-size: 12px; color: #6b7280; }
    .filter-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; padding: 16px; }
    .transaction-info p { margin: 8px 0; padding: 8px 0; border-bottom: 1px solid #eee; }
    .transaction-info p:last-child { border-bottom: none; }
    .modal-content::-webkit-scrollbar { width: 8px; }
    .modal-content::-webkit-scrollbar-track { background: #f1f1f1; border-radius: 4px; }
    .modal-content::-webkit-scrollbar-thumb { background: #c1c1c1; border-radius: 4px; }
`;
document.head.appendChild(styles);

async function apiFetch(endpoint, options = {}) {
    if (!adminToken) { window.location.href = 'admin_login.html'; return null; }
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            ...options,
            headers: { 'Authorization': `Bearer ${adminToken}`, 'Content-Type': 'application/json' }
        });
        if (response.status === 401) { localStorage.removeItem('adminToken'); window.location.href = 'admin_login.html'; return null; }
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || data.message);
        return data;
    } catch (error) { 
        console.error('API Error:', error);
        return null;
    }
}

function formatCurrency(amount) { return ' ' + parseFloat(amount || 0).toLocaleString(); }
function formatDate(dateString) { if (!dateString) return '-'; const date = new Date(dateString); return date.toLocaleDateString(); }
function escapeHtml(text) { if (!text) return ''; const div = document.createElement('div'); div.textContent = text; return div.innerHTML; }
function getStatusClass(status) { if (status === 'completed') return 't-success'; if (status === 'pending') return 't-pending'; return 't-failed'; }

// Load customers for dropdown
async function loadCustomers() {
    const select = document.getElementById('customer_id');
    if (!select) return;
    select.innerHTML = '<option value="">Loading customers...</option>';
    const response = await apiFetch('/api/customers?limit=100');
    if (response && response.success && response.data && response.data.length > 0) {
        select.innerHTML = '<option value="">Select Customer</option>' + 
            response.data.map(c => `<option value="${c.id}" data-phone="${c.phone || ''}">${escapeHtml(c.fullname)} (${c.username}) - ${c.phone || 'No phone'}</option>`).join('');
    } else {
        select.innerHTML = '<option value="">No customers found</option>';
    }
}

// Load packages for dropdown
async function loadPackages() {
    const select = document.getElementById('package_id');
    if (!select) return;
    select.innerHTML = '<option value="">Loading packages...</option>';
    const response = await apiFetch('/api/packages');
    if (response && response.success && response.data && response.data.length > 0) {
        select.innerHTML = '<option value="">Select Package</option>' + 
            response.data.map(p => `<option value="${p.id}" data-price="${p.price}">${escapeHtml(p.package_name)} - ${formatCurrency(p.price)} (${p.validity_days} days)</option>`).join('');
    } else {
        select.innerHTML = '<option value="">No packages found</option>';
    }
}

// Load statistics
async function loadStats() {
    const stats = await apiFetch('/api/payments/stats');
    if (stats && stats.success && stats.data) {
        const data = stats.data;
        const totalTransactions = document.getElementById('totalTransactions');
        const totalAmount = document.getElementById('totalAmount');
        const todayAmount = document.getElementById('todayAmount');
        const todayCount = document.getElementById('todayCount');
        const successRate = document.getElementById('successRate');
        
        if (totalTransactions) totalTransactions.innerHTML = data.total_count || 0;
        if (totalAmount) totalAmount.innerHTML = formatCurrency(data.total_amount);
        if (todayAmount) todayAmount.innerHTML = formatCurrency(data.today_amount);
        if (todayCount) todayCount.innerHTML = (data.today_count || 0) + ' transactions';
        if (successRate) successRate.innerHTML = (data.success_rate || 0) + '%';
    }
}

// Load recent payments
async function loadRecentPayments() {
    const tbody = document.getElementById('transactionsTableBody');
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="8" class="text-center">Loading transactions...</td></tr>';
    
    const stats = await apiFetch('/api/payments/stats');
    if (stats && stats.success && stats.data && stats.data.recent_payments && stats.data.recent_payments.length > 0) {
        let payments = stats.data.recent_payments;
        
        // Apply filters
        if (currentFilters.search) {
            const search = currentFilters.search.toLowerCase();
            payments = payments.filter(p => 
                (p.fullname && p.fullname.toLowerCase().includes(search)) ||
                (p.username && p.username.toLowerCase().includes(search)) ||
                (p.mpesa_receipt && p.mpesa_receipt.toLowerCase().includes(search))
            );
        }
        if (currentFilters.status !== 'all') {
            payments = payments.filter(p => p.status === currentFilters.status);
        }
        if (currentFilters.startDate) {
            payments = payments.filter(p => p.created_at && p.created_at.split('T')[0] >= currentFilters.startDate);
        }
        if (currentFilters.endDate) {
            payments = payments.filter(p => p.created_at && p.created_at.split('T')[0] <= currentFilters.endDate);
        }
        
        if (payments.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" class="text-center">No transactions found</td></tr>';
        } else {
            tbody.innerHTML = payments.map(trans => `
                <tr>
                    <td>${trans.id}</td>
                    <td><strong>${escapeHtml(trans.fullname || trans.customer_name)}</strong><br><small>${escapeHtml(trans.username || '')}</small></td>
                    <td>${escapeHtml(trans.phone || '-')}</td>
                    <td class="cell-price pos">${formatCurrency(trans.amount)}</td>
                    <td><small>${escapeHtml(trans.mpesa_receipt || '-')}</small></td>
                    <td><span class="tag ${getStatusClass(trans.status)}">${trans.status || 'pending'}</span></td>
                    <td class="cell-date">${formatDate(trans.created_at)}</td>
                    <td><button class="btn-icon" onclick="viewTransaction(${trans.id})">👁️</button></td>
                </tr>
            `).join('');
        }
    } else {
        tbody.innerHTML = '<tr><td colspan="8" class="text-center">No transactions found</td></tr>';
    }
}

// View transaction
window.viewTransaction = async function(id) {
    const response = await apiFetch(`/api/payments/${id}`);
    if (response && response.success && response.data) {
        const trans = response.data;
        const detailsDiv = document.getElementById('transactionDetails');
        if (detailsDiv) {
            detailsDiv.innerHTML = `
                <div class="transaction-info">
                    <p><strong>ID:</strong> ${trans.id}</p>
                    <p><strong>Customer:</strong> ${escapeHtml(trans.fullname || trans.customer_name)}</p>
                    <p><strong>Username:</strong> ${escapeHtml(trans.username || '-')}</p>
                    <p><strong>Phone:</strong> ${escapeHtml(trans.phone || '-')}</p>
                    <p><strong>Amount:</strong> ${formatCurrency(trans.amount)}</p>
                    <p><strong>Package:</strong> ${escapeHtml(trans.package_name || '-')}</p>
                    <p><strong>Status:</strong> <span class="tag ${getStatusClass(trans.status)}">${trans.status}</span></p>
                    <p><strong>Receipt:</strong> ${escapeHtml(trans.mpesa_receipt || '-')}</p>
                    <p><strong>Date:</strong> ${formatDate(trans.created_at)}</p>
                </div>
            `;
        }
        const modal = document.getElementById('viewTransactionModal');
        if (modal) modal.style.display = 'flex';
    } else {
        showToast('Could not load transaction details', 'error');
    }
};

// Filter functions
window.applyFilters = function() {
    const searchInput = document.getElementById('searchInput');
    const startDate = document.getElementById('startDate');
    const endDate = document.getElementById('endDate');
    const statusFilter = document.getElementById('statusFilter');
    
    currentFilters.search = searchInput ? searchInput.value : '';
    currentFilters.startDate = startDate ? startDate.value : '';
    currentFilters.endDate = endDate ? endDate.value : '';
    currentFilters.status = statusFilter ? statusFilter.value : 'all';
    
    loadRecentPayments();
    showToast('Filters applied', 'info');
};

window.resetFilters = function() {
    const searchInput = document.getElementById('searchInput');
    const startDate = document.getElementById('startDate');
    const endDate = document.getElementById('endDate');
    const statusFilter = document.getElementById('statusFilter');
    
    if (searchInput) searchInput.value = '';
    if (startDate) startDate.value = '';
    if (endDate) endDate.value = '';
    if (statusFilter) statusFilter.value = 'all';
    
    currentFilters = { search: '', startDate: '', endDate: '', status: 'all' };
    loadRecentPayments();
    showToast('Filters reset', 'info');
};

// STK Push form submission
document.addEventListener('DOMContentLoaded', function() {
    const stkForm = document.getElementById('stkPushForm');
    if (stkForm) {
        stkForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const customerId = document.getElementById('customer_id')?.value;
            const packageId = document.getElementById('package_id')?.value;
            let phone = document.getElementById('phone')?.value;
            const errorDiv = document.getElementById('stkError');
            
            if (!customerId) { 
                if (errorDiv) { errorDiv.textContent = 'Please select a customer'; errorDiv.style.display = 'block'; }
                return; 
            }
            if (!packageId) { 
                if (errorDiv) { errorDiv.textContent = 'Please select a package'; errorDiv.style.display = 'block'; }
                return; 
            }
            if (!phone) { 
                if (errorDiv) { errorDiv.textContent = 'Phone number is required'; errorDiv.style.display = 'block'; }
                return; 
            }
            if (errorDiv) errorDiv.style.display = 'none';
            
            const submitBtn = e.target.querySelector('button[type="submit"]');
            const originalText = submitBtn ? submitBtn.innerHTML : 'Send STK Push';
            if (submitBtn) { submitBtn.innerHTML = 'Sending...'; submitBtn.disabled = true; }
            
            const response = await apiFetch('/api/payments/mpesa/initiate', {
                method: 'POST',
                body: JSON.stringify({
                    customer_id: parseInt(customerId),
                    package_id: parseInt(packageId),
                    phone: phone.replace(/\D/g, '')
                })
            });
            
            if (submitBtn) { submitBtn.innerHTML = originalText; submitBtn.disabled = false; }
            
            if (response && response.success) {
                showToast(`STK Push sent to ${phone}. Check customer's phone.`, 'success');
                closeStkPushModal();
                setTimeout(() => { loadStats(); loadRecentPayments(); }, 3000);
            } else {
                showToast(response?.error || 'Failed to send STK Push', 'error');
            }
        });
    }
});

// Modal functions
window.showStkPushModal = function() { 
    loadCustomers(); 
    loadPackages(); 
    const modal = document.getElementById('stkPushModal');
    if (modal) modal.style.display = 'flex';
};
window.closeStkPushModal = function() { 
    const modal = document.getElementById('stkPushModal');
    if (modal) modal.style.display = 'none';
};
window.closeViewModal = function() { 
    const modal = document.getElementById('viewTransactionModal');
    if (modal) modal.style.display = 'none';
};
window.refreshData = function() { loadStats(); loadRecentPayments(); showToast('Data refreshed!', 'success'); };
window.exportTransactions = function() { showToast('Export feature coming soon!', 'info'); };

// Set current date
const dateElem = document.getElementById('heroDate');
if (dateElem) { 
    const date = new Date();
    dateElem.innerHTML = date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }); 
}

// Get admin name
const user = JSON.parse(localStorage.getItem('adminUser') || '{}');
const adminNameElem = document.getElementById('adminName');
if (adminNameElem) {
    if (user.fullname) adminNameElem.innerHTML = user.fullname.split(' ')[0];
    else if (user.username) adminNameElem.innerHTML = user.username;
}

// Initialize
if (adminToken && adminToken !== 'null' && adminToken.length > 20) {
    loadStats();
    loadRecentPayments();
} else {
    window.location.href = 'admin_login.html';
}

// Close modals when clicking outside
window.onclick = function(event) {
    const stkModal = document.getElementById('stkPushModal');
    const viewModal = document.getElementById('viewTransactionModal');
    if (event.target === stkModal) closeStkPushModal();
    if (event.target === viewModal) closeViewModal();
}
</script>
</body>
</html>