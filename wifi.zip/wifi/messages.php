<?php include('head.php'); ?>
<body data-active="messages" data-crumbs="Workspace | Messages">
<div class="shell">
<div data-shell-sidebar></div>
<div class="main">
<div data-shell-topbar></div>
<main class="content">
<section class="hero">
<div class="hero-text">
<span class="eyebrow">Messaging · <?php echo date('Y'); ?></span>
<h1 class="hero-title">Internal <span class="accent">Messages</span></h1>
<p class="hero-sub">Send and receive messages with customers, admins, and resellers — all in one place</p>
</div>
<div class="hero-actions">
<button class="btn btn--ghost" onclick="markAllAsRead()"><svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/></svg> Mark All Read</button>
<button class="btn btn--primary" onclick="showComposeModal()"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg> New Message</button>
</div>
</section>

<div class="grid">

<!-- Total Messages Card -->
<section class="col-12 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Message Statistics</span>
<h2 class="card-title">Overview</h2>
</div>
<div class="demo-row" style="gap:6px">
<div class="btn-group">
<button class="btn btn--ghost btn--sm is-active" onclick="switchTab('inbox')">📥 Inbox <span id="inboxBadge" class="badge-count"></span></button>
<button class="btn btn--ghost btn--sm" onclick="switchTab('sent')">📤 Sent</button>
<button class="btn btn--ghost btn--sm" onclick="switchTab('archived')">📦 Archived</button>
</div>
</div>
</div>
<div class="chart-meta-row">
<div class="chart-meta-cell"><span class="chart-meta-label">Total Messages</span><span class="chart-meta-value" id="totalMessages">0</span></div>
<div class="chart-meta-cell"><span class="chart-meta-label">Unread</span><span class="chart-meta-value" id="unreadCount">0</span></div>
<div class="chart-meta-cell"><span class="chart-meta-label">Sent</span><span class="chart-meta-value" id="sentCount">0</span></div>
<div class="chart-meta-cell"><span class="chart-meta-label">This Week</span><span class="chart-meta-value" id="weeklyCount">0</span></div>
</div>
</section>

<!-- Messages List Column -->
<section class="col-6 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow" id="currentTabTitle">Inbox</span>
<h2 class="card-title" id="currentTabSubtitle">Your messages</h2>
</div>
<div class="card-actions">
<label class="check"><input type="checkbox" id="selectAll" onclick="toggleSelectAll()"> <span class="box"></span> Select all</label>
</div>
</div>
<div class="chart-canvas-wrap" style="height:400px; overflow-y: auto;" id="messagesList">
<div class="text-center" style="padding: 40px;">Loading messages...</div>
</div>
<div class="chart-meta-row" style="margin-top: 0; border-top: 1px solid var(--border);">
<div class="chart-meta-cell"><span class="chart-meta-label">Showing</span><span class="chart-meta-value" id="showingStart">0</span></div>
<div class="chart-meta-cell"><span class="chart-meta-label">to</span><span class="chart-meta-value" id="showingEnd">0</span></div>
<div class="chart-meta-cell"><span class="chart-meta-label">of</span><span class="chart-meta-value" id="totalRecords">0</span></div>
<div class="chart-meta-cell"><div class="pagination-buttons" style="display: flex; gap: 8px; justify-content: flex-end;">
<button class="btn btn--ghost btn--sm" id="prevPage" onclick="prevPage()" disabled>← Previous</button>
<button class="btn btn--ghost btn--sm" id="nextPage" onclick="nextPage()" disabled>Next →</button>
</div></div>
</div>
</section>

<!-- Message Preview Column -->
<section class="col-6 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Message Preview</span>
<h2 class="card-title">Selected Message</h2>
</div>
<div style="display: flex; gap: 8px;">
<input type="text" id="searchInput" placeholder="Search messages..." class="search-input" style="padding: 6px 12px; border: 1px solid var(--border); border-radius: 6px; width: 160px;">
<select id="filterSelect" class="status-filter" style="padding: 6px 12px; border: 1px solid var(--border); border-radius: 6px;">
<option value="all">All</option>
<option value="read">Read</option>
<option value="unread">Unread</option>
</select>
</div>
</div>
<div class="chart-canvas-wrap" style="height:400px; overflow-y: auto;" id="messagePreview">
<p class="text-center" style="padding: 40px;">Select a message to view details</p>
</div>
<div class="chart-meta-row" style="margin-top: 0; border-top: 1px solid var(--border);">
<div class="chart-meta-cell"><button class="btn btn--primary btn--sm" id="replyBtn" style="display: none;" onclick="replyToCurrent()">↩️ Reply</button></div>
<div class="chart-meta-cell"><button class="btn btn--secondary btn--sm" id="archiveBtn" style="display: none;" onclick="archiveCurrent()">📦 Archive</button></div>
<div class="chart-meta-cell"><button class="btn btn--danger btn--sm" id="deleteBtn" style="display: none;" onclick="deleteCurrent()">🗑️ Delete</button></div>
</div>
</section>

<!-- Bulk Actions -->
<section class="col-12 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Bulk Actions</span>
<h2 class="card-title">Selected Messages</h2>
</div>
</div>
<div class="chart-meta-row" style="border:0;padding:0;margin:0;gap:24px">
<div class="chart-meta-cell"><span class="chart-meta-label">Selected</span><span class="chart-meta-value" id="selectedCount">0</span></div>
<div class="chart-meta-cell"><button onclick="markSelectedAsRead()" class="btn btn--primary btn--sm">✓ Mark as Read</button></div>
<div class="chart-meta-cell"><button onclick="archiveSelected()" class="btn btn--secondary btn--sm">📦 Archive</button></div>
<div class="chart-meta-cell"><button onclick="deleteSelected()" class="btn btn--danger btn--sm">🗑️ Delete</button></div>
</div>
</section>

</div>

<!-- Compose Message Modal -->
<div id="composeModal" class="modal" style="display: none;">
<div class="modal-content" style="max-width: 600px;">
<div class="modal-header"><h3>New Message</h3><button class="modal-close" onclick="closeComposeModal()">&times;</button></div>
<form id="composeForm">
<div class="field"><label>To</label>
<div style="display: flex; gap: 10px;">
<select id="recipient_type" style="padding: 10px; border: 1px solid #ddd; border-radius: 6px; width: 120px;">
<option value="customer">Customer</option><option value="admin">Admin</option><option value="reseller">Reseller</option>
</select>
<select id="recipient_id" style="flex: 1; padding: 10px; border: 1px solid #ddd; border-radius: 6px;" required><option value="">Select recipient...</option></select>
</div>
</div>
<div class="field"><label>Subject</label><input type="text" id="subject" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;" required placeholder="Message subject"></div>
<div class="field"><label>Message</label><textarea id="message" rows="6" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;" required placeholder="Type your message here..."></textarea></div>
<div id="composeErrors" class="form-errors" style="display: none;"></div>
<div class="modal-footer"><button type="button" class="btn btn--ghost" onclick="closeComposeModal()">Cancel</button><button type="submit" class="btn btn--primary">Send Message</button></div>
</form>
</div>
</div>

<!-- Reply Modal -->
<div id="replyModal" class="modal" style="display: none;">
<div class="modal-content" style="max-width: 550px;">
<div class="modal-header"><h3>Reply to Message</h3><button class="modal-close" onclick="closeReplyModal()">&times;</button></div>
<form id="replyForm">
<input type="hidden" id="reply_to_id">
<div class="field"><label>To</label><input type="text" id="reply_to_name" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;" readonly></div>
<div class="field"><label>Subject</label><input type="text" id="reply_subject" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;" readonly></div>
<div class="field"><label>Message</label><textarea id="reply_message" rows="5" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;" required placeholder="Type your reply..."></textarea></div>
<div id="replyErrors" class="form-errors" style="display: none;"></div>
<div class="modal-footer"><button type="button" class="btn btn--ghost" onclick="closeReplyModal()">Cancel</button><button type="submit" class="btn btn--primary">Send Reply</button></div>
</form>
</div>
</div>

</main>
<div data-shell-footer></div>
</div>
</div>

<script>
// ============================================
// MESSAGING SYSTEM - EXACT STRUCTURE MATCH
// ============================================

// const API_BASE_URL = 'https://shabanetech.top/wifi-api';
// let adminToken = localStorage.getItem('adminToken');
let allMessages = [];
let currentPage = 1;
let itemsPerPage = 10;
let currentTab = 'inbox';
let currentFilters = { search: '', status: 'all' };
let selectedMessages = new Set();
let currentViewMessage = null;

function showToast(message, type = 'success') {
    let container = document.getElementById('toastContainer');
    if (!container) { container = document.createElement('div'); container.id = 'toastContainer'; document.body.appendChild(container); }
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `<div class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '✗' : 'ℹ'}</div><div class="toast-message">${message}</div><button class="toast-close" onclick="this.parentElement.remove()">×</button>`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}

async function apiFetch(endpoint, options = {}) {
    if (!adminToken) { window.location.href = 'admin_login.html'; return null; }
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            ...options,
            headers: { 'Authorization': `Bearer ${adminToken}`, 'Content-Type': 'application/json' }
        });
        if (response.status === 401) { localStorage.removeItem('adminToken'); window.location.href = 'admin_login.html'; return null; }
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || data.message);
        return data;
    } catch (error) { showToast(error.message, 'error'); return null; }
}

function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    const now = new Date();
    const diff = Math.floor((now - date) / 1000 / 60);
    if (diff < 1) return 'Just now';
    if (diff < 60) return `${diff} min ago`;
    if (diff < 1440) return `${Math.floor(diff / 60)} hours ago`;
    return date.toLocaleDateString();
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

async function loadStats() {
    const response = await apiFetch('/api/admin/messages/stats');
    if (response && response.success && response.data) {
        const data = response.data;
        document.getElementById('totalMessages').innerHTML = data.total || 0;
        document.getElementById('unreadCount').innerHTML = data.unread || 0;
        document.getElementById('sentCount').innerHTML = data.sent || 0;
        document.getElementById('weeklyCount').innerHTML = data.weekly || 0;
        const inboxBadge = document.getElementById('inboxBadge');
        if (inboxBadge) inboxBadge.innerHTML = data.unread > 0 ? data.unread : '';
    }
}

function renderMessages(messages) {
    if (messages.length === 0) {
        return '<div class="text-center" style="padding: 40px;">No messages found</div>';
    }
    return messages.map(msg => `
        <div class="message-item ${!msg.is_read && currentTab !== 'sent' ? 'unread' : ''} ${selectedMessages.has(msg.id) ? 'selected' : ''}" onclick="selectMessage(${msg.id})" style="padding: 16px; border-bottom: 1px solid var(--border); cursor: pointer;">
            <div style="display: flex; align-items: flex-start; gap: 12px;">
                <input type="checkbox" class="message-checkbox" value="${msg.id}" ${selectedMessages.has(msg.id) ? 'checked' : ''} onclick="event.stopPropagation(); toggleMessageSelection(${msg.id})" style="margin-top: 2px;">
                <div style="flex: 1;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                        <span style="font-weight: 500; font-size: 14px;"><strong>${escapeHtml(currentTab === 'sent' ? msg.recipient_name : msg.sender_name)}</strong> <small style="font-weight: normal; color: #6b7280;">(${currentTab === 'sent' ? msg.recipient_type : msg.sender_type})</small></span>
                        <span style="font-size: 11px; color: #6b7280;">${formatDate(msg.created_at)}</span>
                    </div>
                    <div style="font-size: 14px; margin-bottom: 8px; ${!msg.is_read && currentTab !== 'sent' ? 'font-weight: 600;' : ''}">${!msg.is_read && currentTab !== 'sent' ? '📩 ' : ''}${escapeHtml(msg.subject)}</div>
                    <div style="font-size: 12px; color: #6b7280; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${escapeHtml(msg.message.substring(0, 80))}${msg.message.length > 80 ? '...' : ''}</div>
                    <div style="display: flex; gap: 8px; margin-top: 8px;">
                        <button class="btn-icon" onclick="event.stopPropagation(); replyToMessage(${msg.id})" style="background: none; border: none; cursor: pointer; font-size: 16px;">↩️</button>
                        <button class="btn-icon" onclick="event.stopPropagation(); deleteMessage(${msg.id})" style="background: none; border: none; cursor: pointer; font-size: 16px;">🗑️</button>
                    </div>
                </div>
            </div>
        </div>
    `).join('');
}

async function loadMessages() {
    const container = document.getElementById('messagesList');
    if (!container) return;
    container.innerHTML = '<div class="text-center" style="padding: 40px;">Loading messages...</div>';
    
    let url = `/api/admin/messages?type=${currentTab}&page=${currentPage}&limit=${itemsPerPage}`;
    if (currentFilters.search) url += `&search=${encodeURIComponent(currentFilters.search)}`;
    if (currentFilters.status !== 'all') url += `&is_read=${currentFilters.status === 'read' ? 1 : 0}`;
    
    const response = await apiFetch(url);
    if (response && response.success && response.data) {
        allMessages = response.data;
        const pagination = response.pagination;
        container.innerHTML = renderMessages(allMessages);
        if (pagination) {
            document.getElementById('showingStart').innerHTML = ((currentPage - 1) * itemsPerPage) + 1;
            document.getElementById('showingEnd').innerHTML = Math.min(currentPage * itemsPerPage, pagination.total);
            document.getElementById('totalRecords').innerHTML = pagination.total;
            document.getElementById('prevPage').disabled = currentPage <= 1;
            document.getElementById('nextPage').disabled = currentPage >= pagination.pages;
        }
        updateSelectedCount();
    }
}

function selectMessage(id) {
    const message = allMessages.find(m => m.id === id);
    if (message) {
        currentViewMessage = message;
        const previewContainer = document.getElementById('messagePreview');
        if (previewContainer) {
            previewContainer.innerHTML = `
                <div style="padding: 16px;">
                    <div style="border-bottom: 1px solid var(--border); padding-bottom: 16px; margin-bottom: 16px;">
                        <div style="font-size: 18px; font-weight: 600; margin-bottom: 8px;">${escapeHtml(message.subject)}</div>
                        <div style="font-size: 12px; color: #6b7280;">
                            <strong>From:</strong> ${escapeHtml(message.sender_name)} (${message.sender_type})<br>
                            <strong>To:</strong> ${escapeHtml(message.recipient_name)} (${message.recipient_type})<br>
                            <strong>Date:</strong> ${new Date(message.created_at).toLocaleString()}
                        </div>
                    </div>
                    <div style="line-height: 1.6;">${escapeHtml(message.message).replace(/\n/g, '<br>')}</div>
                </div>
            `;
        }
        document.getElementById('replyBtn').style.display = 'inline-block';
        document.getElementById('archiveBtn').style.display = currentTab !== 'archived' ? 'inline-block' : 'none';
        document.getElementById('deleteBtn').style.display = 'inline-block';
        if (!message.is_read && currentTab !== 'sent') markAsRead(message.id);
    }
}

function replyToCurrent() { if (currentViewMessage) replyToMessage(currentViewMessage.id); }
function archiveCurrent() { if (currentViewMessage) archiveMessage(currentViewMessage.id); }
function deleteCurrent() { if (currentViewMessage) deleteMessage(currentViewMessage.id); }

async function markAsRead(id) {
    const response = await apiFetch(`/api/admin/messages/${id}/read`, { method: 'PUT' });
    if (response && response.success) { loadMessages(); loadStats(); }
}

async function deleteMessage(id) {
    if (confirm('Delete this message?')) {
        const response = await apiFetch(`/api/admin/messages/${id}`, { method: 'DELETE' });
        if (response && response.success) {
            showToast('Message deleted', 'success');
            selectedMessages.delete(id);
            if (currentViewMessage?.id === id) {
                currentViewMessage = null;
                document.getElementById('messagePreview').innerHTML = '<p class="text-center" style="padding: 40px;">Select a message to view details</p>';
                document.getElementById('replyBtn').style.display = 'none';
                document.getElementById('archiveBtn').style.display = 'none';
                document.getElementById('deleteBtn').style.display = 'none';
            }
            loadMessages(); loadStats();
        }
    }
}

async function archiveMessage(id) {
    const response = await apiFetch(`/api/admin/messages/archive`, { method: 'POST', body: JSON.stringify({ ids: [id] }) });
    if (response && response.success) {
        showToast('Message archived', 'success');
        if (currentViewMessage?.id === id) {
            currentViewMessage = null;
            document.getElementById('messagePreview').innerHTML = '<p class="text-center" style="padding: 40px;">Select a message to view details</p>';
        }
        loadMessages(); loadStats();
    }
}

async function replyToMessage(id) {
    const message = allMessages.find(m => m.id === id);
    if (message) {
        document.getElementById('reply_to_id').value = message.id;
        document.getElementById('reply_to_name').value = message.sender_name;
        document.getElementById('reply_subject').value = `Re: ${message.subject}`;
        document.getElementById('replyModal').style.display = 'flex';
    }
}

document.getElementById('replyForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const replyData = { message_id: parseInt(document.getElementById('reply_to_id').value), message: document.getElementById('reply_message').value.trim() };
    if (!replyData.message) { showToast('Message is required', 'error'); return; }
    const response = await apiFetch('/api/admin/messages/reply', { method: 'POST', body: JSON.stringify(replyData) });
    if (response && response.success) {
        showToast('Reply sent!', 'success');
        closeReplyModal();
        loadMessages(); loadStats();
        document.getElementById('replyForm').reset();
    }
});

function toggleSelectAll() {
    const selectAll = document.getElementById('selectAll');
    const checkboxes = document.querySelectorAll('.message-checkbox');
    checkboxes.forEach(cb => {
        cb.checked = selectAll.checked;
        const id = parseInt(cb.value);
        if (selectAll.checked) selectedMessages.add(id);
        else selectedMessages.delete(id);
    });
    updateSelectedCount();
}

function toggleMessageSelection(id) {
    if (selectedMessages.has(id)) selectedMessages.delete(id);
    else selectedMessages.add(id);
    updateSelectedCount();
}

function updateSelectedCount() { document.getElementById('selectedCount').innerHTML = selectedMessages.size; }

async function markSelectedAsRead() {
    if (selectedMessages.size === 0) { showToast('No messages selected', 'error'); return; }
    const ids = Array.from(selectedMessages);
    const response = await apiFetch('/api/admin/messages/mark-read', { method: 'POST', body: JSON.stringify({ ids: ids }) });
    if (response && response.success) {
        showToast(`${selectedMessages.size} message(s) marked as read`, 'success');
        selectedMessages.clear();
        loadMessages(); loadStats();
    }
}

async function archiveSelected() {
    if (selectedMessages.size === 0) { showToast('No messages selected', 'error'); return; }
    const ids = Array.from(selectedMessages);
    const response = await apiFetch('/api/admin/messages/archive', { method: 'POST', body: JSON.stringify({ ids: ids }) });
    if (response && response.success) {
        showToast(`${selectedMessages.size} message(s) archived`, 'success');
        selectedMessages.clear();
        loadMessages(); loadStats();
    }
}

async function deleteSelected() {
    if (selectedMessages.size === 0) { showToast('No messages selected', 'error'); return; }
    if (confirm(`Delete ${selectedMessages.size} message(s)?`)) {
        const ids = Array.from(selectedMessages);
        const response = await apiFetch('/api/admin/messages/delete-multiple', { method: 'POST', body: JSON.stringify({ ids: ids }) });
        if (response && response.success) {
            showToast(`${selectedMessages.size} message(s) deleted`, 'success');
            selectedMessages.clear();
            loadMessages(); loadStats();
        }
    }
}

async function markAllAsRead() {
    const response = await apiFetch('/api/admin/messages/mark-all-read', { method: 'POST' });
    if (response && response.success) { showToast('All messages marked as read', 'success'); loadMessages(); loadStats(); }
}

async function loadRecipients() {
    const type = document.getElementById('recipient_type').value;
    const select = document.getElementById('recipient_id');
    select.innerHTML = '<option value="">Loading...</option>';
    let response;
    if (type === 'customer') response = await apiFetch('/api/customers?limit=100');
    else if (type === 'admin') response = await apiFetch('/api/admins');
    else response = await apiFetch('/api/resellers');
    if (response && response.success && response.data) {
        select.innerHTML = '<option value="">Select recipient...</option>' + response.data.map(r => `<option value="${r.id}">${escapeHtml(r.fullname || r.name || r.username)} (${r.email || r.username})</option>`).join('');
    }
}

document.getElementById('recipient_type')?.addEventListener('change', loadRecipients);

document.getElementById('composeForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const messageData = {
        recipient_type: document.getElementById('recipient_type').value,
        recipient_id: parseInt(document.getElementById('recipient_id').value),
        subject: document.getElementById('subject').value.trim(),
        message: document.getElementById('message').value.trim()
    };
    if (!messageData.recipient_id) { showToast('Select a recipient', 'error'); return; }
    if (!messageData.subject) { showToast('Subject is required', 'error'); return; }
    if (!messageData.message) { showToast('Message is required', 'error'); return; }
    const response = await apiFetch('/api/admin/messages/send', { method: 'POST', body: JSON.stringify(messageData) });
    if (response && response.success) {
        showToast('Message sent!', 'success');
        closeComposeModal();
        loadMessages(); loadStats();
        document.getElementById('composeForm').reset();
    }
});

function switchTab(tab) {
    currentTab = tab;
    currentPage = 1;
    selectedMessages.clear();
    document.querySelectorAll('.btn-group .btn').forEach(btn => btn.classList.remove('is-active'));
    if (tab === 'inbox') document.querySelector('.btn-group .btn:nth-child(1)').classList.add('is-active');
    else if (tab === 'sent') document.querySelector('.btn-group .btn:nth-child(2)').classList.add('is-active');
    else document.querySelector('.btn-group .btn:nth-child(3)').classList.add('is-active');
    const titles = { inbox: 'Inbox', sent: 'Sent', archived: 'Archived' };
    document.getElementById('currentTabTitle').innerHTML = titles[tab];
    loadMessages();
}

function prevPage() { if (currentPage > 1) { currentPage--; loadMessages(); } }
function nextPage() { currentPage++; loadMessages(); }

document.getElementById('searchInput')?.addEventListener('input', (e) => { currentFilters.search = e.target.value; currentPage = 1; loadMessages(); });
document.getElementById('filterSelect')?.addEventListener('change', (e) => { currentFilters.status = e.target.value; currentPage = 1; loadMessages(); });

function showComposeModal() { loadRecipients(); document.getElementById('composeModal').style.display = 'flex'; }
function closeComposeModal() { document.getElementById('composeModal').style.display = 'none'; }
function closeReplyModal() { document.getElementById('replyModal').style.display = 'none'; }

const dateElem = document.getElementById('heroDate');
if (dateElem) { const date = new Date(); dateElem.innerHTML = date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }); }

const user = JSON.parse(localStorage.getItem('adminUser') || '{}');
const adminNameElem = document.getElementById('adminName');
if (adminNameElem) {
    if (user.fullname) adminNameElem.innerHTML = user.fullname.split(' ')[0];
    else if (user.username) adminNameElem.innerHTML = user.username;
}

if (adminToken && adminToken !== 'null' && adminToken.length > 20) { loadStats(); loadMessages(); setInterval(() => { loadMessages(); loadStats(); }, 30000); } 
else { window.location.href = 'admin_login.html'; }

window.onclick = function(event) {
    if (event.target === document.getElementById('composeModal')) closeComposeModal();
    if (event.target === document.getElementById('replyModal')) closeReplyModal();
}
</script>

<style>
.message-item.unread { background: #f0f9ff; }
.message-item.selected { background: #e0e7ff; }
.text-center { text-align: center; }
.btn--secondary { background: #8b5cf6; color: white; border: none; border-radius: 6px; padding: 8px 16px; cursor: pointer; }
.btn--secondary.btn--sm { padding: 4px 12px; }
.btn--danger { background: #ef4444; color: white; border: none; border-radius: 6px; padding: 8px 16px; cursor: pointer; }
.btn--danger.btn--sm { padding: 4px 12px; }
.badge-count { background: #ef4444; color: white; border-radius: 10px; padding: 2px 6px; font-size: 10px; margin-left: 6px; display: inline-block; }
.form-errors { color: #ef4444; font-size: 13px; margin: 16px 0; padding: 10px; background: #fee2e2; border-radius: 6px; display: none; }
.modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center; }
.modal-content { background: white; border-radius: 12px; max-width: 600px; width: 90%; max-height: 90vh; overflow-y: auto; padding: 24px; }
.modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
.modal-close { background: none; border: none; font-size: 24px; cursor: pointer; color: #666; }
.modal-footer { display: flex; gap: 12px; justify-content: flex-end; margin-top: 20px; }
.field { margin-bottom: 16px; }
.field label { display: block; margin-bottom: 6px; font-weight: 500; }
</style>
</body>
</html>