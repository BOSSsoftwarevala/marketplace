<?php include('head.php'); ?>
<body data-active="admin_users" data-crumbs="Workspace | Admin Users">
<div class="shell">
<?php include('sidebar.php'); ?>
<div class="main">
<?php include('topbar.php'); ?>
<main class="content">
<section class="hero">
<div class="hero-text">
<span class="eyebrow" id="heroDate">Admin Users</span>
<h1 class="hero-title">Manage <span class="accent">Admin Users</span></h1>
<p class="hero-sub" id="heroSubText">Create, edit, and manage system administrators</p>
</div>
<div class="hero-actions">
<button class="btn btn--ghost" onclick="exportAdmins()"><svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/></svg> Export</button>
<button class="btn btn--primary" onclick="showAddAdminModal()"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg> Add Admin</button>
</div>
</section>

<!-- Admin Statistics KPI Grid -->
<section class="kpi-grid" aria-label="Admin metrics">
<article class="kpi-card c-success">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon success"><svg viewBox="0 0 24 24"><path d="M20 12H4M12 4v16"/></svg></div>
<div class="kpi-label">Total Admins</div>
</div>
</div>
<div class="kpi-value" id="totalAdmins">0</div>
<div class="kpi-compare">System administrators</div>
</article>

<article class="kpi-card c-danger">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon danger"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg></div>
<div class="kpi-label">Total Admins</div>
</div>
</div>
<div class="kpi-value" id="totalAdmins2">0</div>
<div class="kpi-compare">Registered</div>
</article>

<article class="kpi-card c-purple">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon purple"><svg viewBox="0 0 24 24"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg></div>
<div class="kpi-label">Active</div>
</div>
</div>
<div class="kpi-value" id="activeAdmins">0</div>
<div class="kpi-compare">Active accounts</div>
</article>

<article class="kpi-card c-primary">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon primary"><svg viewBox="0 0 24 24"><path d="M18 20V10M12 20V4M6 20v-4"/></svg></div>
<div class="kpi-label">Created</div>
</div>
</div>
<div class="kpi-value" id="latestAdmin">-</div>
<div class="kpi-compare">Latest admin</div>
</article>
</section>

<!-- Admin Users Table -->
<section class="col-12 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Admin List</span>
<h2 class="card-title">All Administrators</h2>
</div>
<div class="card-actions">
<input type="text" id="searchInput" placeholder="Search by name or email..." class="search-input">
</div>
</div>
<div class="table-responsive">
<table class="table">
<thead>
<th>ID</th>
<th>Full Name</th>
<th>Email</th>
<th>Created</th>
<th>Actions</th>
</thead>
<tbody id="adminsTableBody">
<tr><td colspan="5" class="text-center">Loading admin users...<\/td><\/tr>
</tbody>
</div>
<div class="pagination">
<div>Showing <span id="showingStart">0</span> to <span id="showingEnd">0</span> of <span id="totalRecords">0</span> admins</div>
<div class="pagination-buttons">
<button class="btn btn--small" id="prevPage" onclick="prevPage()" disabled>Previous</button>
<button class="btn btn--small" id="nextPage" onclick="nextPage()" disabled>Next</button>
</div>
</div>
</section>

<!-- Add/Edit Admin Modal - TWO COLUMNS -->
<div id="adminModal" class="modal" style="display: none;">
    <div class="modal-content" style="max-width: 600px;">
        <div class="modal-header">
            <h3 id="modalTitle">Add New Admin</h3>
            <button class="modal-close" onclick="closeAdminModal()">&times;</button>
        </div>
        <form id="adminForm">
            <input type="hidden" id="admin_id">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                <!-- Left Column -->
                <div>
                    <div class="field">
                        <label>Full Name *</label>
                        <input type="text" id="fullname" class="input" required>
                    </div>
                    <div class="field">
                        <label>Email *</label>
                        <input type="email" id="email" class="input" required>
                    </div>
                </div>
                <!-- Right Column -->
                <div>
                    <div class="field" id="passwordField">
                        <label>Password <span id="passwordRequired">*</span></label>
                        <input type="password" id="password" class="input" minlength="4">
                    </div>
                </div>
            </div>
            <div id="formErrors" class="form-errors" style="display: none;"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn--ghost" onclick="closeAdminModal()">Cancel</button>
                <button type="submit" class="btn btn--primary">Save Admin</button>
            </div>
        </form>
    </div>
</div>

<!-- View Admin Modal -->
<div id="viewAdminModal" class="modal" style="display: none;">
    <div class="modal-content" style="max-width: 450px;">
        <div class="modal-header">
            <h3>Admin Details</h3>
            <button class="modal-close" onclick="closeViewModal()">&times;</button>
        </div>
        <div id="adminDetailsContainer"></div>
        <div class="modal-footer">
            <button type="button" class="btn btn--ghost" onclick="closeViewModal()">Close</button>
            <button type="button" class="btn btn--primary" onclick="editFromView()">Edit Admin</button>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div id="deleteModal" class="modal" style="display: none;">
    <div class="modal-content" style="max-width: 400px;">
        <div class="modal-header">
            <h3>Confirm Delete</h3>
            <button class="modal-close" onclick="closeDeleteModal()">&times;</button>
        </div>
        <p>Are you sure you want to delete this admin user?</p>
        <p><strong id="deleteAdminName"></strong></p>
        <p style="color: #ef4444; font-size: 13px;">This action cannot be undone.</p>
        <div class="modal-footer">
            <button type="button" class="btn btn--ghost" onclick="closeDeleteModal()">Cancel</button>
            <button type="button" class="btn btn--danger" onclick="confirmDelete()">Delete Admin</button>
        </div>
    </div>
</div>

<!-- Toast Container -->
<div id="toastContainer"></div>

</main>
<?php include('footer.php'); ?>
</div>
</div>

<style>
.toast-container { position: fixed; top: 20px; right: 20px; z-index: 9999; }
.toast { display: flex; align-items: center; gap: 12px; background: white; border-radius: 8px; padding: 12px 16px; margin-bottom: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); animation: slideIn 0.3s ease forwards; min-width: 280px; border-left: 4px solid; }
.toast-success { border-left-color: #10b981; }.toast-error { border-left-color: #ef4444; }.toast-info { border-left-color: #3b82f6; }
.toast-icon { width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 14px; }
.toast-success .toast-icon { background: #10b98120; color: #10b981; }.toast-error .toast-icon { background: #ef444420; color: #ef4444; }
@keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
.text-center { text-align: center; }.table-responsive { overflow-x: auto; }
.table { width: 100%; border-collapse: collapse; }
.table th, .table td { padding: 12px 16px; text-align: left; border-bottom: 1px solid #e5e7eb; }
.table th { background: #f8f9fa; font-weight: 600; }
.tag { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 500; }
.t-active { background: #dcfce7; color: #166534; }
.btn-icon { background: none; border: none; cursor: pointer; font-size: 16px; padding: 4px 8px; border-radius: 4px; transition: background 0.2s; }
.btn-icon:hover { background: #f0f0f0; }
.btn-danger { background: #ef4444; color: white; border: none; border-radius: 6px; padding: 8px 16px; cursor: pointer; }
.btn-danger:hover { background: #dc2626; }
.search-input { margin-left: 8px; padding: 6px 12px; border-radius: 6px; border: 1px solid #ddd; width: 250px; }
.card-actions { display: flex; gap: 8px; align-items: center; }
.pagination { padding: 16px; display: flex; justify-content: space-between; align-items: center; }
.pagination-buttons { display: flex; gap: 8px; }
.btn--small { padding: 4px 12px; font-size: 12px; }
.modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center; }
.modal-content { background: white; border-radius: 12px; max-width: 600px; width: 90%; max-height: 90vh; overflow-y: auto; padding: 24px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); }
.modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
.modal-close { background: none; border: none; font-size: 24px; cursor: pointer; color: #666; }
.modal-footer { display: flex; gap: 12px; justify-content: flex-end; margin-top: 20px; }
.field { margin-bottom: 16px; }
.field label { display: block; margin-bottom: 6px; font-weight: 500; }
.field input, .field select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; }
.form-errors { color: #ef4444; font-size: 13px; margin: 16px 0; padding: 10px; background: #fee2e2; border-radius: 6px; }
.btn { padding: 10px 20px; border-radius: 6px; cursor: pointer; font-size: 14px; }
.btn--primary { background: #4f46e5; color: white; border: none; }
.btn--ghost { background: none; border: 1px solid #ddd; color: #333; }
.detail-row { display: flex; padding: 8px 0; border-bottom: 1px solid #f0f0f0; }
.detail-label { width: 100px; font-weight: 600; color: #666; }
.detail-value { flex: 1; color: #333; }
</style>

<script>
// ============================================
// ADMIN USERS MANAGEMENT PAGE
// ============================================

// const API_BASE_URL = 'https://shabanetech.top/wifi-api';
// let adminToken = localStorage.getItem('adminToken');
let allAdmins = [];
let currentPage = 1;
let itemsPerPage = 10;
let currentFilters = { search: '' };
let currentViewAdmin = null;
let currentDeleteId = null;

function showToast(message, type = 'success') {
    let container = document.getElementById('toastContainer');
    if (!container) { container = document.createElement('div'); container.id = 'toastContainer'; document.body.appendChild(container); }
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `<div class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '✗' : 'ℹ'}</div><div class="toast-message">${message}</div><button class="toast-close" onclick="this.parentElement.remove()">×</button>`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}

async function apiFetch(endpoint, options = {}) {
    if (!adminToken) { window.location.href = 'admin_login.html'; return null; }
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            ...options,
            headers: { 'Authorization': `Bearer ${adminToken}`, 'Content-Type': 'application/json' }
        });
        if (response.status === 401) { localStorage.removeItem('adminToken'); window.location.href = 'admin_login.html'; return null; }
        const data = await response.json();
        if (!response.ok) {
            if (data.details && data.details.length) {
                const errors = data.details.map(d => d.message).join(', ');
                throw new Error(errors);
            }
            throw new Error(data.error || data.message);
        }
        return data;
    } catch (error) { 
        console.error('API Error:', error);
        showToast(error.message, 'error');
        return null;
    }
}

function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

async function loadStats() {
    const response = await apiFetch('/api/admins');
    if (response && response.success && response.data) {
        const admins = response.data;
        const total = admins.length;
        const active = admins.length; // All admins are considered active in this table
        const latestAdmin = admins.length > 0 ? admins[admins.length - 1].fullname : '-';
        
        document.getElementById('totalAdmins').innerHTML = total;
        document.getElementById('totalAdmins2').innerHTML = total;
        document.getElementById('activeAdmins').innerHTML = active;
        document.getElementById('latestAdmin').innerHTML = escapeHtml(latestAdmin);
    }
}

async function loadAdmins() {
    const tbody = document.getElementById('adminsTableBody');
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="5" class="text-center">Loading admin users...<\/td><\/tr>';
    
    const response = await apiFetch('/api/admins');
    if (response && response.success && response.data) {
        allAdmins = response.data;
        let filtered = [...allAdmins];
        
        if (currentFilters.search) {
            const search = currentFilters.search.toLowerCase();
            filtered = filtered.filter(a => 
                (a.fullname && a.fullname.toLowerCase().includes(search)) ||
                (a.email && a.email.toLowerCase().includes(search))
            );
        }
        
        const total = filtered.length;
        const totalPages = Math.ceil(total / itemsPerPage);
        const start = (currentPage - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        const paginated = filtered.slice(start, end);
        
        if (paginated.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center">No admin users found<\/td><\/tr>';
        } else {
            tbody.innerHTML = paginated.map(admin => `
                <tr>
                    <td>${admin.id}<\/td>
                    <td class="cell-name"><strong>${escapeHtml(admin.fullname)}<\/strong><\/td>
                    <td>${escapeHtml(admin.email)}<\/td>
                    <td class="cell-date">${formatDate(admin.created_at)}<\/td>
                    <td>
                        <button class="btn-icon" onclick="viewAdmin(${admin.id})" title="View">👁️<\/button>
                        <button class="btn-icon" onclick="editAdmin(${admin.id})" title="Edit">✏️<\/button>
                        <button class="btn-icon" onclick="showDeleteModal(${admin.id}, '${escapeHtml(admin.fullname)}')" title="Delete">🗑️<\/button>
                    <\/td>
                </tr>
            `).join('');
        }
        
        document.getElementById('showingStart').innerHTML = total === 0 ? 0 : start + 1;
        document.getElementById('showingEnd').innerHTML = Math.min(end, total);
        document.getElementById('totalRecords').innerHTML = total;
        document.getElementById('prevPage').disabled = currentPage <= 1;
        document.getElementById('nextPage').disabled = currentPage >= totalPages;
    }
}

// View admin
function viewAdmin(id) {
    const admin = allAdmins.find(a => a.id === id);
    if (admin) {
        currentViewAdmin = admin;
        const container = document.getElementById('adminDetailsContainer');
        if (container) {
            container.innerHTML = `
                <div class="detail-row"><span class="detail-label">ID:</span><span class="detail-value">${admin.id}</span></div>
                <div class="detail-row"><span class="detail-label">Full Name:</span><span class="detail-value">${escapeHtml(admin.fullname)}</span></div>
                <div class="detail-row"><span class="detail-label">Email:</span><span class="detail-value">${escapeHtml(admin.email)}</span></div>
                <div class="detail-row"><span class="detail-label">Created:</span><span class="detail-value">${formatDate(admin.created_at)}</span></div>`;
        }
        const modal = document.getElementById('viewAdminModal'); if (modal) modal.style.display = 'flex';
    } else { showToast('Could not load admin details', 'error'); }
}

function editFromView() { 
    if (currentViewAdmin) { 
        closeViewModal(); 
        editAdmin(currentViewAdmin.id); 
    } 
}

// Edit admin
async function editAdmin(id) {
    const admin = allAdmins.find(a => a.id === id);
    if (admin) {
        const titleElem = document.getElementById('modalTitle'); if (titleElem) titleElem.innerText = 'Edit Admin';
        const idField = document.getElementById('admin_id'); if (idField) idField.value = admin.id;
        const nameField = document.getElementById('fullname'); if (nameField) nameField.value = admin.fullname;
        const emailField = document.getElementById('email'); if (emailField) emailField.value = admin.email;
        const passwordField = document.getElementById('password'); if (passwordField) passwordField.value = '';
        const passwordRequired = document.getElementById('passwordRequired');
        if (passwordRequired) passwordRequired.innerHTML = ' (leave blank to keep current)';
        const modal = document.getElementById('adminModal'); if (modal) modal.style.display = 'flex';
    }
}

// Add/Edit admin form
const adminForm = document.getElementById('adminForm');
if (adminForm) {
    adminForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const adminId = document.getElementById('admin_id').value;
        const adminData = {
            fullname: document.getElementById('fullname').value.trim(),
            email: document.getElementById('email').value.trim()
        };
        const password = document.getElementById('password').value;
        if (password) adminData.password = password;
        
        const errorDiv = document.getElementById('formErrors');
        if (!adminData.fullname) { if (errorDiv) { errorDiv.textContent = 'Full name is required'; errorDiv.style.display = 'block'; setTimeout(() => { if(errorDiv) errorDiv.style.display = 'none'; }, 3000); } return; }
        if (!adminData.email) { if (errorDiv) { errorDiv.textContent = 'Email is required'; errorDiv.style.display = 'block'; setTimeout(() => { if(errorDiv) errorDiv.style.display = 'none'; }, 3000); } return; }
        if (!adminId && !password) { if (errorDiv) { errorDiv.textContent = 'Password is required for new admin'; errorDiv.style.display = 'block'; setTimeout(() => { if(errorDiv) errorDiv.style.display = 'none'; }, 3000); } return; }
        if (errorDiv) errorDiv.style.display = 'none';
        
        const submitBtn = e.target.querySelector('button[type="submit"]');
        const originalText = submitBtn ? submitBtn.innerHTML : 'Save Admin';
        if (submitBtn) { submitBtn.innerHTML = 'Saving...'; submitBtn.disabled = true; }
        
        let response;
        if (adminId) {
            response = await apiFetch(`/api/admins/${adminId}`, { method: 'PUT', body: JSON.stringify(adminData) });
        } else {
            response = await apiFetch('/api/admins', { method: 'POST', body: JSON.stringify(adminData) });
        }
        
        if (submitBtn) { submitBtn.innerHTML = originalText; submitBtn.disabled = false; }
        
        if (response && response.success) {
            showToast(`Admin ${adminData.email} ${adminId ? 'updated' : 'created'} successfully!`, 'success');
            closeAdminModal();
            loadAdmins(); loadStats();
            if (adminForm) adminForm.reset();
            const adminIdField = document.getElementById('admin_id'); if (adminIdField) adminIdField.value = '';
            const passwordRequired = document.getElementById('passwordRequired');
            if (passwordRequired) passwordRequired.innerHTML = '*';
        } else { showToast(response?.error || 'Failed to save admin', 'error'); }
    });
}

// Delete admin
function showDeleteModal(id, name) {
    currentDeleteId = id;
    document.getElementById('deleteAdminName').innerHTML = name;
    document.getElementById('deleteModal').style.display = 'flex';
}

async function confirmDelete() {
    if (!currentDeleteId) return;
    const response = await apiFetch(`/api/admins/${currentDeleteId}`, { method: 'DELETE' });
    closeDeleteModal();
    if (response && response.success) {
        showToast('Admin deleted successfully!', 'success');
        loadAdmins(); loadStats();
    } else {
        showToast(response?.error || 'Failed to delete admin', 'error');
    }
    currentDeleteId = null;
}

function showAddAdminModal() {
    const titleElem = document.getElementById('modalTitle'); if (titleElem) titleElem.innerText = 'Add New Admin';
    const form = document.getElementById('adminForm'); if (form) form.reset();
    const idField = document.getElementById('admin_id'); if (idField) idField.value = '';
    const passwordRequired = document.getElementById('passwordRequired');
    if (passwordRequired) passwordRequired.innerHTML = '*';
    const modal = document.getElementById('adminModal'); if (modal) modal.style.display = 'flex';
}

function closeAdminModal() { const modal = document.getElementById('adminModal'); if (modal) modal.style.display = 'none'; }
function closeViewModal() { const modal = document.getElementById('viewAdminModal'); if (modal) modal.style.display = 'none'; currentViewAdmin = null; }
function closeDeleteModal() { const modal = document.getElementById('deleteModal'); if (modal) modal.style.display = 'none'; currentDeleteId = null; }

function prevPage() { if (currentPage > 1) { currentPage--; loadAdmins(); } }
function nextPage() { currentPage++; loadAdmins(); }

const searchInput = document.getElementById('searchInput');
if (searchInput) { searchInput.addEventListener('input', (e) => { currentFilters.search = e.target.value; currentPage = 1; loadAdmins(); }); }

function exportAdmins() {
    if (allAdmins.length === 0) { showToast('No data to export', 'error'); return; }
    let csv = 'ID,Full Name,Email,Created\n';
    allAdmins.forEach(a => { csv += `"${a.id}","${a.fullname}","${a.email}","${a.created_at}"\n`; });
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `admins_${new Date().toISOString().split('T')[0]}.csv`;
    a.click(); URL.revokeObjectURL(url);
    showToast('Export completed!', 'success');
}

const dateElem = document.getElementById('heroDate');
if (dateElem) { const date = new Date(); dateElem.innerHTML = date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }); }

const user = JSON.parse(localStorage.getItem('adminUser') || '{}');
const adminNameElem = document.getElementById('adminName');
if (adminNameElem) {
    if (user.fullname) adminNameElem.innerHTML = user.fullname.split(' ')[0];
    else if (user.username) adminNameElem.innerHTML = user.username;
}

if (adminToken && adminToken !== 'null' && adminToken.length > 20) { loadStats(); loadAdmins(); } 
else { window.location.href = 'admin_login.html'; }

window.onclick = function(event) {
    if (event.target === document.getElementById('adminModal')) closeAdminModal();
    if (event.target === document.getElementById('viewAdminModal')) closeViewModal();
    if (event.target === document.getElementById('deleteModal')) closeDeleteModal();
}
</script>
</body>
</html>