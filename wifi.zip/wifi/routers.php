<?php include('head.php'); ?>
<body data-active="routers" data-crumbs="Workspace | Routers">
<div class="shell">
<?php include('sidebar.php'); ?>
<div class="main">
<?php include('topbar.php'); ?>
<main class="content">
<section class="hero">
<div class="hero-text">
<span class="eyebrow" id="heroDate">Router Management</span>
<h1 class="hero-title">Manage <span class="accent">Routers</span></h1>
<p class="hero-sub" id="heroSubText">Monitor and manage network routers in real-time</p>
</div>
<div class="hero-actions">
<button class="btn btn--ghost" onclick="exportRouters()"><svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/></svg> Export</button>
<button class="btn btn--primary" onclick="showAddRouterModal()"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg> Add Router</button>
</div>
</section>

<!-- Router Statistics KPI Grid -->
<section class="kpi-grid" aria-label="Router metrics">
<article class="kpi-card c-success">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon success"><svg viewBox="0 0 24 24"><path d="M2 12h20M12 2v20"/></svg></div>
<div class="kpi-label">Total Routers</div>
</div>
</div>
<div class="kpi-value" id="totalRouters">0</div>
<div class="kpi-compare">Registered routers</div>
</article>

<article class="kpi-card c-danger">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon danger"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg></div>
<div class="kpi-label">Active Routers</div>
</div>
</div>
<div class="kpi-value" id="activeRouters">0</div>
<div class="kpi-compare">Currently online</div>
</article>

<article class="kpi-card c-purple">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon purple"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg></div>
<div class="kpi-label">Offline</div>
</div>
</div>
<div class="kpi-value" id="offlineRouters">0</div>
<div class="kpi-compare">Not responding</div>
</article>

<article class="kpi-card c-primary">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon primary"><svg viewBox="0 0 24 24"><path d="M3 12h2M19 12h2M12 3v2M12 19v2M7 7l1 1M16 16l1 1M7 17l1-1M16 8l1-1"/></svg></div>
<div class="kpi-label">Avg CPU</div>
</div>
</div>
<div class="kpi-value" id="avgCpu">0%</div>
<div class="kpi-compare">Average CPU load</div>
</article>
</section>

<!-- Routers Table -->
<section class="col-12 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Router List</span>
<h2 class="card-title">All Routers</h2>
</div>
<div class="card-actions">
<input type="text" id="searchInput" placeholder="Search routers..." class="search-input" style="padding: 6px 12px; border-radius: 6px; border: 1px solid var(--border); background: var(--bg);">
<select id="statusFilter" class="status-filter" style="padding: 6px 12px; border-radius: 6px; border: 1px solid var(--border); background: var(--bg);">
<option value="all">All Status</option>
<option value="online">Online</option>
<option value="offline">Offline</option>
<option value="active">Active</option>
<option value="inactive">Inactive</option>
</select>
</div>
</div>
<div class="table-responsive">
<table class="table">
<thead>
<tr>
<th>ID</th>
<th>Router Name</th>
<th>IP Address</th>
<th>Location</th>
<th>Status</th>
<th>Connection</th>
<th>Online Users</th>
<th>Last Seen</th>
<th>Actions</th>
</tr>
</thead>
<tbody id="routersTableBody">
<tr><td colspan="9" class="text-center">Loading routers...</td></tr>
</tbody>
</table>
</div>
</section>

<!-- Toast Container -->
<div id="toastContainer" style="position: fixed; top: 20px; right: 20px; z-index: 9999;"></div>

<!-- Add/Edit Router Modal -->
<div id="routerModal" class="modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
    <div class="modal-content" style="background: white; border-radius: 12px; max-width: 750px; width: 90%; max-height: 90vh; overflow-y: auto; padding: 24px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1);">
        <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; position: sticky; top: 0; background: white; padding-bottom: 12px; border-bottom: 1px solid #eee;">
            <h3 style="margin: 0;" id="modalTitle">Add New Router</h3>
            <button onclick="closeRouterModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: #666;">&times;</button>
        </div>
        <form id="routerForm">
            <input type="hidden" id="router_id">
            
            <!-- Two Column Layout -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                
                <!-- Left Column -->
                <div>
                    <div class="field" style="margin-bottom: 16px;">
                        <label class="field-label" style="display: block; margin-bottom: 6px; font-weight: 500;">Router Name *</label>
                        <input type="text" id="router_name" name="router_name" class="input" required 
                               style="width: 100%; padding: 10px 12px; border: 1px solid #ddd; border-radius: 6px;">
                        <small style="color: #666; font-size: 11px;">Min 3 characters, max 100</small>
                    </div>
                    
                    <div class="field" style="margin-bottom: 16px;">
                        <label class="field-label" style="display: block; margin-bottom: 6px; font-weight: 500;">Router Code *</label>
                        <input type="text" id="router_code" name="router_code" class="input" required 
                               style="width: 100%; padding: 10px 12px; border: 1px solid #ddd; border-radius: 6px;">
                        <small style="color: #666; font-size: 11px;">Min 3 characters, max 50 (e.g., R001)</small>
                    </div>
                    
                    <div class="field" style="margin-bottom: 16px;">
                        <label class="field-label" style="display: block; margin-bottom: 6px; font-weight: 500;">IP Address *</label>
                        <input type="text" id="ip_address" name="ip_address" class="input" required 
                               placeholder="192.168.1.1" style="width: 100%; padding: 10px 12px; border: 1px solid #ddd; border-radius: 6px;">
                        <small style="color: #666; font-size: 11px;">Valid IPv4 address</small>
                    </div>
                    
                    <div class="field" style="margin-bottom: 16px;">
                        <label class="field-label" style="display: block; margin-bottom: 6px; font-weight: 500;">MAC Address</label>
                        <input type="text" id="mac_address" name="mac_address" class="input" 
                               placeholder="00:11:22:33:44:55" style="width: 100%; padding: 10px 12px; border: 1px solid #ddd; border-radius: 6px;">
                        <small style="color: #666; font-size: 11px;">Format: XX:XX:XX:XX:XX:XX (optional)</small>
                    </div>
                </div>
                
                <!-- Right Column -->
                <div>
                    <div class="field" style="margin-bottom: 16px;">
                        <label class="field-label" style="display: block; margin-bottom: 6px; font-weight: 500;">Location</label>
                        <input type="text" id="location" name="location" class="input" 
                               placeholder="Nairobi, Kenya" style="width: 100%; padding: 10px 12px; border: 1px solid #ddd; border-radius: 6px;">
                        <small style="color: #666; font-size: 11px;">Max 255 characters (optional)</small>
                    </div>
                    
                    <div class="field" style="margin-bottom: 16px;">
                        <label class="field-label" style="display: block; margin-bottom: 6px; font-weight: 500;">API Username</label>
                        <input type="text" id="api_username" name="api_username" class="input" 
                               style="width: 100%; padding: 10px 12px; border: 1px solid #ddd; border-radius: 6px;">
                        <small style="color: #666; font-size: 11px;">Max 100 characters (optional)</small>
                    </div>
                    
                    <div class="field" style="margin-bottom: 16px;">
                        <label class="field-label" style="display: block; margin-bottom: 6px; font-weight: 500;">API Password</label>
                        <input type="password" id="api_password" name="api_password" class="input" 
                               style="width: 100%; padding: 10px 12px; border: 1px solid #ddd; border-radius: 6px;">
                        <small style="color: #666; font-size: 11px;">Max 255 characters (optional)</small>
                    </div>
                    
                    <div class="field" style="margin-bottom: 16px;">
                        <label class="field-label" style="display: block; margin-bottom: 6px; font-weight: 500;">Branch ID</label>
                        <input type="number" id="branch_id" name="branch_id" class="input" 
                               placeholder="Optional" style="width: 100%; padding: 10px 12px; border: 1px solid #ddd; border-radius: 6px;">
                        <small style="color: #666; font-size: 11px;">Positive integer (optional)</small>
                    </div>
                </div>
            </div>
            
            <div id="formErrors" style="color: #ef4444; font-size: 13px; margin: 16px 0; padding: 10px; background: #fee2e2; border-radius: 6px; display: none;"></div>
            
            <div style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 20px; padding-top: 16px; border-top: 1px solid #eee;">
                <button type="button" onclick="closeRouterModal()" class="btn btn--ghost" style="padding: 10px 20px;">Cancel</button>
                <button type="submit" class="btn btn--primary" style="padding: 10px 20px; background: #4f46e5; color: white; border: none; border-radius: 6px; cursor: pointer;">Save Router</button>
            </div>
        </form>
    </div>
</div>

<!-- View Router Modal -->
<div id="viewRouterModal" class="modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
    <div class="modal-content" style="background: white; border-radius: 12px; max-width: 550px; width: 90%; max-height: 90vh; overflow-y: auto; padding: 24px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1);">
        <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h3 style="margin: 0;">Router Details</h3>
            <button onclick="closeViewModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: #666;">&times;</button>
        </div>
        <div id="viewRouterDetails" style="max-height: 400px; overflow-y: auto;"></div>
        <div style="margin-top: 20px; display: flex; gap: 10px; justify-content: flex-end;">
            <button onclick="closeViewModal()" class="btn btn--ghost" style="padding: 8px 16px;">Close</button>
            <button onclick="editFromView()" class="btn btn--primary" style="padding: 8px 16px;">Edit Router</button>
        </div>
    </div>
</div>

</main>
<?php include('footer.php'); ?>
</div>
</div>

<script>
// ============================================
// ROUTER MANAGEMENT PAGE 
// MATCHES BACKEND VALIDATION EXACTLY
// ============================================

// const API_BASE_URL = 'https://shabanetech.top/wifi-api';
// let adminToken = localStorage.getItem('adminToken');
let currentRouters = [];
let currentViewRouter = null;
let refreshInterval = null;

function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '✗' : type === 'warning' ? '⚠' : 'ℹ'}</div>
        <div class="toast-message">${message}</div>
        <button class="toast-close" onclick="this.parentElement.remove()">×</button>
    `;
    
    container.appendChild(toast);
    
    setTimeout(() => {
        if (toast.parentElement) {
            toast.style.animation = 'slideOut 0.3s ease forwards';
            setTimeout(() => toast.remove(), 300);
        }
    }, 4000);
}

// Add styles
const styles = document.createElement('style');
styles.textContent = `
    .toast {
        display: flex;
        align-items: center;
        gap: 12px;
        background: white;
        border-radius: 8px;
        padding: 12px 16px;
        margin-bottom: 10px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        animation: slideIn 0.3s ease forwards;
        min-width: 280px;
        border-left: 4px solid;
    }
    .toast-success { border-left-color: #10b981; }
    .toast-error { border-left-color: #ef4444; }
    .toast-warning { border-left-color: #f59e0b; }
    .toast-info { border-left-color: #3b82f6; }
    .toast-icon {
        width: 24px;
        height: 24px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        font-size: 14px;
    }
    .toast-success .toast-icon { background: #10b98120; color: #10b981; }
    .toast-error .toast-icon { background: #ef444420; color: #ef4444; }
    .toast-warning .toast-icon { background: #f59e0b20; color: #f59e0b; }
    .toast-info .toast-icon { background: #3b82f620; color: #3b82f6; }
    .toast-message { flex: 1; font-size: 14px; color: #333; }
    .toast-close {
        background: none;
        border: none;
        font-size: 18px;
        cursor: pointer;
        color: #999;
        padding: 0;
        width: 20px;
        height: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .toast-close:hover { color: #666; }
    
    .status-blink-green {
        display: inline-block;
        width: 12px;
        height: 12px;
        border-radius: 50%;
        background-color: #10b981;
        margin-right: 6px;
        animation: blink-green 1.5s infinite;
    }
    .status-blink-red {
        display: inline-block;
        width: 12px;
        height: 12px;
        border-radius: 50%;
        background-color: #ef4444;
        margin-right: 6px;
        animation: blink-red 1.5s infinite;
    }
    
    @keyframes blink-green {
        0% { opacity: 1; background-color: #10b981; }
        50% { opacity: 0.5; background-color: #34d399; }
        100% { opacity: 1; background-color: #10b981; }
    }
    @keyframes blink-red {
        0% { opacity: 1; background-color: #ef4444; }
        50% { opacity: 0.5; background-color: #f87171; }
        100% { opacity: 1; background-color: #ef4444; }
    }
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
    .text-center { text-align: center; }
    .table-responsive { overflow-x: auto; }
    .tag { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 500; }
    .t-new { background: #dcfce7; color: #166534; }
    .t-warning { background: #fef3c7; color: #92400e; }
    .t-unavail { background: #fee2e2; color: #991b1b; }
    .cell-name strong { display: block; }
    .cell-name small { font-size: 11px; color: #6b7280; }
    .btn-icon { background: none; border: none; cursor: pointer; font-size: 18px; padding: 4px 8px; border-radius: 4px; transition: background 0.2s; }
    .btn-icon:hover { background: #f0f0f0; }
    .search-input, .status-filter { margin-left: 8px; }
    .card-actions { display: flex; gap: 8px; }
`;
document.head.appendChild(styles);

async function apiFetch(endpoint, options = {}) {
    if (!adminToken) {
        window.location.href = 'admin_login.html';
        return null;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            ...options,
            headers: {
                'Authorization': `Bearer ${adminToken}`,
                'Content-Type': 'application/json',
                ...options.headers
            }
        });
        
        if (response.status === 401) {
            localStorage.removeItem('adminToken');
            localStorage.removeItem('adminUser');
            window.location.href = 'admin_login.html';
            return null;
        }
        
        const data = await response.json();
        if (!response.ok) {
            // Handle validation errors
            if (data.details && data.details.length) {
                const errorMsg = data.details.map(d => d.message).join(', ');
                throw new Error(errorMsg);
            }
            throw new Error(data.error || data.message || `HTTP ${response.status}`);
        }
        return data;
    } catch (error) {
        console.error('API Error:', error);
        showToast(error.message || 'API request failed', 'error');
        return null;
    }
}

// Format helpers
function formatDate(dateString) {
    if (!dateString) return 'Never';
    const date = new Date(dateString);
    const now = new Date();
    const diff = Math.floor((now - date) / 1000 / 60);
    
    if (diff < 1) return 'Just now';
    if (diff < 60) return `${diff} min ago`;
    if (diff < 1440) return `${Math.floor(diff / 60)} hours ago`;
    return date.toLocaleDateString();
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Load routers
async function loadRouters() {
    const tbody = document.getElementById('routersTableBody');
    tbody.innerHTML = '<tr><td colspan="9" class="text-center">Loading routers...</td></tr>';
    
    const response = await apiFetch('/api/routers');
    
    if (response && response.success && response.data) {
        currentRouters = response.data;
        
        if (currentRouters.length === 0) {
            tbody.innerHTML = '<tr><td colspan="9" class="text-center">No routers found</td></tr>';
        } else {
            tbody.innerHTML = currentRouters.map(router => {
                const isOnline = router.connection_status === 'online';
                const isActive = router.status === 'active';
                const blinkClass = (isOnline && isActive) ? 'status-blink-green' : 'status-blink-red';
                const statusText = isOnline ? 'Online' : 'Offline';
                
                return `
                    <tr>
                        <td>${router.id}</td>
                        <td class="cell-name">
                            <strong>${escapeHtml(router.router_name)}</strong><br>
                            <small>${escapeHtml(router.router_code || 'No code')}</small>
                        </td>
                        <td>${escapeHtml(router.ip_address)}</td>
                        <td>${escapeHtml(router.location || '-')}</td>
                        <td><span class="tag ${router.status === 'active' ? 't-new' : 't-unavail'}">${router.status}</span></td>
                        <td><div class="status-indicator"><span class="${blinkClass}"></span><span>${statusText}</span></div></td>
                        <td class="text-center"><strong>${router.online_users || 0}</strong></td>
                        <td class="cell-date">${formatDate(router.last_seen)}</td>
                        <td>
                            <button class="btn-icon" onclick="viewRouter(${router.id})" title="View">👁️</button>
                            <button class="btn-icon" onclick="editRouter(${router.id})" title="Edit">✏️</button>
                            <button class="btn-icon" onclick="deleteRouter(${router.id})" title="Delete">🗑️</button>
                        </td>
                    </tr>
                `;
            }).join('');
        }
        
        // Update KPIs
        const total = currentRouters.length;
        const active = currentRouters.filter(r => r.status === 'active' && r.connection_status === 'online').length;
        const offline = currentRouters.filter(r => r.connection_status === 'offline' || r.status !== 'active').length;
        
        document.getElementById('totalRouters').innerHTML = total;
        document.getElementById('activeRouters').innerHTML = active;
        document.getElementById('offlineRouters').innerHTML = offline;
    } else {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center">Failed to load routers</td></tr>';
    }
}

// Validate form - MATCHES BACKEND VALIDATION
function validateRouterForm() {
    const errors = [];
    const routerName = document.getElementById('router_name').value.trim();
    const routerCode = document.getElementById('router_code').value.trim();
    const ipAddress = document.getElementById('ip_address').value.trim();
    const macAddress = document.getElementById('mac_address').value.trim();
    const branchId = document.getElementById('branch_id').value;
    
    // router_name: min 3, max 100, required
    if (!routerName) {
        errors.push('Router name is required');
    } else if (routerName.length < 3) {
        errors.push('Router name must be at least 3 characters');
    } else if (routerName.length > 100) {
        errors.push('Router name must not exceed 100 characters');
    }
    
    // router_code: min 3, max 50, required
    if (!routerCode) {
        errors.push('Router code is required');
    } else if (routerCode.length < 3) {
        errors.push('Router code must be at least 3 characters');
    } else if (routerCode.length > 50) {
        errors.push('Router code must not exceed 50 characters');
    }
    
    // ip_address: valid IP, required
    if (!ipAddress) {
        errors.push('IP address is required');
    } else {
        const ipRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
        if (!ipRegex.test(ipAddress)) {
            errors.push('Please enter a valid IP address (e.g., 192.168.1.1)');
        }
    }
    
    // mac_address: optional, but if provided must match pattern
    if (macAddress) {
        const macRegex = /^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/i;
        if (!macRegex.test(macAddress)) {
            errors.push('MAC address format should be XX:XX:XX:XX:XX:XX');
        }
    }
    
    // location: max 255 (optional)
    const location = document.getElementById('location').value;
    if (location && location.length > 255) {
        errors.push('Location must not exceed 255 characters');
    }
    
    // api_username: max 100 (optional)
    const apiUsername = document.getElementById('api_username').value;
    if (apiUsername && apiUsername.length > 100) {
        errors.push('API username must not exceed 100 characters');
    }
    
    // api_password: max 255 (optional)
    const apiPassword = document.getElementById('api_password').value;
    if (apiPassword && apiPassword.length > 255) {
        errors.push('API password must not exceed 255 characters');
    }
    
    // branch_id: positive integer (optional)
    if (branchId && (parseInt(branchId) <= 0 || isNaN(parseInt(branchId)))) {
        errors.push('Branch ID must be a positive number');
    }
    
    return errors;
}

// Submit form
document.getElementById('routerForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const errors = validateRouterForm();
    const errorDiv = document.getElementById('formErrors');
    
    if (errors.length > 0) {
        errorDiv.innerHTML = errors.map(e => `• ${e}`).join('<br>');
        errorDiv.style.display = 'block';
        errorDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        setTimeout(() => { errorDiv.style.display = 'none'; }, 5000);
        return;
    }
    errorDiv.style.display = 'none';
    
    const routerId = document.getElementById('router_id').value;
    const branchId = document.getElementById('branch_id').value;
    
    const routerData = {
        router_name: document.getElementById('router_name').value.trim(),
        router_code: document.getElementById('router_code').value.trim(),
        ip_address: document.getElementById('ip_address').value.trim(),
        mac_address: document.getElementById('mac_address').value.trim() || undefined,
        location: document.getElementById('location').value.trim() || undefined,
        api_username: document.getElementById('api_username').value.trim() || undefined,
        api_password: document.getElementById('api_password').value || undefined,
        branch_id: branchId ? parseInt(branchId) : undefined
    };
    
    // Remove undefined values
    Object.keys(routerData).forEach(key => {
        if (routerData[key] === undefined) delete routerData[key];
    });
    
    const submitBtn = e.target.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = 'Saving...';
    submitBtn.disabled = true;
    
    let response;
    if (routerId) {
        response = await apiFetch(`/api/routers/${routerId}`, {
            method: 'PUT',
            body: JSON.stringify(routerData)
        });
    } else {
        response = await apiFetch('/api/routers', {
            method: 'POST',
            body: JSON.stringify(routerData)
        });
    }
    
    submitBtn.innerHTML = originalText;
    submitBtn.disabled = false;
    
    if (response && response.success) {
        showToast(`Router ${routerData.router_name} ${routerId ? 'updated' : 'created'} successfully!`, 'success');
        closeRouterModal();
        loadRouters();
        document.getElementById('routerForm').reset();
        document.getElementById('router_id').value = '';
    }
});

// View, Edit, Delete functions
async function viewRouter(id) {
    const response = await apiFetch(`/api/routers/${id}`);
    if (response && response.success && response.data) {
        currentViewRouter = response.data;
        const router = response.data;
        const isOnline = router.connection_status === 'online';
        
        document.getElementById('viewRouterDetails').innerHTML = `
            <div class="router-info">
                <p><strong>ID:</strong> ${router.id}</p>
                <p><strong>Router Name:</strong> ${escapeHtml(router.router_name)}</p>
                <p><strong>Router Code:</strong> ${escapeHtml(router.router_code)}</p>
                <p><strong>IP Address:</strong> ${escapeHtml(router.ip_address)}</p>
                <p><strong>MAC Address:</strong> ${escapeHtml(router.mac_address || '-')}</p>
                <p><strong>Location:</strong> ${escapeHtml(router.location || '-')}</p>
                <p><strong>Status:</strong> <span class="tag ${router.status === 'active' ? 't-new' : 't-unavail'}">${router.status}</span></p>
                <p><strong>Connection:</strong> <span class="${isOnline ? 'status-blink-green' : 'status-blink-red'}"></span> ${isOnline ? 'Online' : 'Offline'}</p>
                <p><strong>Online Users:</strong> ${router.online_users || 0}</p>
                <p><strong>Last Seen:</strong> ${formatDate(router.last_seen)}</p>
                <p><strong>Created:</strong> ${new Date(router.created_at).toLocaleString()}</p>
            </div>
        `;
        document.getElementById('viewRouterModal').style.display = 'flex';
    }
}

function editFromView() {
    if (currentViewRouter) {
        closeViewModal();
        editRouter(currentViewRouter.id);
    }
}

async function editRouter(id) {
    const response = await apiFetch(`/api/routers/${id}`);
    if (response && response.success && response.data) {
        const router = response.data;
        
        document.getElementById('modalTitle').innerText = 'Edit Router';
        document.getElementById('router_id').value = router.id;
        document.getElementById('router_name').value = router.router_name;
        document.getElementById('router_code').value = router.router_code;
        document.getElementById('ip_address').value = router.ip_address;
        document.getElementById('mac_address').value = router.mac_address || '';
        document.getElementById('location').value = router.location || '';
        document.getElementById('api_username').value = router.api_username || '';
        document.getElementById('api_password').value = '';
        document.getElementById('branch_id').value = router.branch_id || '';
        
        document.getElementById('routerModal').style.display = 'flex';
    }
}

async function deleteRouter(id) {
    const router = currentRouters.find(r => r.id === id);
    if (!router) return;
    
    if (confirm(`Are you sure you want to delete "${router.router_name}"? This action cannot be undone.`)) {
        const response = await apiFetch(`/api/routers/${id}`, { method: 'DELETE' });
        if (response && response.success) {
            showToast(`Router "${router.router_name}" deleted successfully!`, 'success');
            loadRouters();
        } else {
            showToast(response?.error || 'Failed to delete router', 'error');
        }
    }
}

function showAddRouterModal() {
    document.getElementById('modalTitle').innerText = 'Add New Router';
    document.getElementById('routerForm').reset();
    document.getElementById('router_id').value = '';
    document.getElementById('formErrors').style.display = 'none';
    document.getElementById('routerModal').style.display = 'flex';
}

function closeRouterModal() { document.getElementById('routerModal').style.display = 'none'; }
function closeViewModal() { document.getElementById('viewRouterModal').style.display = 'none'; currentViewRouter = null; }

// Search and filter
document.getElementById('searchInput')?.addEventListener('input', (e) => {
    const searchTerm = e.target.value.toLowerCase();
    const statusFilter = document.getElementById('statusFilter').value;
    
    let filtered = currentRouters.filter(router => 
        router.router_name.toLowerCase().includes(searchTerm) ||
        router.ip_address.toLowerCase().includes(searchTerm) ||
        (router.location && router.location.toLowerCase().includes(searchTerm))
    );
    
    if (statusFilter !== 'all') {
        if (statusFilter === 'online') filtered = filtered.filter(r => r.connection_status === 'online');
        else if (statusFilter === 'offline') filtered = filtered.filter(r => r.connection_status === 'offline');
        else filtered = filtered.filter(r => r.status === statusFilter);
    }
    
    const tbody = document.getElementById('routersTableBody');
    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center">No routers found</td></tr>';
    } else {
        tbody.innerHTML = filtered.map(router => {
            const isOnline = router.connection_status === 'online';
            const blinkClass = (isOnline && router.status === 'active') ? 'status-blink-green' : 'status-blink-red';
            return `
                <tr>
                    <td>${router.id}</td>
                    <td class="cell-name"><strong>${escapeHtml(router.router_name)}</strong><br><small>${escapeHtml(router.router_code)}</small></td>
                    <td>${escapeHtml(router.ip_address)}</td>
                    <td>${escapeHtml(router.location || '-')}</td>
                    <td><span class="tag ${router.status === 'active' ? 't-new' : 't-unavail'}">${router.status}</span></td>
                    <td><div class="status-indicator"><span class="${blinkClass}"></span><span>${isOnline ? 'Online' : 'Offline'}</span></div></td>
                    <td class="text-center"><strong>${router.online_users || 0}</strong></td>
                    <td class="cell-date">${formatDate(router.last_seen)}</td>
                    <td>
                        <button class="btn-icon" onclick="viewRouter(${router.id})">👁️</button>
                        <button class="btn-icon" onclick="editRouter(${router.id})">✏️</button>
                        <button class="btn-icon" onclick="deleteRouter(${router.id})">🗑️</button>
                    </td>
                </tr>
            `;
        }).join('');
    }
});

document.getElementById('statusFilter')?.addEventListener('change', () => {
    document.getElementById('searchInput').dispatchEvent(new Event('input'));
});

function exportRouters() { showToast('Export feature coming soon!', 'info'); }

function startAutoRefresh() {
    if (refreshInterval) clearInterval(refreshInterval);
    refreshInterval = setInterval(() => loadRouters(), 30000);
}

// Set current date
const dateElem = document.getElementById('heroDate');
if (dateElem) {
    const date = new Date();
    dateElem.innerHTML = date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
}

// Get admin name
const user = JSON.parse(localStorage.getItem('adminUser') || '{}');
const adminNameElem = document.getElementById('adminName');
if (adminNameElem) {
    if (user.fullname) adminNameElem.innerHTML = user.fullname.split(' ')[0];
    else if (user.username) adminNameElem.innerHTML = user.username;
}

// Check authentication and load data
if (adminToken && adminToken !== 'null' && adminToken.length > 20) {
    loadRouters();
    startAutoRefresh();
} else {
    window.location.href = 'admin_login.html';
}

// Close modal when clicking outside
window.onclick = function(event) {
    if (event.target === document.getElementById('routerModal')) closeRouterModal();
    if (event.target === document.getElementById('viewRouterModal')) closeViewModal();
}
</script>

<style>
.status-indicator { display: flex; align-items: center; gap: 8px; }
.router-info p { margin: 8px 0; padding: 8px 0; border-bottom: 1px solid #eee; }
.router-info p:last-child { border-bottom: none; }
.modal-content::-webkit-scrollbar { width: 8px; }
.modal-content::-webkit-scrollbar-track { background: #f1f1f1; border-radius: 4px; }
.modal-content::-webkit-scrollbar-thumb { background: #c1c1c1; border-radius: 4px; }
.text-center { text-align: center; }
</style>
</body>
</html>