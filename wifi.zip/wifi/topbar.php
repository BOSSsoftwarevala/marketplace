<header class="d-topbar">
  <div class="crumbs">
    <button class="hamburger" data-drawer-open aria-label="Open navigation">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <line x1="3" y1="6" x2="21" y2="6"/>
        <line x1="3" y1="12" x2="21" y2="12"/>
        <line x1="3" y1="18" x2="21" y2="18"/>
      </svg>
    </button>
    <span>Workspace</span>
    <svg class="sep" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="m9 18 6-6-6-6"/>
    </svg>
    <span class="current">Dashboard</span>
  </div>
  
  <div class="topbar-actions">
    <!-- Search -->
    <button class="cmd" data-palette-open>
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
        <circle cx="11" cy="11" r="7"/>
        <path d="m21 21-4.3-4.3"/>
      </svg>
      <span>Search...</span>
      <kbd class="kbd">⌘K</kbd>
    </button>

    <!-- Real-time Notifications -->
    <div class="dd-wrap">
      <button class="icon-btn" data-dropdown aria-label="Notifications">
        <svg viewBox="0 0 24 24">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        <span class="count danger" id="notificationCount">0</span>
      </button>
      <div class="dd-menu" role="menu" id="notificationsMenu">
        <div class="dd-head">
          <svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
          Notifications
        </div>
        <div class="dd-list" id="notificationsList">
          <div class="dd-item loading">Loading notifications...</div>
        </div>
        <a class="dd-footer" href="#" id="viewAllNotifications">View all notifications →</a>
      </div>
    </div>

    <!-- Real-time Messages -->
    <div class="dd-wrap">
      <button class="icon-btn" data-dropdown aria-label="Messages">
        <svg viewBox="0 0 24 24">
          <rect x="3" y="5" width="18" height="14" rx="2"/>
          <path d="m3 7 9 6 9-6"/>
        </svg>
        <span class="count info" id="messageCount">0</span>
      </button>
      <div class="dd-menu" role="menu" id="messagesMenu">
        <div class="dd-head">
          <svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>
          Messages
        </div>
        <div class="dd-list" id="messagesList">
          <div class="dd-item loading">Loading messages...</div>
        </div>
        <a class="dd-footer" href="#" id="viewAllMessages">View all messages →</a>
      </div>
    </div>

    <!-- Theme Toggle -->
    <button class="icon-btn" id="themeToggle" aria-label="Toggle theme">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>
      </svg>
    </button>

    <!-- User Profile with Real Data -->
    <div class="dd-wrap">
      <div class="avatar" data-dropdown tabindex="0" role="button" aria-label="Account menu" id="userAvatar">AD</div>
      <div class="dd-menu dd-profile" role="menu">
        <div class="dd-profile-head">
          <div class="dd-profile-name" id="userFullname">Admin User</div>
          <div class="dd-profile-email" id="userEmail">admin@wifi.com</div>
        </div>
        <a class="dd-menu-item" href="profile.php">
          <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
          Settings
        </a>
        <a class="dd-menu-item" href="profile.php">
          <svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
          Profile
        </a>
        <a class="dd-menu-item" href="messages.php">
          <svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>
          Messages
          <span class="badge" id="messageBadge">0</span>
        </a>
        <div class="dd-divider"></div>
        <a class="dd-menu-item danger" href="#" id="logoutBtn">
          <svg viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/></svg>
          Logout
        </a>
      </div>
    </div>
  </div>
</header>

<script>
// API Configuration
const API_BASE_URL = 'https://shabanetech.top/wifi-api';
let adminToken = localStorage.getItem('adminToken');

// Helper function to get time ago
function getTimeAgo(dateString) {
    if (!dateString) return 'Just now';
    const date = new Date(dateString);
    const seconds = Math.floor((new Date() - date) / 1000);
    
    if (seconds < 60) return 'Just now';
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes} min ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `${days} day${days > 1 ? 's' : ''} ago`;
    const weeks = Math.floor(days / 7);
    return `${weeks} week${weeks > 1 ? 's' : ''} ago`;
}

// Get initials from name
function getInitials(name) {
    if (!name) return 'AD';
    const parts = name.split(' ');
    if (parts.length === 1) return parts[0].substring(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

// Load user data from localStorage
function loadUserData() {
    try {
        const user = JSON.parse(localStorage.getItem('adminUser') || '{}');
        if (user.fullname) {
            document.getElementById('userFullname').innerText = user.fullname;
            document.getElementById('userEmail').innerText = user.email || 'admin@wifi.com';
            document.getElementById('userAvatar').innerText = getInitials(user.fullname);
        } else if (user.username) {
            document.getElementById('userFullname').innerText = user.username;
            document.getElementById('userEmail').innerText = user.email || 'admin@wifi.com';
            document.getElementById('userAvatar').innerText = getInitials(user.username);
        }
    } catch (e) {
        console.error('Error loading user data:', e);
    }
}

// Fetch notifications from API
async function fetchNotifications() {
    const container = document.getElementById('notificationsList');
    if (!container) return;
    
    try {
        const response = await fetch(`${API_BASE_URL}/api/admin/notifications`, {
            headers: { 'Authorization': `Bearer ${adminToken}` }
        });
        
        if (!response.ok) throw new Error('Failed to fetch');
        
        const data = await response.json();
        
        if (data.success && data.data && data.data.length > 0) {
            const notifications = data.data;
            document.getElementById('notificationCount').innerText = notifications.length;
            
            container.innerHTML = notifications.slice(0, 5).map(notif => `
                <a class="dd-item" href="${notif.link || '#'}">
                    <div class="dd-avatar">${notif.initials || 'NT'}</div>
                    <div class="dd-body">
                        <div class="dd-text">
                            <strong>${escapeHtml(notif.title)}</strong><br>
                            ${escapeHtml(notif.message)}
                        </div>
                        <div class="dd-time">${notif.time_ago || getTimeAgo(notif.created_at)}</div>
                    </div>
                </a>
            `).join('');
        } else {
            document.getElementById('notificationCount').innerText = '0';
            container.innerHTML = '<div class="dd-item">No new notifications</div>';
        }
    } catch (error) {
        console.error('Error fetching notifications:', error);
        container.innerHTML = '<div class="dd-item">Unable to load notifications</div>';
    }
}

// Fetch messages from API
async function fetchMessages() {
    const container = document.getElementById('messagesList');
    if (!container) return;
    
    try {
        const response = await fetch(`${API_BASE_URL}/api/admin/messages`, {
            headers: { 'Authorization': `Bearer ${adminToken}` }
        });
        
        if (!response.ok) throw new Error('Failed to fetch');
        
        const data = await response.json();
        
        if (data.success && data.data && data.data.length > 0) {
            const messages = data.data;
            const unreadCount = messages.filter(m => !m.is_read).length;
            document.getElementById('messageCount').innerText = unreadCount;
            document.getElementById('messageBadge').innerText = unreadCount;
            
            container.innerHTML = messages.slice(0, 5).map(msg => `
                <a class="dd-item" href="${msg.link || 'messages.php?id=' + msg.id}">
                    <div class="dd-avatar ${msg.avatarClass || 'a1'}">${msg.initials || 'MSG'}</div>
                    <div class="dd-body">
                        <div class="dd-row-head">
                            <strong>${escapeHtml(msg.sender_name || 'System')}</strong>
                            <span class="dd-time">${msg.time_ago || getTimeAgo(msg.created_at)}</span>
                        </div>
                        <div class="dd-preview">${escapeHtml(msg.preview || (msg.message || '').substring(0, 60))}${(msg.message || '').length > 60 ? '...' : ''}</div>
                    </div>
                </a>
            `).join('');
        } else {
            document.getElementById('messageCount').innerText = '0';
            document.getElementById('messageBadge').innerText = '0';
            container.innerHTML = '<div class="dd-item">No messages</div>';
        }
    } catch (error) {
        console.error('Error fetching messages:', error);
        container.innerHTML = '<div class="dd-item">Unable to load messages</div>';
    }
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Logout function
function logout() {
    localStorage.removeItem('adminToken');
    localStorage.removeItem('adminUser');
    localStorage.removeItem('rememberedUsername');
    window.location.href = 'signin.html';
}

// Check authentication
function checkAuth() {
    if (!adminToken) {
        window.location.href = 'signin.html';
        return false;
    }
    return true;
}

// Initialize header data
async function initHeader() {
    if (!checkAuth()) return;
    
    loadUserData();
    await fetchNotifications();
    await fetchMessages();
    
    // Auto-refresh every 30 seconds
    setInterval(() => {
        if (document.hidden) return; // Don't refresh if tab is hidden
        fetchNotifications();
        fetchMessages();
    }, 30000);
}

// Event listeners
document.addEventListener('DOMContentLoaded', () => {
    // Logout button
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', (e) => {
            e.preventDefault();
            logout();
        });
    }
    
    // View all notifications
    const viewAllNotifications = document.getElementById('viewAllNotifications');
    if (viewAllNotifications) {
        viewAllNotifications.addEventListener('click', (e) => {
            e.preventDefault();
            window.location.href = 'notifications.php';
        });
    }
    
    // View all messages
    const viewAllMessages = document.getElementById('viewAllMessages');
    if (viewAllMessages) {
        viewAllMessages.addEventListener('click', (e) => {
            e.preventDefault();
            window.location.href = 'messages.php';
        });
    }
    
    // Theme toggle
    // const themeToggle = document.getElementById('themeToggle');
    // if (themeToggle) {
    //     themeToggle.addEventListener('click', () => {
    //         const currentTheme = document.documentElement.getAttribute('data-theme');
    //         const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    //         document.documentElement.setAttribute('data-theme', newTheme);
    //         localStorage.setItem('dash26-theme', newTheme);
    //     });
    // }
    
    // Initialize
    initHeader();
});
</script>

<style>
/* Additional styles for dynamic content */
.dd-item.loading {
    text-align: center;
    padding: 12px;
    color: #6b7280;
    font-style: italic;
}

.badge {
    background: #ef4444;
    color: white;
    font-size: 10px;
    padding: 2px 6px;
    border-radius: 10px;
    margin-left: auto;
}

.dd-row-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 4px;
}

.dd-preview {
    font-size: 12px;
    color: #6b7280;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.dd-avatar {
    width: 32px;
    height: 32px;
    border-radius: 8px;
    background: #e5e7eb;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 12px;
    color: #4b5563;
}

.dd-avatar.a1 { background: #fee2e2; color: #dc2626; }
.dd-avatar.a2 { background: #dcfce7; color: #16a34a; }
.dd-avatar.a3 { background: #dbeafe; color: #2563eb; }
</style>