#!/bin/bash

echo "🔄 Testing Complete Customer Flow"
echo "================================"
echo ""

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

# 1. Register customer
echo -e "${BLUE}1. Registering Customer...${NC}"
REGISTER=$(curl -s -X POST http://localhost:3200/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "fullname": "Test Customer",
    "phone": "0712345678",
    "email": "test@example.com",
    "username": "test_'$(date +%s)'",
    "password": "password123",
    "package_id": 1
  }')
echo $REGISTER | jq -r '.message // .error'
echo ""

# 2. Login
echo -e "${BLUE}2. Customer Login...${NC}"
LOGIN=$(curl -s -X POST http://localhost:3200/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "password": "password123"
  }')
echo $LOGIN | jq -r '.message // .error'
echo ""

# 3. Get packages
echo -e "${BLUE}3. Available Packages...${NC}"
curl -s http://localhost:3200/api/packages | jq -r '.data[] | "   - \(.package_name): KES \(.price) - \(.validity_days) days"'
echo ""

echo -e "${GREEN}✅ Test flow complete!${NC}"
