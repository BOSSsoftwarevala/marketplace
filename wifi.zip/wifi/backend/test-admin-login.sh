#!/bin/bash

echo "========================================="
echo "🔐 Testing Admin Login"
echo "========================================="
echo ""

API_URL="https://shabanetech.top/wifi-api"

# Test login
echo "Logging in with:"
echo "  Username: admin"
echo "  Password: Movile@123"
echo ""

RESPONSE=$(curl -s -X POST $API_URL/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "Movile@123"
  }')

echo "Response:"
echo $RESPONSE | jq .

# Extract token
TOKEN=$(echo $RESPONSE | jq -r '.data.token')

if [ "$TOKEN" != "null" ] && [ ${#TOKEN} -gt 10 ]; then
    echo ""
    echo "✅ Login successful!"
    echo "Token: ${TOKEN:0:50}..."
    
    # Test protected admin route
    echo ""
    echo "Testing protected admin route..."
    curl -s -X GET "$API_URL/api/admin/dashboard/stats" \
      -H "Authorization: Bearer $TOKEN" | jq '.success'
else
    echo ""
    echo "❌ Login failed"
    echo "Please check the password hash in database"
fi
