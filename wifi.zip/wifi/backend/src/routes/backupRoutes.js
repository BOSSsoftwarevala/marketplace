const express = require('express');
const BackupController = require('../controllers/backupController');
const { authMiddleware, adminMiddleware } = require('../middleware/authMiddleware');

const router = express.Router();

// Get all backups
router.get('/', authMiddleware, adminMiddleware, BackupController.getAllBackups);

// Get backup statistics
router.get('/stats', authMiddleware, adminMiddleware, BackupController.getBackupStats);

// Create backup
router.post('/create', authMiddleware, adminMiddleware, BackupController.createBackup);

// Download backup
router.get('/download/:name', authMiddleware, adminMiddleware, BackupController.downloadBackup);

// Restore backup
router.post('/restore', authMiddleware, adminMiddleware, BackupController.restoreBackup);

// Delete backup
router.delete('/delete/:name', authMiddleware, adminMiddleware, BackupController.deleteBackup);

module.exports = router;
