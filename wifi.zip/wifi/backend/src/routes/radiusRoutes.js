const express = require('express');
const RadiusController = require('../controllers/radiusController');
const { authMiddleware, adminMiddleware } = require('../middleware/authMiddleware');
const { verifyRadiusSecret, radiusRateLimit, validateRadiusPacket, logRadiusAuth, radiusEnabled } = require('../middleware/radiusAuthMiddleware');

const router = express.Router();

/**
 * @route   POST /api/radius/sync/customer/:customer_id
 * @desc    Sync single customer to RADIUS
 * @access  Private (Admin)
 */
router.post('/sync/customer/:customer_id', authMiddleware, adminMiddleware, RadiusController.syncCustomer);

/**
 * @route   POST /api/radius/sync/bulk
 * @desc    Bulk sync all active customers to RADIUS
 * @access  Private (Admin)
 */
router.post('/sync/bulk', authMiddleware, adminMiddleware, RadiusController.bulkSync);

/**
 * @route   GET /api/radius/sessions/active
 * @desc    Get active RADIUS sessions
 * @access  Private (Admin)
 */
router.get('/sessions/active', authMiddleware, adminMiddleware, RadiusController.getActiveSessions);

/**
 * @route   GET /api/radius/sessions/customer/:customer_id
 * @desc    Get session history for a customer
 * @access  Private (Admin)
 */
router.get('/sessions/customer/:customer_id', authMiddleware, adminMiddleware, RadiusController.getCustomerSessions);

/**
 * @route   DELETE /api/radius/sessions/:radacctid
 * @desc    Disconnect active session
 * @access  Private (Admin)
 */
router.delete('/sessions/:radacctid', authMiddleware, adminMiddleware, RadiusController.disconnectSession);

/**
 * @route   GET /api/radius/stats
 * @desc    Get RADIUS statistics
 * @access  Private (Admin)
 */
router.get('/stats', authMiddleware, adminMiddleware, RadiusController.getRadiusStats);

/**
 * @route   POST /api/radius/update-usage
 * @desc    Update usage from RADIUS accounting
 * @access  Private (Admin)
 */
router.post('/update-usage', authMiddleware, adminMiddleware, RadiusController.updateUsage);

/**
 * @route   GET /api/radius/config-status
 * @desc    Get RADIUS configuration status
 * @access  Private (Admin)
 */
router.get('/config-status', authMiddleware, adminMiddleware, RadiusController.getConfigStatus);

/**
 * @route   POST /api/radius/test-auth
 * @desc    Test RADIUS authentication
 * @access  Private (Admin)
 */
router.post('/test-auth', authMiddleware, adminMiddleware, RadiusController.testAuth);

// ============ ENDPOINTS FOR FREERADIUS ============

/**
 * @route   POST /api/radius/authenticate
 * @desc    RADIUS authentication endpoint (called by FreeRADIUS)
 * @access  Private (RADIUS Secret + Rate Limited)
 */
router.post('/authenticate', 
    radiusEnabled,
    verifyRadiusSecret, 
    radiusRateLimit, 
    validateRadiusPacket, 
    logRadiusAuth,
    RadiusController.testAuth  // Using testAuth as it calls canAuthenticate
);

/**
 * @route   POST /api/radius/accounting
 * @desc    RADIUS accounting endpoint (called by FreeRADIUS)
 * @access  Private (RADIUS Secret)
 */
router.post('/accounting',
    radiusEnabled,
    verifyRadiusSecret,
    (req, res) => {
        // Accounting endpoint - log and return success
        console.log('RADIUS Accounting received:', req.body);
        res.json({ success: true });
    }
);

module.exports = router;