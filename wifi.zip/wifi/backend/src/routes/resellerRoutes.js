const express = require('express');
const ResellerController = require('../controllers/resellerController');
const { authMiddleware, adminMiddleware, resellerMiddleware } = require('../middleware/authMiddleware');
const { validate } = require('../middleware/validationMiddleware');
const { rateLimit } = require('express-rate-limit');

const router = express.Router();

// Rate limiting for reseller login
const resellerLoginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 5,
    message: 'Too many login attempts'
});

/**
 * @route   POST /api/resellers/login
 * @desc    Reseller login
 * @access  Public
 */
router.post('/login', resellerLoginLimiter, ResellerController.login);

/**
 * @route   GET /api/resellers
 * @desc    Get all resellers (admin only)
 * @access  Private (Admin)
 */
router.get('/', authMiddleware, adminMiddleware, ResellerController.getAllResellers);

/**
 * @route   POST /api/resellers
 * @desc    Create reseller (admin only)
 * @access  Private (Admin)
 */
router.post('/', authMiddleware, adminMiddleware, validate('createReseller'), ResellerController.createReseller);

/**
 * @route   PUT /api/resellers/:id
 * @desc    Update reseller (admin only)
 * @access  Private (Admin)
 */
router.put('/:id', authMiddleware, adminMiddleware, ResellerController.updateReseller);

/**
 * @route   GET /api/resellers/dashboard
 * @desc    Get reseller dashboard
 * @access  Private (Reseller)
 */
router.get('/dashboard', authMiddleware, resellerMiddleware, ResellerController.getDashboard);

/**
 * @route   POST /api/resellers/vouchers/generate
 * @desc    Generate vouchers for reseller
 * @access  Private (Reseller)
 */
router.post('/vouchers/generate', authMiddleware, resellerMiddleware, validate('generateVouchers'), ResellerController.generateVouchers);

/**
 * @route   GET /api/resellers/sales
 * @desc    Get reseller sales history
 * @access  Private (Reseller)
 */
router.get('/sales', authMiddleware, resellerMiddleware, ResellerController.getSalesHistory);

/**
 * @route   POST /api/resellers/withdraw
 * @desc    Withdraw commission
 * @access  Private (Reseller)
 */
router.post('/withdraw', authMiddleware, resellerMiddleware, ResellerController.withdrawCommission);

module.exports = router;