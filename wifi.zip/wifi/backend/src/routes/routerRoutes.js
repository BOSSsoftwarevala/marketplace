const express = require('express');
const RouterController = require('../controllers/routerController');
const { authMiddleware, adminMiddleware } = require('../middleware/authMiddleware');
const { validate, validateRouterExists } = require('../middleware/validationMiddleware');
const { verifyRadiusSecret } = require('../middleware/radiusAuthMiddleware');

const router = express.Router();

/**
 * @route   GET /api/routers
 * @desc    Get all routers
 * @access  Private (Admin)
 */
router.get('/', authMiddleware, adminMiddleware, RouterController.getAllRouters);

/**
 * @route   GET /api/routers/active
 * @desc    Get active routers (public for RADIUS)
 * @access  Public
 */
router.get('/active', RouterController.getActiveRouters);

/**
 * @route   GET /api/routers/:id
 * @desc    Get router by ID
 * @access  Private (Admin)
 */
router.get('/:id', authMiddleware, adminMiddleware, RouterController.getRouterById);

/**
 * @route   POST /api/routers
 * @desc    Create new router
 * @access  Private (Admin)
 */
router.post('/', authMiddleware, adminMiddleware, validate('createRouter'), RouterController.createRouter);

/**
 * @route   PUT /api/routers/:id
 * @desc    Update router
 * @access  Private (Admin)
 */
router.put('/:id', authMiddleware, adminMiddleware, validate('updateRouter'), RouterController.updateRouter);

/**
 * @route   PUT /api/routers/:id/status
 * @desc    Update router status
 * @access  Private (Admin)
 */
router.put('/:id/status', authMiddleware, adminMiddleware, RouterController.updateRouterStatus);

/**
 * @route   DELETE /api/routers/:id
 * @desc    Delete router
 * @access  Private (Admin)
 */
router.delete('/:id', authMiddleware, adminMiddleware, RouterController.deleteRouter);

/**
 * @route   POST /api/routers/heartbeat/:router_code
 * @desc    Receive heartbeat from router
 * @access  Public (with router code)
 */
router.post('/heartbeat/:router_code', validate('heartbeat'), RouterController.heartbeat);

/**
 * @route   GET /api/routers/:id/heartbeats
 * @desc    Get router heartbeat history
 * @access  Private (Admin)
 */
router.get('/:id/heartbeats', authMiddleware, adminMiddleware, RouterController.getHeartbeatHistory);

/**
 * @route   GET /api/routers/:id/stats
 * @desc    Get router statistics
 * @access  Private (Admin)
 */
router.get('/:id/stats', authMiddleware, adminMiddleware, RouterController.getRouterStats);

/**
 * @route   POST /api/routers/:id/mikrotik
 * @desc    Call MikroTik API on router
 * @access  Private (Admin)
 */
router.post('/:id/mikrotik', authMiddleware, adminMiddleware, RouterController.callMikrotikAPI);

/**
 * @route   DELETE /api/routers/:id/disconnect/:username
 * @desc    Disconnect user from router
 * @access  Private (Admin)
 */
router.delete('/:id/disconnect/:username', authMiddleware, adminMiddleware, RouterController.disconnectUser);

module.exports = router;