const express = require('express');
const BranchController = require('../controllers/branchController');
const { authMiddleware, adminMiddleware } = require('../middleware/authMiddleware');

const router = express.Router();

router.get('/', authMiddleware, adminMiddleware, BranchController.getAllBranches);
router.get('/:id', authMiddleware, adminMiddleware, BranchController.getBranchById);
router.post('/', authMiddleware, adminMiddleware, BranchController.createBranch);
router.put('/:id', authMiddleware, adminMiddleware, BranchController.updateBranch);
router.delete('/:id', authMiddleware, adminMiddleware, BranchController.deleteBranch);

module.exports = router;
