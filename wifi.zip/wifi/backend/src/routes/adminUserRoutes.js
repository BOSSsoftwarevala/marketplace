const express = require('express');
const AdminUserController = require('../controllers/adminUserController');
const { authMiddleware, adminMiddleware } = require('../middleware/authMiddleware');

const router = express.Router();

router.get('/', authMiddleware, adminMiddleware, AdminUserController.getAllAdmins);
router.get('/:id', authMiddleware, adminMiddleware, AdminUserController.getAdminById);
router.post('/', authMiddleware, adminMiddleware, AdminUserController.createAdmin);
router.put('/:id', authMiddleware, adminMiddleware, AdminUserController.updateAdmin);
router.delete('/:id', authMiddleware, adminMiddleware, AdminUserController.deleteAdmin);

module.exports = router;
