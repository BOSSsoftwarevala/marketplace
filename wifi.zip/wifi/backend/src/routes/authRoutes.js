const express = require('express');
const AuthController = require('../controllers/authController');
const { validate } = require('../middleware/validationMiddleware');
const { authMiddleware } = require('../middleware/authMiddleware');
const { rateLimit } = require('express-rate-limit');

const router = express.Router();

// Rate limiting for auth routes
const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5, // 5 attempts
    message: 'Too many login attempts, please try again later'
});

const registerLimiter = rateLimit({
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 10, // 10 registrations per hour
    message: 'Too many registrations from this IP'
});

/**
 * @route   POST /api/auth/register
 * @desc    Register a new customer
 * @access  Public
 */
router.post('/register', registerLimiter, validate('register'), AuthController.register);

/**
 * @route   POST /api/auth/login
 * @desc    Customer login
 * @access  Public
 */
router.post('/login', loginLimiter, validate('login'), AuthController.login);

/**
 * @route   POST /api/auth/logout
 * @desc    Customer logout
 * @access  Private (Customer)
 */
router.post('/logout', authMiddleware, AuthController.logout);

/**
 * @route   POST /api/auth/change-password
 * @desc    Change customer password
 * @access  Private (Customer)
 */
router.post('/change-password', authMiddleware, validate('changePassword'), AuthController.changePassword);

/**
 * @route   POST /api/auth/forgot-password
 * @desc    Request password reset
 * @access  Public
 */
router.post('/forgot-password', validate('forgotPassword'), AuthController.forgotPassword);

/**
 * @route   POST /api/auth/reset-password
 * @desc    Reset password with token
 * @access  Public
 */
router.post('/reset-password', validate('resetPassword'), AuthController.resetPassword);

/**
 * @route   POST /api/auth/radius/auth
 * @desc    RADIUS authentication endpoint (called by FreeRADIUS)
 * @access  Private (RADIUS Secret)
 */
router.post('/radius/auth', AuthController.radiusAuth);

module.exports = router;