const express = require('express');
const { authMiddleware, adminMiddleware } = require('../middleware/authMiddleware');
const { pool } = require('../config/database');
const { logInfo } = require('../config/logger');

const router = express.Router();

/**
 * @route   GET /api/admin/dashboard/stats
 * @desc    Get admin dashboard statistics
 * @access  Private (Admin)
 */
router.get('/dashboard/stats', authMiddleware, adminMiddleware, async (req, res) => {
    try {
        // Customer statistics
        const [customerStats] = await pool.execute(`
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
                SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) as inactive,
                SUM(CASE WHEN status = 'suspended' THEN 1 ELSE 0 END) as suspended
            FROM customers
        `);
        
        // Router statistics
        const [routerStats] = await pool.execute(`
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
                SUM(CASE WHEN connection_status = 'online' THEN 1 ELSE 0 END) as online
            FROM routers
        `);
        
        // Payment statistics (today)
        const [todayPayments] = await pool.execute(`
            SELECT 
                COUNT(*) as count,
                COALESCE(SUM(amount), 0) as total
            FROM payments
            WHERE status = 'completed' AND DATE(transaction_date) = CURDATE()
        `);
        
        // Payment statistics (month)
        const [monthPayments] = await pool.execute(`
            SELECT 
                COUNT(*) as count,
                COALESCE(SUM(amount), 0) as total
            FROM payments
            WHERE status = 'completed' AND MONTH(transaction_date) = MONTH(CURDATE())
        `);
        
        // Active sessions
        const [activeSessions] = await pool.execute(`
            SELECT COUNT(*) as active FROM radacct WHERE acctstoptime IS NULL
        `);
        
        // Recent payments
        const [recentPayments] = await pool.execute(`
            SELECT p.*, c.username, c.fullname
            FROM payments p
            JOIN customers c ON p.customer_id = c.id
            WHERE p.status = 'completed'
            ORDER BY p.transaction_date DESC
            LIMIT 10
        `);
        
        // Recent customers
        const [recentCustomers] = await pool.execute(`
            SELECT c.*, p.package_name
            FROM customers c
            JOIN packages p ON c.package_id = p.id
            ORDER BY c.created_at DESC
            LIMIT 10
        `);
        
        res.json({
            success: true,
            data: {
                customers: customerStats[0],
                routers: routerStats[0],
                payments: {
                    today: todayPayments[0],
                    month: monthPayments[0]
                },
                active_sessions: activeSessions[0].active,
                recent_payments: recentPayments,
                recent_customers: recentCustomers
            }
        });
    } catch (error) {
        console.error('Dashboard stats error:', error);
        res.status(500).json({ success: false, error: 'Failed to fetch statistics' });
    }
});
/**
 * @route   GET /api/admin/notifications
 * @desc    Get real-time notifications from existing tables
 * @access  Private (Admin)
 */
router.get('/notifications', authMiddleware, adminMiddleware, async (req, res) => {
    try {
        const notifications = [];
        
        // 1. New customer registrations (last 7 days)
        const [newCustomers] = await pool.execute(`
            SELECT id, fullname, username, created_at 
            FROM customers 
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
            ORDER BY created_at DESC
            LIMIT 5
        `);
        
        for (const customer of newCustomers) {
            notifications.push({
                id: `customer_${customer.id}`,
                title: 'New Customer',
                message: `${customer.fullname} (${customer.username}) registered`,
                type: 'info',
                time_ago: getTimeAgo(customer.created_at),
                link: `/customers.php?id=${customer.id}`,
                initials: getInitials(customer.fullname)
            });
        }
        
        // 2. Recent payments (last 7 days)
        const [recentPayments] = await pool.execute(`
            SELECT p.*, c.fullname, c.username 
            FROM payments p
            JOIN customers c ON p.customer_id = c.id
            WHERE p.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
            ORDER BY p.created_at DESC
            LIMIT 5
        `);
        
        for (const payment of recentPayments) {
            notifications.push({
                id: `payment_${payment.id}`,
                title: 'Payment Received',
                message: `${payment.fullname} paid KES ${payment.amount} for ${payment.package_name || 'package'}`,
                type: 'success',
                time_ago: getTimeAgo(payment.created_at),
                link: `/payments.php?id=${payment.id}`,
                initials: getInitials(payment.fullname)
            });
        }
        
        // 3. Router offline events (from heartbeats)
        const [offlineRouters] = await pool.execute(`
            SELECT r.id, r.router_name, r.ip_address, r.last_seen
            FROM routers r
            WHERE r.status = 'active' 
            AND r.last_seen < DATE_SUB(NOW(), INTERVAL 5 MINUTE)
            LIMIT 5
        `);
        
        for (const router of offlineRouters) {
            const minutesOffline = Math.floor((new Date() - new Date(router.last_seen)) / 60000);
            notifications.push({
                id: `router_${router.id}`,
                title: 'Router Offline',
                message: `${router.router_name} (${router.ip_address}) offline for ${minutesOffline} minutes`,
                type: 'danger',
                time_ago: `${minutesOffline} min ago`,
                link: `/routers.php?id=${router.id}`,
                initials: router.router_name.substring(0, 2).toUpperCase()
            });
        }
        
        // Sort by time (newest first)
        notifications.sort((a, b) => {
            const aTime = a.time_ago;
            const bTime = b.time_ago;
            return aTime.localeCompare(bTime);
        });
        
        // Limit to 10
        const limited = notifications.slice(0, 10);
        
        res.json({
            success: true,
            data: limited,
            unread_count: limited.length
        });
        
    } catch (error) {
        console.error('Notifications error:', error);
        res.json({ success: true, data: [], unread_count: 0 });
    }
});

/**
 * @route   GET /api/admin/messages
 * @desc    Get messages from customer support inquiries
 * @access  Private (Admin)
 */
router.get('/messages', authMiddleware, adminMiddleware, async (req, res) => {
    try {
        const messages = [];
        
        // Get recent customer support messages or inquiries
        // Using existing tables - you can add a 'support_tickets' or 'inquiries' table
        // For now, we'll use customers with recent issues or pending status
        
        const [pendingCustomers] = await pool.execute(`
            SELECT id, fullname, username, phone, email, status, created_at
            FROM customers 
            WHERE status = 'inactive' OR status = 'suspended'
            ORDER BY created_at DESC
            LIMIT 5
        `);
        
        for (const customer of pendingCustomers) {
            messages.push({
                id: `customer_${customer.id}`,
                sender_name: customer.fullname,
                message: `Account ${customer.status} - requires attention`,
                preview: `Customer ${customer.fullname} has ${customer.status} account`,
                is_read: false,
                time_ago: getTimeAgo(customer.created_at),
                avatarClass: 'a1',
                initials: getInitials(customer.fullname),
                link: `/customers.php?id=${customer.id}`
            });
        }
        
        // Get recent failed payments
        const [failedPayments] = await pool.execute(`
            SELECT p.*, c.fullname, c.username
            FROM payments p
            JOIN customers c ON p.customer_id = c.id
            WHERE p.status = 'failed' 
            AND p.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
            ORDER BY p.created_at DESC
            LIMIT 5
        `);
        
        for (const payment of failedPayments) {
            messages.push({
                id: `payment_${payment.id}`,
                sender_name: payment.fullname,
                message: `Payment failed of KES ${payment.amount}`,
                preview: `Failed payment for ${payment.fullname} - KES ${payment.amount}`,
                is_read: false,
                time_ago: getTimeAgo(payment.created_at),
                avatarClass: 'a2',
                initials: getInitials(payment.fullname),
                link: `/payments.php?id=${payment.id}`
            });
        }
        
        // Get low data limit warnings
        const [lowDataCustomers] = await pool.execute(`
            SELECT c.id, c.fullname, c.username, cu.total_mb, p.data_limit_mb
            FROM customers c
            JOIN customer_usage cu ON c.id = cu.customer_id
            JOIN packages p ON c.package_id = p.id
            WHERE p.data_limit_mb > 0 
            AND cu.total_mb > (p.data_limit_mb * 0.8)
            AND cu.total_mb < p.data_limit_mb
            ORDER BY (p.data_limit_mb - cu.total_mb) ASC
            LIMIT 5
        `);
        
        for (const customer of lowDataCustomers) {
            const percentUsed = Math.round((customer.total_mb / customer.data_limit_mb) * 100);
            messages.push({
                id: `data_${customer.id}`,
                sender_name: customer.fullname,
                message: `Data usage at ${percentUsed}%`,
                preview: `${customer.username} has used ${percentUsed}% of their data limit`,
                is_read: false,
                time_ago: 'Just now',
                avatarClass: 'a3',
                initials: getInitials(customer.fullname),
                link: `/customers.php?id=${customer.id}&tab=usage`
            });
        }
        
        // Sort by time
        messages.sort((a, b) => b.time_ago.localeCompare(a.time_ago));
        
        res.json({
            success: true,
            data: messages.slice(0, 10),
            unread_count: messages.length
        });
        
    } catch (error) {
        console.error('Messages error:', error);
        res.json({ success: true, data: [], unread_count: 0 });
    }
});

// Helper functions
function getTimeAgo(date) {
    if (!date) return 'Just now';
    const seconds = Math.floor((new Date() - new Date(date)) / 1000);
    
    if (seconds < 60) return 'Just now';
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes} min ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `${days} day${days > 1 ? 's' : ''} ago`;
    const weeks = Math.floor(days / 7);
    return `${weeks} week${weeks > 1 ? 's' : ''} ago`;
}

function getInitials(name) {
    if (!name) return 'AD';
    return name.split(' ').map(w => w[0]).join('').substring(0, 2).toUpperCase();
}

/**
 * @route   GET /api/admin/verify
 * @desc    Verify admin token is valid
 * @access  Private (Admin)
 */
router.get('/verify', authMiddleware, adminMiddleware, async (req, res) => {
    try {
        res.json({
            success: true,
            message: 'Token is valid',
            user: {
                id: req.user.id,
                username: req.user.username,
                email: req.user.email,
                role: req.user.role
            }
        });
    } catch (error) {
        console.error('Verify error:', error);
        res.status(500).json({ 
            success: false, 
            error: 'Token verification failed' 
        });
    }
});

/**
 * @route   GET /api/admin/system/info
 * @desc    Get system information
 * @access  Private (Admin)
 */
router.get('/system/info', authMiddleware, adminMiddleware, async (req, res) => {
    try {
        const os = require('os');
        
        const systemInfo = {
            node_version: process.version,
            platform: os.platform(),
            arch: os.arch(),
            cpus: os.cpus().length,
            total_memory: os.totalmem(),
            free_memory: os.freemem(),
            uptime: os.uptime(),
            load_average: os.loadavg(),
            environment: process.env.NODE_ENV || 'development',
            timestamp: new Date()
        };
        
        res.json({
            success: true,
            data: systemInfo
        });
    } catch (error) {
        console.error('System info error:', error);
        res.status(500).json({ success: false, error: 'Failed to fetch system info' });
    }
});

/**
 * @route   GET /api/admin/database/status
 * @desc    Check database status
 * @access  Private (Admin)
 */
router.get('/database/status', authMiddleware, adminMiddleware, async (req, res) => {
    try {
        await pool.execute('SELECT 1');
        
        // Get table counts
        const tables = ['customers', 'routers', 'packages', 'payments', 'vouchers', 'radacct'];
        const counts = {};
        
        for (const table of tables) {
            const [rows] = await pool.execute(`SELECT COUNT(*) as count FROM ${table}`);
            counts[table] = rows[0].count;
        }
        
        res.json({
            success: true,
            data: {
                status: 'connected',
                counts,
                timestamp: new Date()
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            data: {
                status: 'disconnected',
                error: error.message,
                timestamp: new Date()
            }
        });
    }
});

/**
 * @route   POST /api/admin/backup/database
 * @desc    Trigger database backup (admin only)
 * @access  Private (Admin)
 */
router.post('/backup/database', authMiddleware, adminMiddleware, async (req, res) => {
    try {
        const backupName = `backup_${new Date().toISOString().replace(/[:.]/g, '-')}.sql`;
        
        // This would trigger a backup process
        // In production, you might use mysqldump or a backup service
        
        logInfo(`Database backup triggered by admin: ${req.user.id}`, { backupName });
        
        res.json({
            success: true,
            message: 'Backup initiated',
            data: { backup_name: backupName }
        });
    } catch (error) {
        console.error('Backup error:', error);
        res.status(500).json({ success: false, error: 'Backup failed' });
    }
});

module.exports = router;