const express = require('express');
const CustomerController = require('../controllers/customerController');
const { authMiddleware, adminMiddleware, customerMiddleware } = require('../middleware/authMiddleware');
const { validate, validatePagination, validateCustomerExists } = require('../middleware/validationMiddleware');

const router = express.Router();

/**
 * @route   GET /api/customers
 * @desc    Get all customers (admin only)
 * @access  Private (Admin)
 */
router.get('/', authMiddleware, adminMiddleware, validatePagination, CustomerController.getAllCustomers);

/**
 * @route   GET /api/customers/profile
 * @desc    Get current customer profile
 * @access  Private (Customer)
 */
router.get('/profile', authMiddleware, customerMiddleware, CustomerController.getProfile);

/**
 * @route   PUT /api/customers/profile
 * @desc    Update current customer profile
 * @access  Private (Customer)
 */
router.put('/profile', authMiddleware, customerMiddleware, CustomerController.updateProfile);

/**
 * @route   GET /api/customers/usage/stats
 * @desc    Get current customer usage statistics
 * @access  Private (Customer)
 */
router.get('/usage/stats', authMiddleware, customerMiddleware, CustomerController.getUsageStats);

/**
 * @route   GET /api/customers/:id
 * @desc    Get customer by ID (admin only)
 * @access  Private (Admin)
 */
router.get('/:id', authMiddleware, adminMiddleware, CustomerController.getCustomerById);

/**
 * @route   POST /api/customers
 * @desc    Create new customer (admin only)
 * @access  Private (Admin)
 */
router.post('/', authMiddleware, adminMiddleware, validate('register'), CustomerController.createCustomer);

/**
 * @route   PUT /api/customers/:id
 * @desc    Update customer (admin only)
 * @access  Private (Admin)
 */
router.put('/:id', authMiddleware, adminMiddleware, validate('updateCustomer'), CustomerController.updateCustomer);

/**
 * @route   DELETE /api/customers/:id
 * @desc    Delete customer (admin only)
 * @access  Private (Admin)
 */
router.delete('/:id', authMiddleware, adminMiddleware, CustomerController.deleteCustomer);

/**
 * @route   GET /api/customers/:id/usage
 * @desc    Get customer usage statistics (admin only)
 * @access  Private (Admin)
 */
router.get('/:id/usage', authMiddleware, adminMiddleware, CustomerController.getUsageStats);

/**
 * @route   POST /api/customers/router-access
 * @desc    Manage customer router access (admin only)
 * @access  Private (Admin)
 */
router.post('/router-access', authMiddleware, adminMiddleware, validate('manageRouterAccess'), CustomerController.manageRouterAccess);

/**
 * @route   GET /api/customers/:id/sessions
 * @desc    Get customer sessions (admin only)
 * @access  Private (Admin)
 */
router.get('/:id/sessions', authMiddleware, adminMiddleware, CustomerController.getUsageStats);

module.exports = router;