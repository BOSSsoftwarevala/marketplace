const express = require('express');
const PaymentController = require('../controllers/paymentController');
const { authMiddleware, adminMiddleware, customerMiddleware } = require('../middleware/authMiddleware');
const { validate } = require('../middleware/validationMiddleware');
const { rateLimit } = require('express-rate-limit');

const router = express.Router();

// Rate limiting for payment initiation
const paymentLimiter = rateLimit({
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 5, // 5 payment attempts per hour
    message: 'Too many payment attempts, please try again later'
});

/**
 * @route   POST /api/payments/mpesa/initiate
 * @desc    Initiate M-Pesa STK Push payment
 * @access  Private (Customer/Admin)
 */
router.post('/mpesa/initiate', authMiddleware, paymentLimiter, validate('initiatePayment'), PaymentController.initiateMpesaPayment);

/**
 * @route   POST /api/payments/mpesa/callback
 * @desc    M-Pesa STK Push callback URL
 * @access  Public (Called by Safaricom)
 */
router.post('/mpesa/callback', PaymentController.mpesaCallback);

/**
 * @route   GET /api/payments/status/:checkoutRequestId
 * @desc    Check payment status
 * @access  Private
 */
router.get('/status/:checkoutRequestId', authMiddleware, PaymentController.checkPaymentStatus);

/**
 * @route   GET /api/payments/history/:customer_id
 * @desc    Get payment history for a customer
 * @access  Private (Customer/Admin)
 */
router.get('/history/:customer_id', authMiddleware, PaymentController.getPaymentHistory);

/**
 * @route   POST /api/payments/voucher
 * @desc    Process voucher payment
 * @access  Private (Customer)
 */
router.post('/voucher', authMiddleware, customerMiddleware, validate('redeemVoucher'), PaymentController.processVoucherPayment);

/**
 * @route   GET /api/payments/stats
 * @desc    Get payment statistics (admin only)
 * @access  Private (Admin)
 */
router.get('/stats', authMiddleware, adminMiddleware, PaymentController.getPaymentStats);

/**
 * @route   POST /api/payments/refund
 * @desc    Initiate refund (admin only)
 * @access  Private (Admin)
 */
router.post('/refund', authMiddleware, adminMiddleware, PaymentController.initiateRefund);

module.exports = router;