const express = require('express');
const Package = require('../models/Package');
const { authMiddleware, adminMiddleware } = require('../middleware/authMiddleware');

const router = express.Router();

/**
 * @route   GET /api/packages
 * @desc    Get all packages
 * @access  Public
 */
router.get('/', async (req, res) => {
    try {
        const packages = await Package.getAll();
        res.json({
            success: true,
            data: packages
        });
    } catch (error) {
        console.error('Get packages error:', error);
        res.status(500).json({ 
            success: false, 
            error: 'Failed to fetch packages' 
        });
    }
});

/**
 * @route   GET /api/packages/active
 * @desc    Get active packages (with price > 0)
 * @access  Public
 */
router.get('/active', async (req, res) => {
    try {
        const packages = await Package.getActivePackages();
        res.json({
            success: true,
            data: packages
        });
    } catch (error) {
        console.error('Get active packages error:', error);
        res.status(500).json({ 
            success: false, 
            error: 'Failed to fetch active packages' 
        });
    }
});

/**
 * @route   GET /api/packages/:id
 * @desc    Get package by ID
 * @access  Public
 */
router.get('/:id', async (req, res) => {
    try {
        const package_ = await Package.findById(req.params.id);
        if (!package_) {
            return res.status(404).json({ 
                success: false, 
                error: 'Package not found' 
            });
        }
        res.json({
            success: true,
            data: package_
        });
    } catch (error) {
        console.error('Get package error:', error);
        res.status(500).json({ 
            success: false, 
            error: 'Failed to fetch package' 
        });
    }
});

/**
 * @route   POST /api/packages
 * @desc    Create new package (admin only)
 * @access  Private (Admin)
 */
router.post('/', authMiddleware, adminMiddleware, async (req, res) => {
    try {
        const { package_name, price, validity_days, data_limit_mb, upload_speed, download_speed, description } = req.body;
        
        if (!package_name || !price || !validity_days) {
            return res.status(400).json({ 
                success: false, 
                error: 'Package name, price and validity days are required' 
            });
        }
        
        const packageId = await Package.create({
            package_name,
            price,
            validity_days,
            data_limit_mb: data_limit_mb || 0,
            upload_speed: upload_speed || '1M',
            download_speed: download_speed || '1M',
            description
        });
        
        res.status(201).json({
            success: true,
            message: 'Package created successfully',
            data: { id: packageId, package_name }
        });
    } catch (error) {
        console.error('Create package error:', error);
        res.status(500).json({ 
            success: false, 
            error: 'Failed to create package' 
        });
    }
});

/**
 * @route   PUT /api/packages/:id
 * @desc    Update package (admin only)
 * @access  Private (Admin)
 */
router.put('/:id', authMiddleware, adminMiddleware, async (req, res) => {
    try {
        const package_ = await Package.findById(req.params.id);
        if (!package_) {
            return res.status(404).json({ 
                success: false, 
                error: 'Package not found' 
            });
        }
        
        await Package.update(req.params.id, req.body);
        
        res.json({
            success: true,
            message: 'Package updated successfully'
        });
    } catch (error) {
        console.error('Update package error:', error);
        res.status(500).json({ 
            success: false, 
            error: 'Failed to update package' 
        });
    }
});

/**
 * @route   DELETE /api/packages/:id
 * @desc    Delete package (admin only)
 * @access  Private (Admin)
 */
router.delete('/:id', authMiddleware, adminMiddleware, async (req, res) => {
    try {
        const package_ = await Package.findById(req.params.id);
        if (!package_) {
            return res.status(404).json({ 
                success: false, 
                error: 'Package not found' 
            });
        }
        
        await Package.delete(req.params.id);
        
        res.json({
            success: true,
            message: 'Package deleted successfully'
        });
    } catch (error) {
        console.error('Delete package error:', error);
        res.status(500).json({ 
            success: false, 
            error: error.message || 'Failed to delete package'
        });
    }
});

/**
 * @route   GET /api/packages/stats
 * @desc    Get package statistics (admin only)
 * @access  Private (Admin)
 */
router.get('/stats/all', authMiddleware, adminMiddleware, async (req, res) => {
    try {
        const stats = await Package.getStats();
        res.json({
            success: true,
            data: stats
        });
    } catch (error) {
        console.error('Get package stats error:', error);
        res.status(500).json({ 
            success: false, 
            error: 'Failed to fetch package statistics' 
        });
    }
});

module.exports = router;
