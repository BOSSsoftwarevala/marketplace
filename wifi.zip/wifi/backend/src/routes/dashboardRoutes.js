const express = require('express');
const DashboardController = require('../controllers/dashboardController');
const { authMiddleware, adminMiddleware } = require('../middleware/authMiddleware');

const router = express.Router();

/**
 * @route   GET /api/dashboard
 * @desc    Get complete dashboard data in one call
 * @access  Private (Admin only)
 */
router.get('/', authMiddleware, adminMiddleware, DashboardController.getDashboardData);

module.exports = router;
