const express = require('express');
const authRoutes = require('./authRoutes');
const customerRoutes = require('./customerRoutes');
const paymentRoutes = require('./paymentRoutes');
const routerRoutes = require('./routerRoutes');
const voucherRoutes = require('./voucherRoutes');
const resellerRoutes = require('./resellerRoutes');
const radiusRoutes = require('./radiusRoutes');
const adminRoutes = require('./adminRoutes');

const router = express.Router();

// API version prefix
const API_VERSION = '/api/v1';

// Mount routes
router.use('/auth', authRoutes);
router.use('/customers', customerRoutes);
router.use('/payments', paymentRoutes);
router.use('/routers', routerRoutes);
router.use('/vouchers', voucherRoutes);
router.use('/resellers', resellerRoutes);
router.use('/radius', radiusRoutes);
router.use('/admin', adminRoutes);

// Health check endpoint
router.get('/health', (req, res) => {
    res.json({
        success: true,
        status: 'healthy',
        timestamp: new Date(),
        version: '1.0.0'
    });
});

// API info endpoint
router.get('/', (req, res) => {
    res.json({
        success: true,
        name: 'WiFi Billing System API',
        version: '1.0.0',
        description: 'ISP-grade WiFi billing system with FreeRADIUS integration',
        endpoints: {
            auth: '/api/auth',
            customers: '/api/customers',
            payments: '/api/payments',
            routers: '/api/routers',
            vouchers: '/api/vouchers',
            resellers: '/api/resellers',
            radius: '/api/radius',
            admin: '/api/admin'
        }
    });
});

module.exports = router;