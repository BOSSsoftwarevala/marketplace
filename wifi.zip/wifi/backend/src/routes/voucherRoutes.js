const express = require('express');
const VoucherController = require('../controllers/voucherController');
const { authMiddleware, adminMiddleware, customerMiddleware } = require('../middleware/authMiddleware');
const { validate } = require('../middleware/validationMiddleware');

const router = express.Router();

// Generate vouchers (admin only)
router.post('/generate', authMiddleware, adminMiddleware, validate('generateVouchers'), VoucherController.generateVouchers);

// Get all vouchers (admin only)
router.get('/', authMiddleware, adminMiddleware, VoucherController.getAllVouchers);

// Get voucher statistics (admin only)
router.get('/stats', authMiddleware, adminMiddleware, VoucherController.getVoucherStats);

// Get voucher by ID (admin only) - ADD THIS
router.get('/:id', authMiddleware, adminMiddleware, VoucherController.getVoucherById);

// Update voucher (admin only) - ADD THIS FOR EDIT
router.put('/:id', authMiddleware, adminMiddleware, VoucherController.updateVoucher);

// Get voucher by code
router.get('/code/:code', authMiddleware, adminMiddleware, VoucherController.getVoucherByCode);

// Redeem voucher (customer self-service)
router.post('/redeem', authMiddleware, customerMiddleware, validate('redeemVoucher'), VoucherController.redeemVoucher);

// Delete voucher (admin only)
router.delete('/:id', authMiddleware, adminMiddleware, VoucherController.deleteVoucher);

module.exports = router;