const dotenv = require('dotenv');

dotenv.config();

const radiusConfig = {
    // FreeRADIUS Server settings
    server: {
        host: process.env.RADIUS_HOST || 'localhost',
        auth_port: parseInt(process.env.RADIUS_AUTH_PORT) || 1812,
        acct_port: parseInt(process.env.RADIUS_ACCT_PORT) || 1813,
        secret: process.env.RADIUS_SECRET || 'testing123',
        timeout: parseInt(process.env.RADIUS_TIMEOUT) || 5,
        retries: parseInt(process.env.RADIUS_RETRIES) || 3
    },
    
    // Database table mappings
    tables: {
        radcheck: 'radcheck',
        radreply: 'radreply',
        radacct: 'radacct',
        radusergroup: 'radusergroup',
        radgroupreply: 'radgroupreply'
    },
    
    // RADIUS attributes
    attributes: {
        // Authentication
        CLEARTEXT_PASSWORD: 'Cleartext-Password',
        USER_PASSWORD: 'User-Password',
        
        // Authorization
        MIKROTIK_RATE_LIMIT: 'Mikrotik-Rate-Limit',
        SESSION_TIMEOUT: 'Session-Timeout',
        IDLE_TIMEOUT: 'Idle-Timeout',
        REPLY_MESSAGE: 'Reply-Message',
        
        // Accounting
        ACCT_STATUS_TYPE: 'Acct-Status-Type',
        ACCT_INPUT_OCTETS: 'Acct-Input-Octets',
        ACCT_OUTPUT_OCTETS: 'Acct-Output-Octets',
        ACCT_SESSION_TIME: 'Acct-Session-Time',
        ACCT_TERMINATE_CAUSE: 'Acct-Terminate-Cause'
    },
    
    // Accounting status types
    acctStatusType: {
        START: 1,
        STOP: 2,
        ALIVE: 3,
        INTERIM_UPDATE: 3,
        ACCOUNTING_ON: 7,
        ACCOUNTING_OFF: 8
    },
    
    // Terminate causes
    terminateCause: {
        USER_REQUEST: 'User-Request',
        LOST_CARRIER: 'Lost-Carrier',
        LOST_SERVICE: 'Lost-Service',
        IDLE_TIMEOUT: 'Idle-Timeout',
        SESSION_TIMEOUT: 'Session-Timeout',
        ADMIN_RESET: 'Admin-Reset',
        ADMIN_REBOOT: 'Admin-Reboot',
        PORT_ERROR: 'Port-Error',
        NAS_ERROR: 'NAS-Error',
        NAS_REQUEST: 'NAS-Request',
        NAS_REBOOT: 'NAS-Reboot',
        PORT_UNNEEDED: 'Port-Unneeded',
        PORT_PREEMPTED: 'Port-Preempted',
        PORT_SUSPENDED: 'Port-Suspended',
        SERVICE_UNAVAILABLE: 'Service-Unavailable',
        CALLBACK: 'Callback',
        USER_ERROR: 'User-Error',
        HOST_REQUEST: 'Host-Request'
    },
    
    // Default values
    defaults: {
        upload_speed: '1M',
        download_speed: '1M',
        session_timeout: 86400, // 24 hours in seconds
        idle_timeout: 300, // 5 minutes in seconds
        interim_interval: 300 // 5 minutes
    },
    
    // MikroTik specific settings
    mikrotik: {
        api_port: parseInt(process.env.MIKROTIK_API_PORT) || 8728,
        api_ssl_port: parseInt(process.env.MIKROTIK_API_SSL_PORT) || 8729,
        hotspot_enabled: true,
        hotspot_server: 'hotspot1'
    }
};

// Get speed limit string for MikroTik
const getRateLimit = (uploadSpeed, downloadSpeed) => {
    const upload = uploadSpeed || radiusConfig.defaults.upload_speed;
    const download = downloadSpeed || radiusConfig.defaults.download_speed;
    return `${upload}/${download}`;
};

// Parse rate limit from MikroTik format
const parseRateLimit = (rateLimit) => {
    if (!rateLimit) return null;
    const [upload, download] = rateLimit.split('/');
    return { upload, download };
};

module.exports = {
    radiusConfig,
    getRateLimit,
    parseRateLimit
};