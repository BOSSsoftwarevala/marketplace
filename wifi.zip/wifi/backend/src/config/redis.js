const redis = require('redis');
const dotenv = require('dotenv');

dotenv.config();

let redisClient = null;
let isConnected = false;

const getRedisConfig = () => {
    const config = {
        socket: {
            host: process.env.REDIS_HOST || 'localhost',
            port: parseInt(process.env.REDIS_PORT) || 6379,
            reconnectStrategy: (retries) => {
                if (retries > 10) {
                    console.error('❌ Redis max reconnection attempts reached');
                    return new Error('Redis max reconnection attempts reached');
                }
                return Math.min(retries * 100, 3000);
            },
            connectTimeout: 10000
        }
    };
    
    if (process.env.REDIS_PASSWORD) {
        config.password = process.env.REDIS_PASSWORD;
    }
    
    if (process.env.REDIS_DB) {
        config.database = parseInt(process.env.REDIS_DB);
    }
    
    return config;
};

const connectRedis = async () => {
    try {
        const config = getRedisConfig();
        redisClient = redis.createClient(config);
        
        redisClient.on('connect', () => {
            console.log('✅ Redis connected successfully');
            isConnected = true;
        });
        
        redisClient.on('error', (err) => {
            console.error('❌ Redis error:', err.message);
            isConnected = false;
        });
        
        redisClient.on('reconnecting', () => {
            console.log('🔄 Redis reconnecting...');
        });
        
        await redisClient.connect();
        
        // Test connection
        await redisClient.set('ping', 'pong');
        const result = await redisClient.get('ping');
        if (result === 'pong') {
            console.log('✅ Redis connection verified');
        }
        
        return redisClient;
    } catch (error) {
        console.error('❌ Redis connection failed:', error.message);
        // Don't throw - allow app to start without Redis
        redisClient = null;
        isConnected = false;
        return null;
    }
};

const getRedisClient = () => {
    return redisClient;
};

const isRedisConnected = () => {
    return isConnected && redisClient && redisClient.isOpen;
};

// Cache helper functions
const cacheGet = async (key) => {
    if (!isRedisConnected()) return null;
    try {
        const value = await redisClient.get(key);
        return value ? JSON.parse(value) : null;
    } catch (error) {
        console.error('Redis cache get error:', error);
        return null;
    }
};

const cacheSet = async (key, value, ttlSeconds = 3600) => {
    if (!isRedisConnected()) return false;
    try {
        const stringValue = JSON.stringify(value);
        await redisClient.setEx(key, ttlSeconds, stringValue);
        return true;
    } catch (error) {
        console.error('Redis cache set error:', error);
        return false;
    }
};

const cacheDelete = async (key) => {
    if (!isRedisConnected()) return false;
    try {
        await redisClient.del(key);
        return true;
    } catch (error) {
        console.error('Redis cache delete error:', error);
        return false;
    }
};

const cacheFlush = async () => {
    if (!isRedisConnected()) return false;
    try {
        await redisClient.flushAll();
        return true;
    } catch (error) {
        console.error('Redis cache flush error:', error);
        return false;
    }
};

// Session management
const setSession = async (sessionId, data, ttlSeconds = 86400) => {
    return await cacheSet(`session:${sessionId}`, data, ttlSeconds);
};

const getSession = async (sessionId) => {
    return await cacheGet(`session:${sessionId}`);
};

const deleteSession = async (sessionId) => {
    return await cacheDelete(`session:${sessionId}`);
};

// Rate limiting
const rateLimitCheck = async (key, limit, windowSeconds) => {
    if (!isRedisConnected()) return { allowed: true, remaining: limit };
    
    try {
        const current = await redisClient.incr(`rate:${key}`);
        if (current === 1) {
            await redisClient.expire(`rate:${key}`, windowSeconds);
        }
        
        const remaining = Math.max(0, limit - current);
        return {
            allowed: current <= limit,
            remaining,
            limit,
            current
        };
    } catch (error) {
        console.error('Rate limit check error:', error);
        return { allowed: true, remaining: limit };
    }
};

// User online status tracking
const setUserOnline = async (userId, routerId, sessionId) => {
    if (!isRedisConnected()) return false;
    try {
        const userData = JSON.stringify({ routerId, sessionId, timestamp: Date.now() });
        await redisClient.setEx(`user:online:${userId}`, 300, userData);
        await redisClient.sAdd(`router:users:${routerId}`, userId.toString());
        await redisClient.expire(`router:users:${routerId}`, 300);
        return true;
    } catch (error) {
        console.error('Set user online error:', error);
        return false;
    }
};

const setUserOffline = async (userId, routerId) => {
    if (!isRedisConnected()) return false;
    try {
        await redisClient.del(`user:online:${userId}`);
        await redisClient.sRem(`router:users:${routerId}`, userId.toString());
        return true;
    } catch (error) {
        console.error('Set user offline error:', error);
        return false;
    }
};

const getOnlineUsers = async (routerId) => {
    if (!isRedisConnected()) return [];
    try {
        const users = await redisClient.sMembers(`router:users:${routerId}`);
        return users;
    } catch (error) {
        console.error('Get online users error:', error);
        return [];
    }
};

module.exports = {
    redisClient,
    connectRedis,
    getRedisClient,
    isRedisConnected,
    cacheGet,
    cacheSet,
    cacheDelete,
    cacheFlush,
    setSession,
    getSession,
    deleteSession,
    rateLimitCheck,
    setUserOnline,
    setUserOffline,
    getOnlineUsers
};