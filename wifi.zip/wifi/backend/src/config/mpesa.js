const dotenv = require('dotenv');

dotenv.config();

const mpesaConfig = {
    // Environment
    environment: process.env.MPESA_ENV || 'sandbox',
    
    // API URLs
    urls: {
        sandbox: 'https://sandbox.safaricom.co.ke',
        production: 'https://api.safaricom.co.ke'
    },
    
    // Endpoints
    endpoints: {
        auth: '/oauth/v1/generate',
        stk_push: '/mpesa/stkpush/v1/processrequest',
        stk_query: '/mpesa/stkpushquery/v1/query',
        b2c: '/mpesa/b2c/v1/paymentrequest',
        b2b: '/mpesa/b2b/v1/paymentrequest',
        reversal: '/mpesa/reversal/v1/request',
        account_balance: '/mpesa/accountbalance/v1/query',
        transaction_status: '/mpesa/transactionstatus/v1/query',
        c2b_register: '/mpesa/c2b/v1/registerurl',
        c2b_simulate: '/mpesa/c2b/v1/simulate'
    },
    
    // Credentials
    credentials: {
        consumer_key: process.env.MPESA_CONSUMER_KEY,
        consumer_secret: process.env.MPESA_CONSUMER_SECRET,
        passkey: process.env.MPESA_PASSKEY,
        shortcode: process.env.MPESA_SHORTCODE,
        initiator_name: process.env.MPESA_INITIATOR_NAME,
        initiator_password: process.env.MPESA_INITIATOR_PASSWORD,
        security_credential: process.env.MPESA_SECURITY_CREDENTIAL
    },
    
    // Transaction types
    transactionTypes: {
        c2b: {
            CUSTOMER_PAY_BILL_ONLINE: 'CustomerPayBillOnline',
            CUSTOMER_BUY_GOODS_ONLINE: 'CustomerBuyGoodsOnline'
        },
        b2c: {
            SALARY_PAYMENT: 'SalaryPayment',
            BUSINESS_PAYMENT: 'BusinessPayment',
            PROMOTION_PAYMENT: 'PromotionPayment'
        },
        b2b: {
            BUSINESS_PAY_BILL: 'BusinessPayBill',
            BUSINESS_BUY_GOODS: 'BusinessBuyGoods',
            DISBURSEMENT: 'Disbursement',
            REVERSAL: 'Reversal'
        }
    },
    
    // Command IDs
    commandIDs: {
        b2c: {
            SALARY: 'SalaryPayment',
            BUSINESS: 'BusinessPayment',
            PROMOTION: 'PromotionPayment'
        },
        reversal: 'TransactionReversal',
        account_balance: 'AccountBalance',
        transaction_status: 'TransactionStatusQuery'
    },
    
    // Response codes
    responseCodes: {
        SUCCESS: '0',
        PENDING: '1',
        FAILED: '1037'
    },
    
    // Result codes
    resultCodes: {
        SUCCESS: 0,
        INSUFFICIENT_FUNDS: 1,
        EXPIRED: 2,
        FAILED: 1037
    },
    
    // Default values
    defaults: {
        shortcode_type: 'paybill', // paybill or till_number
        timeout_seconds: 60,
        result_url_timeout: 10
    },
    
    // Business shortcode types
    shortcodeTypes: {
        PAYBILL: 'paybill',
        TILL_NUMBER: 'till_number'
    }
};

// Get base URL based on environment
const getBaseUrl = () => {
    return mpesaConfig.urls[mpesaConfig.environment];
};

// Generate password for STK push
const generatePassword = (shortcode, passkey, timestamp) => {
    const str = `${shortcode}${passkey}${timestamp}`;
    return Buffer.from(str).toString('base64');
};

// Format phone number to international format (254XXXXXXXXX)
const formatPhoneNumber = (phone) => {
    // Remove any non-digit characters
    let cleaned = phone.toString().replace(/\D/g, '');
    
    // Check if it's a Safaricom number (starts with 07 or 01)
    if (cleaned.startsWith('0')) {
        cleaned = '254' + cleaned.substring(1);
    } else if (cleaned.startsWith('7') || cleaned.startsWith('1')) {
        cleaned = '254' + cleaned;
    }
    
    // Validate phone number length (12 digits for Kenya)
    if (cleaned.length !== 12) {
        throw new Error(`Invalid phone number format: ${phone}`);
    }
    
    return cleaned;
};

// Format amount (ensure decimal with 2 places)
const formatAmount = (amount) => {
    return parseFloat(amount).toFixed(2);
};

module.exports = {
    mpesaConfig,
    getBaseUrl,
    generatePassword,
    formatPhoneNumber,
    formatAmount
};