const mysql = require('mysql2/promise');
const dotenv = require('dotenv');

dotenv.config();

const pool = mysql.createPool({
    host: process.env.DB_HOST || '127.0',
    port: parseInt(process.env.DB_PORT) || 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'wifi_billing',
    waitForConnections: true,
    connectionLimit: parseInt(process.env.DB_POOL_SIZE) || 10,
    queueLimit: 0,
    enableKeepAlive: true,
    keepAliveInitialDelay: 0,
    // For handling timeouts
    // acquireTimeout: 60000,
    // timeout: 60000
});

// Test connection
const testConnection = async () => {
    try {
        const connection = await pool.getConnection();
        console.log('✅ MySQL Database connected successfully');
        connection.release();
        return true;
    } catch (error) {
        console.error('❌ Database connection failed:', error.message);
        throw error;
    }
};

// Health check function
const getDatabaseStatus = async () => {
    try {
        const [rows] = await pool.execute('SELECT 1 as connected');
        return { connected: rows[0].connected === 1, timestamp: new Date() };
    } catch (error) {
        return { connected: false, error: error.message, timestamp: new Date() };
    }
};

module.exports = { pool, testConnection, getDatabaseStatus };