const Joi = require('joi');

/**
 * Validation schemas
 */
const schemas = {
    // Customer registration
    register: Joi.object({
        fullname: Joi.string().min(3).max(100).required(),
        phone: Joi.string().pattern(/^[0-9]{10,12}$/).required(),
        email: Joi.string().email().optional().allow('', null),
        username: Joi.string().min(3).max(50).pattern(/^[a-zA-Z0-9_.-]+$/).required(),
        password: Joi.string().min(4).max(100).required(),
        package_id: Joi.number().integer().positive().required()
    }),
    
    // Customer login
    login: Joi.object({
        username: Joi.string().required(),
        password: Joi.string().required()
    }),
    
    // Change password
    changePassword: Joi.object({
        old_password: Joi.string().required(),
        new_password: Joi.string().min(4).max(100).required()
    }),
    
    // Forgot password
    forgotPassword: Joi.object({
        username_or_phone: Joi.string().required()
    }),
    
    // Reset password
    resetPassword: Joi.object({
        token: Joi.string().required(),
        new_password: Joi.string().min(4).max(100).required()
    }),
    
    // Create package
    createPackage: Joi.object({
        package_name: Joi.string().min(3).max(100).required(),
        price: Joi.number().positive().required(),
        validity_days: Joi.number().integer().min(1).max(365).required(),
        data_limit_mb: Joi.number().integer().min(0).default(0),
        upload_speed: Joi.string().pattern(/^\d+[KMG]?$/).default('1M'),
        download_speed: Joi.string().pattern(/^\d+[KMG]?$/).default('1M'),
        description: Joi.string().max(500).optional().allow('', null)
    }),
    
    // Update package
    updatePackage: Joi.object({
        package_name: Joi.string().min(3).max(100),
        price: Joi.number().positive(),
        validity_days: Joi.number().integer().min(1).max(365),
        data_limit_mb: Joi.number().integer().min(0),
        upload_speed: Joi.string().pattern(/^\d+[KMG]?$/),
        download_speed: Joi.string().pattern(/^\d+[KMG]?$/),
        description: Joi.string().max(500).optional().allow('', null)
    }),
    
    // Create router
    createRouter: Joi.object({
        router_name: Joi.string().min(3).max(100).required(),
        router_code: Joi.string().min(3).max(50).required(),
        ip_address: Joi.string().ip().required(),
        mac_address: Joi.string().pattern(/^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/).optional(),
        location: Joi.string().max(255).optional(),
        api_username: Joi.string().max(100).optional(),
        api_password: Joi.string().max(255).optional(),
        branch_id: Joi.number().integer().positive().optional()
    }),
    
    // Update router
    updateRouter: Joi.object({
        router_name: Joi.string().min(3).max(100),
        router_code: Joi.string().min(3).max(50),
        ip_address: Joi.string().ip(),
        mac_address: Joi.string().pattern(/^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/),
        location: Joi.string().max(255),
        api_username: Joi.string().max(100),
        api_password: Joi.string().max(255),
        status: Joi.string().valid('active', 'inactive', 'maintenance'),
        branch_id: Joi.number().integer().positive().allow(null)
    }),
    
    // M-Pesa payment initiation
    initiatePayment: Joi.object({
        customer_id: Joi.number().integer().positive().required(),
        package_id: Joi.number().integer().positive().required(),
        phone: Joi.string().pattern(/^[0-9]{10,12}$/).optional()
    }),
    
    // Voucher redemption
    redeemVoucher: Joi.object({
        voucher_code: Joi.string().pattern(/^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/).required()
    }),
    
    // Generate vouchers
    generateVouchers: Joi.object({
        package_id: Joi.number().integer().positive().required(),
        quantity: Joi.number().integer().min(1).max(1000).default(1),
        amount: Joi.number().positive().optional(),
        expiry_days: Joi.number().integer().min(1).max(365).default(30)
    }),
    
    // Create reseller
    createReseller: Joi.object({
        fullname: Joi.string().min(3).max(100).required(),
        phone: Joi.string().pattern(/^[0-9]{10,12}$/).required(),
        email: Joi.string().email().optional().allow('', null),
        username: Joi.string().min(3).max(50).pattern(/^[a-zA-Z0-9_.-]+$/).required(),
        password: Joi.string().min(4).max(100).required(),
        commission_percent: Joi.number().min(0).max(100).default(10)
    }),
    
    // Router access management
    manageRouterAccess: Joi.object({
        customer_id: Joi.number().integer().positive().required(),
        router_id: Joi.number().integer().positive().required(),
        action: Joi.string().valid('allow', 'block', 'remove').required()
    }),
    
    // Customer update
    updateCustomer: Joi.object({
        fullname: Joi.string().min(3).max(100),
        phone: Joi.string().pattern(/^[0-9]{10,12}$/),
        email: Joi.string().email().allow('', null),
        package_id: Joi.number().integer().positive(),
        status: Joi.string().valid('active', 'inactive', 'suspended')
    }),
    
    // Heartbeat data
    heartbeat: Joi.object({
        cpu_usage: Joi.number().min(0).max(100),
        ram_usage: Joi.number().min(0).max(100),
        online_users: Joi.number().integer().min(0),
        upload_mbps: Joi.number().min(0),
        download_mbps: Joi.number().min(0),
        status: Joi.string().valid('online', 'offline')
    }),
    
    // RADIUS auth
    radiusAuth: Joi.object({
        username: Joi.string().required(),
        password: Joi.string().required(),
        nas_ip_address: Joi.string().ip().optional(),
        called_station_id: Joi.string().optional(),
        calling_station_id: Joi.string().optional()
    }),
    
    // RADIUS accounting
    radiusAccounting: Joi.object({
        username: Joi.string().required(),
        acct_status_type: Joi.string().valid('Start', 'Stop', 'Alive', 'Interim-Update').required(),
        session_id: Joi.string().optional(),
        nas_ip_address: Joi.string().ip().optional(),
        input_octets: Joi.number().min(0).optional(),
        output_octets: Joi.number().min(0).optional(),
        session_time: Joi.number().min(0).optional()
    })
};

/**
 * Validation middleware factory
 */
const validate = (schemaName, source = 'body') => {
    return (req, res, next) => {
        const schema = schemas[schemaName];
        
        if (!schema) {
            return res.status(500).json({ 
                success: false, 
                error: `Validation schema '${schemaName}' not found` 
            });
        }
        
        let dataToValidate;
        if (source === 'body') {
            dataToValidate = req.body;
        } else if (source === 'query') {
            dataToValidate = req.query;
        } else if (source === 'params') {
            dataToValidate = req.params;
        } else {
            dataToValidate = req.body;
        }
        
        const { error, value } = schema.validate(dataToValidate, { abortEarly: false });
        
        if (error) {
            const errors = error.details.map(detail => ({
                field: detail.path.join('.'),
                message: detail.message
            }));
            
            return res.status(400).json({ 
                success: false, 
                error: 'Validation failed',
                details: errors
            });
        }
        
        // Replace request data with validated data
        if (source === 'body') {
            req.body = value;
        } else if (source === 'query') {
            req.query = value;
        } else if (source === 'params') {
            req.params = value;
        }
        
        next();
    };
};

/**
 * Sanitize input to prevent XSS and injection
 */
const sanitizeInput = (req, res, next) => {
    const sanitizeString = (str) => {
        if (typeof str !== 'string') return str;
        return str
            .replace(/[<>]/g, '') // Remove < and >
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    };
    
    const sanitizeObject = (obj) => {
        if (!obj || typeof obj !== 'object') return obj;
        
        for (const key in obj) {
            if (typeof obj[key] === 'string') {
                // Don't sanitize passwords
                if (key !== 'password' && !key.includes('password')) {
                    obj[key] = sanitizeString(obj[key]);
                }
            } else if (typeof obj[key] === 'object') {
                obj[key] = sanitizeObject(obj[key]);
            }
        }
        return obj;
    };
    
    req.body = sanitizeObject(req.body);
    req.query = sanitizeObject(req.query);
    req.params = sanitizeObject(req.params);
    
    next();
};

/**
 * Validate pagination parameters
 */
const validatePagination = (req, res, next) => {
    let { page, limit } = req.query;
    
    page = parseInt(page);
    limit = parseInt(limit);
    
    if (isNaN(page) || page < 1) page = 1;
    if (isNaN(limit) || limit < 1) limit = 20;
    if (limit > 100) limit = 100;
    
    req.pagination = { page, limit, offset: (page - 1) * limit };
    next();
};

/**
 * Validate date range parameters
 */
const validateDateRange = (req, res, next) => {
    let { start_date, end_date } = req.query;
    
    if (start_date) {
        const start = new Date(start_date);
        if (isNaN(start.getTime())) {
            return res.status(400).json({ 
                success: false, 
                error: 'Invalid start_date format' 
            });
        }
        req.start_date = start;
    }
    
    if (end_date) {
        const end = new Date(end_date);
        if (isNaN(end.getTime())) {
            return res.status(400).json({ 
                success: false, 
                error: 'Invalid end_date format' 
            });
        }
        req.end_date = end;
    }
    
    // Validate that start_date is before end_date
    if (req.start_date && req.end_date && req.start_date > req.end_date) {
        return res.status(400).json({ 
            success: false, 
            error: 'start_date must be before end_date' 
        });
    }
    
    next();
};

/**
 * Validate customer exists
 */
const validateCustomerExists = async (req, res, next) => {
    const customerId = req.params.customer_id || req.body.customer_id || req.user?.id;
    
    if (!customerId) {
        return res.status(400).json({ 
            success: false, 
            error: 'Customer ID required' 
        });
    }
    
    const [customers] = await pool.execute(
        'SELECT id, username, status FROM customers WHERE id = ?',
        [customerId]
    );
    
    if (customers.length === 0) {
        return res.status(404).json({ 
            success: false, 
            error: 'Customer not found' 
        });
    }
    
    req.customer = customers[0];
    next();
};

/**
 * Validate router exists
 */
const validateRouterExists = async (req, res, next) => {
    const routerId = req.params.id || req.params.router_id || req.body.router_id;
    
    if (!routerId) {
        return res.status(400).json({ 
            success: false, 
            error: 'Router ID required' 
        });
    }
    
    const [routers] = await pool.execute(
        'SELECT id, router_name, status, ip_address FROM routers WHERE id = ?',
        [routerId]
    );
    
    if (routers.length === 0) {
        return res.status(404).json({ 
            success: false, 
            error: 'Router not found' 
        });
    }
    
    req.router = routers[0];
    next();
};

/**
 * Validate package exists
 */
const validatePackageExists = async (req, res, next) => {
    const packageId = req.params.package_id || req.body.package_id;
    
    if (!packageId) {
        return res.status(400).json({ 
            success: false, 
            error: 'Package ID required' 
        });
    }
    
    const [packages] = await pool.execute(
        'SELECT id, package_name, price FROM packages WHERE id = ?',
        [packageId]
    );
    
    if (packages.length === 0) {
        return res.status(404).json({ 
            success: false, 
            error: 'Package not found' 
        });
    }
    
    req.package = packages[0];
    next();
};

/**
 * Validate voucher code format and existence
 */
const validateVoucherCode = async (req, res, next) => {
    const voucherCode = req.body.voucher_code || req.params.code;
    
    if (!voucherCode) {
        return res.status(400).json({ 
            success: false, 
            error: 'Voucher code required' 
        });
    }
    
    const voucherRegex = /^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/;
    if (!voucherRegex.test(voucherCode)) {
        return res.status(400).json({ 
            success: false, 
            error: 'Invalid voucher code format' 
        });
    }
    
    const [vouchers] = await pool.execute(
        'SELECT id, status, expiry_date, package_id FROM vouchers WHERE voucher_code = ?',
        [voucherCode]
    );
    
    if (vouchers.length === 0) {
        return res.status(404).json({ 
            success: false, 
            error: 'Voucher not found' 
        });
    }
    
    req.voucher = vouchers[0];
    next();
};

// Import pool for validation functions
const { pool } = require('../config/database');

module.exports = {
    validate,
    sanitizeInput,
    validatePagination,
    validateDateRange,
    validateCustomerExists,
    validateRouterExists,
    validatePackageExists,
    validateVoucherCode,
    schemas
};