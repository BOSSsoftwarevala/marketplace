const jwt = require('jsonwebtoken');
const { pool } = require('../config/database');
const { redisClient, cacheGet } = require('../config/redis');
const { logWarning, logError } = require('../config/logger');

/**
 * Verify JWT token and attach user to request
 */
const authMiddleware = async (req, res, next) => {
    try {
        const token = req.headers.authorization?.split(' ')[1] || req.query.token || req.body.token;
        
        if (!token) {
            return res.status(401).json({ 
                success: false, 
                error: 'Access denied. No token provided.' 
            });
        }
        
        // Verify token
        let decoded;
        try {
            decoded = jwt.verify(token, process.env.JWT_SECRET);
        } catch (err) {
            if (err.name === 'TokenExpiredError') {
                return res.status(401).json({ 
                    success: false, 
                    error: 'Token expired. Please login again.' 
                });
            }
            return res.status(401).json({ 
                success: false, 
                error: 'Invalid token.' 
            });
        }
        
        // Check if token is in Redis (for logout/invalidation)
        const cachedToken = await cacheGet(`token:${decoded.id}`);
        if (cachedToken && cachedToken !== token) {
            return res.status(401).json({ 
                success: false, 
                error: 'Session invalid. Please login again.' 
            });
        }
        
        // Get user based on role
        if (decoded.role === 'customer') {
            const [users] = await pool.execute(
                'SELECT id, username, fullname, email, phone, status, package_id FROM customers WHERE id = ?',
                [decoded.id]
            );
            
            if (users.length === 0) {
                return res.status(401).json({ 
                    success: false, 
                    error: 'User not found.' 
                });
            }
            
            if (users[0].status !== 'active') {
                return res.status(403).json({ 
                    success: false, 
                    error: `Account is ${users[0].status}. Please contact support.` 
                });
            }
            
            req.user = {
                id: users[0].id,
                username: users[0].username,
                fullname: users[0].fullname,
                email: users[0].email,
                phone: users[0].phone,
                role: 'customer',
                package_id: users[0].package_id
            };
            
        } else if (decoded.role === 'admin') {
            // For admin, check admin table or just verify from .env
            const adminEmail = process.env.ADMIN_EMAIL;
            if (decoded.email !== adminEmail) {
                return res.status(403).json({ 
                    success: false, 
                    error: 'Unauthorized admin access.' 
                });
            }
            
            req.user = {
                id: decoded.id,
                username: decoded.username,
                email: decoded.email,
                role: 'admin'
            };
            
        } else if (decoded.role === 'reseller') {
            const [resellers] = await pool.execute(
                'SELECT id, username, fullname, phone, email, status, commission_percent, balance FROM resellers WHERE id = ?',
                [decoded.id]
            );
            
            if (resellers.length === 0 || resellers[0].status !== 'active') {
                return res.status(401).json({ 
                    success: false, 
                    error: 'Reseller account not active.' 
                });
            }
            
            req.user = {
                id: resellers[0].id,
                username: resellers[0].username,
                fullname: resellers[0].fullname,
                phone: resellers[0].phone,
                email: resellers[0].email,
                role: 'reseller',
                commission_percent: resellers[0].commission_percent,
                balance: resellers[0].balance
            };
            
        } else {
            return res.status(401).json({ 
                success: false, 
                error: 'Invalid user role.' 
            });
        }
        
        // Store token for potential invalidation
        req.token = token;
        req.userId = decoded.id;
        
        next();
    } catch (error) {
        logError('Auth middleware error:', error);
        res.status(500).json({ 
            success: false, 
            error: 'Authentication error.' 
        });
    }
};

/**
 * Admin only middleware
 */
const adminMiddleware = (req, res, next) => {
    if (!req.user || req.user.role !== 'admin') {
        logWarning(`Unauthorized admin access attempt: ${req.user?.username || 'unknown'}`);
        return res.status(403).json({ 
            success: false, 
            error: 'Admin access required.' 
        });
    }
    next();
};

/**
 * Reseller only middleware
 */
const resellerMiddleware = (req, res, next) => {
    if (!req.user || req.user.role !== 'reseller') {
        return res.status(403).json({ 
            success: false, 
            error: 'Reseller access required.' 
        });
    }
    next();
};

/**
 * Customer only middleware
 */
const customerMiddleware = (req, res, next) => {
    if (!req.user || req.user.role !== 'customer') {
        return res.status(403).json({ 
            success: false, 
            error: 'Customer access required.' 
        });
    }
    next();
};

/**
 * Optional auth - doesn't require authentication but attaches user if present
 */
const optionalAuthMiddleware = async (req, res, next) => {
    try {
        const token = req.headers.authorization?.split(' ')[1];
        
        if (token) {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            
            if (decoded.role === 'customer') {
                const [users] = await pool.execute(
                    'SELECT id, username, fullname, status FROM customers WHERE id = ?',
                    [decoded.id]
                );
                if (users.length > 0 && users[0].status === 'active') {
                    req.user = {
                        id: users[0].id,
                        username: users[0].username,
                        fullname: users[0].fullname,
                        role: 'customer'
                    };
                }
            }
        }
    } catch (err) {
        // Ignore token errors for optional auth
    }
    next();
};

module.exports = {
    authMiddleware,
    adminMiddleware,
    resellerMiddleware,
    customerMiddleware,
    optionalAuthMiddleware
};