const crypto = require('crypto');
const { radiusConfig } = require('../config/radius');
const { logWarning, logError } = require('../config/logger');
const { redisClient, rateLimitCheck } = require('../config/redis');

/**
 * Verify RADIUS shared secret for incoming requests
 * For use when FreeRADIUS calls your endpoints
 */
const verifyRadiusSecret = (req, res, next) => {
    const providedSecret = req.headers['x-radius-secret'] || req.query.secret;
    const expectedSecret = process.env.RADIUS_SECRET || radiusConfig.server.secret;
    
    if (!providedSecret || providedSecret !== expectedSecret) {
        logWarning(`Invalid RADIUS secret attempt from ${req.ip}`);
        return res.status(401).json({ 
            success: false, 
            message: 'Invalid RADIUS secret' 
        });
    }
    
    next();
};

/**
 * Rate limiting for RADIUS authentication requests
 * Prevents brute force attacks
 */
const radiusRateLimit = async (req, res, next) => {
    const username = req.body.username || req.query.username;
    const ip = req.ip;
    
    if (!username) {
        return next();
    }
    
    // Rate limit per username
    const usernameKey = `radius:ratelimit:user:${username}`;
    const usernameLimit = await rateLimitCheck(usernameKey, 10, 300); // 10 attempts per 5 minutes
    
    if (!usernameLimit.allowed) {
        logWarning(`RADIUS rate limit exceeded for user: ${username}`, { ip });
        return res.status(429).json({ 
            success: false, 
            message: 'Too many authentication attempts. Please try again later.' 
        });
    }
    
    // Rate limit per IP
    const ipKey = `radius:ratelimit:ip:${ip}`;
    const ipLimit = await rateLimitCheck(ipKey, 30, 300); // 30 attempts per 5 minutes
    
    if (!ipLimit.allowed) {
        logWarning(`RADIUS rate limit exceeded for IP: ${ip}`);
        return res.status(429).json({ 
            success: false, 
            message: 'Too many requests from this IP.' 
        });
    }
    
    next();
};

/**
 * Validate RADIUS packet format
 */
const validateRadiusPacket = (req, res, next) => {
    const { username, password, nas_ip_address, called_station_id, calling_station_id } = req.body;
    
    if (!username || !password) {
        return res.status(400).json({ 
            success: false, 
            message: 'Missing required fields: username and password' 
        });
    }
    
    // Validate username format (alphanumeric, underscore, dot, dash)
    const usernameRegex = /^[a-zA-Z0-9_.-]{3,50}$/;
    if (!usernameRegex.test(username)) {
        return res.status(400).json({ 
            success: false, 
            message: 'Invalid username format' 
        });
    }
    
    // Validate password length
    if (password.length < 4 || password.length > 128) {
        return res.status(400).json({ 
            success: false, 
            message: 'Invalid password length' 
        });
    }
    
    // Validate NAS IP if provided
    if (nas_ip_address) {
        const ipRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
        if (!ipRegex.test(nas_ip_address)) {
            return res.status(400).json({ 
                success: false, 
                message: 'Invalid NAS IP address format' 
            });
        }
    }
    
    next();
};

/**
 * Log RADIUS authentication attempts
 */
const logRadiusAuth = (req, res, next) => {
    const startTime = Date.now();
    const { username, nas_ip_address } = req.body;
    
    // Store start time for response time calculation
    req.radiusStartTime = startTime;
    req.radiusUsername = username;
    req.radiusNasIp = nas_ip_address;
    
    // Override res.json to log after response
    const originalJson = res.json;
    res.json = function(data) {
        const responseTime = Date.now() - startTime;
        
        const logData = {
            username: req.radiusUsername,
            nas_ip: req.radiusNasIp,
            client_ip: req.ip,
            success: data.success || false,
            response_time_ms: responseTime,
            timestamp: new Date().toISOString()
        };
        
        if (data.success) {
            console.log(`✅ RADIUS Auth Success: ${logData.username} (${responseTime}ms)`);
        } else {
            console.log(`❌ RADIUS Auth Failed: ${logData.username} - ${data.message || 'Unknown error'} (${responseTime}ms)`);
        }
        
        originalJson.call(this, data);
    };
    
    next();
};

/**
 * Check if RADIUS service is enabled
 */
const radiusEnabled = (req, res, next) => {
    const enabled = process.env.RADIUS_ENABLED !== 'false';
    
    if (!enabled) {
        return res.status(503).json({ 
            success: false, 
            message: 'RADIUS service is currently disabled' 
        });
    }
    
    next();
};

/**
 * Verify RADIUS accounting packet
 */
const validateAccountingPacket = (req, res, next) => {
    const { username, acct_status_type, session_id, nas_ip_address } = req.body;
    
    if (!username || !acct_status_type) {
        return res.status(400).json({ 
            success: false, 
            message: 'Missing required accounting fields' 
        });
    }
    
    // Validate accounting status type
    const validStatusTypes = ['Start', 'Stop', 'Alive', 'Interim-Update', 'Accounting-On', 'Accounting-Off'];
    if (!validStatusTypes.includes(acct_status_type)) {
        return res.status(400).json({ 
            success: false, 
            message: 'Invalid accounting status type' 
        });
    }
    
    // Validate session ID format (usually alphanumeric)
    if (session_id && !/^[a-zA-Z0-9-]+$/.test(session_id)) {
        return res.status(400).json({ 
            success: false, 
            message: 'Invalid session ID format' 
        });
    }
    
    next();
};

module.exports = {
    verifyRadiusSecret,
    radiusRateLimit,
    validateRadiusPacket,
    logRadiusAuth,
    radiusEnabled,
    validateAccountingPacket
};