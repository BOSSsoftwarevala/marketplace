const { logError } = require('../config/logger');

/**
 * Global error handler middleware
 */
const errorHandler = (err, req, res, next) => {
    // Log the error
    logError(`Error: ${err.message}`, err, {
        url: req.url,
        method: req.method,
        ip: req.ip,
        user: req.user?.id,
        body: sanitizeForLog(req.body)
    });
    
    // Default error response
    const statusCode = err.statusCode || 500;
    const message = err.message || 'Internal server error';
    
    // Don't expose internal errors in production
    const isProduction = process.env.NODE_ENV === 'production';
    const errorResponse = {
        success: false,
        error: message,
        ...(isProduction ? {} : { stack: err.stack })
    };
    
    // Add validation errors if present
    if (err.validationErrors) {
        errorResponse.details = err.validationErrors;
    }
    
    res.status(statusCode).json(errorResponse);
};

/**
 * 404 Not Found handler
 */
const notFound = (req, res) => {
    res.status(404).json({
        success: false,
        error: `Cannot ${req.method} ${req.url}`,
        message: 'Route not found'
    });
};

/**
 * Async handler wrapper to avoid try-catch in controllers
 */
const asyncHandler = (fn) => {
    return (req, res, next) => {
        Promise.resolve(fn(req, res, next)).catch(next);
    };
};

/**
 * Sanitize object for logging (remove sensitive data)
 */
const sanitizeForLog = (obj) => {
    if (!obj || typeof obj !== 'object') return obj;
    
    const sanitized = { ...obj };
    const sensitiveFields = ['password', 'token', 'secret', 'api_key', 'api_password', 'old_password', 'new_password'];
    
    for (const field of sensitiveFields) {
        if (sanitized[field]) {
            sanitized[field] = '[REDACTED]';
        }
    }
    
    return sanitized;
};

/**
 * Rate limit exceeded handler
 */
const rateLimitHandler = (req, res) => {
    res.status(429).json({
        success: false,
        error: 'Too many requests',
        message: 'Please try again later',
        retryAfter: 60 // seconds
    });
};

/**
 * Request timeout handler
 */
const timeoutHandler = (req, res) => {
    res.status(408).json({
        success: false,
        error: 'Request timeout',
        message: 'The server timed out waiting for the request'
    });
};

/**
 * Body parser error handler
 */
const bodyParserErrorHandler = (err, req, res, next) => {
    if (err.type === 'entity.too.large') {
        return res.status(413).json({
            success: false,
            error: 'Request entity too large',
            message: 'The request body exceeds the size limit'
        });
    }
    
    if (err.type === 'encoding.unsupported') {
        return res.status(415).json({
            success: false,
            error: 'Unsupported media type',
            message: 'The request encoding is not supported'
        });
    }
    
    next(err);
};

/**
 * CORS error handler (for debugging)
 */
const corsErrorHandler = (err, req, res, next) => {
    if (err.message.includes('CORS')) {
        return res.status(403).json({
            success: false,
            error: 'CORS error',
            message: 'Origin not allowed'
        });
    }
    next(err);
};

// Custom error classes
class AppError extends Error {
    constructor(message, statusCode = 500) {
        super(message);
        this.statusCode = statusCode;
        this.isOperational = true;
        Error.captureStackTrace(this, this.constructor);
    }
}

class ValidationError extends AppError {
    constructor(message, validationErrors = null) {
        super(message, 400);
        this.validationErrors = validationErrors;
    }
}

class AuthenticationError extends AppError {
    constructor(message = 'Authentication failed') {
        super(message, 401);
    }
}

class AuthorizationError extends AppError {
    constructor(message = 'Unauthorized access') {
        super(message, 403);
    }
}

class NotFoundError extends AppError {
    constructor(resource = 'Resource') {
        super(`${resource} not found`, 404);
    }
}

class ConflictError extends AppError {
    constructor(message = 'Resource already exists') {
        super(message, 409);
    }
}

module.exports = {
    errorHandler,
    notFound,
    asyncHandler,
    rateLimitHandler,
    timeoutHandler,
    bodyParserErrorHandler,
    corsErrorHandler,
    sanitizeForLog,
    AppError,
    ValidationError,
    AuthenticationError,
    AuthorizationError,
    NotFoundError,
    ConflictError
};