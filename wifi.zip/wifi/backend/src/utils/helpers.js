const crypto = require('crypto');
const moment = require('moment');

/**
 * Generate random token
 */
const generateToken = (length = 32) => {
    return crypto.randomBytes(length).toString('hex');
};

/**
 * Generate random OTP (One Time Password)
 */
const generateOTP = (length = 6) => {
    const digits = '0123456789';
    let otp = '';
    for (let i = 0; i < length; i++) {
        otp += digits[Math.floor(Math.random() * digits.length)];
    }
    return otp;
};

/**
 * Format currency (Kenyan Shillings)
 */
const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-KE', {
        style: 'currency',
        currency: 'KES',
        minimumFractionDigits: 2
    }).format(amount);
};

/**
 * Format phone number to international format
 */
const formatPhoneNumber = (phone) => {
    let cleaned = phone.toString().replace(/\D/g, '');
    
    if (cleaned.startsWith('0')) {
        cleaned = '254' + cleaned.substring(1);
    } else if (cleaned.startsWith('7') || cleaned.startsWith('1')) {
        cleaned = '254' + cleaned;
    }
    
    return cleaned;
};

/**
 * Format phone number to local format (07XXXXXXXX)
 */
const formatPhoneLocal = (phone) => {
    let cleaned = phone.toString().replace(/\D/g, '');
    
    if (cleaned.startsWith('254')) {
        cleaned = '0' + cleaned.substring(3);
    }
    
    return cleaned;
};

/**
 * Validate email format
 */
const isValidEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
};

/**
 * Validate phone number (Kenya)
 */
const isValidPhone = (phone) => {
    const cleaned = phone.toString().replace(/\D/g, '');
    const phoneRegex = /^(254|0)[17][0-9]{8}$/;
    return phoneRegex.test(cleaned);
};

/**
 * Validate IP address
 */
const isValidIP = (ip) => {
    const ipRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    return ipRegex.test(ip);
};

/**
 * Validate MAC address
 */
const isValidMAC = (mac) => {
    const macRegex = /^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/;
    return macRegex.test(mac);
};

/**
 * Calculate days between two dates
 */
const daysBetween = (date1, date2) => {
    const d1 = new Date(date1);
    const d2 = new Date(date2);
    const diffTime = Math.abs(d2 - d1);
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
};

/**
 * Check if date is expired
 */
const isExpired = (date) => {
    return new Date(date) < new Date();
};

/**
 * Add days to date
 */
const addDays = (date, days) => {
    const result = new Date(date);
    result.setDate(result.getDate() + days);
    return result;
};

/**
 * Sleep/delay function
 */
const sleep = (ms) => {
    return new Promise(resolve => setTimeout(resolve, ms));
};

/**
 * Retry async function with exponential backoff
 */
const retry = async (fn, retries = 3, delay = 1000) => {
    try {
        return await fn();
    } catch (error) {
        if (retries <= 0) throw error;
        await sleep(delay);
        return retry(fn, retries - 1, delay * 2);
    }
};

/**
 * Deep clone object
 */
const deepClone = (obj) => {
    return JSON.parse(JSON.stringify(obj));
};

/**
 * Mask sensitive data
 */
const maskSensitive = (data, fields = ['password', 'token', 'api_key', 'secret']) => {
    if (!data || typeof data !== 'object') return data;
    
    const masked = { ...data };
    for (const field of fields) {
        if (masked[field]) {
            masked[field] = '********';
        }
    }
    return masked;
};

/**
 * Truncate string
 */
const truncate = (str, length = 100, suffix = '...') => {
    if (str.length <= length) return str;
    return str.substring(0, length - suffix.length) + suffix;
};

/**
 * Generate slug from string
 */
const generateSlug = (str) => {
    return str
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-|-$/g, '');
};

/**
 * Parse bytes to human readable format
 */
const bytesToHuman = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

/**
 * Parse seconds to human readable format
 */
const secondsToHuman = (seconds) => {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    const parts = [];
    if (days > 0) parts.push(`${days}d`);
    if (hours > 0) parts.push(`${hours}h`);
    if (minutes > 0) parts.push(`${minutes}m`);
    if (secs > 0) parts.push(`${secs}s`);
    
    return parts.join(' ') || '0s';
};

/**
 * Get file extension from filename
 */
const getFileExtension = (filename) => {
    return filename.slice((filename.lastIndexOf('.') - 1 >>> 0) + 2);
};

/**
 * Generate random color (for UI)
 */
const randomColor = () => {
    return '#' + Math.floor(Math.random() * 16777215).toString(16);
};

/**
 * Group array by key
 */
const groupBy = (array, key) => {
    return array.reduce((result, item) => {
        const groupKey = item[key];
        if (!result[groupKey]) {
            result[groupKey] = [];
        }
        result[groupKey].push(item);
        return result;
    }, {});
};

/**
 * Chunk array into smaller arrays
 */
const chunkArray = (array, size) => {
    const chunks = [];
    for (let i = 0; i < array.length; i += size) {
        chunks.push(array.slice(i, i + size));
    }
    return chunks;
};

/**
 * Remove duplicates from array
 */
const uniqueArray = (array, key = null) => {
    if (!key) {
        return [...new Set(array)];
    }
    const seen = new Set();
    return array.filter(item => {
        const value = item[key];
        if (seen.has(value)) return false;
        seen.add(value);
        return true;
    });
};

/**
 * Sort array by key
 */
const sortByKey = (array, key, ascending = true) => {
    return array.sort((a, b) => {
        let aVal = a[key];
        let bVal = b[key];
        
        if (typeof aVal === 'string') {
            aVal = aVal.toLowerCase();
            bVal = bVal.toLowerCase();
        }
        
        if (ascending) {
            return aVal > bVal ? 1 : -1;
        } else {
            return aVal < bVal ? 1 : -1;
        }
    });
};

/**
 * Get query parameters from URL
 */
const parseQueryParams = (url) => {
    const params = {};
    const queryString = url.split('?')[1];
    if (!queryString) return params;
    
    queryString.split('&').forEach(param => {
        const [key, value] = param.split('=');
        params[decodeURIComponent(key)] = decodeURIComponent(value || '');
    });
    
    return params;
};

/**
 * Build URL with query parameters
 */
const buildUrl = (base, params) => {
    const url = new URL(base);
    Object.keys(params).forEach(key => {
        if (params[key] !== undefined && params[key] !== null) {
            url.searchParams.append(key, params[key]);
        }
    });
    return url.toString();
};

/**
 * Compare two objects for equality (shallow)
 */
const shallowEqual = (obj1, obj2) => {
    const keys1 = Object.keys(obj1);
    const keys2 = Object.keys(obj2);
    
    if (keys1.length !== keys2.length) return false;
    
    for (const key of keys1) {
        if (obj1[key] !== obj2[key]) return false;
    }
    
    return true;
};

/**
 * Pick specific fields from object
 */
const pick = (obj, keys) => {
    return keys.reduce((result, key) => {
        if (obj[key] !== undefined) {
            result[key] = obj[key];
        }
        return result;
    }, {});
};

/**
 * Omit specific fields from object
 */
const omit = (obj, keys) => {
    const result = { ...obj };
    keys.forEach(key => delete result[key]);
    return result;
};

/**
 * Convert object to query string
 */
const toQueryString = (obj) => {
    return Object.keys(obj)
        .filter(key => obj[key] !== undefined && obj[key] !== null)
        .map(key => `${encodeURIComponent(key)}=${encodeURIComponent(obj[key])}`)
        .join('&');
};

/**
 * Parse JSON safely (no throw)
 */
const safeJsonParse = (json, defaultValue = null) => {
    try {
        return JSON.parse(json);
    } catch {
        return defaultValue;
    }
};

/**
 * Stringify JSON safely (no throw)
 */
const safeJsonStringify = (obj, defaultValue = '{}') => {
    try {
        return JSON.stringify(obj);
    } catch {
        return defaultValue;
    }
};

/**
 * Get environment variable with fallback
 */
const env = (key, defaultValue = null) => {
    const value = process.env[key];
    return value !== undefined ? value : defaultValue;
};

/**
 * Check if running in production
 */
const isProduction = () => {
    return process.env.NODE_ENV === 'production';
};

/**
 * Check if running in development
 */
const isDevelopment = () => {
    return process.env.NODE_ENV === 'development';
};

/**
 * Get current timestamp in various formats
 */
const timestamp = {
    unix: () => Math.floor(Date.now() / 1000),
    iso: () => new Date().toISOString(),
    mysql: () => moment().format('YYYY-MM-DD HH:mm:ss'),
    date: () => moment().format('YYYY-MM-DD'),
    time: () => moment().format('HH:mm:ss')
};

module.exports = {
    generateToken,
    generateOTP,
    formatCurrency,
    formatPhoneNumber,
    formatPhoneLocal,
    isValidEmail,
    isValidPhone,
    isValidIP,
    isValidMAC,
    daysBetween,
    isExpired,
    addDays,
    sleep,
    retry,
    deepClone,
    maskSensitive,
    truncate,
    generateSlug,
    bytesToHuman,
    secondsToHuman,
    getFileExtension,
    randomColor,
    groupBy,
    chunkArray,
    uniqueArray,
    sortByKey,
    parseQueryParams,
    buildUrl,
    shallowEqual,
    pick,
    omit,
    toQueryString,
    safeJsonParse,
    safeJsonStringify,
    env,
    isProduction,
    isDevelopment,
    timestamp
};