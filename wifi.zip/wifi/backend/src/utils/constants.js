/**
 * Application constants
 */

// User roles
const USER_ROLES = {
    ADMIN: 'admin',
    CUSTOMER: 'customer',
    RESELLER: 'reseller'
};

// Customer statuses
const CUSTOMER_STATUS = {
    ACTIVE: 'active',
    INACTIVE: 'inactive',
    SUSPENDED: 'suspended',
    EXPIRED: 'expired'
};

// Router statuses
const ROUTER_STATUS = {
    ACTIVE: 'active',
    INACTIVE: 'inactive',
    MAINTENANCE: 'maintenance'
};

// Router connection statuses
const ROUTER_CONNECTION = {
    ONLINE: 'online',
    OFFLINE: 'offline'
};

// Payment statuses
const PAYMENT_STATUS = {
    PENDING: 'pending',
    COMPLETED: 'completed',
    FAILED: 'failed',
    REFUNDED: 'refunded'
};

// Voucher statuses
const VOUCHER_STATUS = {
    UNUSED: 'unused',
    USED: 'used',
    EXPIRED: 'expired'
};

// Session statuses
const SESSION_STATUS = {
    ONLINE: 'online',
    OFFLINE: 'offline'
};

// RADIUS accounting status types
const RADIUS_ACCT_STATUS = {
    START: 1,
    STOP: 2,
    ALIVE: 3,
    INTERIM_UPDATE: 3,
    ACCOUNTING_ON: 7,
    ACCOUNTING_OFF: 8
};

// RADIUS terminate causes
const RADIUS_TERMINATE_CAUSE = {
    USER_REQUEST: 'User-Request',
    LOST_CARRIER: 'Lost-Carrier',
    LOST_SERVICE: 'Lost-Service',
    IDLE_TIMEOUT: 'Idle-Timeout',
    SESSION_TIMEOUT: 'Session-Timeout',
    ADMIN_RESET: 'Admin-Reset',
    ADMIN_REBOOT: 'Admin-Reboot',
    PORT_ERROR: 'Port-Error',
    NAS_ERROR: 'NAS-Error',
    NAS_REQUEST: 'NAS-Request',
    NAS_REBOOT: 'NAS-Reboot',
    PORT_UNNEEDED: 'Port-Unneeded',
    PORT_PREEMPTED: 'Port-Preempted',
    PORT_SUSPENDED: 'Port-Suspended',
    SERVICE_UNAVAILABLE: 'Service-Unavailable',
    CALLBACK: 'Callback',
    USER_ERROR: 'User-Error',
    HOST_REQUEST: 'Host-Request'
};

// M-Pesa transaction types
const MPESA_TRANSACTION_TYPES = {
    C2B: {
        CUSTOMER_PAY_BILL_ONLINE: 'CustomerPayBillOnline',
        CUSTOMER_BUY_GOODS_ONLINE: 'CustomerBuyGoodsOnline'
    },
    B2C: {
        SALARY_PAYMENT: 'SalaryPayment',
        BUSINESS_PAYMENT: 'BusinessPayment',
        PROMOTION_PAYMENT: 'PromotionPayment'
    },
    B2B: {
        BUSINESS_PAY_BILL: 'BusinessPayBill',
        BUSINESS_BUY_GOODS: 'BusinessBuyGoods',
        DISBURSEMENT: 'Disbursement',
        REVERSAL: 'Reversal'
    }
};

// M-Pesa result codes
const MPESA_RESULT_CODES = {
    SUCCESS: 0,
    INSUFFICIENT_FUNDS: 1,
    EXPIRED: 2,
    FAILED: 1037,
    CANCELLED: 1032
};

// SMS templates
const SMS_TEMPLATES = {
    WELCOME: 'welcome',
    PAYMENT_CONFIRMATION: 'payment_confirmation',
    VOUCHER_REDEMPTION: 'voucher_redemption',
    EXPIRY_WARNING: 'expiry_warning',
    DATA_LIMIT_WARNING: 'data_limit_warning',
    PASSWORD_RESET: 'password_reset',
    ACCOUNT_ACTIVATION: 'account_activation',
    LOW_BALANCE: 'low_balance',
    COMMISSION_PAYMENT: 'commission_payment'
};

// Cache TTLs (seconds)
const CACHE_TTL = {
    SHORT: 60,           // 1 minute
    MEDIUM: 300,         // 5 minutes
    LONG: 3600,          // 1 hour
    DAY: 86400,          // 24 hours
    WEEK: 604800         // 7 days
};

// Rate limits
const RATE_LIMITS = {
    AUTH: {
        windowMs: 15 * 60 * 1000,  // 15 minutes
        max: 5                      // 5 attempts
    },
    REGISTRATION: {
        windowMs: 60 * 60 * 1000,   // 1 hour
        max: 10                      // 10 registrations
    },
    PAYMENT: {
        windowMs: 60 * 60 * 1000,   // 1 hour
        max: 5                       // 5 attempts
    },
    SMS: {
        windowMs: 60 * 60 * 1000,   // 1 hour
        max: 10                      // 10 SMS per phone
    },
    API: {
        windowMs: 15 * 60 * 1000,   // 15 minutes
        max: 100                     // 100 requests per IP
    }
};

// Default values
const DEFAULTS = {
    PACKAGE: {
        validity_days: 30,
        data_limit_mb: 0,
        upload_speed: '1M',
        download_speed: '1M'
    },
    RESELLER: {
        commission_percent: 10
    },
    SESSION: {
        idle_timeout: 300,     // 5 minutes
        session_timeout: 86400  // 24 hours
    },
    PAGINATION: {
        page: 1,
        limit: 20
    }
};

// HTTP status codes
const HTTP_STATUS = {
    OK: 200,
    CREATED: 201,
    ACCEPTED: 202,
    NO_CONTENT: 204,
    BAD_REQUEST: 400,
    UNAUTHORIZED: 401,
    FORBIDDEN: 403,
    NOT_FOUND: 404,
    METHOD_NOT_ALLOWED: 405,
    CONFLICT: 409,
    UNPROCESSABLE_ENTITY: 422,
    TOO_MANY_REQUESTS: 429,
    INTERNAL_SERVER_ERROR: 500,
    BAD_GATEWAY: 502,
    SERVICE_UNAVAILABLE: 503
};

// Error codes
const ERROR_CODES = {
    VALIDATION_ERROR: 'VALIDATION_ERROR',
    AUTHENTICATION_ERROR: 'AUTHENTICATION_ERROR',
    AUTHORIZATION_ERROR: 'AUTHORIZATION_ERROR',
    NOT_FOUND_ERROR: 'NOT_FOUND_ERROR',
    CONFLICT_ERROR: 'CONFLICT_ERROR',
    RATE_LIMIT_ERROR: 'RATE_LIMIT_ERROR',
    PAYMENT_ERROR: 'PAYMENT_ERROR',
    DATABASE_ERROR: 'DATABASE_ERROR',
    RADIUS_ERROR: 'RADIUS_ERROR',
    NETWORK_ERROR: 'NETWORK_ERROR',
    INTERNAL_ERROR: 'INTERNAL_ERROR'
};

// Event types for WebSocket
const WS_EVENTS = {
    CONNECTION: 'connection',
    DISCONNECT: 'disconnect',
    AUTHENTICATE: 'authenticate',
    PAYMENT_COMPLETED: 'payment_completed',
    SESSION_STARTED: 'session_started',
    SESSION_ENDED: 'session_ended',
    ROUTER_STATUS_CHANGE: 'router_status_change',
    CUSTOMER_STATUS_CHANGE: 'customer_status_change',
    NEW_VOUCHER: 'new_voucher',
    NEW_RESELLER_SALE: 'new_reseller_sale',
    ALERT: 'alert'
};

// Time units in seconds
const TIME_UNITS = {
    SECOND: 1,
    MINUTE: 60,
    HOUR: 3600,
    DAY: 86400,
    WEEK: 604800,
    MONTH: 2592000,
    YEAR: 31536000
};

// Data units in bytes
const DATA_UNITS = {
    B: 1,
    KB: 1024,
    MB: 1048576,
    GB: 1073741824,
    TB: 1099511627776
};

// Speed units in bits per second
const SPEED_UNITS = {
    BPS: 1,
    KBPS: 1000,
    MBPS: 1000000,
    GBPS: 1000000000
};

// MIME types
const MIME_TYPES = {
    JSON: 'application/json',
    XML: 'application/xml',
    TEXT: 'text/plain',
    HTML: 'text/html',
    CSS: 'text/css',
    JS: 'application/javascript',
    PNG: 'image/png',
    JPEG: 'image/jpeg',
    GIF: 'image/gif',
    SVG: 'image/svg+xml',
    PDF: 'application/pdf',
    ZIP: 'application/zip'
};

// Regular expressions
const REGEX = {
    EMAIL: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
    PHONE_KENYA: /^(254|0)[17][0-9]{8}$/,
    IPV4: /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/,
    MAC: /^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/,
    USERNAME: /^[a-zA-Z0-9_.-]{3,50}$/,
    PASSWORD: /^.{4,100}$/,
    VOUCHER_CODE: /^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/,
    UUID: /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
};

// Date formats
const DATE_FORMATS = {
    ISO: 'YYYY-MM-DDTHH:mm:ss.SSSZ',
    MYSQL: 'YYYY-MM-DD HH:mm:ss',
    DATE: 'YYYY-MM-DD',
    TIME: 'HH:mm:ss',
    DATETIME: 'YYYY-MM-DD HH:mm:ss',
    HUMAN: 'DD/MM/YYYY HH:mm:ss',
    HUMAN_DATE: 'DD/MM/YYYY',
    HUMAN_TIME: 'HH:mm:ss'
};

// Log levels
const LOG_LEVELS = {
    ERROR: 'error',
    WARN: 'warn',
    INFO: 'info',
    DEBUG: 'debug',
    HTTP: 'http'
};

module.exports = {
    USER_ROLES,
    CUSTOMER_STATUS,
    ROUTER_STATUS,
    ROUTER_CONNECTION,
    PAYMENT_STATUS,
    VOUCHER_STATUS,
    SESSION_STATUS,
    RADIUS_ACCT_STATUS,
    RADIUS_TERMINATE_CAUSE,
    MPESA_TRANSACTION_TYPES,
    MPESA_RESULT_CODES,
    SMS_TEMPLATES,
    CACHE_TTL,
    RATE_LIMITS,
    DEFAULTS,
    HTTP_STATUS,
    ERROR_CODES,
    WS_EVENTS,
    TIME_UNITS,
    DATA_UNITS,
    SPEED_UNITS,
    MIME_TYPES,
    REGEX,
    DATE_FORMATS,
    LOG_LEVELS
};