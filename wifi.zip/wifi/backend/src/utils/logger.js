const winston = require('winston');
const path = require('path');
const fs = require('fs');

// Create logs directory if it doesn't exist
const logDir = path.join(__dirname, '../../logs');
if (!fs.existsSync(logDir)) {
    fs.mkdirSync(logDir, { recursive: true });
}

// Define log format
const logFormat = winston.format.combine(
    winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    winston.format.errors({ stack: true }),
    winston.format.splat(),
    winston.format.json(),
    winston.format.printf(({ timestamp, level, message, stack, ...meta }) => {
        let log = `${timestamp} [${level.toUpperCase()}]: ${message}`;
        if (Object.keys(meta).length > 0 && !meta.stack) {
            log += ` ${JSON.stringify(meta)}`;
        }
        if (stack) {
            log += `\n${stack}`;
        }
        return log;
    })
);

// Create logger instance
const logger = winston.createLogger({
    level: process.env.LOG_LEVEL || 'info',
    format: logFormat,
    transports: [
        // Console transport for development
        new winston.transports.Console({
            format: winston.format.combine(
                winston.format.colorize(),
                winston.format.simple()
            )
        }),
        // File transport for errors
        new winston.transports.File({
            filename: path.join(logDir, 'error.log'),
            level: 'error',
            maxsize: 10485760, // 10MB
            maxFiles: 5,
            format: logFormat
        }),
        // File transport for all logs
        new winston.transports.File({
            filename: path.join(logDir, 'combined.log'),
            maxsize: 10485760, // 10MB
            maxFiles: 5,
            format: logFormat
        })
    ]
});

// Separate file for API access logs
const accessLogger = winston.createLogger({
    level: 'info',
    format: logFormat,
    transports: [
        new winston.transports.File({
            filename: path.join(logDir, 'access.log'),
            maxsize: 10485760,
            maxFiles: 5,
            format: logFormat
        })
    ]
});

// Separate file for M-Pesa transactions
const mpesaLogger = winston.createLogger({
    level: 'info',
    format: logFormat,
    transports: [
        new winston.transports.File({
            filename: path.join(logDir, 'mpesa.log'),
            maxsize: 10485760,
            maxFiles: 10,
            format: logFormat
        })
    ]
});

// Separate file for RADIUS logs
const radiusLogger = winston.createLogger({
    level: 'info',
    format: logFormat,
    transports: [
        new winston.transports.File({
            filename: path.join(logDir, 'radius.log'),
            maxsize: 10485760,
            maxFiles: 5,
            format: logFormat
        })
    ]
});

// Helper functions
const logInfo = (message, meta = {}) => {
    logger.info(message, meta);
};

const logError = (message, error = null, meta = {}) => {
    if (error) {
        logger.error(message, { ...meta, error: error.message, stack: error.stack });
    } else {
        logger.error(message, meta);
    }
};

const logWarning = (message, meta = {}) => {
    logger.warn(message, meta);
};

const logDebug = (message, meta = {}) => {
    logger.debug(message, meta);
};

const logAccess = (req, res, responseTime) => {
    accessLogger.info({
        method: req.method,
        url: req.url,
        status: res.statusCode,
        responseTime: `${responseTime}ms`,
        ip: req.ip,
        userAgent: req.get('user-agent'),
        userId: req.user?.id,
        username: req.user?.username
    });
};

const logMpesa = (transaction, status, details = {}) => {
    mpesaLogger.info({
        transaction,
        status,
        ...details,
        timestamp: new Date().toISOString()
    });
};

const logRadius = (event, username, details = {}) => {
    radiusLogger.info({
        event,
        username,
        ...details,
        timestamp: new Date().toISOString()
    });
};

module.exports = {
    logger,
    accessLogger,
    mpesaLogger,
    radiusLogger,
    logInfo,
    logError,
    logWarning,
    logDebug,
    logAccess,
    logMpesa,
    logRadius
};