const { pool } = require('../config/database');
const Package = require('../models/Package');
const { logInfo, logError } = require('../config/logger');
const { cacheDelete } = require('../config/redis');

// Helper function to generate unique voucher code - MOVED OUTSIDE CLASS
function generateVoucherCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 12; i++) {
        if (i > 0 && i % 4 === 0) {
            code += '-';
        }
        code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
}

class VoucherController {
    /**
     * Generate vouchers
     */
    static async generateVouchers(req, res) {
        try {
            const { package_id, quantity = 1, amount = null, expiry_days = 30 } = req.body;
            
            const package_ = await Package.findById(package_id);
            if (!package_) {
                return res.status(404).json({ 
                    success: false, 
                    error: 'Package not found' 
                });
            }
            
            const voucherAmount = amount || package_.price;
            const vouchers = [];
            const expiryDate = new Date();
            expiryDate.setDate(expiryDate.getDate() + expiry_days);
            
            for (let i = 0; i < quantity; i++) {
                const code = generateVoucherCode();
                
                const [result] = await pool.execute(
                    `INSERT INTO vouchers (voucher_code, package_id, amount, expiry_date, status)
                     VALUES (?, ?, ?, ?, 'unused')`,
                    [code, package_id, voucherAmount, expiryDate]
                );
                
                vouchers.push({
                    id: result.insertId,
                    code,
                    amount: voucherAmount,
                    package: package_.package_name,
                    expiry_date: expiryDate
                });
            }
            
            await cacheDelete('vouchers:list');
            
            logInfo(`Generated ${quantity} vouchers for package ${package_.package_name}`, {
                admin: req.user.id,
                totalAmount: voucherAmount * quantity
            });
            
            res.status(201).json({
                success: true,
                message: `${quantity} voucher(s) generated successfully`,
                data: {
                    vouchers,
                    summary: {
                        total: quantity,
                        total_amount: voucherAmount * quantity,
                        package: package_.package_name
                    }
                }
            });
        } catch (error) {
            logError('Generate vouchers error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to generate vouchers' 
            });
        }
    }
    
    /**
     * Get all vouchers - FIXED VERSION
     */
    static async getAllVouchers(req, res) {
        try {
            const { status, page = 1, limit = 50 } = req.query;
            const offset = (parseInt(page) - 1) * parseInt(limit);
            
            // FIXED: Use LEFT JOIN to handle missing data
            let query = `
                SELECT v.*, 
                       COALESCE(p.package_name, 'Unknown') as package_name, 
                       p.price, p.validity_days, p.data_limit_mb,
                       c.fullname as used_by_name, 
                       c.username as used_by_username
                FROM vouchers v
                LEFT JOIN packages p ON v.package_id = p.id
                LEFT JOIN customers c ON v.used_by = c.id
                WHERE 1=1
            `;
            
            const params = [];
            
            // FIXED: Only add status filter if valid
            if (status && status !== 'all' && status !== 'undefined' && status !== '') {
                query += ` AND v.status = ?`;
                params.push(status);
            }
            
            query += ` ORDER BY v.id DESC LIMIT ? OFFSET ?`;
            params.push(parseInt(limit), offset);
            
            const [vouchers] = await pool.execute(query, params);
            
            // Get total count - FIXED
            let countQuery = `SELECT COUNT(*) as total FROM vouchers WHERE 1=1`;
            const countParams = [];
            
            if (status && status !== 'all' && status !== 'undefined' && status !== '') {
                countQuery += ` AND status = ?`;
                countParams.push(status);
            }
            
            const [total] = await pool.execute(countQuery, countParams);
            
            res.json({
                success: true,
                data: vouchers,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total: total[0].total,
                    pages: Math.ceil(total[0].total / parseInt(limit))
                }
            });
        } catch (error) {
            logError('Get vouchers error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to fetch vouchers',
                message: error.message
            });
        }
    }
    
    /**
     * Get voucher by ID - ADD THIS METHOD
     */
    static async getVoucherById(req, res) {
        try {
            const { id } = req.params;
            
            const [vouchers] = await pool.execute(
                `SELECT v.*, 
                        COALESCE(p.package_name, 'Unknown') as package_name, 
                        p.price, p.validity_days,
                        c.fullname as used_by_name, 
                        c.username as used_by_username
                 FROM vouchers v
                 LEFT JOIN packages p ON v.package_id = p.id
                 LEFT JOIN customers c ON v.used_by = c.id
                 WHERE v.id = ?`,
                [id]
            );
            
            if (vouchers.length === 0) {
                return res.status(404).json({ 
                    success: false, 
                    error: 'Voucher not found' 
                });
            }
            
            res.json({
                success: true,
                data: vouchers[0]
            });
        } catch (error) {
            logError('Get voucher error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to fetch voucher' 
            });
        }
    }
    
    /**
     * Get voucher by code
     */
    static async getVoucherByCode(req, res) {
        try {
            const { code } = req.params;
            
            const [vouchers] = await pool.execute(
                `SELECT v.*, 
                        COALESCE(p.package_name, 'Unknown') as package_name, 
                        p.validity_days, p.data_limit_mb,
                        p.upload_speed, p.download_speed
                 FROM vouchers v
                 LEFT JOIN packages p ON v.package_id = p.id
                 WHERE v.voucher_code = ?`,
                [code]
            );
            
            if (vouchers.length === 0) {
                return res.status(404).json({ 
                    success: false, 
                    error: 'Voucher not found' 
                });
            }
            
            res.json({
                success: true,
                data: vouchers[0]
            });
        } catch (error) {
            logError('Get voucher error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to fetch voucher' 
            });
        }
    }
    
    /**
     * Redeem voucher (customer self-service)
     */
    static async redeemVoucher(req, res) {
        const connection = await pool.getConnection();
        try {
            const { voucher_code } = req.body;
            const customerId = req.user.id;
            
            await connection.beginTransaction();
            
            const [vouchers] = await connection.execute(
                `SELECT v.*, p.package_name, p.price, p.validity_days, p.data_limit_mb,
                        p.upload_speed, p.download_speed
                 FROM vouchers v
                 JOIN packages p ON v.package_id = p.id
                 WHERE v.voucher_code = ? AND v.status = 'unused'`,
                [voucher_code]
            );
            
            if (vouchers.length === 0) {
                await connection.rollback();
                return res.status(404).json({ 
                    success: false, 
                    error: 'Invalid or already used voucher code' 
                });
            }
            
            const voucher = vouchers[0];
            
            if (voucher.expiry_date && new Date(voucher.expiry_date) < new Date()) {
                await connection.execute(
                    `UPDATE vouchers SET status = 'expired' WHERE id = ?`,
                    [voucher.id]
                );
                await connection.rollback();
                return res.status(400).json({ 
                    success: false, 
                    error: 'Voucher has expired' 
                });
            }
            
            const [customers] = await connection.execute(
                `SELECT * FROM customers WHERE id = ?`,
                [customerId]
            );
            const customer = customers[0];
            
            await connection.execute(
                `INSERT INTO payments (customer_id, phone, amount, package_id, mpesa_receipt, status, transaction_date)
                 VALUES (?, ?, ?, ?, ?, 'completed', NOW())`,
                [customerId, customer.phone, voucher.price, voucher.package_id, `VOUCHER-${voucher_code}`]
            );
            
            await connection.execute(
                `UPDATE vouchers SET status = 'used', used_by = ? WHERE id = ?`,
                [customerId, voucher.id]
            );
            
            await connection.execute(
                `UPDATE customers SET status = 'active', package_id = ? WHERE id = ?`,
                [voucher.package_id, customerId]
            );
            
            const RadiusSyncService = require('../services/radiusSyncService');
            await RadiusSyncService.syncCustomerToRadius(customerId);
            
            await connection.commit();
            
            await cacheDelete(`customer:${customerId}`);
            await cacheDelete('vouchers:list');
            
            logInfo(`Voucher redeemed: ${voucher_code}`, {
                customerId,
                voucherId: voucher.id
            });
            
            res.json({
                success: true,
                message: 'Voucher redeemed successfully',
                data: {
                    package: voucher.package_name,
                    validity_days: voucher.validity_days,
                    speed: `${voucher.upload_speed}/${voucher.download_speed}`
                }
            });
        } catch (error) {
            await connection.rollback();
            logError('Redeem voucher error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to redeem voucher' 
            });
        } finally {
            connection.release();
        }
    }
    
    /**
     * Delete voucher
     */
    static async deleteVoucher(req, res) {
        try {
            const { id } = req.params;
            
            const [vouchers] = await pool.execute(
                `SELECT * FROM vouchers WHERE id = ?`,
                [id]
            );
            
            if (vouchers.length === 0) {
                return res.status(404).json({ 
                    success: false, 
                    error: 'Voucher not found' 
                });
            }
            
            const voucher = vouchers[0];
            
            if (voucher.status === 'used') {
                return res.status(400).json({ 
                    success: false, 
                    error: 'Cannot delete used voucher' 
                });
            }
            
            await pool.execute(`DELETE FROM vouchers WHERE id = ?`, [id]);
            
            await cacheDelete('vouchers:list');
            
            logInfo(`Voucher deleted: ${voucher.voucher_code}`, { admin: req.user.id });
            
            res.json({
                success: true,
                message: 'Voucher deleted successfully'
            });
        } catch (error) {
            logError('Delete voucher error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to delete voucher' 
            });
        }
    }
    
    /**
     * Get voucher statistics
     */
    static async getVoucherStats(req, res) {
        try {
            const [stats] = await pool.execute(`
                SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN status = 'unused' THEN 1 ELSE 0 END) as unused,
                    SUM(CASE WHEN status = 'used' THEN 1 ELSE 0 END) as used,
                    SUM(CASE WHEN status = 'expired' THEN 1 ELSE 0 END) as expired,
                    SUM(CASE WHEN status = 'used' THEN amount ELSE 0 END) as total_redeemed
                FROM vouchers
            `);
            
            const [dailyGenerated] = await pool.execute(`
                SELECT 
                    DATE(created_at) as date,
                    COUNT(*) as count,
                    SUM(amount) as total
                FROM vouchers
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
                GROUP BY DATE(created_at)
                ORDER BY date DESC
            `);
            
            res.json({
                success: true,
                data: {
                    summary: stats[0],
                    daily_generated: dailyGenerated
                }
            });
        } catch (error) {
            logError('Get voucher stats error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to fetch voucher statistics' 
            });
        }
    }
    
    /**
     * Update voucher - ADD THIS METHOD FOR EDIT FUNCTIONALITY
     */
    static async updateVoucher(req, res) {
        try {
            const { id } = req.params;
            const { package_id, amount, status, expiry_date } = req.body;
            
            // Check if voucher exists
            const [existing] = await pool.execute(
                'SELECT * FROM vouchers WHERE id = ?',
                [id]
            );
            
            if (existing.length === 0) {
                return res.status(404).json({ 
                    success: false, 
                    error: 'Voucher not found' 
                });
            }
            
            const updates = [];
            const params = [];
            
            if (package_id !== undefined) {
                updates.push('package_id = ?');
                params.push(package_id);
            }
            if (amount !== undefined) {
                updates.push('amount = ?');
                params.push(amount);
            }
            if (status !== undefined) {
                updates.push('status = ?');
                params.push(status);
            }
            if (expiry_date !== undefined) {
                updates.push('expiry_date = ?');
                params.push(expiry_date);
            }
            
            if (updates.length === 0) {
                return res.status(400).json({ 
                    success: false, 
                    error: 'No fields to update' 
                });
            }
            
            params.push(id);
            await pool.execute(
                `UPDATE vouchers SET ${updates.join(', ')} WHERE id = ?`,
                params
            );
            
            await cacheDelete('vouchers:list');
            
            logInfo(`Voucher ${id} updated`, { admin: req.user.id });
            
            res.json({
                success: true,
                message: 'Voucher updated successfully'
            });
        } catch (error) {
            logError('Update voucher error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to update voucher' 
            });
        }
    }
}

module.exports = VoucherController;