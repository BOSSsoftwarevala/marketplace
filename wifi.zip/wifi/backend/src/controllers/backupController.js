const { pool } = require('../config/database');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);
const { logInfo, logError } = require('../config/logger');

// Backup directory
const BACKUP_DIR = path.join(__dirname, '../../backups');

// Ensure backup directory exists
if (!fs.existsSync(BACKUP_DIR)) {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
}

class BackupController {
    /**
     * Get all backups
     */
    static async getAllBackups(req, res) {
        try {
            const files = fs.readdirSync(BACKUP_DIR);
            const backups = [];
            
            for (const file of files) {
                if (file.endsWith('.sql') || file.endsWith('.gz')) {
                    const stats = fs.statSync(path.join(BACKUP_DIR, file));
                    const [type, ...rest] = file.split('_');
                    
                    backups.push({
                        name: file,
                        size: stats.size,
                        type: type === 'full' ? 'full' : (type === 'schema' ? 'schema' : 'data'),
                        created_at: stats.birthtime || stats.ctime,
                        path: path.join(BACKUP_DIR, file)
                    });
                }
            }
            
            // Sort by date descending
            backups.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
            
            res.json({
                success: true,
                data: backups
            });
        } catch (error) {
            logError('Get backups error:', error);
            res.status(500).json({ success: false, error: 'Failed to fetch backups' });
        }
    }
    
    /**
     * Get backup statistics
     */
    static async getBackupStats(req, res) {
        try {
            const files = fs.readdirSync(BACKUP_DIR);
            let totalSize = 0;
            let latestBackup = null;
            
            for (const file of files) {
                if (file.endsWith('.sql') || file.endsWith('.gz')) {
                    const stats = fs.statSync(path.join(BACKUP_DIR, file));
                    totalSize += stats.size;
                    
                    const backupDate = stats.birthtime || stats.ctime;
                    if (!latestBackup || backupDate > new Date(latestBackup.created_at)) {
                        latestBackup = {
                            name: file,
                            created_at: backupDate
                        };
                    }
                }
            }
            
            // Get database size
            const [dbSize] = await pool.execute(`
                SELECT SUM(data_length + index_length) as size 
                FROM information_schema.tables 
                WHERE table_schema = DATABASE()
            `);
            
            res.json({
                success: true,
                data: {
                    total_backups: files.filter(f => f.endsWith('.sql') || f.endsWith('.gz')).length,
                    total_size: totalSize,
                    latest_backup: latestBackup ? latestBackup.name : null,
                    database_size: dbSize[0].size || 0
                }
            });
        } catch (error) {
            logError('Get backup stats error:', error);
            res.status(500).json({ success: false, error: 'Failed to fetch backup stats' });
        }
    }
    
    /**
     * Create backup
     */
    static async createBackup(req, res) {
        try {
            const { name, type = 'full', tables = [] } = req.body;
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const backupName = name || `${type}_backup_${timestamp}.sql`;
            const backupPath = path.join(BACKUP_DIR, backupName);
            
            const dbConfig = {
                host: process.env.DB_HOST || 'localhost',
                user: process.env.DB_USER || 'root',
                password: process.env.DB_PASSWORD || '',
                database: process.env.DB_NAME || 'wifi_billing'
            };
            
            let mysqldumpCmd = `mysqldump -h ${dbConfig.host} -u ${dbConfig.user}`;
            
            if (dbConfig.password) {
                mysqldumpCmd += ` -p${dbConfig.password}`;
            }
            
            mysqldumpCmd += ` ${dbConfig.database}`;
            
            // Add table-specific options
            if (type === 'schema') {
                mysqldumpCmd += ' --no-data';
            } else if (type === 'data') {
                mysqldumpCmd += ' --no-create-info';
            }
            
            // Add specific tables if selected
            if (tables && tables.length > 0) {
                mysqldumpCmd += ` ${tables.join(' ')}`;
            }
            
            mysqldumpCmd += ` > "${backupPath}"`;
            
            logInfo('Creating backup...', { backupName, type });
            
            await execPromise(mysqldumpCmd);
            
            // Compress backup file
            const gzipCmd = `gzip "${backupPath}"`;
            await execPromise(gzipCmd);
            
            const compressedPath = backupPath + '.gz';
            const stats = fs.statSync(compressedPath);
            
            logInfo('Backup created successfully', { backupName, size: stats.size });
            
            res.status(201).json({
                success: true,
                message: 'Backup created successfully',
                data: {
                    name: backupName + '.gz',
                    size: stats.size,
                    type: type,
                    created_at: new Date()
                }
            });
        } catch (error) {
            logError('Create backup error:', error);
            res.status(500).json({ success: false, error: 'Failed to create backup' });
        }
    }
    
    /**
     * Download backup
     */
    static async downloadBackup(req, res) {
        try {
            const { name } = req.params;
            const filePath = path.join(BACKUP_DIR, name);
            
            if (!fs.existsSync(filePath)) {
                return res.status(404).json({ success: false, error: 'Backup not found' });
            }
            
            res.download(filePath, name, (err) => {
                if (err) {
                    logError('Download error:', err);
                    res.status(500).json({ success: false, error: 'Failed to download backup' });
                }
            });
        } catch (error) {
            logError('Download backup error:', error);
            res.status(500).json({ success: false, error: 'Failed to download backup' });
        }
    }
    
    /**
     * Restore backup
     */
    static async restoreBackup(req, res) {
        const connection = await pool.getConnection();
        try {
            const { name } = req.body;
            const filePath = path.join(BACKUP_DIR, name);
            
            if (!fs.existsSync(filePath)) {
                return res.status(404).json({ success: false, error: 'Backup not found' });
            }
            
            // Decompress if needed
            let sqlFile = filePath;
            if (filePath.endsWith('.gz')) {
                const decompressedPath = filePath.replace('.gz', '');
                await execPromise(`gunzip -c "${filePath}" > "${decompressedPath}"`);
                sqlFile = decompressedPath;
            }
            
            const dbConfig = {
                host: process.env.DB_HOST || 'localhost',
                user: process.env.DB_USER || 'root',
                password: process.env.DB_PASSWORD || '',
                database: process.env.DB_NAME || 'wifi_billing'
            };
            
            // Restore using mysql command
            let mysqlCmd = `mysql -h ${dbConfig.host} -u ${dbConfig.user}`;
            
            if (dbConfig.password) {
                mysqlCmd += ` -p${dbConfig.password}`;
            }
            
            mysqlCmd += ` ${dbConfig.database} < "${sqlFile}"`;
            
            logInfo('Restoring backup...', { name });
            await execPromise(mysqlCmd);
            
            // Clean up decompressed file
            if (sqlFile !== filePath && fs.existsSync(sqlFile)) {
                fs.unlinkSync(sqlFile);
            }
            
            logInfo('Backup restored successfully', { name });
            
            res.json({
                success: true,
                message: 'Backup restored successfully'
            });
        } catch (error) {
            logError('Restore backup error:', error);
            res.status(500).json({ success: false, error: 'Failed to restore backup' });
        } finally {
            connection.release();
        }
    }
    
    /**
     * Delete backup
     */
    static async deleteBackup(req, res) {
        try {
            const { name } = req.params;
            const filePath = path.join(BACKUP_DIR, name);
            
            if (!fs.existsSync(filePath)) {
                return res.status(404).json({ success: false, error: 'Backup not found' });
            }
            
            fs.unlinkSync(filePath);
            
            // Also delete associated .sql file if exists
            const sqlFile = filePath.replace('.gz', '');
            if (fs.existsSync(sqlFile)) {
                fs.unlinkSync(sqlFile);
            }
            
            logInfo('Backup deleted', { name });
            
            res.json({
                success: true,
                message: 'Backup deleted successfully'
            });
        } catch (error) {
            logError('Delete backup error:', error);
            res.status(500).json({ success: false, error: 'Failed to delete backup' });
        }
    }
}

module.exports = BackupController;
