const Customer = require('../models/Customer');
const Package = require('../models/Package');
const RadCheck = require('../models/RadCheck');
const RadReply = require('../models/RadReply');
const RadiusSyncService = require('../services/radiusSyncService');
const { pool } = require('../config/database');
const { logInfo, logError } = require('../config/logger');
const { cacheGet, cacheSet, cacheDelete } = require('../config/redis');

class CustomerController {
    /**
     * Get all customers (admin only)
     */
    static async getAllCustomers(req, res) {
        try {
            const { page = 1, limit = 20, status, search } = req.query;
            const offset = (page - 1) * limit;
            
            let query = `
                SELECT c.*, p.package_name, p.price, p.validity_days, p.data_limit_mb,
                       p.upload_speed, p.download_speed,
                       COALESCE(cu.total_mb, 0) as used_mb,
                       CASE 
                           WHEN c.status = 'active' AND DATE_ADD(c.created_at, INTERVAL p.validity_days DAY) < NOW() 
                           THEN 'expired'
                           ELSE c.status 
                       END as current_status
                FROM customers c
                JOIN packages p ON c.package_id = p.id
                LEFT JOIN customer_usage cu ON c.id = cu.customer_id
                WHERE 1=1
            `;
            
            const params = [];
            
            if (status && status !== 'all') {
                query += ` AND c.status = ?`;
                params.push(status);
            }
            
            if (search) {
                query += ` AND (c.fullname LIKE ? OR c.username LIKE ? OR c.phone LIKE ?)`;
                const searchParam = `%${search}%`;
                params.push(searchParam, searchParam, searchParam);
            }
            
            query += ` ORDER BY c.created_at DESC LIMIT ? OFFSET ?`;
            params.push(parseInt(limit), parseInt(offset));
            
            const [customers] = await pool.execute(query, params);
            
            // Get total count
            let countQuery = `SELECT COUNT(*) as total FROM customers c WHERE 1=1`;
            const countParams = [];
            
            if (status && status !== 'all') {
                countQuery += ` AND c.status = ?`;
                countParams.push(status);
            }
            
            if (search) {
                countQuery += ` AND (c.fullname LIKE ? OR c.username LIKE ? OR c.phone LIKE ?)`;
                const searchParam = `%${search}%`;
                countParams.push(searchParam, searchParam, searchParam);
            }
            
            const [total] = await pool.execute(countQuery, countParams);
            
            res.json({
                success: true,
                data: customers,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total: total[0].total,
                    pages: Math.ceil(total[0].total / limit)
                }
            });
        } catch (error) {
            logError('Get customers error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to fetch customers' 
            });
        }
    }
    
    /**
     * Get customer by ID
     */
    static async getCustomerById(req, res) {
        try {
            const { id } = req.params;
            
            // Check cache first
            const cacheKey = `customer:${id}`;
            let customer = await cacheGet(cacheKey);
            
            if (!customer) {
                customer = await Customer.findById(id);
                if (!customer) {
                    return res.status(404).json({ 
                        success: false, 
                        error: 'Customer not found' 
                    });
                }
                
                // Cache for 5 minutes
                await cacheSet(cacheKey, customer, 300);
            }
            
            // Get usage data
            const usage = await Customer.getCustomerUsage(id);
            
            // Get router access
            const [routerAccess] = await pool.execute(
                `SELECT r.id, r.router_name, r.ip_address, cra.status
                 FROM customer_router_access cra
                 JOIN routers r ON cra.router_id = r.id
                 WHERE cra.customer_id = ?`,
                [id]
            );
            
            // Get payment history
            const [payments] = await pool.execute(
                `SELECT p.*, pk.package_name
                 FROM payments p
                 JOIN packages pk ON p.package_id = pk.id
                 WHERE p.customer_id = ?
                 ORDER BY p.created_at DESC
                 LIMIT 10`,
                [id]
            );
            
            res.json({
                success: true,
                data: {
                    ...customer,
                    usage,
                    router_access: routerAccess,
                    recent_payments: payments
                }
            });
        } catch (error) {
            logError('Get customer error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to fetch customer' 
            });
        }
    }
    
    /**
     * Create new customer
     */
    static async createCustomer(req, res) {
        try {
            const { fullname, phone, email, username, password, package_id } = req.body;
            
            // Validate
            if (!fullname || !phone || !username || !password || !package_id) {
                return res.status(400).json({ 
                    success: false, 
                    error: 'Missing required fields' 
                });
            }
            
            // Check username
            const existing = await Customer.findByUsername(username);
            if (existing) {
                return res.status(400).json({ 
                    success: false, 
                    error: 'Username already exists' 
                });
            }
            
            // Check phone
            const [phoneCheck] = await pool.execute(
                'SELECT id FROM customers WHERE phone = ?',
                [phone]
            );
            if (phoneCheck.length > 0) {
                return res.status(400).json({ 
                    success: false, 
                    error: 'Phone number already registered' 
                });
            }
            
            // Get package
            const package_ = await Package.findById(package_id);
            if (!package_) {
                return res.status(400).json({ 
                    success: false, 
                    error: 'Invalid package' 
                });
            }
            
            // Create customer
            const customerId = await Customer.create({
                fullname, phone, email, username, password, package_id
            });
            
            // Sync to RADIUS
            await RadiusSyncService.syncCustomerToRadius(customerId);
            
            // Clear cache
            await cacheDelete('customers:list');
            
            logInfo(`Customer created by admin: ${username}`, { customerId, admin: req.user.id });
            
            res.status(201).json({
                success: true,
                message: 'Customer created successfully',
                data: { id: customerId, username }
            });
        } catch (error) {
            logError('Create customer error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to create customer' 
            });
        }
    }
    
    /**
     * Update customer
     */
    static async updateCustomer(req, res) {
        try {
            const { id } = req.params;
            const { fullname, phone, email, package_id, status } = req.body;
            
            const customer = await Customer.findById(id);
            if (!customer) {
                return res.status(404).json({ 
                    success: false, 
                    error: 'Customer not found' 
                });
            }
            
            // Update customer
            const updates = [];
            const params = [];
            
            if (fullname) {
                updates.push('fullname = ?');
                params.push(fullname);
            }
            if (phone) {
                updates.push('phone = ?');
                params.push(phone);
            }
            if (email !== undefined) {
                updates.push('email = ?');
                params.push(email);
            }
            if (package_id) {
                updates.push('package_id = ?');
                params.push(package_id);
            }
            if (status) {
                updates.push('status = ?');
                params.push(status);
                // Update RADIUS status
                await RadCheck.updateStatus(customer.username, status);
            }
            
            if (updates.length > 0) {
                params.push(id);
                await pool.execute(
                    `UPDATE customers SET ${updates.join(', ')} WHERE id = ?`,
                    params
                );
            }
            
            // Resync to RADIUS if package changed
            if (package_id) {
                await RadiusSyncService.syncCustomerToRadius(id);
            }
            
            // Clear cache
            await cacheDelete(`customer:${id}`);
            await cacheDelete('customers:list');
            
            logInfo(`Customer updated: ${customer.username}`, { customerId: id, admin: req.user.id });
            
            res.json({
                success: true,
                message: 'Customer updated successfully'
            });
        } catch (error) {
            logError('Update customer error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to update customer' 
            });
        }
    }
    
    /**
     * Delete customer
     */
    static async deleteCustomer(req, res) {
        try {
            const { id } = req.params;
            
            const customer = await Customer.findById(id);
            if (!customer) {
                return res.status(404).json({ 
                    success: false, 
                    error: 'Customer not found' 
                });
            }
            
            // Delete from RADIUS tables
            await pool.execute('DELETE FROM radcheck WHERE username = ?', [customer.username]);
            await pool.execute('DELETE FROM radreply WHERE username = ?', [customer.username]);
            await pool.execute('DELETE FROM radacct WHERE username = ?', [customer.username]);
            
            // Delete from customer tables
            await pool.execute('DELETE FROM customer_router_access WHERE customer_id = ?', [id]);
            await pool.execute('DELETE FROM customer_usage WHERE customer_id = ?', [id]);
            await pool.execute('DELETE FROM router_sessions WHERE customer_id = ?', [id]);
            await pool.execute('DELETE FROM payments WHERE customer_id = ?', [id]);
            await pool.execute('DELETE FROM customers WHERE id = ?', [id]);
            
            // Clear cache
            await cacheDelete(`customer:${id}`);
            await cacheDelete('customers:list');
            
            logInfo(`Customer deleted: ${customer.username}`, { customerId: id, admin: req.user.id });
            
            res.json({
                success: true,
                message: 'Customer deleted successfully'
            });
        } catch (error) {
            logError('Delete customer error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to delete customer' 
            });
        }
    }
    
    /**
     * Get customer profile (self)
     */
    static async getProfile(req, res) {
        try {
            const customerId = req.user.id;
            
            const customer = await Customer.findById(customerId);
            if (!customer) {
                return res.status(404).json({ 
                    success: false, 
                    error: 'Customer not found' 
                });
            }
            
            const usage = await Customer.getCustomerUsage(customerId);
            
            // Calculate remaining days
            const createdAt = new Date(customer.created_at);
            const expiryDate = new Date(createdAt);
            expiryDate.setDate(expiryDate.getDate() + customer.validity_days);
            const remainingDays = Math.max(0, Math.ceil((expiryDate - new Date()) / (1000 * 60 * 60 * 24)));
            
            // Calculate remaining data
            const remainingData = Math.max(0, (customer.data_limit_mb || 0) - (usage.total_mb || 0));
            
            res.json({
                success: true,
                data: {
                    id: customer.id,
                    fullname: customer.fullname,
                    username: customer.username,
                    phone: customer.phone,
                    email: customer.email,
                    package: customer.package_name,
                    status: customer.status,
                    upload_speed: customer.upload_speed,
                    download_speed: customer.download_speed,
                    created_at: customer.created_at,
                    valid_until: expiryDate,
                    remaining_days: remainingDays,
                    data_used_mb: usage.total_mb || 0,
                    data_limit_mb: customer.data_limit_mb || 0,
                    remaining_data_mb: remainingData,
                    session_time: usage.session_time || 0
                }
            });
        } catch (error) {
            logError('Get profile error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to fetch profile' 
            });
        }
    }
    
    /**
     * Update profile (self)
     */
    static async updateProfile(req, res) {
        try {
            const customerId = req.user.id;
            const { email, fullname } = req.body;
            
            const updates = [];
            const params = [];
            
            if (fullname) {
                updates.push('fullname = ?');
                params.push(fullname);
            }
            if (email !== undefined) {
                updates.push('email = ?');
                params.push(email);
            }
            
            if (updates.length > 0) {
                params.push(customerId);
                await pool.execute(
                    `UPDATE customers SET ${updates.join(', ')} WHERE id = ?`,
                    params
                );
            }
            
            // Clear cache
            await cacheDelete(`customer:${customerId}`);
            
            logInfo(`Profile updated: ${req.user.username}`, { customerId });
            
            res.json({
                success: true,
                message: 'Profile updated successfully'
            });
        } catch (error) {
            logError('Update profile error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to update profile' 
            });
        }
    }
    
    /**
     * Get customer usage statistics
     */
    static async getUsageStats(req, res) {
        try {
            const customerId = req.user?.id || req.params.id;
            
            // Get daily usage for last 30 days
            const [dailyUsage] = await pool.execute(`
                SELECT 
                    DATE(acctstarttime) as date,
                    SUM(acctinputoctets + acctoutputoctets) / (1024 * 1024) as total_mb,
                    COUNT(*) as sessions
                FROM radacct
                WHERE username = (SELECT username FROM customers WHERE id = ?)
                    AND acctstarttime >= DATE_SUB(NOW(), INTERVAL 30 DAY)
                GROUP BY DATE(acctstarttime)
                ORDER BY date DESC
            `, [customerId]);
            
            // Get hourly usage for last 24 hours
            const [hourlyUsage] = await pool.execute(`
                SELECT 
                    HOUR(acctstarttime) as hour,
                    SUM(acctinputoctets + acctoutputoctets) / (1024 * 1024) as total_mb
                FROM radacct
                WHERE username = (SELECT username FROM customers WHERE id = ?)
                    AND acctstarttime >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
                GROUP BY HOUR(acctstarttime)
                ORDER BY hour ASC
            `, [customerId]);
            
            res.json({
                success: true,
                data: {
                    daily: dailyUsage,
                    hourly: hourlyUsage
                }
            });
        } catch (error) {
            logError('Get usage stats error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to fetch usage statistics' 
            });
        }
    }
    
    /**
     * Manage router access for customer
     */
    static async manageRouterAccess(req, res) {
        try {
            const { customerId, routerId, action } = req.body;
            
            if (action === 'allow') {
                await pool.execute(
                    `INSERT INTO customer_router_access (customer_id, router_id, status)
                     VALUES (?, ?, 'allowed')
                     ON DUPLICATE KEY UPDATE status = 'allowed'`,
                    [customerId, routerId]
                );
            } else if (action === 'block') {
                await pool.execute(
                    `INSERT INTO customer_router_access (customer_id, router_id, status)
                     VALUES (?, ?, 'blocked')
                     ON DUPLICATE KEY UPDATE status = 'blocked'`,
                    [customerId, routerId]
                );
            } else if (action === 'remove') {
                await pool.execute(
                    `DELETE FROM customer_router_access
                     WHERE customer_id = ? AND router_id = ?`,
                    [customerId, routerId]
                );
            } else {
                return res.status(400).json({ 
                    success: false, 
                    error: 'Invalid action' 
                });
            }
            
            // Clear cache
            await cacheDelete(`customer:${customerId}`);
            
            logInfo(`Router access updated for customer ${customerId}: ${action} router ${routerId}`);
            
            res.json({
                success: true,
                message: `Router access ${action}ed successfully`
            });
        } catch (error) {
            logError('Manage router access error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to manage router access' 
            });
        }
    }
}

module.exports = CustomerController;