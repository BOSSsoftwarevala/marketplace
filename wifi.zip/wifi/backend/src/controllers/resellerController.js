const bcrypt = require('bcryptjs');
const { pool } = require('../config/database');
const { logInfo, logError } = require('../config/logger');
const { cacheDelete, cacheGet, cacheSet } = require('../config/redis');

class ResellerController {
    /**
     * Get all resellers
     */
    static async getAllResellers(req, res) {
        try {
            const [resellers] = await pool.execute(`
                SELECT r.*, 
                       COUNT(DISTINCT rs.id) as total_sales,
                       SUM(rs.commission) as total_commission_earned
                FROM resellers r
                LEFT JOIN reseller_sales rs ON r.id = rs.reseller_id
                GROUP BY r.id
                ORDER BY r.created_at DESC
            `);
            
            res.json({
                success: true,
                data: resellers
            });
        } catch (error) {
            logError('Get resellers error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to fetch resellers' 
            });
        }
    }
    
    /**
     * Create reseller
     */
    static async createReseller(req, res) {
        try {
            const { fullname, phone, email, username, password, commission_percent } = req.body;
            
            // Check existing
            const [existing] = await pool.execute(
                'SELECT id FROM resellers WHERE username = ? OR phone = ?',
                [username, phone]
            );
            
            if (existing.length > 0) {
                return res.status(400).json({ 
                    success: false, 
                    error: 'Username or phone already exists' 
                });
            }
            
            const hashedPassword = await bcrypt.hash(password, 10);
            
            const [result] = await pool.execute(
                `INSERT INTO resellers (fullname, phone, email, username, password, commission_percent, status)
                 VALUES (?, ?, ?, ?, ?, ?, 'active')`,
                [fullname, phone, email, username, hashedPassword, commission_percent || 10]
            );
            
            logInfo(`Reseller created: ${username}`, { resellerId: result.insertId, admin: req.user.id });
            
            res.status(201).json({
                success: true,
                message: 'Reseller created successfully',
                data: { id: result.insertId, username }
            });
        } catch (error) {
            logError('Create reseller error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to create reseller' 
            });
        }
    }
    
    /**
     * Reseller login
     */
    static async login(req, res) {
        try {
            const { username, password } = req.body;
            
            const [resellers] = await pool.execute(
                'SELECT * FROM resellers WHERE username = ? AND status = "active"',
                [username]
            );
            
            if (resellers.length === 0) {
                return res.status(401).json({ 
                    success: false, 
                    error: 'Invalid credentials' 
                });
            }
            
            const reseller = resellers[0];
            const isValid = await bcrypt.compare(password, reseller.password);
            
            if (!isValid) {
                return res.status(401).json({ 
                    success: false, 
                    error: 'Invalid credentials' 
                });
            }
            
            const jwt = require('jsonwebtoken');
            const token = jwt.sign(
                { id: reseller.id, username: reseller.username, role: 'reseller' },
                process.env.JWT_SECRET,
                { expiresIn: '7d' }
            );
            
            logInfo(`Reseller logged in: ${username}`, { resellerId: reseller.id });
            
            res.json({
                success: true,
                data: {
                    token,
                    reseller: {
                        id: reseller.id,
                        fullname: reseller.fullname,
                        username: reseller.username,
                        phone: reseller.phone,
                        email: reseller.email,
                        commission_percent: reseller.commission_percent,
                        balance: reseller.balance
                    }
                }
            });
        } catch (error) {
            logError('Reseller login error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Login failed' 
            });
        }
    }
    
    /**
     * Get reseller dashboard stats
     */
    static async getDashboard(req, res) {
        try {
            const resellerId = req.user.id;
            
            // Get sales statistics
            const [sales] = await pool.execute(`
                SELECT 
                    COUNT(*) as total_sales,
                    SUM(amount) as total_amount,
                    SUM(commission) as total_commission,
                    AVG(amount) as avg_sale_amount
                FROM reseller_sales
                WHERE reseller_id = ?
            `, [resellerId]);
            
            // Get recent sales
            const [recentSales] = await pool.execute(`
                SELECT rs.*, v.voucher_code, p.package_name
                FROM reseller_sales rs
                JOIN vouchers v ON rs.voucher_id = v.id
                JOIN packages p ON v.package_id = p.id
                WHERE rs.reseller_id = ?
                ORDER BY rs.created_at DESC
                LIMIT 10
            `, [resellerId]);
            
            // Get daily sales for chart
            const [dailySales] = await pool.execute(`
                SELECT 
                    DATE(created_at) as date,
                    COUNT(*) as count,
                    SUM(amount) as total
                FROM reseller_sales
                WHERE reseller_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
                GROUP BY DATE(created_at)
                ORDER BY date DESC
            `, [resellerId]);
            
            res.json({
                success: true,
                data: {
                    summary: sales[0],
                    recent_sales: recentSales,
                    daily_sales: dailySales
                }
            });
        } catch (error) {
            logError('Reseller dashboard error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to fetch dashboard data' 
            });
        }
    }
    
    /**
     * Generate vouchers for reseller
     */
    static async generateVouchers(req, res) {
        try {
            const resellerId = req.user.id;
            const { package_id, quantity = 1 } = req.body;
            
            // Get package details
            const Package = require('../models/Package');
            const package_ = await Package.findById(package_id);
            
            if (!package_) {
                return res.status(404).json({ 
                    success: false, 
                    error: 'Package not found' 
                });
            }
            
            // Get reseller
            const [resellers] = await pool.execute(
                'SELECT * FROM resellers WHERE id = ?',
                [resellerId]
            );
            const reseller = resellers[0];
            
            // Calculate total cost
            const totalCost = package_.price * quantity;
            
            // Check if reseller has enough balance
            if (reseller.balance < totalCost) {
                return res.status(400).json({ 
                    success: false, 
                    error: `Insufficient balance. Available: ${reseller.balance}, Required: ${totalCost}` 
                });
            }
            
            const vouchers = [];
            const expiryDate = new Date();
            expiryDate.setDate(expiryDate.getDate() + package_.validity_days);
            
            for (let i = 0; i < quantity; i++) {
                const code = generateVoucherCode();
                
                const [result] = await pool.execute(
                    `INSERT INTO vouchers (voucher_code, package_id, amount, expiry_date, status)
                     VALUES (?, ?, ?, ?, 'unused')`,
                    [code, package_id, package_.price, expiryDate]
                );
                
                // Record reseller sale
                const commission = (package_.price * reseller.commission_percent) / 100;
                await pool.execute(
                    `INSERT INTO reseller_sales (reseller_id, voucher_id, amount, commission)
                     VALUES (?, ?, ?, ?)`,
                    [resellerId, result.insertId, package_.price, commission]
                );
                
                vouchers.push({
                    id: result.insertId,
                    code,
                    amount: package_.price,
                    commission
                });
            }
            
            // Deduct from reseller balance
            await pool.execute(
                `UPDATE resellers SET balance = balance - ? WHERE id = ?`,
                [totalCost, resellerId]
            );
            
            logInfo(`Reseller generated ${quantity} vouchers`, {
                resellerId,
                totalCost,
                commissionEarned: (package_.price * reseller.commission_percent / 100) * quantity
            });
            
            res.json({
                success: true,
                message: `${quantity} voucher(s) generated successfully`,
                data: {
                    vouchers,
                    summary: {
                        total_vouchers: quantity,
                        total_cost: totalCost,
                        commission_rate: reseller.commission_percent,
                        total_commission: (package_.price * reseller.commission_percent / 100) * quantity,
                        remaining_balance: reseller.balance - totalCost
                    }
                }
            });
        } catch (error) {
            logError('Reseller generate vouchers error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to generate vouchers' 
            });
        }
    }
    
    /**
     * Get reseller sales history
     */
    static async getSalesHistory(req, res) {
        try {
            const resellerId = req.user.id;
            const { page = 1, limit = 50 } = req.query;
            const offset = (page - 1) * limit;
            
            const [sales] = await pool.execute(`
                SELECT rs.*, v.voucher_code, v.status as voucher_status,
                       p.package_name, p.price as package_price, p.validity_days,
                       c.fullname as used_by_name, c.username as used_by_username
                FROM reseller_sales rs
                JOIN vouchers v ON rs.voucher_id = v.id
                JOIN packages p ON v.package_id = p.id
                LEFT JOIN customers c ON v.used_by = c.id
                WHERE rs.reseller_id = ?
                ORDER BY rs.created_at DESC
                LIMIT ? OFFSET ?
            `, [resellerId, parseInt(limit), parseInt(offset)]);
            
            const [total] = await pool.execute(
                'SELECT COUNT(*) as total FROM reseller_sales WHERE reseller_id = ?',
                [resellerId]
            );
            
            res.json({
                success: true,
                data: sales,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total: total[0].total,
                    pages: Math.ceil(total[0].total / limit)
                }
            });
        } catch (error) {
            logError('Get sales history error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to fetch sales history' 
            });
        }
    }
    
    /**
     * Withdraw commission (request payout)
     */
    static async withdrawCommission(req, res) {
        try {
            const resellerId = req.user.id;
            const { amount, phone } = req.body;
            
            const [resellers] = await pool.execute(
                'SELECT * FROM resellers WHERE id = ?',
                [resellerId]
            );
            const reseller = resellers[0];
            
            if (amount > reseller.balance) {
                return res.status(400).json({ 
                    success: false, 
                    error: 'Insufficient balance' 
                });
            }
            
            // Create withdrawal request (implement M-Pesa B2C here)
            // await MpesaService.b2cPayment(phone, amount, 'BusinessPayment', 'Commission withdrawal');
            
            // Deduct balance
            await pool.execute(
                `UPDATE resellers SET balance = balance - ? WHERE id = ?`,
                [amount, resellerId]
            );
            
            // Record withdrawal (create withdrawals table if needed)
            await pool.execute(
                `INSERT INTO reseller_withdrawals (reseller_id, amount, phone, status)
                 VALUES (?, ?, ?, 'pending')`,
                [resellerId, amount, phone]
            );
            
            logInfo(`Reseller withdrawal requested: ${amount}`, { resellerId });
            
            res.json({
                success: true,
                message: 'Withdrawal request submitted successfully',
                data: {
                    amount,
                    new_balance: reseller.balance - amount
                }
            });
        } catch (error) {
            logError('Withdraw commission error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to process withdrawal' 
            });
        }
    }
    
    /**
     * Update reseller (admin)
     */
    static async updateReseller(req, res) {
        try {
            const { id } = req.params;
            const { commission_percent, status, balance } = req.body;
            
            const updates = [];
            const params = [];
            
            if (commission_percent !== undefined) {
                updates.push('commission_percent = ?');
                params.push(commission_percent);
            }
            if (status !== undefined) {
                updates.push('status = ?');
                params.push(status);
            }
            if (balance !== undefined) {
                updates.push('balance = ?');
                params.push(balance);
            }
            
            if (updates.length > 0) {
                params.push(id);
                await pool.execute(
                    `UPDATE resellers SET ${updates.join(', ')} WHERE id = ?`,
                    params
                );
            }
            
            logInfo(`Reseller updated: ID ${id}`, { admin: req.user.id });
            
            res.json({
                success: true,
                message: 'Reseller updated successfully'
            });
        } catch (error) {
            logError('Update reseller error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to update reseller' 
            });
        }
    }
}

// Helper function to generate unique voucher code
function generateVoucherCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 12; i++) {
        if (i > 0 && i % 4 === 0) {
            code += '-';
        }
        code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
}

module.exports = ResellerController;