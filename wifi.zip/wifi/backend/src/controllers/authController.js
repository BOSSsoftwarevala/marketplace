const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const Customer = require('../models/Customer');
const RadCheck = require('../models/RadCheck');
const RadReply = require('../models/RadReply');
const { pool } = require('../config/database');
const { logInfo, logError, logWarning } = require('../config/logger');
const { redisClient, setSession } = require('../config/redis');

class AuthController {
    /**
     * Register a new customer
     */
    static async register(req, res) {
        try {
            const { fullname, phone, email, username, password, package_id } = req.body;
            
            // Validate required fields
            if (!fullname || !phone || !username || !password || !package_id) {
                return res.status(400).json({ 
                    success: false, 
                    error: 'Missing required fields' 
                });
            }
            
            // Check if username exists in customers table
            const existing = await Customer.findByUsername(username);
            if (existing) {
                return res.status(400).json({ 
                    success: false, 
                    error: 'Username already exists' 
                });
            }
            
            // Check if username exists in admins table
            const [adminExists] = await pool.execute(
                'SELECT id FROM admins WHERE username = ?',
                [username]
            );
            if (adminExists.length > 0) {
                return res.status(400).json({ 
                    success: false, 
                    error: 'Username already exists' 
                });
            }
            
            // Check if phone exists
            const [phoneCheck] = await pool.execute(
                'SELECT id FROM customers WHERE phone = ?',
                [phone]
            );
            if (phoneCheck.length > 0) {
                return res.status(400).json({ 
                    success: false, 
                    error: 'Phone number already registered' 
                });
            }
            
            // Create customer
            const customerId = await Customer.create({
                fullname, phone, email, username, password, package_id
            });
            
            // Get package details
            const Package = require('../models/Package');
            const package_ = await Package.findById(package_id);
            
            if (!package_) {
                return res.status(400).json({ 
                    success: false, 
                    error: 'Invalid package' 
                });
            }
            
            // Create pending payment record
            await pool.execute(
                `INSERT INTO payments (customer_id, phone, amount, package_id, status)
                 VALUES (?, ?, ?, ?, 'pending')`,
                [customerId, phone, package_.price, package_id]
            );
            
            logInfo(`New customer registered: ${username}`, { customerId, phone });
            
            res.status(201).json({
                success: true,
                message: 'Registration successful. Please complete payment to activate.',
                data: {
                    customerId,
                    username,
                    package: package_.package_name,
                    amount: package_.price
                }
            });
        } catch (error) {
            logError('Registration error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Registration failed' 
            });
        }
    }
    
    /**
     * Login - checks both admins and customers tables
     */
   /**
 * Login - checks both admins and customers tables
 */
/**
 * Login - checks admins table for admin, customers table for customers
 */
static async login(req, res) {
    try {
        const { username, password } = req.body;
        
        if (!username || !password) {
            return res.status(400).json({ 
                success: false, 
                error: 'Username and password required' 
            });
        }
        
        // FIRST: Check if user is an ADMIN (from admins table)
        const [admins] = await pool.execute(
            'SELECT *, "admin" as role FROM admins WHERE (username = ? OR email = ?) AND status = "active"',
            [username, username]
        );
        
        let user = null;
        let userType = null;
        
        if (admins.length > 0) {
            user = admins[0];
            userType = 'admin';
        } else {
            // SECOND: Check if user is a CUSTOMER (from customers table)
            const customer = await Customer.findByUsername(username);
            if (customer) {
                user = customer;
                userType = 'customer';
            }
        }
        
        // If no user found in either table
        if (!user) {
            logWarning(`Failed login attempt - user not found: ${username}`);
            return res.status(401).json({ 
                success: false, 
                error: 'Invalid credentials' 
            });
        }
        
        // Verify password
        const isValid = await bcrypt.compare(password, user.password);
        if (!isValid) {
            logWarning(`Failed login attempt - invalid password: ${username}`);
            return res.status(401).json({ 
                success: false, 
                error: 'Invalid credentials' 
            });
        }
        
        // Handle ADMIN login (from admins table)
        if (userType === 'admin') {
            // Update last login
            await pool.execute(
                'UPDATE admins SET last_login = NOW() WHERE id = ?',
                [user.id]
            );
            
            // Generate JWT token for admin
            const token = jwt.sign(
                { 
                    id: user.id, 
                    username: user.username || user.email,
                    email: user.email,
                    role: 'admin' 
                },
                process.env.JWT_SECRET,
                { expiresIn: process.env.JWT_EXPIRE || '7d' }
            );
            
            // Store session in Redis
            await setSession(`admin:${user.id}`, {
                token,
                loginTime: new Date().toISOString(),
                ip: req.ip
            }, 86400);
            
            logInfo(`Admin logged in: ${user.username || user.email}`, { adminId: user.id });
            
            return res.json({
                success: true,
                message: 'Admin login successful',
                data: {
                    token,
                    user: {
                        id: user.id,
                        fullname: user.fullname,
                        username: user.username || user.email,
                        email: user.email,
                        role: 'admin'
                    }
                }
            });
        }
        
        // Handle CUSTOMER login (from customers table)
        // Check account status
        if (user.status !== 'active') {
            let errorMessage = 'Account not active. ';
            if (user.status === 'inactive') {
                errorMessage += 'Please complete payment to activate.';
            } else if (user.status === 'suspended') {
                errorMessage += 'Account suspended. Please contact support.';
            }
            
            return res.status(403).json({ 
                success: false, 
                error: errorMessage,
                status: user.status
            });
        }
        
        // Check package expiry
        const createdAt = new Date(user.created_at);
        const expiryDate = new Date(createdAt);
        expiryDate.setDate(expiryDate.getDate() + user.validity_days);
        
        if (new Date() > expiryDate) {
            await Customer.updateStatus(user.id, 'inactive');
            await RadCheck.updateStatus(username, 'inactive');
            
            return res.status(403).json({ 
                success: false, 
                error: 'Package expired. Please renew.' 
            });
        }
        
        // Check data limit
        const usage = await Customer.getCustomerUsage(user.id);
        if (user.data_limit_mb > 0 && usage.total_mb >= user.data_limit_mb) {
            await Customer.updateStatus(user.id, 'suspended');
            await RadCheck.updateStatus(username, 'suspended');
            
            return res.status(403).json({ 
                success: false, 
                error: 'Data limit exceeded. Please upgrade your package.' 
            });
        }
        
        // Generate JWT token for customer
        const token = jwt.sign(
            { 
                id: user.id, 
                username: user.username, 
                role: 'customer',
                package_id: user.package_id
            },
            process.env.JWT_SECRET,
            { expiresIn: process.env.JWT_EXPIRE || '7d' }
        );
        
        // Store session in Redis
        await setSession(`customer:${user.id}`, {
            token,
            loginTime: new Date().toISOString(),
            ip: req.ip
        }, 86400);
        
        logInfo(`Customer logged in: ${username}`, { customerId: user.id });
        
        res.json({
            success: true,
            message: 'Login successful',
            data: {
                token,
                user: {
                    id: user.id,
                    fullname: user.fullname,
                    username: user.username,
                    phone: user.phone,
                    email: user.email,
                    package: user.package_name,
                    package_id: user.package_id,
                    status: user.status,
                    upload_speed: user.upload_speed,
                    download_speed: user.download_speed,
                    role: 'customer',
                    valid_until: expiryDate
                }
            }
        });
    } catch (error) {
        logError('Login error:', error);
        res.status(500).json({ 
            success: false, 
            error: 'Login failed' 
        });
    }
}
    
    /**
     * RADIUS authentication endpoint
     * Called by FreeRADIUS for authentication
     */
    static async radiusAuth(req, res) {
        try {
            const { username, password, nas_ip_address, called_station_id, calling_station_id } = req.body;
            
            if (!username || !password) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Username and password required' 
                });
            }
            
            // Check both tables for RADIUS auth
            let user = null;
            
            // Check admins table first
            const [admins] = await pool.execute(
                'SELECT * FROM admins WHERE username = ? AND status = "active"',
                [username]
            );
            
            if (admins.length > 0) {
                user = admins[0];
            } else {
                // Check customers table
                const customer = await Customer.findByUsername(username);
                if (customer && customer.status === 'active') {
                    user = customer;
                }
            }
            
            if (!user) {
                logWarning(`RADIUS auth failed - user not found: ${username}`);
                return res.json({ 
                    success: false, 
                    message: 'User not found' 
                });
            }
            
            // Check password
            const isValid = await bcrypt.compare(password, user.password);
            if (!isValid) {
                logWarning(`RADIUS auth failed - invalid password: ${username}`);
                return res.json({ 
                    success: false, 
                    message: 'Invalid password' 
                });
            }
            
            // For admin users, allow immediate access
            if (user.role === 'admin') {
                logInfo(`RADIUS auth success (admin): ${username}`);
                return res.json({
                    success: true,
                    message: 'Access granted',
                    reply_attributes: {
                        'Mikrotik-Rate-Limit': '100M/100M',
                        'Session-Timeout': '86400',
                        'Idle-Timeout': '300'
                    }
                });
            }
            
            // For customers, continue with normal checks
            // Check account status
            if (user.status !== 'active') {
                logWarning(`RADIUS auth failed - account inactive: ${username}`, { status: user.status });
                return res.json({ 
                    success: false, 
                    message: `Account ${user.status}` 
                });
            }
            
            // Check router access if NAS IP is provided
            if (nas_ip_address) {
                const [router] = await pool.execute(
                    `SELECT id, status, router_name FROM routers WHERE ip_address = ?`,
                    [nas_ip_address]
                );
                
                if (router.length > 0) {
                    // Check if router is active
                    if (router[0].status !== 'active') {
                        return res.json({ 
                            success: false, 
                            message: 'Router is inactive' 
                        });
                    }
                    
                    // Check customer router access
                    const canAccess = await Customer.canAccessRouter(user.id, router[0].id);
                    if (!canAccess) {
                        logWarning(`RADIUS auth failed - router access denied: ${username}`, { router: router[0].router_name });
                        return res.json({ 
                            success: false, 
                            message: 'Access denied for this router' 
                        });
                    }
                }
            }
            
            // Check package expiry
            const createdAt = new Date(user.created_at);
            const expiryDate = new Date(createdAt);
            expiryDate.setDate(expiryDate.getDate() + user.validity_days);
            
            if (new Date() > expiryDate) {
                await Customer.updateStatus(user.id, 'inactive');
                await RadCheck.updateStatus(username, 'inactive');
                
                return res.json({ 
                    success: false, 
                    message: 'Package expired' 
                });
            }
            
            // Check data limit
            const usage = await Customer.getCustomerUsage(user.id);
            if (user.data_limit_mb > 0 && usage.total_mb >= user.data_limit_mb) {
                await Customer.updateStatus(user.id, 'suspended');
                await RadCheck.updateStatus(username, 'suspended');
                
                return res.json({ 
                    success: false, 
                    message: 'Data limit exceeded' 
                });
            }
            
            // Get speed limits and other RADIUS attributes
            const limits = await RadReply.getCustomerLimits(username);
            
            // Prepare RADIUS reply attributes
            const replyAttributes = {
                'Mikrotik-Rate-Limit': `${limits.upload_speed || user.upload_speed || '1M'}/${limits.download_speed || user.download_speed || '1M'}`,
                'Session-Timeout': limits.session_timeout || (user.validity_days * 86400) || 86400,
                'Idle-Timeout': limits.idle_timeout || 300
            };
            
            logInfo(`RADIUS auth success: ${username}`, { nas_ip: nas_ip_address });
            
            res.json({
                success: true,
                message: 'Access granted',
                reply_attributes: replyAttributes
            });
        } catch (error) {
            logError('RADIUS auth error:', error);
            res.json({ 
                success: false, 
                message: 'Authentication failed' 
            });
        }
    }
    
    /**
     * Logout user (works for both admin and customer)
     */
    static async logout(req, res) {
        try {
            const userId = req.user.id;
            const role = req.user.role;
            
            // Remove from Redis based on role
            if (role === 'admin') {
                await setSession(`admin:${userId}`, null, 0);
            } else {
                await setSession(`customer:${userId}`, null, 0);
            }
            
            logInfo(`User logged out: ${req.user.username}`, { userId, role });
            
            res.json({
                success: true,
                message: 'Logout successful'
            });
        } catch (error) {
            logError('Logout error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Logout failed' 
            });
        }
    }
    
    /**
     * Change password (works for both admin and customer)
     */
    static async changePassword(req, res) {
        try {
            const { old_password, new_password } = req.body;
            const userId = req.user.id;
            const role = req.user.role;
            
            let user = null;
            let table = '';
            
            if (role === 'admin') {
                const [admins] = await pool.execute(
                    'SELECT * FROM admins WHERE id = ?',
                    [userId]
                );
                user = admins[0];
                table = 'admins';
            } else {
                user = await Customer.findById(userId);
                table = 'customers';
            }
            
            if (!user) {
                return res.status(404).json({ 
                    success: false, 
                    error: 'User not found' 
                });
            }
            
            // Verify old password
            const isValid = await bcrypt.compare(old_password, user.password);
            if (!isValid) {
                return res.status(401).json({ 
                    success: false, 
                    error: 'Current password is incorrect' 
                });
            }
            
            // Update password
            const hashedPassword = await bcrypt.hash(new_password, 10);
            await pool.execute(
                `UPDATE ${table} SET password = ? WHERE id = ?`,
                [hashedPassword, userId]
            );
            
            // If customer, also update RADIUS
            if (role === 'customer') {
                await RadCheck.update(user.username, new_password);
            }
            
            logInfo(`Password changed: ${user.username}`, { userId, role });
            
            res.json({
                success: true,
                message: 'Password changed successfully'
            });
        } catch (error) {
            logError('Change password error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Password change failed' 
            });
        }
    }
    
    /**
     * Forgot password - send reset link
     */
    static async forgotPassword(req, res) {
        try {
            const { username_or_phone } = req.body;
            
            // Find user in customers table
            let user = await Customer.findByUsername(username_or_phone);
            let userType = 'customer';
            
            if (!user) {
                const [rows] = await pool.execute(
                    'SELECT * FROM customers WHERE phone = ?',
                    [username_or_phone]
                );
                user = rows[0];
            }
            
            // If not found in customers, check admins
            if (!user) {
                const [admins] = await pool.execute(
                    'SELECT * FROM admins WHERE username = ? OR email = ?',
                    [username_or_phone, username_or_phone]
                );
                if (admins.length > 0) {
                    user = admins[0];
                    userType = 'admin';
                }
            }
            
            if (!user) {
                return res.status(404).json({ 
                    success: false, 
                    error: 'User not found' 
                });
            }
            
            // Generate reset token
            const resetToken = jwt.sign(
                { id: user.id, type: 'password_reset', role: userType },
                process.env.JWT_SECRET,
                { expiresIn: '1h' }
            );
            
            // Store token in Redis
            await setSession(`reset:${userType}:${user.id}`, resetToken, 3600);
            
            // Send SMS or Email with reset link
            const resetLink = `${process.env.FRONTEND_URL}/reset-password?token=${resetToken}&role=${userType}`;
            
            logInfo(`Password reset requested: ${user.username}`, { userId: user.id, userType });
            
            res.json({
                success: true,
                message: 'Password reset link sent to your registered phone number/email'
            });
        } catch (error) {
            logError('Forgot password error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Password reset request failed' 
            });
        }
    }
    
    /**
     * Reset password with token
     */
    static async resetPassword(req, res) {
        try {
            const { token, new_password } = req.body;
            
            // Verify token
            let decoded;
            try {
                decoded = jwt.verify(token, process.env.JWT_SECRET);
            } catch (err) {
                return res.status(400).json({ 
                    success: false, 
                    error: 'Invalid or expired token' 
                });
            }
            
            if (decoded.type !== 'password_reset') {
                return res.status(400).json({ 
                    success: false, 
                    error: 'Invalid token type' 
                });
            }
            
            // Verify token in Redis
            const storedToken = await setSession(`reset:${decoded.role}:${decoded.id}`, null, 0);
            if (!storedToken || storedToken !== token) {
                return res.status(400).json({ 
                    success: false, 
                    error: 'Token has been used or expired' 
                });
            }
            
            // Get user based on role
            let user = null;
            let table = '';
            
            if (decoded.role === 'admin') {
                const [admins] = await pool.execute(
                    'SELECT * FROM admins WHERE id = ?',
                    [decoded.id]
                );
                user = admins[0];
                table = 'admins';
            } else {
                user = await Customer.findById(decoded.id);
                table = 'customers';
            }
            
            if (!user) {
                return res.status(404).json({ 
                    success: false, 
                    error: 'User not found' 
                });
            }
            
            // Update password
            const hashedPassword = await bcrypt.hash(new_password, 10);
            await pool.execute(
                `UPDATE ${table} SET password = ? WHERE id = ?`,
                [hashedPassword, decoded.id]
            );
            
            // If customer, also update RADIUS
            if (decoded.role === 'customer') {
                await RadCheck.update(user.username, new_password);
            }
            
            // Delete reset token
            await setSession(`reset:${decoded.role}:${decoded.id}`, null, 0);
            
            logInfo(`Password reset completed: ${user.username}`, { userId: decoded.id, role: decoded.role });
            
            res.json({
                success: true,
                message: 'Password reset successfully'
            });
        } catch (error) {
            logError('Reset password error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Password reset failed' 
            });
        }
    }
}

module.exports = AuthController;