const { pool } = require('../config/database');
const { logInfo, logError } = require('../config/logger');

class DashboardController {
    /**
     * Get complete dashboard data in one API call
     */
    static async getDashboardData(req, res) {
        try {
            const adminId = req.user.id;
            
            // 1. Get customer statistics
            const [customerStats] = await pool.execute(`
                SELECT 
                    COUNT(*) as total_customers,
                    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_customers,
                    SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) as inactive_customers,
                    SUM(CASE WHEN status = 'suspended' THEN 1 ELSE 0 END) as suspended_customers
                FROM customers
            `);
            
            // 2. Get recent customers (last 5)
            const [recentCustomers] = await pool.execute(`
                SELECT c.id, c.fullname, c.username, c.phone, c.email, c.status, c.created_at,
                       p.package_name
                FROM customers c
                LEFT JOIN packages p ON c.package_id = p.id
                ORDER BY c.created_at DESC
                LIMIT 5
            `);
            
            // 3. Get payment statistics
            const [paymentStats] = await pool.execute(`
                SELECT 
                    COUNT(*) as total_payments,
                    SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END) as total_revenue,
                    SUM(CASE WHEN status = 'completed' AND DATE(created_at) = CURDATE() THEN amount ELSE 0 END) as today_revenue,
                    SUM(CASE WHEN status = 'completed' AND MONTH(created_at) = MONTH(CURDATE()) THEN amount ELSE 0 END) as month_revenue,
                    COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_payments,
                    COUNT(CASE WHEN status = 'failed' THEN 1 END) as failed_payments
                FROM payments
            `);
            
            // 4. Get recent payments (last 5)
            const [recentPayments] = await pool.execute(`
                SELECT p.id, p.amount, p.status, p.created_at, p.mpesa_receipt,
                       c.fullname, c.username, c.phone,
                       pk.package_name
                FROM payments p
                JOIN customers c ON p.customer_id = c.id
                LEFT JOIN packages pk ON p.package_id = pk.id
                ORDER BY p.created_at DESC
                LIMIT 5
            `);
            
            // 5. Get router statistics
            const [routerStats] = await pool.execute(`
                SELECT 
                    COUNT(*) as total_routers,
                    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_routers,
                    SUM(CASE WHEN connection_status = 'online' THEN 1 ELSE 0 END) as online_routers,
                    SUM(CASE WHEN connection_status = 'offline' THEN 1 ELSE 0 END) as offline_routers
                FROM routers
            `);
            
            // 6. Get active RADIUS sessions
            const [activeSessions] = await pool.execute(`
                SELECT ra.*, c.fullname, c.username,
                       TIMESTAMPDIFF(SECOND, ra.acctstarttime, NOW()) as session_seconds,
                       ROUND((ra.acctinputoctets + ra.acctoutputoctets) / (1024 * 1024), 2) as total_mb
                FROM radacct ra
                JOIN customers c ON ra.username = c.username
                WHERE ra.acctstoptime IS NULL
                ORDER BY ra.acctstarttime DESC
                LIMIT 10
            `);
            
            // 7. Get session statistics
            const [sessionStats] = await pool.execute(`
                SELECT 
                    COUNT(*) as total_sessions_today,
                    COUNT(CASE WHEN acctstoptime IS NULL THEN 1 END) as active_sessions
                FROM radacct
                WHERE DATE(acctstarttime) = CURDATE()
            `);
            
            // 8. Get all packages
            const [packages] = await pool.execute(`
                SELECT id, package_name, price, validity_days, data_limit_mb, 
                       upload_speed, download_speed, description
                FROM packages
                ORDER BY price ASC
            `);
            
            // 9. Get recent vouchers
            const [recentVouchers] = await pool.execute(`
                SELECT v.voucher_code, v.amount, v.status, v.created_at, v.expiry_date,
                       p.package_name, c.fullname as used_by_name
                FROM vouchers v
                LEFT JOIN packages p ON v.package_id = p.id
                LEFT JOIN customers c ON v.used_by = c.id
                ORDER BY v.created_at DESC
                LIMIT 5
            `);
            
            // 10. Get system health (from your existing health check)
            let systemHealth = {
                database: 'connected',
                redis: 'connected',
                radius: 'enabled'
            };
            
            try {
                const [dbCheck] = await pool.execute('SELECT 1 as connected');
                systemHealth.database = dbCheck[0].connected === 1 ? 'connected' : 'disconnected';
            } catch (err) {
                systemHealth.database = 'disconnected';
            }
            
            // Return complete dashboard data
            res.json({
                success: true,
                data: {
                    // Summary KPIs
                    summary: {
                        total_customers: customerStats[0].total_customers || 0,
                        active_customers: customerStats[0].active_customers || 0,
                        total_revenue: parseFloat(paymentStats[0].total_revenue || 0),
                        today_revenue: parseFloat(paymentStats[0].today_revenue || 0),
                        month_revenue: parseFloat(paymentStats[0].month_revenue || 0),
                        active_sessions: sessionStats[0].active_sessions || 0,
                        active_routers: routerStats[0].active_routers || 0,
                        total_routers: routerStats[0].total_routers || 0
                    },
                    
                    // Recent data tables
                    recent_customers: recentCustomers,
                    recent_payments: recentPayments,
                    recent_vouchers: recentVouchers,
                    active_sessions: activeSessions,
                    
                    // Master data
                    packages: packages,
                    
                    // Statistics
                    statistics: {
                        customers: customerStats[0],
                        payments: paymentStats[0],
                        routers: routerStats[0],
                        sessions: sessionStats[0]
                    },
                    
                    // System health
                    system_health: systemHealth,
                    
                    // Timestamp
                    last_updated: new Date().toISOString()
                }
            });
            
        } catch (error) {
            logError('Dashboard data error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to fetch dashboard data',
                message: error.message
            });
        }
    }
}

module.exports = DashboardController;
