const { pool } = require('../config/database');
const RadiusSyncService = require('../services/radiusSyncService');
const { logInfo, logError, logRadius } = require('../config/logger');
const { cacheGet, cacheSet, cacheDelete } = require('../config/redis');

class RadiusController {
    /**
     * Sync single customer to RADIUS
     */
    static async syncCustomer(req, res) {
        try {
            const { customer_id } = req.params;
            
            await RadiusSyncService.syncCustomerToRadius(customer_id);
            
            // Clear cache
            await cacheDelete(`customer:${customer_id}`);
            
            logInfo(`Customer synced to RADIUS: ${customer_id}`, { admin: req.user?.id });
            
            res.json({
                success: true,
                message: 'Customer synced to RADIUS successfully'
            });
        } catch (error) {
            logError('Sync customer error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to sync customer' 
            });
        }
    }
    
    /**
     * Bulk sync all active customers
     */
    static async bulkSync(req, res) {
        try {
            const result = await RadiusSyncService.bulkSync();
            
            logInfo(`Bulk sync completed: ${result.synced}/${result.total} customers`, {
                admin: req.user?.id
            });
            
            res.json({
                success: true,
                message: `Synced ${result.synced} of ${result.total} active customers`,
                data: result
            });
        } catch (error) {
            logError('Bulk sync error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Bulk sync failed' 
            });
        }
    }
    
    /**
     * Get active RADIUS sessions
     */
    static async getActiveSessions(req, res) {
        try {
            const [sessions] = await pool.execute(`
                SELECT ra.*, c.fullname, c.phone, c.package_id, p.package_name,
                       r.router_name, r.location as router_location,
                       TIMESTAMPDIFF(SECOND, ra.acctstarttime, NOW()) as session_seconds,
                       ROUND((ra.acctinputoctets + ra.acctoutputoctets) / (1024 * 1024), 2) as total_mb
                FROM radacct ra
                JOIN customers c ON ra.username = c.username
                LEFT JOIN packages p ON c.package_id = p.id
                LEFT JOIN routers r ON ra.nasipaddress = r.ip_address
                WHERE ra.acctstoptime IS NULL
                ORDER BY ra.acctstarttime DESC
            `);
            
            res.json({
                success: true,
                data: sessions,
                count: sessions.length
            });
        } catch (error) {
            logError('Get active sessions error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to fetch active sessions' 
            });
        }
    }
    
    /**
     * Get session history for a customer
     */
    static async getCustomerSessions(req, res) {
        try {
            const { customer_id } = req.params;
            const { limit = 50, offset = 0 } = req.query;
            
            const [sessions] = await pool.execute(`
                SELECT ra.*, r.router_name,
                       TIMESTAMPDIFF(SECOND, ra.acctstarttime, COALESCE(ra.acctstoptime, NOW())) as session_seconds,
                       ROUND((ra.acctinputoctets + ra.acctoutputoctets) / (1024 * 1024), 2) as total_mb,
                       ROUND(ra.acctinputoctets / (1024 * 1024), 2) as download_mb,
                       ROUND(ra.acctoutputoctets / (1024 * 1024), 2) as upload_mb
                FROM radacct ra
                LEFT JOIN routers r ON ra.nasipaddress = r.ip_address
                WHERE ra.username = (SELECT username FROM customers WHERE id = ?)
                ORDER BY ra.acctstarttime DESC
                LIMIT ? OFFSET ?
            `, [customer_id, parseInt(limit), parseInt(offset)]);
            
            const [total] = await pool.execute(`
                SELECT COUNT(*) as total 
                FROM radacct 
                WHERE username = (SELECT username FROM customers WHERE id = ?)
            `, [customer_id]);
            
            res.json({
                success: true,
                data: sessions,
                pagination: {
                    limit: parseInt(limit),
                    offset: parseInt(offset),
                    total: total[0].total
                }
            });
        } catch (error) {
            logError('Get customer sessions error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to fetch customer sessions' 
            });
        }
    }
    
    /**
     * Disconnect active session
     */
    static async disconnectSession(req, res) {
        try {
            const { radacctid } = req.params;
            
            // Get session details
            const [sessions] = await pool.execute(
                `SELECT ra.*, c.id as customer_id 
                 FROM radacct ra
                 JOIN customers c ON ra.username = c.username
                 WHERE ra.radacctid = ? AND ra.acctstoptime IS NULL`,
                [radacctid]
            );
            
            if (sessions.length === 0) {
                return res.status(404).json({ 
                    success: false, 
                    error: 'Active session not found' 
                });
            }
            
            const session = sessions[0];
            
            // Update radacct to mark as stopped
            await pool.execute(
                `UPDATE radacct 
                 SET acctstoptime = NOW(), 
                     acctterminatecause = 'Admin-Reset',
                     acctsessiontime = TIMESTAMPDIFF(SECOND, acctstarttime, NOW())
                 WHERE radacctid = ?`,
                [radacctid]
            );
            
            // Update router session if exists
            await pool.execute(
                `UPDATE router_sessions 
                 SET status = 'offline', logout_time = NOW()
                 WHERE customer_id = ? AND router_id = (
                     SELECT id FROM routers WHERE ip_address = ?
                 ) AND status = 'online'`,
                [session.customer_id, session.nasipaddress]
            );
            
            logRadius('Session disconnected by admin', session.username, {
                radacctid,
                admin: req.user?.id,
                nasip: session.nasipaddress
            });
            
            res.json({
                success: true,
                message: 'Session disconnected successfully',
                data: {
                    username: session.username,
                    session_time: session.acctsessiontime
                }
            });
        } catch (error) {
            logError('Disconnect session error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to disconnect session' 
            });
        }
    }
    
    /**
     * Get RADIUS statistics
     */
    static async getRadiusStats(req, res) {
        try {
            // Active sessions
            const [activeSessions] = await pool.execute(
                `SELECT COUNT(*) as active FROM radacct WHERE acctstoptime IS NULL`
            );
            
            // Today's sessions
            const [todaySessions] = await pool.execute(
                `SELECT COUNT(*) as today FROM radacct WHERE DATE(acctstarttime) = CURDATE()`
            );
            
            // Total traffic (last 30 days)
            const [traffic] = await pool.execute(`
                SELECT 
                    SUM(acctinputoctets + acctoutputoctets) as total_bytes,
                    SUM(acctinputoctets) as total_input_bytes,
                    SUM(acctoutputoctets) as total_output_bytes,
                    COUNT(*) as total_sessions
                FROM radacct
                WHERE acctstarttime >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            `);
            
            // Unique users this month
            const [uniqueUsers] = await pool.execute(`
                SELECT COUNT(DISTINCT username) as unique_users
                FROM radacct
                WHERE acctstarttime >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            `);
            
            // Average session duration
            const [avgSession] = await pool.execute(`
                SELECT AVG(acctsessiontime) as avg_seconds
                FROM radacct
                WHERE acctstoptime IS NOT NULL
                    AND acctstarttime >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            `);
            
            // Daily session stats for chart
            const [dailyStats] = await pool.execute(`
                SELECT 
                    DATE(acctstarttime) as date,
                    COUNT(*) as sessions,
                    SUM(acctinputoctets + acctoutputoctets) / (1024 * 1024 * 1024) as total_gb
                FROM radacct
                WHERE acctstarttime >= DATE_SUB(NOW(), INTERVAL 30 DAY)
                GROUP BY DATE(acctstarttime)
                ORDER BY date DESC
            `);
            
            res.json({
                success: true,
                data: {
                    active_sessions: activeSessions[0].active,
                    today_sessions: todaySessions[0].today,
                    unique_users_30d: uniqueUsers[0].unique_users,
                    total_sessions_30d: traffic[0].total_sessions,
                    total_traffic_gb: traffic[0].total_bytes ? 
                        (traffic[0].total_bytes / (1024 * 1024 * 1024)).toFixed(2) : 0,
                    avg_session_minutes: avgSession[0].avg_seconds ? 
                        Math.round(avgSession[0].avg_seconds / 60) : 0,
                    daily_stats: dailyStats
                }
            });
        } catch (error) {
            logError('Get RADIUS stats error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to fetch RADIUS statistics' 
            });
        }
    }
    
    /**
     * Update usage from RADIUS accounting
     */
    static async updateUsage(req, res) {
        try {
            await RadiusSyncService.updateUsageFromRadius();
            
            logInfo('Usage updated from RADIUS', { admin: req.user?.id });
            
            res.json({
                success: true,
                message: 'Usage data updated successfully'
            });
        } catch (error) {
            logError('Update usage error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to update usage data' 
            });
        }
    }
    
    /**
     * Get RADIUS configuration status
     */
    static async getConfigStatus(req, res) {
        try {
            // Check if radcheck table has entries
            const [radcheckCount] = await pool.execute(
                'SELECT COUNT(*) as count FROM radcheck'
            );
            
            // Check if radreply table has entries
            const [radreplyCount] = await pool.execute(
                'SELECT COUNT(*) as count FROM radreply'
            );
            
            // Check if radacct table has entries
            const [radacctCount] = await pool.execute(
                'SELECT COUNT(*) as count FROM radacct'
            );
            
            res.json({
                success: true,
                data: {
                    tables: {
                        radcheck: { exists: true, count: radcheckCount[0].count },
                        radreply: { exists: true, count: radreplyCount[0].count },
                        radacct: { exists: true, count: radacctCount[0].count }
                    },
                    sync_status: {
                        customers_in_radcheck: radcheckCount[0].count,
                        active_customers: await getActiveCustomerCount()
                    }
                }
            });
        } catch (error) {
            logError('Get config status error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to fetch RADIUS configuration status' 
            });
        }
    }
    
    /**
     * Test RADIUS authentication
     */
    static async testAuth(req, res) {
        try {
            const { username, password } = req.body;
            
            const result = await RadiusSyncService.canAuthenticate(username, password);
            
            res.json({
                success: true,
                authenticated: result,
                message: result ? 'Authentication successful' : 'Authentication failed'
            });
        } catch (error) {
            logError('Test auth error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to test authentication' 
            });
        }
    }
}

async function getActiveCustomerCount() {
    const [rows] = await pool.execute(
        "SELECT COUNT(*) as count FROM customers WHERE status = 'active'"
    );
    return rows[0].count;
}

module.exports = RadiusController;