const { pool } = require('../config/database');
const bcrypt = require('bcryptjs');
const { logInfo, logError } = require('../config/logger');

class AdminUserController {
    // Get all admin users - BASED ON ACTUAL TABLE STRUCTURE
    static async getAllAdmins(req, res) {
        try {
            // Only select columns that actually exist in your admins table
            const [admins] = await pool.execute(
                'SELECT id, email, fullname, created_at FROM admins ORDER BY id ASC'
            );
            res.json({ success: true, data: admins });
        } catch (error) {
            logError('Get admins error:', error);
            res.status(500).json({ success: false, error: 'Failed to fetch admins', message: error.message });
        }
    }
    
    // Get admin by ID
    static async getAdminById(req, res) {
        try {
            const { id } = req.params;
            const [admins] = await pool.execute(
                'SELECT id, email, fullname, created_at FROM admins WHERE id = ?',
                [id]
            );
            if (admins.length === 0) {
                return res.status(404).json({ success: false, error: 'Admin not found' });
            }
            res.json({ success: true, data: admins[0] });
        } catch (error) {
            logError('Get admin error:', error);
            res.status(500).json({ success: false, error: 'Failed to fetch admin' });
        }
    }
    
    // Create admin user
    static async createAdmin(req, res) {
        try {
            const { email, fullname, password } = req.body;
            
            if (!email || !fullname || !password) {
                return res.status(400).json({ success: false, error: 'Email, fullname and password are required' });
            }
            
            // Check if email exists
            const [existingEmail] = await pool.execute('SELECT id FROM admins WHERE email = ?', [email]);
            if (existingEmail.length > 0) {
                return res.status(400).json({ success: false, error: 'Email already exists' });
            }
            
            const hashedPassword = await bcrypt.hash(password, 10);
            const [result] = await pool.execute(
                `INSERT INTO admins (email, fullname, password) VALUES (?, ?, ?)`,
                [email, fullname, hashedPassword]
            );
            
            logInfo(`Admin user created: ${email}`, { admin: req.user.id });
            
            res.status(201).json({
                success: true,
                message: 'Admin created successfully',
                data: { id: result.insertId, email, fullname }
            });
        } catch (error) {
            logError('Create admin error:', error);
            res.status(500).json({ success: false, error: 'Failed to create admin' });
        }
    }
    
    // Update admin user
    static async updateAdmin(req, res) {
        try {
            const { id } = req.params;
            const { fullname, password } = req.body;
            
            const updates = [];
            const params = [];
            
            if (fullname !== undefined) { updates.push('fullname = ?'); params.push(fullname); }
            
            if (password) {
                const hashedPassword = await bcrypt.hash(password, 10);
                updates.push('password = ?');
                params.push(hashedPassword);
            }
            
            if (updates.length === 0) {
                return res.status(400).json({ success: false, error: 'No fields to update' });
            }
            
            params.push(id);
            await pool.execute(`UPDATE admins SET ${updates.join(', ')} WHERE id = ?`, params);
            
            logInfo(`Admin ${id} updated`, { admin: req.user.id });
            
            res.json({ success: true, message: 'Admin updated successfully' });
        } catch (error) {
            logError('Update admin error:', error);
            res.status(500).json({ success: false, error: 'Failed to update admin' });
        }
    }
    
    // Delete admin user
    static async deleteAdmin(req, res) {
        try {
            const { id } = req.params;
            
            // Prevent deleting own account (using email comparison)
            if (req.user.email) {
                const [admin] = await pool.execute('SELECT email FROM admins WHERE id = ?', [id]);
                if (admin.length > 0 && admin[0].email === req.user.email) {
                    return res.status(400).json({ success: false, error: 'Cannot delete your own account' });
                }
            }
            
            const [result] = await pool.execute('DELETE FROM admins WHERE id = ?', [id]);
            
            if (result.affectedRows === 0) {
                return res.status(404).json({ success: false, error: 'Admin not found' });
            }
            
            logInfo(`Admin ${id} deleted`, { admin: req.user.id });
            
            res.json({ success: true, message: 'Admin deleted successfully' });
        } catch (error) {
            logError('Delete admin error:', error);
            res.status(500).json({ success: false, error: 'Failed to delete admin' });
        }
    }
}

module.exports = AdminUserController;
