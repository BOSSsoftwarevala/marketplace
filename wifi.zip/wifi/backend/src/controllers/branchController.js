const { pool } = require('../config/database');
const { logInfo, logError } = require('../config/logger');

class BranchController {
    // Get all branches
    static async getAllBranches(req, res) {
        try {
            const [branches] = await pool.execute(
                'SELECT * FROM branches ORDER BY branch_name ASC'
            );
            res.json({ success: true, data: branches });
        } catch (error) {
            logError('Get branches error:', error);
            res.status(500).json({ success: false, error: 'Failed to fetch branches' });
        }
    }
    
    // Get branch by ID
    static async getBranchById(req, res) {
        try {
            const { id } = req.params;
            const [branches] = await pool.execute(
                'SELECT * FROM branches WHERE id = ?',
                [id]
            );
            if (branches.length === 0) {
                return res.status(404).json({ success: false, error: 'Branch not found' });
            }
            res.json({ success: true, data: branches[0] });
        } catch (error) {
            logError('Get branch error:', error);
            res.status(500).json({ success: false, error: 'Failed to fetch branch' });
        }
    }
    
    // Create branch
    static async createBranch(req, res) {
        try {
            const { branch_name, location, status = 'active' } = req.body;
            if (!branch_name) {
                return res.status(400).json({ success: false, error: 'Branch name is required' });
            }
            const [result] = await pool.execute(
                'INSERT INTO branches (branch_name, location, status) VALUES (?, ?, ?)',
                [branch_name, location || null, status]
            );
            logInfo(`Branch created: ${branch_name}`, { admin: req.user.id });
            res.status(201).json({
                success: true,
                message: 'Branch created successfully',
                data: { id: result.insertId, branch_name, location, status }
            });
        } catch (error) {
            logError('Create branch error:', error);
            res.status(500).json({ success: false, error: 'Failed to create branch' });
        }
    }
    
    // Update branch
    static async updateBranch(req, res) {
        try {
            const { id } = req.params;
            const { branch_name, location, status } = req.body;
            const updates = [];
            const params = [];
            if (branch_name !== undefined) { updates.push('branch_name = ?'); params.push(branch_name); }
            if (location !== undefined) { updates.push('location = ?'); params.push(location); }
            if (status !== undefined) { updates.push('status = ?'); params.push(status); }
            if (updates.length === 0) {
                return res.status(400).json({ success: false, error: 'No fields to update' });
            }
            params.push(id);
            await pool.execute(`UPDATE branches SET ${updates.join(', ')} WHERE id = ?`, params);
            logInfo(`Branch ${id} updated`, { admin: req.user.id });
            res.json({ success: true, message: 'Branch updated successfully' });
        } catch (error) {
            logError('Update branch error:', error);
            res.status(500).json({ success: false, error: 'Failed to update branch' });
        }
    }
    
    // Delete branch
    static async deleteBranch(req, res) {
        try {
            const { id } = req.params;
            const [routers] = await pool.execute(
                'SELECT COUNT(*) as count FROM routers WHERE branch_id = ?',
                [id]
            );
            if (routers[0].count > 0) {
                return res.status(400).json({ 
                    success: false, 
                    error: `Cannot delete branch with ${routers[0].count} assigned router(s)` 
                });
            }
            await pool.execute('DELETE FROM branches WHERE id = ?', [id]);
            logInfo(`Branch ${id} deleted`, { admin: req.user.id });
            res.json({ success: true, message: 'Branch deleted successfully' });
        } catch (error) {
            logError('Delete branch error:', error);
            res.status(500).json({ success: false, error: 'Failed to delete branch' });
        }
    }
}

module.exports = BranchController;
