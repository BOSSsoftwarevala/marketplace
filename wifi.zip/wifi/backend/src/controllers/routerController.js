const Router = require('../models/Router');
const { pool } = require('../config/database');
const { logInfo, logError } = require('../config/logger');
const { cacheGet, cacheSet, cacheDelete } = require('../config/redis');

class RouterController {
    /**
     * Get all routers
     */
    static async getAllRouters(req, res) {
        try {
            const routers = await Router.getAll();
            
            // Get online/offline status from Redis
            for (const router of routers) {
                const onlineUsers = await cacheGet(`router:online:${router.id}`);
                router.cached_online_users = onlineUsers || 0;
            }
            
            res.json({
                success: true,
                data: routers
            });
        } catch (error) {
            logError('Get routers error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to fetch routers' 
            });
        }
    }
    
    /**
     * Get active routers
     */
    static async getActiveRouters(req, res) {
        try {
            const routers = await Router.getActiveRouters();
            res.json({
                success: true,
                data: routers
            });
        } catch (error) {
            logError('Get active routers error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to fetch active routers' 
            });
        }
    }
    
    /**
     * Get router by ID
     */
    static async getRouterById(req, res) {
        try {
            const { id } = req.params;
            
            const cacheKey = `router:${id}`;
            let router = await cacheGet(cacheKey);
            
            if (!router) {
                router = await Router.findById(id);
                if (!router) {
                    return res.status(404).json({ 
                        success: false, 
                        error: 'Router not found' 
                    });
                }
                await cacheSet(cacheKey, router, 300);
            }
            
            // Get statistics
            const stats = await Router.getRouterStats(id);
            const heartbeats = await Router.getHeartbeatHistory(id, 24);
            
            // Get online users from Redis
            const onlineUsers = await cacheGet(`router:online:${id}`) || 0;
            
            res.json({
                success: true,
                data: {
                    ...router,
                    stats,
                    heartbeats,
                    online_users_cache: onlineUsers
                }
            });
        } catch (error) {
            logError('Get router error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to fetch router' 
            });
        }
    }
    
    /**
     * Create new router
     */
    static async createRouter(req, res) {
        try {
            const { router_name, router_code, ip_address, mac_address, location, 
                    api_username, api_password, branch_id } = req.body;
            
            if (!router_name || !router_code || !ip_address) {
                return res.status(400).json({ 
                    success: false, 
                    error: 'Router name, code and IP address are required' 
                });
            }
            
            const routerId = await Router.create({
                router_name, router_code, ip_address, mac_address, location,
                api_username, api_password, branch_id
            });
            
            // Clear cache
            await cacheDelete('routers:all');
            
            logInfo(`Router created: ${router_name}`, { routerId, admin: req.user.id });
            
            res.status(201).json({
                success: true,
                message: 'Router created successfully',
                data: { id: routerId, router_name, router_code }
            });
        } catch (error) {
            logError('Create router error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to create router' 
            });
        }
    }
    
    /**
     * Update router
     */
    static async updateRouter(req, res) {
        try {
            const { id } = req.params;
            const updates = [];
            const params = [];
            
            const router = await Router.findById(id);
            if (!router) {
                return res.status(404).json({ 
                    success: false, 
                    error: 'Router not found' 
                });
            }
            
            const fields = ['router_name', 'router_code', 'ip_address', 'mac_address', 
                           'location', 'api_username', 'api_password', 'branch_id', 'status'];
            
            for (const field of fields) {
                if (req.body[field] !== undefined) {
                    updates.push(`${field} = ?`);
                    params.push(req.body[field]);
                }
            }
            
            if (updates.length > 0) {
                params.push(id);
                await pool.execute(
                    `UPDATE routers SET ${updates.join(', ')} WHERE id = ?`,
                    params
                );
            }
            
            // Clear cache
            await cacheDelete(`router:${id}`);
            await cacheDelete('routers:all');
            
            logInfo(`Router updated: ${router.router_name}`, { routerId: id, admin: req.user.id });
            
            res.json({
                success: true,
                message: 'Router updated successfully'
            });
        } catch (error) {
            logError('Update router error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to update router' 
            });
        }
    }
    
    /**
     * Update router status
     */
    static async updateRouterStatus(req, res) {
        try {
            const { id } = req.params;
            const { status } = req.body;
            
            if (!['active', 'inactive', 'maintenance'].includes(status)) {
                return res.status(400).json({ 
                    success: false, 
                    error: 'Invalid status' 
                });
            }
            
            const router = await Router.findById(id);
            if (!router) {
                return res.status(404).json({ 
                    success: false, 
                    error: 'Router not found' 
                });
            }
            
            await Router.updateStatus(id, status);
            
            // Clear cache
            await cacheDelete(`router:${id}`);
            await cacheDelete('routers:all');
            
            logInfo(`Router status updated: ${router.router_name} -> ${status}`, { routerId: id });
            
            res.json({
                success: true,
                message: `Router status updated to ${status}`
            });
        } catch (error) {
            logError('Update router status error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to update router status' 
            });
        }
    }
    
    /**
     * Receive heartbeat from router
     */
    static async heartbeat(req, res) {
        try {
            const { router_code } = req.params;
            const { cpu_usage, ram_usage, online_users, upload_mbps, download_mbps, status } = req.body;
            
            // Find router by code
            const router = await Router.findByCode(router_code);
            if (!router) {
                return res.status(404).json({ 
                    success: false, 
                    error: 'Router not found' 
                });
            }
            
            // Add heartbeat record
            await Router.addHeartbeat(router.id, {
                cpu_usage,
                ram_usage,
                online_users: online_users || 0,
                upload_mbps,
                download_mbps
            });
            
            // Update online users in Redis
            await cacheSet(`router:online:${router.id}`, online_users || 0, 600);
            
            // Update connection status
            await Router.updateConnectionStatus(router.id, status === 'online' ? 'online' : 'offline', online_users);
            
            // Clear cache
            await cacheDelete(`router:${router.id}`);
            
            res.json({
                success: true,
                message: 'Heartbeat received'
            });
        } catch (error) {
            logError('Heartbeat error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to process heartbeat' 
            });
        }
    }
    
    /**
     * Get router heartbeat history
     */
    static async getHeartbeatHistory(req, res) {
        try {
            const { id } = req.params;
            const { limit = 24 } = req.query;
            
            const heartbeats = await Router.getHeartbeatHistory(id, parseInt(limit));
            
            res.json({
                success: true,
                data: heartbeats
            });
        } catch (error) {
            logError('Get heartbeat history error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to fetch heartbeat history' 
            });
        }
    }
    
    /**
     * Get router statistics
     */
    static async getRouterStats(req, res) {
        try {
            const { id } = req.params;
            
            const stats = await Router.getRouterStats(id);
            
            // Get user sessions per router
            const [sessions] = await pool.execute(`
                SELECT 
                    COUNT(*) as total_sessions,
                    COUNT(CASE WHEN status = 'online' THEN 1 END) as active_sessions,
                    SUM(upload_mb) as total_upload_mb,
                    SUM(download_mb) as total_download_mb
                FROM router_sessions
                WHERE router_id = ?
            `, [id]);
            
            // Get bandwidth usage over time
            const [bandwidth] = await pool.execute(`
                SELECT 
                    DATE(heartbeat_time) as date,
                    HOUR(heartbeat_time) as hour,
                    AVG(upload_mbps) as avg_upload,
                    AVG(download_mbps) as avg_download
                FROM router_heartbeats
                WHERE router_id = ? AND heartbeat_time >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                GROUP BY DATE(heartbeat_time), HOUR(heartbeat_time)
                ORDER BY date DESC, hour DESC
            `, [id]);
            
            res.json({
                success: true,
                data: {
                    ...stats,
                    sessions: sessions[0],
                    bandwidth_history: bandwidth
                }
            });
        } catch (error) {
            logError('Get router stats error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to fetch router statistics' 
            });
        }
    }
    
    /**
     * Delete router
     */
    static async deleteRouter(req, res) {
        try {
            const { id } = req.params;
            
            const router = await Router.findById(id);
            if (!router) {
                return res.status(404).json({ 
                    success: false, 
                    error: 'Router not found' 
                });
            }
            
            // Check if router has active sessions
            const [sessions] = await pool.execute(
                `SELECT COUNT(*) as count FROM router_sessions WHERE router_id = ? AND status = 'online'`,
                [id]
            );
            
            if (sessions[0].count > 0) {
                return res.status(400).json({ 
                    success: false, 
                    error: 'Cannot delete router with active sessions' 
                });
            }
            
            // Delete router and related data
            await pool.execute('DELETE FROM router_heartbeats WHERE router_id = ?', [id]);
            await pool.execute('DELETE FROM router_sessions WHERE router_id = ?', [id]);
            await pool.execute('DELETE FROM customer_router_access WHERE router_id = ?', [id]);
            await pool.execute('DELETE FROM routers WHERE id = ?', [id]);
            
            // Clear cache
            await cacheDelete(`router:${id}`);
            await cacheDelete('routers:all');
            
            logInfo(`Router deleted: ${router.router_name}`, { routerId: id, admin: req.user.id });
            
            res.json({
                success: true,
                message: 'Router deleted successfully'
            });
        } catch (error) {
            logError('Delete router error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to delete router' 
            });
        }
    }
    
    /**
     * Call MikroTik API endpoint
     */
    static async callMikrotikAPI(req, res) {
        try {
            const { id } = req.params;
            const { endpoint, method = 'GET', data } = req.body;
            
            const result = await Router.callMikrotikAPI(id, endpoint, method, data);
            
            res.json({
                success: true,
                data: result
            });
        } catch (error) {
            logError('MikroTik API call error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to call MikroTik API',
                details: error.message
            });
        }
    }
    
    /**
     * Disconnect user from router
     */
    static async disconnectUser(req, res) {
        try {
            const { id, username } = req.params;
            
            await Router.disconnectUser(id, username);
            
            // Update session status
            await pool.execute(
                `UPDATE router_sessions 
                 SET status = 'offline', logout_time = NOW()
                 WHERE router_id = ? AND customer_id = (SELECT id FROM customers WHERE username = ?)
                 AND status = 'online'`,
                [id, username]
            );
            
            logInfo(`User disconnected from router: ${username}`, { routerId: id });
            
            res.json({
                success: true,
                message: `User ${username} disconnected successfully`
            });
        } catch (error) {
            logError('Disconnect user error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to disconnect user' 
            });
        }
    }
}

module.exports = RouterController;