const MpesaService = require('../services/mpesaService');
const Customer = require('../models/Customer');
const Package = require('../models/Package');
const RadiusSyncService = require('../services/radiusSyncService');
const { pool } = require('../config/database');
const { logInfo, logError, logMpesa } = require('../config/logger');
const { cacheDelete } = require('../config/redis');

class PaymentController {
    /**
     * Initiate M-Pesa STK Push payment
     */
    static async initiateMpesaPayment(req, res) {
        try {
            const { customer_id, package_id, phone } = req.body;
            
            // Get customer and package details
            const customer = await Customer.findById(customer_id);
            const package_ = await Package.findById(package_id);
            
            if (!customer) {
                return res.status(404).json({ 
                    success: false, 
                    error: 'Customer not found' 
                });
            }
            
            if (!package_) {
                return res.status(404).json({ 
                    success: false, 
                    error: 'Package not found' 
                });
            }
            
            // Format phone number
            const mpesa = new MpesaService();
            const formattedPhone = mpesa.formatPhoneNumber(phone || customer.phone);
            
            // Create pending payment record
            const [result] = await pool.execute(
                `INSERT INTO payments (customer_id, phone, amount, package_id, status)
                 VALUES (?, ?, ?, ?, 'pending')`,
                [customer_id, formattedPhone, package_.price, package_id]
            );
            
            const paymentId = result.insertId;
            
            // Initiate STK Push
            const accountReference = `WIFI${customer_id}${Date.now()}`;
            const transactionDesc = `${package_.package_name} - ${package_.validity_days} days`;
            
            logMpesa('STK Push Initiated', 'pending', {
                paymentId,
                customer: customer.username,
                amount: package_.price,
                phone: formattedPhone
            });
            
            const stkResponse = await mpesa.stkPush(
                formattedPhone,
                package_.price,
                accountReference,
                transactionDesc
            );
            
            // Store transaction reference
            await pool.execute(
                `UPDATE payments SET mpesa_receipt = ? WHERE id = ?`,
                [stkResponse.CheckoutRequestID, paymentId]
            );
            
            res.json({
                success: true,
                message: 'STK Push sent. Please check your phone and enter PIN.',
                data: {
                    checkoutRequestId: stkResponse.CheckoutRequestID,
                    paymentId: paymentId,
                    merchantRequestId: stkResponse.MerchantRequestID,
                    amount: package_.price,
                    phone: formattedPhone
                }
            });
        } catch (error) {
            logError('Payment initiation error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to initiate payment. Please try again.' 
            });
        }
    }
    
    /**
     * M-Pesa STK Push callback handler
     */
    static async mpesaCallback(req, res) {
        try {
            const { Body } = req.body;
            
            if (!Body || !Body.stkCallback) {
                logError('Invalid M-Pesa callback received', null, { body: req.body });
                return res.status(400).json({ ResultCode: 1, ResultDesc: 'Invalid callback data' });
            }
            
            const { stkCallback } = Body;
            const {
                MerchantRequestID,
                CheckoutRequestID,
                ResultCode,
                ResultDesc,
                CallbackMetadata
            } = stkCallback;
            
            logMpesa('STK Push Callback Received', ResultCode === 0 ? 'success' : 'failed', {
                CheckoutRequestID,
                ResultCode,
                ResultDesc
            });
            
            // Update payment record with callback result
            let mpesaReceipt = null;
            let amount = 0;
            let phone = null;
            
            if (ResultCode === 0 && CallbackMetadata) {
                const items = CallbackMetadata.Item;
                for (const item of items) {
                    if (item.Name === 'MpesaReceiptNumber') mpesaReceipt = item.Value;
                    if (item.Name === 'Amount') amount = item.Value;
                    if (item.Name === 'PhoneNumber') phone = item.Value;
                }
            }
            
            // Find payment by CheckoutRequestID
            const [payments] = await pool.execute(
                `SELECT p.*, c.username, c.id as customer_id, c.status
                 FROM payments p
                 JOIN customers c ON p.customer_id = c.id
                 WHERE p.mpesa_receipt = ? AND p.status = 'pending'`,
                [CheckoutRequestID]
            );
            
            if (payments.length === 0) {
                logError('Payment not found for callback', null, { CheckoutRequestID });
                return res.json({ ResultCode: 0, ResultDesc: 'Success' });
            }
            
            const payment = payments[0];
            
            if (ResultCode === 0 && mpesaReceipt) {
                // Payment successful
                await pool.execute(
                    `UPDATE payments 
                     SET status = 'completed', 
                         mpesa_receipt = ?,
                         transaction_date = NOW()
                     WHERE id = ?`,
                    [mpesaReceipt, payment.id]
                );
                
                // Update M-Pesa transaction record
                await pool.execute(
                    `INSERT INTO mpesa_transactions 
                     (checkout_request_id, merchant_request_id, phone, amount, mpesa_receipt, 
                      result_code, result_desc, transaction_date)
                     VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
                    [CheckoutRequestID, MerchantRequestID, phone, amount, mpesaReceipt, 
                     ResultCode, ResultDesc, new Date()]
                );
                
                // Activate customer if not already active
                if (payment.status !== 'active') {
                    await Customer.updateStatus(payment.customer_id, 'active');
                    
                    // Sync to RADIUS
                    await RadiusSyncService.syncCustomerToRadius(payment.customer_id);
                    
                    logInfo(`Customer activated after payment: ${payment.username}`, {
                        customerId: payment.customer_id,
                        amount,
                        receipt: mpesaReceipt
                    });
                }
                
                // Clear cache
                await cacheDelete(`customer:${payment.customer_id}`);
                
                // Emit WebSocket event
                const io = req.app.get('io');
                io.to(`user_${payment.customer_id}`).emit('payment_completed', {
                    success: true,
                    amount,
                    receipt: mpesaReceipt,
                    package_id: payment.package_id
                });
                
            } else {
                // Payment failed
                await pool.execute(
                    `UPDATE payments SET status = 'failed', result_desc = ? WHERE id = ?`,
                    [ResultDesc, payment.id]
                );
                
                logMpesa('Payment Failed', 'failed', {
                    paymentId: payment.id,
                    customer: payment.username,
                    resultCode: ResultCode,
                    resultDesc: ResultDesc
                });
            }
            
            // Always respond with success to M-Pesa
            res.json({ ResultCode: 0, ResultDesc: 'Success' });
            
        } catch (error) {
            logError('M-Pesa callback processing error:', error);
            res.json({ ResultCode: 0, ResultDesc: 'Success' }); // Still respond success to M-Pesa
        }
    }
    
    /**
     * Check payment status
     */
    static async checkPaymentStatus(req, res) {
        try {
            const { checkoutRequestId } = req.params;
            
            // Check local database first
            const [transactions] = await pool.execute(
                `SELECT * FROM mpesa_transactions WHERE checkout_request_id = ?`,
                [checkoutRequestId]
            );
            
            if (transactions.length > 0) {
                return res.json({
                    success: true,
                    status: transactions[0].result_code === 0 ? 'completed' : 'failed',
                    transaction: transactions[0]
                });
            }
            
            // Query M-Pesa API for status
            const mpesa = new MpesaService();
            const status = await mpesa.queryStatus(checkoutRequestId);
            
            res.json({
                success: true,
                status: status.ResultCode === 0 ? 'pending' : 'failed',
                data: status
            });
        } catch (error) {
            logError('Check payment status error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to check payment status' 
            });
        }
    }
    
    /**
     * Get payment history for customer
     */
    static async getPaymentHistory(req, res) {
        try {
            const { customer_id } = req.params;
            const { limit = 50, offset = 0 } = req.query;
            
            const [payments] = await pool.execute(
                `SELECT p.*, pk.package_name, pk.validity_days, pk.data_limit_mb,
                        pk.upload_speed, pk.download_speed
                 FROM payments p
                 JOIN packages pk ON p.package_id = pk.id
                 WHERE p.customer_id = ?
                 ORDER BY p.created_at DESC
                 LIMIT ? OFFSET ?`,
                [customer_id, parseInt(limit), parseInt(offset)]
            );
            
            const [total] = await pool.execute(
                `SELECT COUNT(*) as total FROM payments WHERE customer_id = ?`,
                [customer_id]
            );
            
            res.json({
                success: true,
                data: payments,
                pagination: {
                    limit: parseInt(limit),
                    offset: parseInt(offset),
                    total: total[0].total
                }
            });
        } catch (error) {
            logError('Get payment history error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to fetch payment history' 
            });
        }
    }
    
    /**
     * Process voucher payment
     */
    static async processVoucherPayment(req, res) {
        try {
            const { customer_id, voucher_code } = req.body;
            
            // Find voucher
            const [vouchers] = await pool.execute(
                `SELECT v.*, p.package_name, p.price, p.validity_days, p.data_limit_mb,
                        p.upload_speed, p.download_speed
                 FROM vouchers v
                 JOIN packages p ON v.package_id = p.id
                 WHERE v.voucher_code = ? AND v.status = 'unused'`,
                [voucher_code]
            );
            
            if (vouchers.length === 0) {
                return res.status(404).json({ 
                    success: false, 
                    error: 'Invalid or already used voucher code' 
                });
            }
            
            const voucher = vouchers[0];
            
            // Check if voucher expired
            if (voucher.expiry_date && new Date(voucher.expiry_date) < new Date()) {
                await pool.execute(
                    `UPDATE vouchers SET status = 'expired' WHERE id = ?`,
                    [voucher.id]
                );
                return res.status(400).json({ 
                    success: false, 
                    error: 'Voucher has expired' 
                });
            }
            
            // Create payment record
            const [result] = await pool.execute(
                `INSERT INTO payments (customer_id, phone, amount, package_id, mpesa_receipt, status, transaction_date)
                 VALUES (?, (SELECT phone FROM customers WHERE id = ?), ?, ?, ?, 'completed', NOW())`,
                [customer_id, customer_id, voucher.price, voucher.package_id, `VOUCHER-${voucher_code}`]
            );
            
            // Mark voucher as used
            await pool.execute(
                `UPDATE vouchers SET status = 'used', used_by = ? WHERE id = ?`,
                [customer_id, voucher.id]
            );
            
            // Activate customer
            await Customer.updateStatus(customer_id, 'active');
            
            // Sync to RADIUS
            await RadiusSyncService.syncCustomerToRadius(customer_id);
            
            // Clear cache
            await cacheDelete(`customer:${customer_id}`);
            
            logInfo(`Voucher payment processed: ${voucher_code}`, {
                customerId: customer_id,
                voucherId: voucher.id,
                amount: voucher.price
            });
            
            res.json({
                success: true,
                message: 'Voucher redeemed successfully',
                data: {
                    package: voucher.package_name,
                    validity_days: voucher.validity_days,
                    speed: `${voucher.upload_speed}/${voucher.download_speed}`
                }
            });
        } catch (error) {
            logError('Process voucher error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to process voucher' 
            });
        }
    }
    
    /**
     * Get payment statistics (admin)
     */
    static async getPaymentStats(req, res) {
        try {
            const { period = 'month' } = req.query;
            
            let dateCondition = '';
            if (period === 'today') {
                dateCondition = 'AND DATE(created_at) = CURDATE()';
            } else if (period === 'week') {
                dateCondition = 'AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)';
            } else if (period === 'month') {
                dateCondition = 'AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)';
            } else if (period === 'year') {
                dateCondition = 'AND created_at >= DATE_SUB(NOW(), INTERVAL 1 YEAR)';
            }
            
            const [stats] = await pool.execute(`
                SELECT 
                    COUNT(*) as total_transactions,
                    SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END) as total_amount,
                    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_count,
                    SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed_count,
                    AVG(CASE WHEN status = 'completed' THEN amount ELSE NULL END) as avg_amount,
                    MAX(CASE WHEN status = 'completed' THEN amount ELSE NULL END) as max_amount
                FROM payments
                WHERE status != 'pending'
                ${dateCondition}
            `);
            
            // Get daily payments for chart
            const [dailyPayments] = await pool.execute(`
                SELECT 
                    DATE(created_at) as date,
                    COUNT(*) as count,
                    SUM(amount) as total
                FROM payments
                WHERE status = 'completed'
                    AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
                GROUP BY DATE(created_at)
                ORDER BY date DESC
            `);
            
            // Get payment methods breakdown
            const [paymentMethods] = await pool.execute(`
                SELECT 
                    CASE 
                        WHEN mpesa_receipt LIKE 'VOUCHER-%' THEN 'voucher'
                        WHEN mpesa_receipt IS NOT NULL AND mpesa_receipt != '' THEN 'mpesa'
                        ELSE 'other'
                    END as method,
                    COUNT(*) as count,
                    SUM(amount) as total
                FROM payments
                WHERE status = 'completed'
                GROUP BY method
            `);
            
            res.json({
                success: true,
                data: {
                    summary: stats[0],
                    daily: dailyPayments,
                    methods: paymentMethods
                }
            });
        } catch (error) {
            logError('Get payment stats error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to fetch payment statistics' 
            });
        }
    }
    
    /**
     * Initiate refund (admin)
     */
    static async initiateRefund(req, res) {
        try {
            const { payment_id, reason } = req.body;
            
            const [payments] = await pool.execute(
                `SELECT p.*, c.phone, c.username 
                 FROM payments p
                 JOIN customers c ON p.customer_id = c.id
                 WHERE p.id = ? AND p.status = 'completed'`,
                [payment_id]
            );
            
            if (payments.length === 0) {
                return res.status(404).json({ 
                    success: false, 
                    error: 'Payment not found or not completed' 
                });
            }
            
            const payment = payments[0];
            
            // Initiate B2C refund
            const mpesa = new MpesaService();
            const refundResult = await mpesa.b2cPayment(
                payment.phone,
                payment.amount,
                'BusinessPayment',
                `Refund for payment ${payment.id}: ${reason}`
            );
            
            // Update payment status
            await pool.execute(
                `UPDATE payments SET status = 'refunded' WHERE id = ?`,
                [payment_id]
            );
            
            // Deactivate customer if needed
            if (payment.customer_id) {
                await Customer.updateStatus(payment.customer_id, 'inactive');
                await cacheDelete(`customer:${payment.customer_id}`);
            }
            
            logInfo(`Refund initiated for payment ${payment_id}`, {
                amount: payment.amount,
                customer: payment.username,
                reason
            });
            
            res.json({
                success: true,
                message: 'Refund initiated successfully',
                data: refundResult
            });
        } catch (error) {
            logError('Initiate refund error:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to initiate refund' 
            });
        }
    }
}

module.exports = PaymentController;