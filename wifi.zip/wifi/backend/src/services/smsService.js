const axios = require('axios');
const { logInfo, logError } = require('../config/logger');
const { redisClient, rateLimitCheck } = require('../config/redis');

class SmsService {
    constructor() {
        this.apiKey = process.env.SMS_API_KEY;
        this.username = process.env.SMS_USERNAME;
        this.senderId = process.env.SMS_SENDER_ID || 'WIFI-BILLING';
        this.environment = process.env.NODE_ENV || 'development';
        
        // Africa's Talking API
        this.baseUrl = this.environment === 'production'
            ? 'https://api.africastalking.com/version1'
            : 'https://api.sandbox.africastalking.com/version1';
    }
    
    /**
     * Send SMS message
     */
    async sendSms(phoneNumber, message) {
        // Format phone number (remove leading 0, add 254)
        let formattedPhone = phoneNumber.toString().replace(/\D/g, '');
        if (formattedPhone.startsWith('0')) {
            formattedPhone = '254' + formattedPhone.substring(1);
        }
        
        // Rate limiting per phone number
        const rateLimitKey = `sms:ratelimit:${formattedPhone}`;
        const rateCheck = await rateLimitCheck(rateLimitKey, 10, 3600); // 10 SMS per hour
        
        if (!rateCheck.allowed) {
            logError(`SMS rate limit exceeded for ${formattedPhone}`);
            throw new Error('SMS rate limit exceeded. Please try again later.');
        }
        
        try {
            const response = await axios.post(
                `${this.baseUrl}/messaging`,
                new URLSearchParams({
                    username: this.username,
                    to: formattedPhone,
                    message: message.substring(0, 160), // Max 160 characters
                    from: this.senderId
                }),
                {
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'apiKey': this.apiKey
                    },
                    timeout: 30000
                }
            );
            
            logInfo(`SMS sent to ${formattedPhone}`, {
                messageLength: message.length,
                response: response.data
            });
            
            return {
                success: true,
                messageId: response.data.SMSMessageData?.Recipients?.[0]?.messageId,
                status: response.data.SMSMessageData?.Recipients?.[0]?.status
            };
        } catch (error) {
            logError(`SMS send failed for ${formattedPhone}:`, error);
            throw new Error(`SMS failed: ${error.response?.data?.error || error.message}`);
        }
    }
    
    /**
     * Send payment confirmation SMS
     */
    async sendPaymentConfirmation(phoneNumber, customerName, amount, packageName, validityDays, receipt) {
        const message = `Dear ${customerName}, your payment of KES ${amount} for ${packageName} package has been received. Your internet is active for ${validityDays} days. Receipt: ${receipt}. Thank you for choosing us!`;
        
        return await this.sendSms(phoneNumber, message);
    }
    
    /**
     * Send voucher redemption SMS
     */
    async sendVoucherRedemptionSms(phoneNumber, customerName, packageName, validityDays) {
        const message = `Dear ${customerName}, your voucher for ${packageName} has been redeemed successfully. Your internet is active for ${validityDays} days. Thank you!`;
        
        return await this.sendSms(phoneNumber, message);
    }
    
    /**
     Send expiry warning SMS
     */
    async sendExpiryWarning(phoneNumber, customerName, daysRemaining) {
        const message = `Dear ${customerName}, your internet package will expire in ${daysRemaining} day(s). Please renew to avoid interruption. Visit our portal to recharge.`;
        
        return await this.sendSms(phoneNumber, message);
    }
    
    /**
     * Send data limit warning SMS
     */
    async sendDataLimitWarning(phoneNumber, customerName, usedPercent) {
        const message = `Dear ${customerName}, you have used ${usedPercent}% of your data limit. Please upgrade your package to continue enjoying uninterrupted service.`;
        
        return await this.sendSms(phoneNumber, message);
    }
    
    /**
     * Send welcome SMS
     */
    async sendWelcomeSms(phoneNumber, customerName, username, password) {
        const message = `Welcome ${customerName}! Your WiFi account has been created. Username: ${username}, Password: ${password}. Please login to complete payment and activate your internet.`;
        
        return await this.sendSms(phoneNumber, message);
    }
    
    /**
     * Send account activation SMS
     */
    async sendAccountActivationSms(phoneNumber, customerName, username, password) {
        const message = `Dear ${customerName}, your account has been activated! Username: ${username}, Password: ${password}. You can now connect to our WiFi network.`;
        
        return await this.sendSms(phoneNumber, message);
    }
    
    /**
     * Send password reset SMS
     */
    async sendPasswordResetSms(phoneNumber, customerName, resetCode) {
        const message = `Dear ${customerName}, your password reset code is: ${resetCode}. This code expires in 1 hour. If you didn't request this, please ignore.`;
        
        return await this.sendSms(phoneNumber, message);
    }
    
    /**
     * Send low balance alert to reseller
     */
    async sendLowBalanceAlert(phoneNumber, resellerName, currentBalance) {
        const message = `Dear ${resellerName}, your balance is low: KES ${currentBalance}. Please top up to continue generating vouchers.`;
        
        return await this.sendSms(phoneNumber, message);
    }
    
    /**
     * Send commission payment notification
     */
    async sendCommissionPaymentSms(phoneNumber, resellerName, amount) {
        const message = `Dear ${resellerName}, KES ${amount} has been deposited to your account as commission payment. Thank you for your partnership!`;
        
        return await this.sendSms(phoneNumber, message);
    }
    
    /**
     * Send bulk SMS (with rate limiting)
     */
    async sendBulkSms(recipients, message, batchSize = 50) {
        const results = [];
        
        for (let i = 0; i < recipients.length; i += batchSize) {
            const batch = recipients.slice(i, i + batchSize);
            const batchPromises = batch.map(recipient => 
                this.sendSms(recipient.phone, message)
                    .then(result => ({ ...recipient, success: true, result }))
                    .catch(error => ({ ...recipient, success: false, error: error.message }))
            );
            
            const batchResults = await Promise.all(batchPromises);
            results.push(...batchResults);
            
            // Delay between batches to avoid rate limiting
            if (i + batchSize < recipients.length) {
                await new Promise(resolve => setTimeout(resolve, 1000));
            }
        }
        
        const successful = results.filter(r => r.success).length;
        const failed = results.filter(r => !r.success).length;
        
        logInfo(`Bulk SMS completed: ${successful} sent, ${failed} failed`);
        
        return { results, successful, failed };
    }
    
    /**
     * Check SMS balance
     */
    async getBalance() {
        try {
            const response = await axios.get(
                `${this.baseUrl}/messaging/balance`,
                {
                    headers: {
                        'apiKey': this.apiKey
                    },
                    timeout: 10000
                }
            );
            
            return {
                success: true,
                balance: response.data.balance
            };
        } catch (error) {
            logError('Failed to get SMS balance:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }
}

module.exports = SmsService;