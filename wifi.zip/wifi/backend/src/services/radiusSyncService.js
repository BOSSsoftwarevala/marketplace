const Customer = require('../models/Customer');
const RadCheck = require('../models/RadCheck');
const RadReply = require('../models/RadReply');
const Package = require('../models/Package');
const { pool } = require('../config/database');
const { logInfo, logError, logRadius } = require('../config/logger');
const { redisClient, cacheDelete } = require('../config/redis');

class RadiusSyncService {
    /**
     * Sync a single customer to FreeRADIUS tables
     */
    static async syncCustomerToRadius(customerId) {
        const customer = await Customer.findById(customerId);
        if (!customer) {
            throw new Error('Customer not found');
        }
        
        const package_ = await Package.findById(customer.package_id);
        
        logRadius('Syncing customer to RADIUS', customer.username, { customerId });
        
        // Sync radcheck (authentication)
        await RadCheck.create(customer.username, customer.password);
        await RadCheck.updateStatus(customer.username, customer.status);
        
        // Sync radreply (authorization - speed limits and timeouts)
        if (package_) {
            // Set speed limits
            await RadReply.setSpeedLimit(
                customer.username,
                package_.upload_speed || '1M',
                package_.download_speed || '1M'
            );
            
            // Set session timeout (validity period in seconds)
            if (package_.validity_days) {
                const timeoutSeconds = package_.validity_days * 24 * 60 * 60;
                await RadReply.setSessionTimeout(customer.username, timeoutSeconds);
            }
            
            // Set idle timeout (default 5 minutes)
            await RadReply.setIdleTimeout(customer.username, 300);
        }
        
        // Clear cache
        await cacheDelete(`radius:limits:${customer.username}`);
        
        logRadius('Customer synced to RADIUS successfully', customer.username);
        
        return true;
    }
    
    /**
     * Check if customer can authenticate (for FreeRADIUS)
     */
    static async canAuthenticate(username, password, nasIpAddress = null) {
        const customer = await Customer.findByUsername(username);
        
        if (!customer) {
            logRadius('Authentication failed - user not found', username);
            return false;
        }
        
        // Check password
        const bcrypt = require('bcryptjs');
        const isValidPassword = await bcrypt.compare(password, customer.password);
        if (!isValidPassword) {
            logRadius('Authentication failed - invalid password', username);
            return false;
        }
        
        // Check status
        if (customer.status !== 'active') {
            logRadius(`Authentication failed - account ${customer.status}`, username);
            return false;
        }
        
        // Check if package expired
        const createdAt = new Date(customer.created_at);
        const expiryDate = new Date(createdAt);
        expiryDate.setDate(expiryDate.getDate() + customer.validity_days);
        
        if (new Date() > expiryDate) {
            await Customer.updateStatus(customer.id, 'inactive');
            await RadCheck.updateStatus(username, 'inactive');
            logRadius('Authentication failed - package expired', username);
            return false;
        }
        
        // Check data limit
        const usage = await Customer.getCustomerUsage(customer.id);
        if (customer.data_limit_mb > 0 && usage.total_mb >= customer.data_limit_mb) {
            await Customer.updateStatus(customer.id, 'suspended');
            await RadCheck.updateStatus(username, 'suspended');
            logRadius('Authentication failed - data limit exceeded', username, { used: usage.total_mb, limit: customer.data_limit_mb });
            return false;
        }
        
        // Check router access if NAS IP provided
        if (nasIpAddress) {
            const [router] = await pool.execute(
                'SELECT id FROM routers WHERE ip_address = ?',
                [nasIpAddress]
            );
            
            if (router.length > 0) {
                const canAccess = await Customer.canAccessRouter(customer.id, router[0].id);
                if (!canAccess) {
                    logRadius('Authentication failed - router access denied', username, { nasIp: nasIpAddress });
                    return false;
                }
            }
        }
        
        logRadius('Authentication successful', username);
        return true;
    }
    
    /**
     * Get RADIUS reply attributes for a user
     */
    static async getRadiusAttributes(username) {
        const customer = await Customer.findByUsername(username);
        
        if (!customer || customer.status !== 'active') {
            return null;
        }
        
        const limits = await RadReply.getCustomerLimits(username);
        
        return {
            'Mikrotik-Rate-Limit': `${limits.upload_speed}/${limits.download_speed}`,
            'Session-Timeout': limits.session_timeout.toString(),
            'Idle-Timeout': limits.idle_timeout.toString()
        };
    }
    
    /**
     * Update customer usage from RADIUS accounting
     */
    static async updateUsageFromRadius() {
        // Get all active sessions with their usage
        const [sessions] = await pool.execute(`
            SELECT 
                username,
                SUM(acctinputoctets) as total_input,
                SUM(acctoutputoctets) as total_output,
                SUM(acctsessiontime) as total_time,
                COUNT(*) as session_count
            FROM radacct
            WHERE acctstoptime IS NULL
            GROUP BY username
        `);
        
        let updated = 0;
        
        for (const session of sessions) {
            const customer = await Customer.findByUsername(session.username);
            if (customer) {
                const uploadMb = Math.floor((session.total_output || 0) / (1024 * 1024));
                const downloadMb = Math.floor((session.total_input || 0) / (1024 * 1024));
                const totalMb = uploadMb + downloadMb;
                
                await pool.execute(`
                    INSERT INTO customer_usage (customer_id, upload_mb, download_mb, total_mb, session_time, last_update)
                    VALUES (?, ?, ?, ?, ?, NOW())
                    ON DUPLICATE KEY UPDATE
                    upload_mb = VALUES(upload_mb),
                    download_mb = VALUES(download_mb),
                    total_mb = VALUES(total_mb),
                    session_time = VALUES(session_time),
                    last_update = NOW()
                `, [customer.id, uploadMb, downloadMb, totalMb, session.total_time || 0]);
                
                // Check if data limit exceeded
                const package_ = await Package.findById(customer.package_id);
                if (package_ && package_.data_limit_mb > 0 && totalMb >= package_.data_limit_mb) {
                    await Customer.updateStatus(customer.id, 'suspended');
                    await RadCheck.updateStatus(session.username, 'suspended');
                    logRadius('Customer suspended - data limit exceeded', session.username, { used: totalMb, limit: package_.data_limit_mb });
                }
                
                updated++;
            }
        }
        
        logInfo(`Updated usage for ${updated} customers from RADIUS`);
        return updated;
    }
    
    /**
     * Bulk sync all active customers to RADIUS
     */
    static async bulkSync() {
        const customers = await Customer.getActiveCustomers();
        
        let synced = 0;
        let failed = 0;
        
        for (const customer of customers) {
            try {
                await RadCheck.create(customer.username, customer.password);
                await RadCheck.updateStatus(customer.username, 'active');
                
                await RadReply.setSpeedLimit(
                    customer.username,
                    customer.upload_speed || '1M',
                    customer.download_speed || '1M'
                );
                
                if (customer.validity_days) {
                    const timeoutSeconds = customer.validity_days * 24 * 60 * 60;
                    await RadReply.setSessionTimeout(customer.username, timeoutSeconds);
                }
                
                synced++;
            } catch (error) {
                logError(`Failed to sync customer ${customer.username}:`, error);
                failed++;
            }
        }
        
        logInfo(`Bulk sync completed: ${synced} synced, ${failed} failed, ${customers.length} total`);
        
        return { total: customers.length, synced, failed };
    }
    
    /**
     * Clean up old RADIUS data
     */
    static async cleanupOldData(daysToKeep = 90) {
        // Delete old accounting records
        const [acctDeleted] = await pool.execute(
            `DELETE FROM radacct 
             WHERE acctstoptime IS NOT NULL 
               AND acctstoptime < DATE_SUB(NOW(), INTERVAL ? DAY)`,
            [daysToKeep]
        );
        
        // Delete orphaned radcheck entries (no matching customer)
        const [checkDeleted] = await pool.execute(`
            DELETE FROM radcheck 
            WHERE username NOT IN (SELECT username FROM customers WHERE username IS NOT NULL)
              AND attribute = 'Cleartext-Password'
        `);
        
        // Delete orphaned radreply entries
        const [replyDeleted] = await pool.execute(`
            DELETE FROM radreply 
            WHERE username NOT IN (SELECT username FROM customers WHERE username IS NOT NULL)
        `);
        
        logInfo(`Cleanup completed: ${acctDeleted.affectedRows} accounting records, ${checkDeleted.affectedRows} check records, ${replyDeleted.affectedRows} reply records deleted`);
        
        return {
            accounting_deleted: acctDeleted.affectedRows,
            check_deleted: checkDeleted.affectedRows,
            reply_deleted: replyDeleted.affectedRows
        };
    }
    
    /**
     * Get RADIUS synchronization status
     */
    static async getSyncStatus() {
        const [radiusUsers] = await pool.execute(
            `SELECT COUNT(DISTINCT username) as count FROM radcheck WHERE attribute = 'Cleartext-Password'`
        );
        
        const [activeCustomers] = await pool.execute(
            `SELECT COUNT(*) as count FROM customers WHERE status = 'active'`
        );
        
        const [missingUsers] = await pool.execute(`
            SELECT c.username 
            FROM customers c
            LEFT JOIN radcheck r ON c.username = r.username AND r.attribute = 'Cleartext-Password'
            WHERE c.status = 'active' AND r.id IS NULL
        `);
        
        return {
            radius_users: radiusUsers[0].count,
            active_customers: activeCustomers[0].count,
            missing_in_radius: missingUsers.length,
            sync_percentage: activeCustomers[0].count > 0 
                ? ((radiusUsers[0].count / activeCustomers[0].count) * 100).toFixed(2)
                : 100
        };
    }
}

module.exports = RadiusSyncService;