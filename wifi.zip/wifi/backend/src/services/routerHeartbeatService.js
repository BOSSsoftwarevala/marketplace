const Router = require('../models/Router');
const { pool } = require('../config/database');
const { logInfo, logError, logWarning } = require('../config/logger');
const { redisClient, cacheSet, cacheGet, setUserOnline, setUserOffline } = require('../config/redis');
const axios = require('axios');

class RouterHeartbeatService {
    /**
     * Process heartbeat from router
     */
    static async processHeartbeat(routerCode, data) {
        const { cpu_usage, ram_usage, online_users, upload_mbps, download_mbps, status } = data;
        
        // Find router by code
        const router = await Router.findByCode(routerCode);
        if (!router) {
            logWarning(`Heartbeat from unknown router: ${routerCode}`);
            return { success: false, message: 'Router not found' };
        }
        
        // Add heartbeat record
        await Router.addHeartbeat(router.id, {
            cpu_usage,
            ram_usage,
            online_users: online_users || 0,
            upload_mbps,
            download_mbps
        });
        
        // Update online users in Redis
        await cacheSet(`router:online:${router.id}`, online_users || 0, 600);
        
        // Update connection status
        await Router.updateConnectionStatus(router.id, status === 'online' ? 'online' : 'offline', online_users);
        
        // Check for alerts
        await this.checkAlerts(router, { cpu_usage, ram_usage, upload_mbps, download_mbps });
        
        logInfo(`Heartbeat processed for router: ${router.router_name}`, {
            routerId: router.id,
            onlineUsers: online_users,
            cpu: cpu_usage,
            ram: ram_usage
        });
        
        return { success: true, message: 'Heartbeat processed' };
    }
    
    /**
     * Check for router alerts
     */
    static async checkAlerts(router, metrics) {
        const alerts = [];
        
        // CPU alert (> 80%)
        if (metrics.cpu_usage && metrics.cpu_usage > 80) {
            alerts.push(`CPU usage is ${metrics.cpu_usage}%`);
        }
        
        // RAM alert (> 85%)
        if (metrics.ram_usage && metrics.ram_usage > 85) {
            alerts.push(`RAM usage is ${metrics.ram_usage}%`);
        }
        
        // Bandwidth alert (> 90% of capacity)
        // This would require knowing router capacity from config
        
        if (alerts.length > 0) {
            logWarning(`Router alert for ${router.router_name}: ${alerts.join(', ')}`, {
                routerId: router.id,
                alerts
            });
            
            // Store alert in database
            await pool.execute(
                `INSERT INTO router_alerts (router_id, alert_type, message, created_at)
                 VALUES (?, 'system', ?, NOW())`,
                [router.id, alerts.join(', ')]
            );
        }
        
        return alerts;
    }
    
    /**
     * Monitor all routers for offline status
     */
    static async monitorOfflineRouters() {
        const offlineRouters = await Router.getOfflineRouters();
        
        for (const router of offlineRouters) {
            const minutesOffline = router.last_seen 
                ? Math.floor((new Date() - new Date(router.last_seen)) / 60000)
                : 5;
            
            if (minutesOffline >= 5) {
                logWarning(`Router offline: ${router.router_name} (${minutesOffline} minutes)`, {
                    routerId: router.id,
                    ip: router.ip_address,
                    minutesOffline
                });
                
                // Update status to offline if not already
                if (router.connection_status !== 'offline') {
                    await Router.updateConnectionStatus(router.id, 'offline');
                }
                
                // Store offline event
                await pool.execute(
                    `INSERT INTO router_events (router_id, event_type, message, created_at)
                     VALUES (?, 'offline', ?, NOW())`,
                    [router.id, `Router offline for ${minutesOffline} minutes`]
                );
            }
        }
        
        return offlineRouters.length;
    }
    
    /**
     * Poll router for status (active monitoring)
     */
    static async pollRouter(routerId) {
        const router = await Router.findById(routerId);
        if (!router || router.status !== 'active') return null;
        
        try {
            // Try to ping the router
            const startTime = Date.now();
            const response = await axios.get(`http://${router.ip_address}:${process.env.MIKROTIK_API_PORT || 8728}/rest/system/resource`, {
                auth: {
                    username: router.api_username,
                    password: router.api_password
                },
                timeout: 5000
            });
            const responseTime = Date.now() - startTime;
            
            if (response.data) {
                const metrics = {
                    cpu_usage: response.data['cpu-load'],
                    ram_usage: ((response.data['total-memory'] - response.data['free-memory']) / response.data['total-memory'] * 100),
                    uptime: response.data.uptime,
                    version: response.data.version
                };
                
                // Get online users
                const usersResponse = await axios.get(`http://${router.ip_address}:${process.env.MIKROTIK_API_PORT || 8728}/rest/ip/hotspot/user`, {
                    auth: {
                        username: router.api_username,
                        password: router.api_password
                    },
                    timeout: 5000
                });
                
                const onlineUsers = usersResponse.data.filter(u => u.disabled === 'false').length;
                
                // Process heartbeat
                await this.processHeartbeat(router.router_code, {
                    cpu_usage: metrics.cpu_usage,
                    ram_usage: metrics.ram_usage,
                    online_users: onlineUsers,
                    status: 'online'
                });
                
                return { success: true, metrics, onlineUsers, responseTime };
            }
        } catch (error) {
            logError(`Poll router ${router.router_name} error:`, error);
            return { success: false, error: error.message };
        }
        
        return null;
    }
    
    /**
     * Sync online users from router to Redis
     */
    static async syncOnlineUsers(routerId) {
        const router = await Router.findById(routerId);
        if (!router || router.status !== 'active') return 0;
        
        try {
            const response = await axios.get(`http://${router.ip_address}:${process.env.MIKROTIK_API_PORT || 8728}/rest/ip/hotspot/user`, {
                auth: {
                    username: router.api_username,
                    password: router.api_password
                },
                timeout: 5000
            });
            
            const onlineUsers = response.data.filter(u => u.disabled === 'false');
            
            // Update Redis for each online user
            for (const user of onlineUsers) {
                // Find customer by username
                const [customer] = await pool.execute(
                    'SELECT id FROM customers WHERE username = ?',
                    [user.name]
                );
                
                if (customer.length > 0) {
                    await setUserOnline(customer[0].id, routerId, user['.id']);
                }
            }
            
            // Update router online users count
            await cacheSet(`router:online:${routerId}`, onlineUsers.length, 600);
            await Router.updateConnectionStatus(routerId, 'online', onlineUsers.length);
            
            return onlineUsers.length;
        } catch (error) {
            logError(`Sync online users for router ${router.router_name} error:`, error);
            return 0;
        }
    }
    
    /**
     * Get router statistics for dashboard
     */
    static async getRouterDashboardStats() {
        const routers = await Router.getAll();
        const stats = {
            total: routers.length,
            online: 0,
            offline: 0,
            total_users: 0,
            avg_cpu: 0,
            avg_ram: 0
        };
        
        let totalCpu = 0;
        let totalRam = 0;
        let cpuCount = 0;
        let ramCount = 0;
        
        for (const router of routers) {
            if (router.connection_status === 'online') {
                stats.online++;
            } else {
                stats.offline++;
            }
            
            stats.total_users += router.online_users || 0;
            
            // Get latest heartbeat
            const [heartbeat] = await pool.execute(
                `SELECT cpu_usage, ram_usage FROM router_heartbeats 
                 WHERE router_id = ? ORDER BY heartbeat_time DESC LIMIT 1`,
                [router.id]
            );
            
            if (heartbeat.length > 0) {
                if (heartbeat[0].cpu_usage) {
                    totalCpu += heartbeat[0].cpu_usage;
                    cpuCount++;
                }
                if (heartbeat[0].ram_usage) {
                    totalRam += heartbeat[0].ram_usage;
                    ramCount++;
                }
            }
        }
        
        stats.avg_cpu = cpuCount > 0 ? (totalCpu / cpuCount).toFixed(1) : 0;
        stats.avg_ram = ramCount > 0 ? (totalRam / ramCount).toFixed(1) : 0;
        
        return stats;
    }
    
    /**
     * Get router bandwidth usage over time
     */
    static async getBandwidthHistory(routerId, hours = 24) {
        const [rows] = await pool.execute(
            `SELECT 
                heartbeat_time,
                upload_mbps,
                download_mbps,
                online_users
             FROM router_heartbeats
             WHERE router_id = ? AND heartbeat_time >= DATE_SUB(NOW(), INTERVAL ? HOUR)
             ORDER BY heartbeat_time ASC`,
            [routerId, hours]
        );
        
        return rows;
    }
}

module.exports = RouterHeartbeatService;