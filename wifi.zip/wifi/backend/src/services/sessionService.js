const { pool } = require('../config/database');
const Customer = require('../models/Customer');
const Router = require('../models/Router');
const { logInfo, logError, logRadius } = require('../config/logger');
const { redisClient, setUserOnline, setUserOffline, getOnlineUsers } = require('../config/redis');

class SessionService {
    /**
     * Start a new session
     */
    static async startSession(customerId, routerId, sessionData) {
        const { ip_address, mac_address, session_id } = sessionData;
        
        // Check for existing active session
        const [existing] = await pool.execute(
            `SELECT id FROM router_sessions 
             WHERE customer_id = ? AND status = 'online'`,
            [customerId]
        );
        
        if (existing.length > 0) {
            // End existing session
            await this.endSession(existing[0].id, 'new_session');
        }
        
        // Create new session
        const [result] = await pool.execute(
            `INSERT INTO router_sessions 
             (customer_id, router_id, login_time, ip_address, mac_address, session_id, status)
             VALUES (?, ?, NOW(), ?, ?, ?, 'online')`,
            [customerId, routerId, ip_address, mac_address, session_id]
        );
        
        // Mark user online in Redis
        await setUserOnline(customerId, routerId, result.insertId);
        
        logInfo(`Session started for customer ${customerId}`, {
            routerId,
            sessionId: result.insertId,
            ip: ip_address
        });
        
        return result.insertId;
    }
    
    /**
     * End a session
     */
    static async endSession(sessionId, reason = 'logout') {
        const [result] = await pool.execute(
            `UPDATE router_sessions 
             SET logout_time = NOW(), status = 'offline', terminate_reason = ?
             WHERE id = ? AND status = 'online'`,
            [reason, sessionId]
        );
        
        if (result.affectedRows > 0) {
            // Get session details to update Redis
            const [session] = await pool.execute(
                `SELECT customer_id, router_id FROM router_sessions WHERE id = ?`,
                [sessionId]
            );
            
            if (session.length > 0) {
                await setUserOffline(session[0].customer_id, session[0].router_id);
            }
            
            logInfo(`Session ended: ${sessionId}`, { reason });
        }
        
        return result.affectedRows > 0;
    }
    
    /**
     * End all sessions for a customer
     */
    static async endCustomerSessions(customerId, reason = 'admin') {
        const [sessions] = await pool.execute(
            `SELECT id FROM router_sessions 
             WHERE customer_id = ? AND status = 'online'`,
            [customerId]
        );
        
        let ended = 0;
        for (const session of sessions) {
            if (await this.endSession(session.id, reason)) {
                ended++;
            }
        }
        
        logInfo(`Ended ${ended} sessions for customer ${customerId}`, { reason });
        return ended;
    }
    
    /**
     * Get active sessions for a customer
     */
    static async getCustomerActiveSessions(customerId) {
        const [rows] = await pool.execute(
            `SELECT rs.*, r.router_name, r.ip_address as router_ip, r.location
             FROM router_sessions rs
             JOIN routers r ON rs.router_id = r.id
             WHERE rs.customer_id = ? AND rs.status = 'online'`,
            [customerId]
        );
        
        return rows;
    }
    
    /**
     * Get all active sessions (for admin)
     */
    static async getAllActiveSessions() {
        const [rows] = await pool.execute(
            `SELECT rs.*, c.username, c.fullname, c.phone, r.router_name, r.location
             FROM router_sessions rs
             JOIN customers c ON rs.customer_id = c.id
             JOIN routers r ON rs.router_id = r.id
             WHERE rs.status = 'online'
             ORDER BY rs.login_time DESC`
        );
        
        return rows;
    }
    
    /**
     * Update session traffic usage
     */
    static async updateSessionTraffic(sessionId, uploadMb, downloadMb) {
        const [result] = await pool.execute(
            `UPDATE router_sessions 
             SET upload_mb = upload_mb + ?,
                 download_mb = download_mb + ?
             WHERE id = ? AND status = 'online'`,
            [uploadMb || 0, downloadMb || 0, sessionId]
        );
        
        return result.affectedRows > 0;
    }
    
    /**
     * Get session statistics
     */
    static async getSessionStats(period = 'today') {
        let dateCondition = '';
        if (period === 'today') {
            dateCondition = 'AND DATE(login_time) = CURDATE()';
        } else if (period === 'week') {
            dateCondition = 'AND login_time >= DATE_SUB(NOW(), INTERVAL 7 DAY)';
        } else if (period === 'month') {
            dateCondition = 'AND login_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)';
        }
        
        const [stats] = await pool.execute(`
            SELECT 
                COUNT(*) as total_sessions,
                SUM(CASE WHEN status = 'online' THEN 1 ELSE 0 END) as active_sessions,
                AVG(TIMESTAMPDIFF(MINUTE, login_time, COALESCE(logout_time, NOW()))) as avg_duration_minutes,
                SUM(upload_mb + download_mb) as total_traffic_mb
            FROM router_sessions
            WHERE 1=1 ${dateCondition}
        `);
        
        // Sessions per router
        const [perRouter] = await pool.execute(`
            SELECT 
                r.router_name,
                COUNT(rs.id) as session_count,
                SUM(CASE WHEN rs.status = 'online' THEN 1 ELSE 0 END) as active_count
            FROM router_sessions rs
            JOIN routers r ON rs.router_id = r.id
            WHERE rs.login_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            GROUP BY r.id, r.router_name
            ORDER BY session_count DESC
        `);
        
        return {
            summary: stats[0],
            per_router: perRouter
        };
    }
    
    /**
     * Clean up old sessions (completed sessions older than days)
     */
    static async cleanupOldSessions(daysToKeep = 30) {
        const [result] = await pool.execute(
            `DELETE FROM router_sessions 
             WHERE status = 'offline' 
               AND logout_time < DATE_SUB(NOW(), INTERVAL ? DAY)`,
            [daysToKeep]
        );
        
        logInfo(`Cleaned up ${result.affectedRows} old sessions`);
        return result.affectedRows;
    }
    
    /**
     * Get session by ID
     */
    static async getSessionById(sessionId) {
        const [rows] = await pool.execute(
            `SELECT rs.*, c.username, c.fullname, c.phone, r.router_name, r.location
             FROM router_sessions rs
             JOIN customers c ON rs.customer_id = c.id
             JOIN routers r ON rs.router_id = r.id
             WHERE rs.id = ?`,
            [sessionId]
        );
        
        return rows[0];
    }
    
    /**
     * Get session count for router
     */
    static async getRouterSessionCount(routerId) {
        const [rows] = await pool.execute(
            `SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'online' THEN 1 ELSE 0 END) as active
             FROM router_sessions
             WHERE router_id = ?`,
            [routerId]
        );
        
        return rows[0];
    }
    
    /**
     * Sync session from RADIUS accounting
     */
    static async syncFromRadius(username, radiusSession) {
        const customer = await Customer.findByUsername(username);
        if (!customer) return null;
        
        const router = await Router.findByIp(radiusSession.nasipaddress);
        if (!router) return null;
        
        // Check if session exists
        const [existing] = await pool.execute(
            `SELECT id FROM router_sessions 
             WHERE session_id = ? OR (customer_id = ? AND status = 'online')`,
            [radiusSession.acctsessionid, customer.id]
        );
        
        if (existing.length > 0) {
            // Update existing session
            await pool.execute(
                `UPDATE router_sessions 
                 SET upload_mb = upload_mb + ?,
                     download_mb = download_mb + ?
                 WHERE id = ?`,
                [
                    Math.floor((radiusSession.acctoutputoctets || 0) / (1024 * 1024)),
                    Math.floor((radiusSession.acctinputoctets || 0) / (1024 * 1024)),
                    existing[0].id
                ]
            );
            
            return existing[0].id;
        } else {
            // Create new session
            const sessionId = await this.startSession(customer.id, router.id, {
                ip_address: radiusSession.framedipaddress,
                mac_address: radiusSession.callingstationid,
                session_id: radiusSession.acctsessionid
            });
            
            return sessionId;
        }
    }
}

module.exports = SessionService;