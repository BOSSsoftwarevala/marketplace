const axios = require('axios');
const crypto = require('crypto');
const { pool } = require('../config/database');
const Customer = require('../models/Customer');
const Package = require('../models/Package');
const RadiusSyncService = require('./radiusSyncService');
const { logInfo, logError, logMpesa } = require('../config/logger');
const { redisClient, cacheSet, cacheGet } = require('../config/redis');

class MpesaService {
    constructor() {
        this.consumerKey = process.env.MPESA_CONSUMER_KEY;
        this.consumerSecret = process.env.MPESA_CONSUMER_SECRET;
        this.passkey = process.env.MPESA_PASSKEY;
        this.shortcode = process.env.MPESA_SHORTCODE;
        this.environment = process.env.MPESA_ENV || 'sandbox';
        
        // For B2C (Business to Customer - refunds/reseller commissions)
        this.initiatorName = process.env.MPESA_INITIATOR_NAME;
        this.initiatorPassword = process.env.MPESA_INITIATOR_PASSWORD;
        this.securityCredential = process.env.MPESA_SECURITY_CREDENTIAL;
        
        this.baseUrl = this.environment === 'production' 
            ? 'https://api.safaricom.co.ke'
            : 'https://sandbox.safaricom.co.ke';
        
        // Token cache
        this.accessToken = null;
        this.tokenExpiry = null;
    }

    /**
     * Get OAuth Access Token
     */
    async getAccessToken() {
        // Check if token is still valid (5 minutes buffer)
        if (this.accessToken && this.tokenExpiry && Date.now() < this.tokenExpiry) {
            return this.accessToken;
        }

        const auth = Buffer.from(`${this.consumerKey}:${this.consumerSecret}`).toString('base64');
        
        try {
            const response = await axios.get(
                `${this.baseUrl}/oauth/v1/generate?grant_type=client_credentials`,
                {
                    headers: {
                        Authorization: `Basic ${auth}`
                    },
                    timeout: 30000
                }
            );
            
            this.accessToken = response.data.access_token;
            // Token expires in 3600 seconds, set expiry 5 minutes early
            this.tokenExpiry = Date.now() + ((response.data.expires_in || 3599) - 300) * 1000;
            
            // Cache token in Redis as backup
            await cacheSet('mpesa:access_token', this.accessToken, 3500);
            
            logInfo('✅ M-Pesa access token obtained');
            return this.accessToken;
        } catch (error) {
            logError('❌ M-Pesa token error:', error);
            throw new Error('Failed to get M-Pesa access token');
        }
    }

    /**
     * Generate timestamp in M-Pesa format (YYYYMMDDHHMMSS)
     */
    getTimestamp() {
        const date = new Date();
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const hour = String(date.getHours()).padStart(2, '0');
        const minute = String(date.getMinutes()).padStart(2, '0');
        const second = String(date.getSeconds()).padStart(2, '0');
        
        return `${year}${month}${day}${hour}${minute}${second}`;
    }

    /**
     * Generate password for STK push
     */
    generatePassword(shortcode, passkey, timestamp) {
        const str = `${shortcode}${passkey}${timestamp}`;
        return Buffer.from(str).toString('base64');
    }

    /**
     * Format phone number to international format (254XXXXXXXXX)
     */
    formatPhoneNumber(phone) {
        // Remove any non-digit characters
        let cleaned = phone.toString().replace(/\D/g, '');
        
        // Check if it's a Safaricom number (starts with 07 or 01)
        if (cleaned.startsWith('0')) {
            cleaned = '254' + cleaned.substring(1);
        } else if (cleaned.startsWith('7') || cleaned.startsWith('1')) {
            cleaned = '254' + cleaned;
        }
        
        // Validate phone number length (12 digits for Kenya)
        if (cleaned.length !== 12) {
            throw new Error(`Invalid phone number format: ${phone}`);
        }
        
        return cleaned;
    }

    /**
     * Initiate STK Push payment
     */
    async stkPush(phoneNumber, amount, accountReference, transactionDesc) {
        const token = await this.getAccessToken();
        const timestamp = this.getTimestamp();
        const password = this.generatePassword(this.shortcode, this.passkey, timestamp);
        
        // Format phone number
        const formattedPhone = this.formatPhoneNumber(phoneNumber);
        
        const data = {
            BusinessShortCode: this.shortcode,
            Password: password,
            Timestamp: timestamp,
            TransactionType: 'CustomerPayBillOnline',
            Amount: Math.round(amount),
            PartyA: formattedPhone,
            PartyB: this.shortcode,
            PhoneNumber: formattedPhone,
            CallBackURL: process.env.MPESA_CALLBACK_URL,
            AccountReference: accountReference.substring(0, 12),
            TransactionDesc: transactionDesc.substring(0, 13)
        };
        
        try {
            logMpesa('STK Push Initiated', 'pending', {
                phone: formattedPhone,
                amount,
                accountReference
            });
            
            const response = await axios.post(
                `${this.baseUrl}/mpesa/stkpush/v1/processrequest`,
                data,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            
            // Store transaction in database
            await pool.execute(
                `INSERT INTO mpesa_transactions 
                 (checkout_request_id, merchant_request_id, phone, amount, result_code, result_desc, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, NOW())`,
                [
                    response.data.CheckoutRequestID, 
                    response.data.MerchantRequestID, 
                    formattedPhone, 
                    amount, 
                    0, 
                    'Pending'
                ]
            );
            
            logMpesa('STK Push Sent', 'pending', {
                checkoutRequestId: response.data.CheckoutRequestID,
                responseCode: response.data.ResponseCode
            });
            
            return response.data;
        } catch (error) {
            logError('STK Push error:', error);
            throw new Error(`STK Push failed: ${error.response?.data?.errorMessage || error.message}`);
        }
    }

    /**
     * Query STK Push status
     */
    async queryStatus(checkoutRequestId) {
        const token = await this.getAccessToken();
        const timestamp = this.getTimestamp();
        const password = this.generatePassword(this.shortcode, this.passkey, timestamp);
        
        const data = {
            BusinessShortCode: this.shortcode,
            Password: password,
            Timestamp: timestamp,
            CheckoutRequestID: checkoutRequestId
        };
        
        try {
            const response = await axios.post(
                `${this.baseUrl}/mpesa/stkpushquery/v1/query`,
                data,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            
            return response.data;
        } catch (error) {
            logError('Query status error:', error);
            throw new Error(`Query failed: ${error.response?.data?.errorMessage || error.message}`);
        }
    }

    /**
     * Process M-Pesa callback
     */
    async processCallback(callbackData) {
        const { Body } = callbackData;
        
        if (!Body || !Body.stkCallback) {
            logError('Invalid M-Pesa callback received', null, { body: callbackData });
            return { success: false, message: 'Invalid callback data' };
        }
        
        const { stkCallback } = Body;
        const {
            MerchantRequestID,
            CheckoutRequestID,
            ResultCode,
            ResultDesc,
            CallbackMetadata
        } = stkCallback;
        
        logMpesa('STK Push Callback Received', ResultCode === 0 ? 'success' : 'failed', {
            CheckoutRequestID,
            ResultCode,
            ResultDesc
        });
        
        // Update transaction record
        await pool.execute(
            `UPDATE mpesa_transactions 
             SET result_code = ?, result_desc = ?, transaction_date = NOW()
             WHERE checkout_request_id = ?`,
            [ResultCode, ResultDesc, CheckoutRequestID]
        );
        
        let mpesaReceipt = null;
        let amount = 0;
        let phone = null;
        
        if (ResultCode === 0 && CallbackMetadata) {
            const items = CallbackMetadata.Item;
            for (const item of items) {
                if (item.Name === 'MpesaReceiptNumber') mpesaReceipt = item.Value;
                if (item.Name === 'Amount') amount = item.Value;
                if (item.Name === 'PhoneNumber') phone = item.Value;
            }
            
            // Update with receipt
            await pool.execute(
                `UPDATE mpesa_transactions SET mpesa_receipt = ? WHERE checkout_request_id = ?`,
                [mpesaReceipt, CheckoutRequestID]
            );
        }
        
        // Find associated payment
        const [payments] = await pool.execute(
            `SELECT p.*, c.username, c.id as customer_id 
             FROM payments p
             JOIN customers c ON p.customer_id = c.id
             WHERE p.mpesa_receipt = ? AND p.status = 'pending'`,
            [CheckoutRequestID]
        );
        
        if (payments.length > 0) {
            const payment = payments[0];
            
            if (ResultCode === 0 && mpesaReceipt) {
                // Payment successful
                await pool.execute(
                    `UPDATE payments 
                     SET status = 'completed', 
                         mpesa_receipt = ?,
                         transaction_date = NOW()
                     WHERE id = ?`,
                    [mpesaReceipt, payment.id]
                );
                
                // Activate customer
                if (payment.status !== 'active') {
                    await Customer.updateStatus(payment.customer_id, 'active');
                    await RadiusSyncService.syncCustomerToRadius(payment.customer_id);
                }
                
                logInfo(`Payment completed for ${payment.username}`, {
                    customerId: payment.customer_id,
                    amount,
                    receipt: mpesaReceipt
                });
                
                return {
                    success: true,
                    message: 'Payment completed',
                    customerId: payment.customer_id,
                    amount,
                    receipt: mpesaReceipt
                };
            } else {
                // Payment failed
                await pool.execute(
                    `UPDATE payments SET status = 'failed', result_desc = ? WHERE id = ?`,
                    [ResultDesc, payment.id]
                );
                
                logMpesa('Payment Failed', 'failed', {
                    paymentId: payment.id,
                    customer: payment.username,
                    resultCode: ResultCode,
                    resultDesc: ResultDesc
                });
                
                return {
                    success: false,
                    message: ResultDesc,
                    customerId: payment.customer_id
                };
            }
        }
        
        return {
            success: ResultCode === 0,
            message: ResultDesc
        };
    }

    /**
     * B2C Payment (for refunds and reseller commissions)
     */
    async b2cPayment(phoneNumber, amount, commandId = 'BusinessPayment', remarks = '') {
        const token = await this.getAccessToken();
        const formattedPhone = this.formatPhoneNumber(phoneNumber);
        
        // Generate security credential (encrypted password)
        const securityCredential = this.generateSecurityCredential();
        
        const data = {
            InitiatorName: this.initiatorName,
            SecurityCredential: securityCredential,
            CommandID: commandId,
            Amount: Math.round(amount),
            PartyA: this.shortcode,
            PartyB: formattedPhone,
            Remarks: remarks.substring(0, 100),
            QueueTimeOutURL: `${process.env.MPESA_CALLBACK_URL}/b2c/timeout`,
            ResultURL: `${process.env.MPESA_CALLBACK_URL}/b2c/result`,
            Occasion: remarks.substring(0, 100)
        };
        
        try {
            logMpesa('B2C Payment Initiated', 'pending', {
                phone: formattedPhone,
                amount,
                commandId
            });
            
            const response = await axios.post(
                `${this.baseUrl}/mpesa/b2c/v1/paymentrequest`,
                data,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            
            return response.data;
        } catch (error) {
            logError('B2C Payment error:', error);
            throw new Error(`B2C Payment failed: ${error.response?.data?.errorMessage || error.message}`);
        }
    }

    /**
     * Generate security credential for B2C
     */
    generateSecurityCredential() {
        // In production, this should encrypt the initiator password using Safaricom's public certificate
        // For sandbox, it's often just the plain password or a specific format
        if (this.environment === 'sandbox') {
            return this.initiatorPassword;
        }
        
        // Production: Encrypt using certificate
        // This is a placeholder - implement actual encryption
        return this.initiatorPassword;
    }

    /**
     * Reverse transaction (refund)
     */
    async reverseTransaction(transactionId, amount, receiverParty, remarks = '') {
        const token = await this.getAccessToken();
        
        const data = {
            CommandID: 'TransactionReversal',
            ReceiverParty: receiverParty,
            RecieverIdentifierType: '11', // 11 = Paybill, 4 = MSISDN
            Amount: Math.round(amount),
            TransactionID: transactionId,
            Initiator: this.initiatorName,
            SecurityCredential: this.generateSecurityCredential(),
            Occasion: remarks.substring(0, 100),
            Remarks: remarks.substring(0, 100),
            QueueTimeOutURL: `${process.env.MPESA_CALLBACK_URL}/reversal/timeout`,
            ResultURL: `${process.env.MPESA_CALLBACK_URL}/reversal/result`
        };
        
        try {
            const response = await axios.post(
                `${this.baseUrl}/mpesa/reversal/v1/request`,
                data,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            
            return response.data;
        } catch (error) {
            logError('Transaction reversal error:', error);
            throw new Error(`Reversal failed: ${error.response?.data?.errorMessage || error.message}`);
        }
    }

    /**
     * Register C2B URLs
     */
    async registerC2BUrls(confirmationUrl, validationUrl) {
        const token = await this.getAccessToken();
        
        const data = {
            ShortCode: this.shortcode,
            ResponseType: 'Completed',
            ConfirmationURL: confirmationUrl,
            ValidationURL: validationUrl
        };
        
        try {
            const response = await axios.post(
                `${this.baseUrl}/mpesa/c2b/v1/registerurl`,
                data,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            
            return response.data;
        } catch (error) {
            logError('C2B registration error:', error);
            throw new Error(`C2B registration failed: ${error.response?.data?.errorMessage || error.message}`);
        }
    }

    /**
     * Simulate C2B payment (sandbox only)
     */
    async simulateC2B(phoneNumber, amount, shortCode, commandId = 'CustomerPayBillOnline') {
        if (this.environment === 'production') {
            throw new Error('C2B simulation only available in sandbox');
        }
        
        const token = await this.getAccessToken();
        const formattedPhone = this.formatPhoneNumber(phoneNumber);
        
        const data = {
            ShortCode: shortCode || this.shortcode,
            CommandID: commandId,
            Amount: Math.round(amount),
            Msisdn: formattedPhone,
            BillRefNumber: `TEST${Date.now()}`
        };
        
        try {
            const response = await axios.post(
                `${this.baseUrl}/mpesa/c2b/v1/simulate`,
                data,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            
            return response.data;
        } catch (error) {
            logError('C2B simulation error:', error);
            throw new Error(`C2B simulation failed: ${error.response?.data?.errorMessage || error.message}`);
        }
    }

    /**
     * Check account balance
     */
    async checkAccountBalance(partyA, identifierType = '4') {
        const token = await this.getAccessToken();
        
        const data = {
            CommandID: 'AccountBalance',
            PartyA: partyA || this.shortcode,
            IdentifierType: identifierType,
            Remarks: 'Balance Check',
            Initiator: this.initiatorName,
            SecurityCredential: this.generateSecurityCredential(),
            QueueTimeOutURL: `${process.env.MPESA_CALLBACK_URL}/balance/timeout`,
            ResultURL: `${process.env.MPESA_CALLBACK_URL}/balance/result`
        };
        
        try {
            const response = await axios.post(
                `${this.baseUrl}/mpesa/accountbalance/v1/query`,
                data,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );
            
            return response.data;
        } catch (error) {
            logError('Account balance error:', error);
            throw new Error(`Balance check failed: ${error.response?.data?.errorMessage || error.message}`);
        }
    }
}

module.exports = MpesaService;