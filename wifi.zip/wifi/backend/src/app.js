const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { createServer } = require('http');
const { Server } = require('socket.io');
const path = require('path');
const dotenv = require('dotenv');

// Load environment variables
dotenv.config();

// Import configurations
const { pool, testConnection, getDatabaseStatus } = require('./config/database');
const { connectRedis, redisClient, isRedisConnected } = require('./config/redis');
const { logInfo, logError, logAccess } = require('./utils/logger');

// Import routes
const authRoutes = require('./routes/authRoutes');
const customerRoutes = require('./routes/customerRoutes');
const paymentRoutes = require('./routes/paymentRoutes');
const routerRoutes = require('./routes/routerRoutes');
const voucherRoutes = require('./routes/voucherRoutes');
const resellerRoutes = require('./routes/resellerRoutes');
const radiusRoutes = require('./routes/radiusRoutes');
const adminRoutes = require('./routes/adminRoutes');
const dashboardRoutes = require('./routes/dashboardRoutes');
const adminUserRoutes = require('./routes/adminUserRoutes');  // <-- ONGEZA HII
const backupRoutes = require('./routes/backupRoutes');
// Import middleware
const { errorHandler, notFound, rateLimitHandler } = require('./middleware/errorMiddleware');
const { sanitizeInput } = require('./middleware/validationMiddleware');

// Initialize Express app
const app = express();
const httpServer = createServer(app);

// Socket.IO setup
const io = new Server(httpServer, {
    cors: {
        origin: process.env.FRONTEND_URL || '*',
        methods: ['GET', 'POST', 'PUT', 'DELETE'],
        credentials: true
    },
    transports: ['websocket', 'polling']
});

// Make io accessible to routes
app.set('io', io);

// Global rate limiter
const globalLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // Limit each IP to 100 requests per windowMs
    message: {
        success: false,
        error: 'Too many requests from this IP',
        message: 'Please try again later'
    },
    handler: rateLimitHandler,
    skip: (req) => {
        // Skip rate limiting for trusted IPs or specific endpoints
        const trustedIps = ['127.0.0.1', '::1'];
        return trustedIps.includes(req.ip) || req.path === '/health';
    }
});

// Middleware
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'"],
            scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
            imgSrc: ["'self'", "data:", "https:"],
        },
    },
    crossOriginEmbedderPolicy: false,
}));

// CORS configuration
app.use(cors({
    origin: process.env.FRONTEND_URL || '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'X-RADIUS-Secret'],
    credentials: true,
    maxAge: 86400 // 24 hours
}));

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Input sanitization
app.use(sanitizeInput);

// Request logging middleware
app.use((req, res, next) => {
    const startTime = Date.now();
    
    // Log request
    logInfo(`${req.method} ${req.url}`, {
        ip: req.ip,
        userAgent: req.get('user-agent'),
        userId: req.user?.id
    });
    
    // Capture response
    const originalJson = res.json;
    res.json = function(data) {
        const responseTime = Date.now() - startTime;
        logAccess(req, res, responseTime);
        originalJson.call(this, data);
    };
    
    next();
});

// Apply global rate limiter (except for health check)
app.use(/^(?!\/health).*$/, globalLimiter);

// ==================== ROUTES ====================

// Health check endpoint
app.get('/health', async (req, res) => {
    const dbStatus = await getDatabaseStatus();
    const redisStatus = isRedisConnected();
    
    res.json({
        success: true,
        status: 'healthy',
        timestamp: new Date().toISOString(),
        version: '1.0.0',
        services: {
            database: dbStatus,
            redis: redisStatus ? 'connected' : 'disconnected',
            radius: process.env.RADIUS_ENABLED === 'true' ? 'enabled' : 'disabled'
        },
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        environment: process.env.NODE_ENV || 'development'
    });
});

// Add after your existing routes
app.get('/status', (req, res) => {
    res.json({
        success: true,
        status: 'running',
        uptime: process.uptime(),
        timestamp: new Date().toISOString(),
        version: '1.0.0',
        services: {
            database: 'connected',
            redis: 'connected',
            radius: 'enabled'
        }
    });
});

app.get('/ping', (req, res) => {
    res.send('pong');
});

// API info endpoint
app.get('/api', (req, res) => {
    res.json({
        success: true,
        name: 'WiFi Billing System API',
        version: '1.0.0',
        description: 'ISP-grade WiFi billing system with FreeRADIUS integration',
        documentation: '/api/docs',
        endpoints: {
            auth: '/api/auth',
            customers: '/api/customers',
            payments: '/api/payments',
            routers: '/api/routers',
            vouchers: '/api/vouchers',
            resellers: '/api/resellers',
            radius: '/api/radius',
            admin: '/api/admin'
        },
        status: {
            health: '/health',
            metrics: '/metrics'
        }
    });
});

// Metrics endpoint (for monitoring)
app.get('/metrics', async (req, res) => {
    try {
        // Get database stats
        const [customerCount] = await pool.execute('SELECT COUNT(*) as count FROM customers');
        const [routerCount] = await pool.execute('SELECT COUNT(*) as count FROM routers');
        const [activeSessions] = await pool.execute('SELECT COUNT(*) as count FROM radacct WHERE acctstoptime IS NULL');
        
        res.json({
            success: true,
            timestamp: new Date().toISOString(),
            metrics: {
                customers: {
                    total: customerCount[0].count
                },
                routers: {
                    total: routerCount[0].count
                },
                radius: {
                    active_sessions: activeSessions[0].count
                },
                system: {
                    uptime_seconds: process.uptime(),
                    memory_usage_mb: Math.round(process.memoryUsage().rss / 1024 / 1024),
                    cpu_usage: process.cpuUsage()
                }
            }
        });
    } catch (error) {
        logError('Metrics error:', error);
        res.status(500).json({ success: false, error: 'Failed to fetch metrics' });
    }
});

// API Routes
const branchRoutes = require('./routes/branchRoutes');
const packageRoutes = require('./routes/packageRoutes');
app.use('/api/auth', authRoutes);
app.use('/api/customers', customerRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/routers', routerRoutes);
app.use('/api/vouchers', voucherRoutes);
app.use('/api/resellers', resellerRoutes);
app.use('/api/radius', radiusRoutes);
app.use('/api/packages', packageRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/branches', branchRoutes);  // <-- ONGEZA HII IKIWA HAIPO
app.use('/api/admins', adminUserRoutes);  // <-- ONGEZA HII
app.use('/api/backups', backupRoutes);
// Static files (if any)
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// ==================== SOCKET.IO ====================

// Socket.IO authentication middleware
io.use(async (socket, next) => {
    const token = socket.handshake.auth.token;
    
    if (!token) {
        return next(new Error('Authentication required'));
    }
    
    try {
        const jwt = require('jsonwebtoken');
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        
        // Get user from database based on role
        if (decoded.role === 'customer') {
            const [users] = await pool.execute(
                'SELECT id, username, fullname, status FROM customers WHERE id = ?',
                [decoded.id]
            );
            
            if (users.length > 0 && users[0].status === 'active') {
                socket.user = {
                    id: users[0].id,
                    username: users[0].username,
                    fullname: users[0].fullname,
                    role: 'customer'
                };
                return next();
            }
        } else if (decoded.role === 'admin') {
            socket.user = {
                id: decoded.id,
                username: decoded.username,
                role: 'admin'
            };
            return next();
        } else if (decoded.role === 'reseller') {
            const [resellers] = await pool.execute(
                'SELECT id, username, fullname, status FROM resellers WHERE id = ?',
                [decoded.id]
            );
            
            if (resellers.length > 0 && resellers[0].status === 'active') {
                socket.user = {
                    id: resellers[0].id,
                    username: resellers[0].username,
                    fullname: resellers[0].fullname,
                    role: 'reseller'
                };
                return next();
            }
        }
        
        next(new Error('Invalid user'));
    } catch (error) {
        next(new Error('Invalid token'));
    }
});

// Socket.IO connection handler
io.on('connection', (socket) => {
    logInfo(`New WebSocket connection: ${socket.id}`, { user: socket.user?.username });
    
    // Join user to their personal room
    if (socket.user) {
        socket.join(`user_${socket.user.id}`);
        socket.join(`role_${socket.user.role}`);
        
        // Emit welcome message
        socket.emit('connected', {
            message: `Welcome ${socket.user.fullname || socket.user.username}`,
            user: socket.user,
            timestamp: new Date().toISOString()
        });
    }
    
    // Handle ping/pong for connection health
    socket.on('ping', () => {
        socket.emit('pong', { timestamp: new Date().toISOString() });
    });
    
    // Handle subscription to router updates
    socket.on('subscribe:router', (routerId) => {
        if (socket.user && (socket.user.role === 'admin' || socket.user.role === 'reseller')) {
            socket.join(`router_${routerId}`);
            socket.emit('subscribed', { routerId, message: `Subscribed to router ${routerId}` });
            logInfo(`User ${socket.user.username} subscribed to router ${routerId}`);
        }
    });
    
    // Handle subscription to customer updates
    socket.on('subscribe:customer', (customerId) => {
        if (socket.user && (socket.user.role === 'admin' || socket.user.id === customerId)) {
            socket.join(`customer_${customerId}`);
            socket.emit('subscribed', { customerId, message: `Subscribed to customer ${customerId}` });
        }
    });
    
    // Handle disconnection
    socket.on('disconnect', () => {
        logInfo(`WebSocket disconnected: ${socket.id}`, { user: socket.user?.username });
    });
});

// ==================== EMITTER FUNCTIONS ====================

// Helper functions to emit events from controllers
global.emitPaymentCompleted = (customerId, data) => {
    io.to(`user_${customerId}`).to(`customer_${customerId}`).emit('payment:completed', {
        ...data,
        timestamp: new Date().toISOString()
    });
    io.to('role_admin').emit('payment:notification', { customerId, ...data });
};

global.emitSessionStarted = (customerId, sessionData) => {
    io.to(`user_${customerId}`).to(`customer_${customerId}`).emit('session:started', sessionData);
    io.to('role_admin').emit('session:notification', { type: 'started', customerId, ...sessionData });
};

global.emitSessionEnded = (customerId, sessionData) => {
    io.to(`user_${customerId}`).to(`customer_${customerId}`).emit('session:ended', sessionData);
    io.to('role_admin').emit('session:notification', { type: 'ended', customerId, ...sessionData });
};

global.emitRouterStatusChange = (routerId, status) => {
    io.to(`router_${routerId}`).to('role_admin').emit('router:status', { routerId, status, timestamp: new Date().toISOString() });
};

global.emitCustomerStatusChange = (customerId, status) => {
    io.to(`user_${customerId}`).to(`customer_${customerId}`).to('role_admin').emit('customer:status', { customerId, status, timestamp: new Date().toISOString() });
};

global.emitAlert = (type, message, data = {}) => {
    io.to('role_admin').emit('alert', { type, message, data, timestamp: new Date().toISOString() });
};

// ==================== ERROR HANDLING ====================

// 404 handler for undefined routes
app.use(notFound);

// Global error handler
app.use(errorHandler);

// Uncaught exception handler
process.on('uncaughtException', (error) => {
    logError('Uncaught Exception:', error);
    // Gracefully shutdown
    process.exit(1);
});

// Unhandled rejection handler
process.on('unhandledRejection', (reason, promise) => {
    logError('Unhandled Rejection:', reason);
});

// Graceful shutdown
const gracefulShutdown = async () => {
    logInfo('Received shutdown signal, closing gracefully...');
    
    // Close HTTP server
    httpServer.close(async () => {
        logInfo('HTTP server closed');
        
        // Close database connections
        try {
            await pool.end();
            logInfo('Database connections closed');
        } catch (error) {
            logError('Error closing database:', error);
        }
        
        // Close Redis connection
        if (redisClient && isRedisConnected()) {
            try {
                await redisClient.quit();
                logInfo('Redis connection closed');
            } catch (error) {
                logError('Error closing Redis:', error);
            }
        }
        
        logInfo('Graceful shutdown completed');
        process.exit(0);
    });
    
    // Force shutdown after 10 seconds
    setTimeout(() => {
        logError('Could not close connections in time, forcefully shutting down');
        process.exit(1);
    }, 10000);
};

// Handle shutdown signals
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// ==================== START SERVER FUNCTION ====================

const startServer = async () => {
    try {
        // Test database connection
        await testConnection();
        logInfo('✅ Database connection established');
        
        // Connect to Redis
        await connectRedis();
        logInfo('✅ Redis connection established');
        
        // Get server port
        const PORT = process.env.PORT || 3000;
        
        // Start HTTP server
        httpServer.listen(PORT, () => {
            logInfo(`🚀 Server running on port ${PORT}`);
            logInfo(`📡 API available at: http://localhost:${PORT}/api`);
            logInfo(`❤️  Health check: http://localhost:${PORT}/health`);
            logInfo(`🔌 WebSocket server ready`);
            logInfo(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
        });
        
    } catch (error) {
        logError('Failed to start server:', error);
        process.exit(1);
    }
};

// Start the server if this file is run directly
if (require.main === module) {
    startServer();
}

// Export for testing
module.exports = { app, httpServer, io, startServer };
