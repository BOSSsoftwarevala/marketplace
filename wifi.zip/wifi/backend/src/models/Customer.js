const { pool } = require('../config/database');
const bcrypt = require('bcryptjs');
const { logError } = require('../config/logger');

class Customer {
    /**
     * Create a new customer
     */
    static async create(customerData) {
        const { fullname, phone, email, username, password, package_id } = customerData;
        const hashedPassword = await bcrypt.hash(password, 10);
        
        const [result] = await pool.execute(
            `INSERT INTO customers (fullname, phone, email, username, password, package_id, status) 
             VALUES (?, ?, ?, ?, ?, ?, 'inactive')`,
            [fullname, phone, email || null, username, hashedPassword, package_id]
        );
        
        return result.insertId;
    }
    
    /**
     * Find customer by username
     */
    static async findByUsername(username) {
        const [rows] = await pool.execute(
            `SELECT c.*, p.package_name, p.price, p.validity_days, p.data_limit_mb,
                    p.upload_speed, p.download_speed, p.description as package_description
             FROM customers c
             LEFT JOIN packages p ON c.package_id = p.id
             WHERE c.username = ?`,
            [username]
        );
        return rows[0];
    }
    
    /**
     * Find customer by ID
     */
    static async findById(id) {
        const [rows] = await pool.execute(
            `SELECT c.*, p.package_name, p.price, p.validity_days, p.data_limit_mb,
                    p.upload_speed, p.download_speed, p.description as package_description
             FROM customers c
             LEFT JOIN packages p ON c.package_id = p.id
             WHERE c.id = ?`,
            [id]
        );
        return rows[0];
    }
    
    /**
     * Find customer by phone
     */
    static async findByPhone(phone) {
        const [rows] = await pool.execute(
            `SELECT c.*, p.package_name, p.price, p.validity_days, p.data_limit_mb,
                    p.upload_speed, p.download_speed
             FROM customers c
             LEFT JOIN packages p ON c.package_id = p.id
             WHERE c.phone = ?`,
            [phone]
        );
        return rows[0];
    }
    
    /**
     * Update customer status
     */
    static async updateStatus(customerId, status) {
        const [result] = await pool.execute(
            `UPDATE customers SET status = ? WHERE id = ?`,
            [status, customerId]
        );
        return result.affectedRows > 0;
    }
    
    /**
     * Update customer package
     */
    static async updatePackage(customerId, packageId) {
        const [result] = await pool.execute(
            `UPDATE customers SET package_id = ? WHERE id = ?`,
            [packageId, customerId]
        );
        return result.affectedRows > 0;
    }
    
    /**
     * Update customer password
     */
    static async updatePassword(customerId, newPassword) {
        const hashedPassword = await bcrypt.hash(newPassword, 10);
        const [result] = await pool.execute(
            `UPDATE customers SET password = ? WHERE id = ?`,
            [hashedPassword, customerId]
        );
        return result.affectedRows > 0;
    }
    
    /**
     * Check if customer can access a specific router
     */
    static async canAccessRouter(customerId, routerId) {
        const [rows] = await pool.execute(
            `SELECT status FROM customer_router_access 
             WHERE customer_id = ? AND router_id = ?`,
            [customerId, routerId]
        );
        
        if (rows.length === 0) return true; // No restriction = allowed
        return rows[0].status === 'allowed';
    }
    
    /**
     * Get all active customers
     */
    static async getActiveCustomers() {
        const [rows] = await pool.execute(
            `SELECT c.*, p.package_name, p.upload_speed, p.download_speed,
                    p.validity_days, p.data_limit_mb
             FROM customers c
             JOIN packages p ON c.package_id = p.id
             WHERE c.status = 'active'`
        );
        return rows;
    }
    
    /**
     * Get customer usage statistics
     */
    static async getCustomerUsage(customerId) {
        const [rows] = await pool.execute(
            `SELECT * FROM customer_usage WHERE customer_id = ?`,
            [customerId]
        );
        return rows[0] || { upload_mb: 0, download_mb: 0, total_mb: 0, session_time: 0 };
    }
    
    /**
     * Update customer usage
     */
    static async updateUsage(customerId, uploadMb, downloadMb, sessionTime) {
        const [result] = await pool.execute(
            `INSERT INTO customer_usage (customer_id, upload_mb, download_mb, total_mb, session_time, last_update)
             VALUES (?, ?, ?, ?, ?, NOW())
             ON DUPLICATE KEY UPDATE
             upload_mb = upload_mb + VALUES(upload_mb),
             download_mb = download_mb + VALUES(download_mb),
             total_mb = total_mb + VALUES(total_mb),
             session_time = session_time + VALUES(session_time),
             last_update = NOW()`,
            [customerId, uploadMb || 0, downloadMb || 0, (uploadMb || 0) + (downloadMb || 0), sessionTime || 0]
        );
        return result.affectedRows > 0;
    }
    
    /**
     * Get customer expiry date
     */
    static async getExpiryDate(customerId) {
        const customer = await this.findById(customerId);
        if (!customer) return null;
        
        const createdAt = new Date(customer.created_at);
        const expiryDate = new Date(createdAt);
        expiryDate.setDate(expiryDate.getDate() + customer.validity_days);
        
        return expiryDate;
    }
    
    /**
     * Check if customer is expired
     */
    static async isExpired(customerId) {
        const expiryDate = await this.getExpiryDate(customerId);
        if (!expiryDate) return true;
        return new Date() > expiryDate;
    }
    
    /**
     * Get remaining days for customer
     */
    static async getRemainingDays(customerId) {
        const expiryDate = await this.getExpiryDate(customerId);
        if (!expiryDate) return 0;
        
        const remainingMs = expiryDate - new Date();
        return Math.max(0, Math.ceil(remainingMs / (1000 * 60 * 60 * 24)));
    }
    
    /**
     * Get remaining data in MB
     */
    static async getRemainingData(customerId) {
        const customer = await this.findById(customerId);
        if (!customer || !customer.data_limit_mb) return 0;
        
        const usage = await this.getCustomerUsage(customerId);
        return Math.max(0, customer.data_limit_mb - (usage.total_mb || 0));
    }
    
    /**
     * Check and expire customers whose packages have expired
     */
    static async checkAndExpireCustomers() {
        const [rows] = await pool.execute(`
            SELECT c.id, c.username, p.validity_days, p.data_limit_mb,
                   COALESCE(cu.total_mb, 0) as used_mb
            FROM customers c
            JOIN packages p ON c.package_id = p.id
            LEFT JOIN customer_usage cu ON c.id = cu.customer_id
            WHERE c.status = 'active'
              AND DATE_ADD(c.created_at, INTERVAL p.validity_days DAY) < NOW()
        `);
        
        const expiredCustomers = [];
        
        for (const customer of rows) {
            let newStatus = 'inactive';
            
            // Check if data limit exceeded
            if (customer.data_limit_mb > 0 && customer.used_mb >= customer.data_limit_mb) {
                newStatus = 'suspended';
            }
            
            await this.updateStatus(customer.id, newStatus);
            expiredCustomers.push({ id: customer.id, username: customer.username, newStatus });
        }
        
        return expiredCustomers;
    }
    
    /**
     * Search customers
     */
    static async search(searchTerm, limit = 20) {
        const searchPattern = `%${searchTerm}%`;
        const [rows] = await pool.execute(
            `SELECT c.id, c.fullname, c.username, c.phone, c.email, c.status,
                    p.package_name
             FROM customers c
             LEFT JOIN packages p ON c.package_id = p.id
             WHERE c.fullname LIKE ? 
                OR c.username LIKE ? 
                OR c.phone LIKE ?
                OR c.email LIKE ?
             LIMIT ?`,
            [searchPattern, searchPattern, searchPattern, searchPattern, limit]
        );
        return rows;
    }
    
    /**
     * Get customers by router
     */
    static async getCustomersByRouter(routerId) {
        const [rows] = await pool.execute(
            `SELECT c.id, c.fullname, c.username, c.phone, c.status,
                    cra.status as router_access
             FROM customers c
             JOIN customer_router_access cra ON c.id = cra.customer_id
             WHERE cra.router_id = ?`,
            [routerId]
        );
        return rows;
    }
    
    /**
     * Get customer count by status
     */
    static async getCountByStatus() {
        const [rows] = await pool.execute(
            `SELECT status, COUNT(*) as count 
             FROM customers 
             GROUP BY status`
        );
        return rows;
    }
    
    /**
     * Delete customer and all related data
     */
    static async delete(customerId) {
        const connection = await pool.getConnection();
        try {
            await connection.beginTransaction();
            
            // Get username for RADIUS tables
            const [customer] = await connection.execute(
                'SELECT username FROM customers WHERE id = ?',
                [customerId]
            );
            
            if (customer.length === 0) {
                throw new Error('Customer not found');
            }
            
            const username = customer[0].username;
            
            // Delete from RADIUS tables
            await connection.execute('DELETE FROM radcheck WHERE username = ?', [username]);
            await connection.execute('DELETE FROM radreply WHERE username = ?', [username]);
            await connection.execute('DELETE FROM radacct WHERE username = ?', [username]);
            
            // Delete from customer tables
            await connection.execute('DELETE FROM customer_router_access WHERE customer_id = ?', [customerId]);
            await connection.execute('DELETE FROM customer_usage WHERE customer_id = ?', [customerId]);
            await connection.execute('DELETE FROM router_sessions WHERE customer_id = ?', [customerId]);
            await connection.execute('DELETE FROM payments WHERE customer_id = ?', [customerId]);
            await connection.execute('DELETE FROM customers WHERE id = ?', [customerId]);
            
            await connection.commit();
            return true;
        } catch (error) {
            await connection.rollback();
            logError('Delete customer error:', error);
            throw error;
        } finally {
            connection.release();
        }
    }
}

module.exports = Customer;