const { pool } = require('../config/database');

class Package {
    /**
     * Get all packages
     */
    static async getAll() {
        const [rows] = await pool.execute(
            `SELECT * FROM packages ORDER BY price ASC`
        );
        return rows;
    }
    
    /**
     * Get active packages (with price > 0)
     */
    static async getActivePackages() {
        const [rows] = await pool.execute(
            `SELECT * FROM packages WHERE price > 0 ORDER BY price ASC`
        );
        return rows;
    }
    
    /**
     * Find package by ID
     */
    static async findById(id) {
        const [rows] = await pool.execute(
            `SELECT * FROM packages WHERE id = ?`,
            [id]
        );
        return rows[0];
    }
    
    /**
     * Find package by name
     */
    static async findByName(name) {
        const [rows] = await pool.execute(
            `SELECT * FROM packages WHERE package_name = ?`,
            [name]
        );
        return rows[0];
    }
    
    /**
     * Create a new package
     */
    static async create(packageData) {
        const { package_name, price, validity_days, data_limit_mb, upload_speed, download_speed, description } = packageData;
        
        const [result] = await pool.execute(
            `INSERT INTO packages (package_name, price, validity_days, data_limit_mb, upload_speed, download_speed, description) 
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [package_name, price, validity_days, data_limit_mb || 0, upload_speed || '1M', download_speed || '1M', description || null]
        );
        
        return result.insertId;
    }
    
    /**
     * Update a package
     */
    static async update(id, packageData) {
        const { package_name, price, validity_days, data_limit_mb, upload_speed, download_speed, description } = packageData;
        
        const [result] = await pool.execute(
            `UPDATE packages 
             SET package_name = COALESCE(?, package_name),
                 price = COALESCE(?, price),
                 validity_days = COALESCE(?, validity_days),
                 data_limit_mb = COALESCE(?, data_limit_mb),
                 upload_speed = COALESCE(?, upload_speed),
                 download_speed = COALESCE(?, download_speed),
                 description = COALESCE(?, description)
             WHERE id = ?`,
            [package_name, price, validity_days, data_limit_mb, upload_speed, download_speed, description, id]
        );
        
        return result.affectedRows > 0;
    }
    
    /**
     * Delete a package (only if no customers use it)
     */
    static async delete(id) {
        // Check if package is in use
        const [customers] = await pool.execute(
            'SELECT COUNT(*) as count FROM customers WHERE package_id = ?',
            [id]
        );
        
        if (customers[0].count > 0) {
            throw new Error('Cannot delete package that is assigned to customers');
        }
        
        const [result] = await pool.execute(
            `DELETE FROM packages WHERE id = ?`,
            [id]
        );
        
        return result.affectedRows > 0;
    }
    
    /**
     * Get package statistics
     */
    static async getStats() {
        const [rows] = await pool.execute(`
            SELECT 
                p.id,
                p.package_name,
                p.price,
                p.validity_days,
                COUNT(c.id) as customer_count,
                SUM(CASE WHEN c.status = 'active' THEN 1 ELSE 0 END) as active_customers,
                SUM(CASE WHEN DATE_ADD(c.created_at, INTERVAL p.validity_days DAY) < NOW() THEN 1 ELSE 0 END) as expired_customers
            FROM packages p
            LEFT JOIN customers c ON p.id = c.package_id
            GROUP BY p.id
            ORDER BY p.price ASC
        `);
        return rows;
    }
    
    /**
     * Get most popular packages
     */
    static async getMostPopular(limit = 5) {
        const [rows] = await pool.execute(`
            SELECT 
                p.id,
                p.package_name,
                p.price,
                COUNT(c.id) as customer_count
            FROM packages p
            JOIN customers c ON p.id = c.package_id
            WHERE c.status = 'active'
            GROUP BY p.id
            ORDER BY customer_count DESC
            LIMIT ?
        `, [limit]);
        return rows;
    }
    
    /**
     * Get package revenue
     */
    static async getRevenue(startDate, endDate) {
        let query = `
            SELECT 
                p.id,
                p.package_name,
                COUNT(pay.id) as sales_count,
                SUM(pay.amount) as total_revenue
            FROM packages p
            JOIN payments pay ON p.id = pay.package_id
            WHERE pay.status = 'completed'
        `;
        
        const params = [];
        
        if (startDate) {
            query += ` AND pay.transaction_date >= ?`;
            params.push(startDate);
        }
        
        if (endDate) {
            query += ` AND pay.transaction_date <= ?`;
            params.push(endDate);
        }
        
        query += ` GROUP BY p.id ORDER BY total_revenue DESC`;
        
        const [rows] = await pool.execute(query, params);
        return rows;
    }
}

module.exports = Package;