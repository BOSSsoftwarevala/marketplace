const { pool } = require('../config/database');
const axios = require('axios');
const { logError } = require('../config/logger');

class Router {
    /**
     * Get all routers
     */
    static async getAll() {
        const [rows] = await pool.execute(
            `SELECT r.*, b.branch_name 
             FROM routers r
             LEFT JOIN branches b ON r.branch_id = b.id
             ORDER BY r.router_name ASC`
        );
        return rows;
    }
    
    /**
     * Get active routers
     */
    static async getActiveRouters() {
        const [rows] = await pool.execute(
            `SELECT r.*, b.branch_name 
             FROM routers r
             LEFT JOIN branches b ON r.branch_id = b.id
             WHERE r.status = 'active' 
             ORDER BY r.router_name ASC`
        );
        return rows;
    }
    
    /**
     * Find router by ID
     */
    static async findById(id) {
        const [rows] = await pool.execute(
            `SELECT r.*, b.branch_name 
             FROM routers r
             LEFT JOIN branches b ON r.branch_id = b.id
             WHERE r.id = ?`,
            [id]
        );
        return rows[0];
    }
    
    /**
     * Find router by code
     */
    static async findByCode(routerCode) {
        const [rows] = await pool.execute(
            `SELECT * FROM routers WHERE router_code = ?`,
            [routerCode]
        );
        return rows[0];
    }
    
    /**
     * Find router by IP address
     */
    static async findByIp(ipAddress) {
        const [rows] = await pool.execute(
            `SELECT * FROM routers WHERE ip_address = ?`,
            [ipAddress]
        );
        return rows[0];
    }
    
    /**
     * Create a new router
     */
    static async create(routerData) {
        const { router_name, router_code, ip_address, mac_address, location, api_username, api_password, branch_id } = routerData;
        
        const [result] = await pool.execute(
            `INSERT INTO routers (router_name, router_code, ip_address, mac_address, location, api_username, api_password, branch_id) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [router_name, router_code, ip_address, mac_address || null, location || null, api_username || null, api_password || null, branch_id || null]
        );
        
        return result.insertId;
    }
    
    /**
     * Update router
     */
    static async update(id, routerData) {
        const fields = [];
        const params = [];
        
        const allowedFields = ['router_name', 'router_code', 'ip_address', 'mac_address', 'location', 'api_username', 'api_password', 'branch_id', 'status'];
        
        for (const field of allowedFields) {
            if (routerData[field] !== undefined) {
                fields.push(`${field} = ?`);
                params.push(routerData[field]);
            }
        }
        
        if (fields.length === 0) return false;
        
        params.push(id);
        const [result] = await pool.execute(
            `UPDATE routers SET ${fields.join(', ')} WHERE id = ?`,
            params
        );
        
        return result.affectedRows > 0;
    }
    
    /**
     * Update router status
     */
    static async updateStatus(id, status) {
        const [result] = await pool.execute(
            `UPDATE routers SET status = ? WHERE id = ?`,
            [status, id]
        );
        return result.affectedRows > 0;
    }
    
    /**
     * Update router connection status
     */
    static async updateConnectionStatus(id, connectionStatus, onlineUsers = null) {
        const updates = ['connection_status = ?', 'last_seen = NOW()'];
        const params = [connectionStatus];
        
        if (onlineUsers !== null) {
            updates.push('online_users = ?');
            params.push(onlineUsers);
        }
        
        params.push(id);
        const [result] = await pool.execute(
            `UPDATE routers SET ${updates.join(', ')} WHERE id = ?`,
            params
        );
        
        return result.affectedRows > 0;
    }
    
    /**
     * Add heartbeat record
     */
    static async addHeartbeat(routerId, data) {
        const { cpu_usage, ram_usage, online_users, upload_mbps, download_mbps } = data;
        
        const [result] = await pool.execute(
            `INSERT INTO router_heartbeats (router_id, cpu_usage, ram_usage, online_users, upload_mbps, download_mbps, heartbeat_time) 
             VALUES (?, ?, ?, ?, ?, ?, NOW())`,
            [routerId, cpu_usage || null, ram_usage || null, online_users || 0, upload_mbps || null, download_mbps || null]
        );
        
        // Update router status
        await this.updateConnectionStatus(routerId, 'online', online_users);
        
        return result.insertId;
    }
    
    /**
     * Get heartbeat history
     */
    static async getHeartbeatHistory(routerId, limit = 24) {
        const [rows] = await pool.execute(
            `SELECT * FROM router_heartbeats 
             WHERE router_id = ? 
             ORDER BY heartbeat_time DESC 
             LIMIT ?`,
            [routerId, limit]
        );
        return rows;
    }
    
    /**
     * Get router statistics
     */
    static async getRouterStats(routerId) {
        const [rows] = await pool.execute(
            `SELECT 
                COUNT(DISTINCT rs.customer_id) as total_customers,
                COUNT(CASE WHEN rs.status = 'online' THEN 1 END) as online_sessions,
                SUM(rs.upload_mb) as total_upload_mb,
                SUM(rs.download_mb) as total_download_mb,
                AVG(rh.cpu_usage) as avg_cpu,
                AVG(rh.ram_usage) as avg_ram,
                AVG(rh.upload_mbps) as avg_upload_mbps,
                AVG(rh.download_mbps) as avg_download_mbps
             FROM routers r
             LEFT JOIN router_sessions rs ON r.id = rs.router_id
             LEFT JOIN router_heartbeats rh ON r.id = rh.router_id AND rh.heartbeat_time > DATE_SUB(NOW(), INTERVAL 1 HOUR)
             WHERE r.id = ?`,
            [routerId]
        );
        
        return rows[0];
    }
    
    /**
     * Call MikroTik API
     */
    static async callMikrotikAPI(routerId, endpoint, method = 'GET', data = null) {
        const router = await this.findById(routerId);
        if (!router) throw new Error('Router not found');
        
        const url = `http://${router.ip_address}:${process.env.MIKROTIK_API_PORT || 8728}/rest/${endpoint}`;
        
        const config = {
            method,
            url,
            auth: {
                username: router.api_username,
                password: router.api_password
            },
            headers: {
                'Content-Type': 'application/json'
            },
            timeout: 10000
        };
        
        if (data && method !== 'GET') {
            config.data = data;
        }
        
        try {
            const response = await axios(config);
            return response.data;
        } catch (error) {
            logError(`MikroTik API error for router ${router.router_name}:`, error);
            throw new Error(`MikroTik API error: ${error.message}`);
        }
    }
    
    /**
     * Get online users from router
     */
    static async getOnlineUsers(routerId) {
        try {
            const users = await this.callMikrotikAPI(routerId, 'ip/hotspot/user');
            return users.filter(u => u.disabled === 'false').length;
        } catch (error) {
            logError('Get online users error:', error);
            return 0;
        }
    }
    
    /**
     * Disconnect a user from router
     */
    static async disconnectUser(routerId, username) {
        try {
            const result = await this.callMikrotikAPI(routerId, `ip/hotspot/user/remove/${username}`, 'DELETE');
            return result;
        } catch (error) {
            logError('Disconnect user error:', error);
            throw error;
        }
    }
    
    /**
     * Get router bandwidth usage
     */
    static async getBandwidth(routerId) {
        try {
            const interfaces = await this.callMikrotikAPI(routerId, 'interface');
            const totalBandwidth = { upload: 0, download: 0 };
            
            for (const iface of interfaces) {
                if (iface.running && iface.name !== 'lo') {
                    totalBandwidth.upload += parseInt(iface['tx-bps'] || 0);
                    totalBandwidth.download += parseInt(iface['rx-bps'] || 0);
                }
            }
            
            return {
                upload_mbps: (totalBandwidth.upload / 1000000).toFixed(2),
                download_mbps: (totalBandwidth.download / 1000000).toFixed(2)
            };
        } catch (error) {
            logError('Get bandwidth error:', error);
            return { upload_mbps: 0, download_mbps: 0 };
        }
    }
    
    /**
     * Delete router and related data
     */
    static async delete(id) {
        const connection = await pool.getConnection();
        try {
            await connection.beginTransaction();
            
            // Check for active sessions
            const [sessions] = await connection.execute(
                'SELECT COUNT(*) as count FROM router_sessions WHERE router_id = ? AND status = "online"',
                [id]
            );
            
            if (sessions[0].count > 0) {
                throw new Error('Cannot delete router with active sessions');
            }
            
            await connection.execute('DELETE FROM router_heartbeats WHERE router_id = ?', [id]);
            await connection.execute('DELETE FROM router_sessions WHERE router_id = ?', [id]);
            await connection.execute('DELETE FROM customer_router_access WHERE router_id = ?', [id]);
            await connection.execute('DELETE FROM routers WHERE id = ?', [id]);
            
            await connection.commit();
            return true;
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    }
    
    /**
     * Get offline routers (no heartbeat in last 5 minutes)
     */
    static async getOfflineRouters() {
        const [rows] = await pool.execute(
            `SELECT * FROM routers 
             WHERE status = 'active' 
               AND (last_seen IS NULL OR last_seen < DATE_SUB(NOW(), INTERVAL 5 MINUTE))`
        );
        return rows;
    }
}

module.exports = Router;