const { pool } = require('../config/database');

class Voucher {
    /**
     * Generate vouchers
     */
    static async generate(packageId, quantity = 1, amount = null, expiryDays = 30, createdBy = null) {
        const Package = require('./Package');
        const package_ = await Package.findById(packageId);
        
        if (!package_) {
            throw new Error('Package not found');
        }
        
        const voucherAmount = amount || package_.price;
        const expiryDate = new Date();
        expiryDate.setDate(expiryDate.getDate() + expiryDays);
        
        const vouchers = [];
        
        for (let i = 0; i < quantity; i++) {
            const code = this.generateCode();
            
            const [result] = await pool.execute(
                `INSERT INTO vouchers (voucher_code, package_id, amount, expiry_date, status, created_by)
                 VALUES (?, ?, ?, ?, 'unused', ?)`,
                [code, packageId, voucherAmount, expiryDate, createdBy]
            );
            
            vouchers.push({
                id: result.insertId,
                code,
                amount: voucherAmount,
                package_name: package_.package_name,
                expiry_date: expiryDate
            });
        }
        
        return vouchers;
    }
    
    /**
     * Generate unique voucher code
     */
    static generateCode() {
        const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ0123456789';
        let code = '';
        for (let i = 0; i < 12; i++) {
            if (i > 0 && i % 4 === 0) {
                code += '-';
            }
            code += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return code;
    }
    
    /**
     * Find voucher by code
     */
    static async findByCode(code) {
        const [rows] = await pool.execute(
            `SELECT v.*, p.package_name, p.validity_days, p.data_limit_mb,
                    p.upload_speed, p.download_speed, p.price as package_price
             FROM vouchers v
             JOIN packages p ON v.package_id = p.id
             WHERE v.voucher_code = ?`,
            [code]
        );
        return rows[0];
    }
    
    /**
     * Find voucher by ID
     */
    static async findById(id) {
        const [rows] = await pool.execute(
            `SELECT v.*, p.package_name, p.validity_days, p.data_limit_mb,
                    p.upload_speed, p.download_speed
             FROM vouchers v
             JOIN packages p ON v.package_id = p.id
             WHERE v.id = ?`,
            [id]
        );
        return rows[0];
    }
    
    /**
     * Redeem voucher
     */
    static async redeem(code, customerId) {
        const voucher = await this.findByCode(code);
        
        if (!voucher) {
            throw new Error('Voucher not found');
        }
        
        if (voucher.status !== 'unused') {
            throw new Error(`Voucher is already ${voucher.status}`);
        }
        
        if (voucher.expiry_date && new Date(voucher.expiry_date) < new Date()) {
            await this.updateStatus(voucher.id, 'expired');
            throw new Error('Voucher has expired');
        }
        
        const connection = await pool.getConnection();
        
        try {
            await connection.beginTransaction();
            
            // Update voucher status
            await connection.execute(
                `UPDATE vouchers SET status = 'used', used_by = ?, used_at = NOW() WHERE id = ?`,
                [customerId, voucher.id]
            );
            
            // Create payment record
            const [paymentResult] = await connection.execute(
                `INSERT INTO payments (customer_id, amount, package_id, mpesa_receipt, status, transaction_date)
                 VALUES (?, ?, ?, ?, 'completed', NOW())`,
                [customerId, voucher.amount, voucher.package_id, `VOUCHER-${code}`]
            );
            
            // Update customer package and status
            await connection.execute(
                `UPDATE customers SET package_id = ?, status = 'active' WHERE id = ?`,
                [voucher.package_id, customerId]
            );
            
            await connection.commit();
            
            return {
                voucher,
                paymentId: paymentResult.insertId,
                package: {
                    id: voucher.package_id,
                    name: voucher.package_name,
                    validity_days: voucher.validity_days,
                    data_limit_mb: voucher.data_limit_mb,
                    upload_speed: voucher.upload_speed,
                    download_speed: voucher.download_speed
                }
            };
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    }
    
    /**
     * Update voucher status
     */
    static async updateStatus(voucherId, status) {
        const [result] = await pool.execute(
            `UPDATE vouchers SET status = ? WHERE id = ?`,
            [status, voucherId]
        );
        return result.affectedRows > 0;
    }
    
    /**
     * Get all vouchers with pagination
     */
    static async getAll({ status = null, page = 1, limit = 50 }) {
        const offset = (page - 1) * limit;
        let query = `
            SELECT v.*, p.package_name, c.fullname as used_by_name
            FROM vouchers v
            JOIN packages p ON v.package_id = p.id
            LEFT JOIN customers c ON v.used_by = c.id
            WHERE 1=1
        `;
        const params = [];
        
        if (status) {
            query += ` AND v.status = ?`;
            params.push(status);
        }
        
        query += ` ORDER BY v.created_at DESC LIMIT ? OFFSET ?`;
        params.push(limit, offset);
        
        const [rows] = await pool.execute(query, params);
        
        // Get total count
        let countQuery = `SELECT COUNT(*) as total FROM vouchers WHERE 1=1`;
        if (status) {
            countQuery += ` AND status = ?`;
        }
        const [total] = await pool.execute(countQuery, status ? [status] : []);
        
        return {
            data: rows,
            pagination: {
                page,
                limit,
                total: total[0].total,
                pages: Math.ceil(total[0].total / limit)
            }
        };
    }
    
    /**
     * Get voucher statistics
     */
    static async getStats() {
        const [rows] = await pool.execute(`
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'unused' THEN 1 ELSE 0 END) as unused,
                SUM(CASE WHEN status = 'used' THEN 1 ELSE 0 END) as used,
                SUM(CASE WHEN status = 'expired' THEN 1 ELSE 0 END) as expired,
                SUM(CASE WHEN status = 'used' THEN amount ELSE 0 END) as total_redeemed,
                AVG(CASE WHEN status = 'used' THEN amount ELSE NULL END) as avg_amount
            FROM vouchers
        `);
        
        const [byPackage] = await pool.execute(`
            SELECT 
                p.package_name,
                COUNT(v.id) as total,
                SUM(CASE WHEN v.status = 'used' THEN 1 ELSE 0 END) as used_count,
                SUM(CASE WHEN v.status = 'used' THEN v.amount ELSE 0 END) as total_amount
            FROM vouchers v
            JOIN packages p ON v.package_id = p.id
            GROUP BY p.id, p.package_name
            ORDER BY total_amount DESC
        `);
        
        return {
            summary: rows[0],
            by_package: byPackage
        };
    }
    
    /**
     * Delete expired vouchers
     */
    static async deleteExpired() {
        const [result] = await pool.execute(
            `DELETE FROM vouchers 
             WHERE status = 'expired' 
                OR (status = 'unused' AND expiry_date < NOW())`
        );
        return result.affectedRows;
    }
    
    /**
     * Check and update expired vouchers
     */
    static async updateExpired() {
        const [result] = await pool.execute(
            `UPDATE vouchers 
             SET status = 'expired' 
             WHERE status = 'unused' AND expiry_date < NOW()`
        );
        return result.affectedRows;
    }
    
    /**
     * Delete voucher
     */
    static async delete(id) {
        const [result] = await pool.execute(
            `DELETE FROM vouchers WHERE id = ? AND status != 'used'`,
            [id]
        );
        return result.affectedRows > 0;
    }
}

module.exports = Voucher;