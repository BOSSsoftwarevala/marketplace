const { pool } = require('../config/database');

class RadAcct {
    /**
     * Get active sessions
     */
    static async getActiveSessions() {
        const [rows] = await pool.execute(
            `SELECT ra.*, c.fullname, c.username, c.phone,
                    TIMESTAMPDIFF(SECOND, ra.acctstarttime, NOW()) as session_seconds,
                    ROUND((ra.acctinputoctets + ra.acctoutputoctets) / (1024 * 1024), 2) as total_mb
             FROM radacct ra
             JOIN customers c ON ra.username = c.username
             WHERE ra.acctstoptime IS NULL
             ORDER BY ra.acctstarttime DESC`
        );
        return rows;
    }
    
    /**
     * Get sessions for a customer
     */
    static async getCustomerSessions(username, limit = 50, offset = 0) {
        const [rows] = await pool.execute(
            `SELECT ra.*,
                    TIMESTAMPDIFF(SECOND, ra.acctstarttime, COALESCE(ra.acctstoptime, NOW())) as session_seconds,
                    ROUND((ra.acctinputoctets + ra.acctoutputoctets) / (1024 * 1024), 2) as total_mb,
                    ROUND(ra.acctinputoctets / (1024 * 1024), 2) as download_mb,
                    ROUND(ra.acctoutputoctets / (1024 * 1024), 2) as upload_mb
             FROM radacct ra
             WHERE ra.username = ?
             ORDER BY ra.acctstarttime DESC
             LIMIT ? OFFSET ?`,
            [username, limit, offset]
        );
        
        const [total] = await pool.execute(
            `SELECT COUNT(*) as total FROM radacct WHERE username = ?`,
            [username]
        );
        
        return {
            data: rows,
            pagination: {
                limit,
                offset,
                total: total[0].total
            }
        };
    }
    
    /**
     * Get session by ID
     */
    static async findById(radacctid) {
        const [rows] = await pool.execute(
            `SELECT ra.*, c.fullname, c.username
             FROM radacct ra
             JOIN customers c ON ra.username = c.username
             WHERE ra.radacctid = ?`,
            [radacctid]
        );
        return rows[0];
    }
    
    /**
     * Stop a session
     */
    static async stopSession(radacctid, terminateCause = 'Admin-Reset') {
        const [result] = await pool.execute(
            `UPDATE radacct 
             SET acctstoptime = NOW(), 
                 acctterminatecause = ?,
                 acctsessiontime = TIMESTAMPDIFF(SECOND, acctstarttime, NOW())
             WHERE radacctid = ? AND acctstoptime IS NULL`,
            [terminateCause, radacctid]
        );
        return result.affectedRows > 0;
    }
    
    /**
     * Get session statistics
     */
    static async getStats(days = 30) {
        const [active] = await pool.execute(
            `SELECT COUNT(*) as active FROM radacct WHERE acctstoptime IS NULL`
        );
        
        const [today] = await pool.execute(
            `SELECT COUNT(*) as today FROM radacct WHERE DATE(acctstarttime) = CURDATE()`
        );
        
        const [traffic] = await pool.execute(
            `SELECT 
                SUM(acctinputoctets + acctoutputoctets) as total_bytes,
                SUM(acctinputoctets) as total_input_bytes,
                SUM(acctoutputoctets) as total_output_bytes,
                COUNT(*) as total_sessions,
                AVG(acctsessiontime) as avg_session_seconds
             FROM radacct
             WHERE acctstarttime >= DATE_SUB(NOW(), INTERVAL ? DAY)`,
            [days]
        );
        
        const [uniqueUsers] = await pool.execute(
            `SELECT COUNT(DISTINCT username) as unique_users
             FROM radacct
             WHERE acctstarttime >= DATE_SUB(NOW(), INTERVAL ? DAY)`,
            [days]
        );
        
        const [daily] = await pool.execute(
            `SELECT 
                DATE(acctstarttime) as date,
                COUNT(*) as sessions,
                SUM(acctinputoctets + acctoutputoctets) / (1024 * 1024 * 1024) as total_gb
             FROM radacct
             WHERE acctstarttime >= DATE_SUB(NOW(), INTERVAL 30 DAY)
             GROUP BY DATE(acctstarttime)
             ORDER BY date DESC`
        );
        
        return {
            active_sessions: active[0].active,
            today_sessions: today[0].today,
            total_sessions: traffic[0].total_sessions || 0,
            unique_users: uniqueUsers[0].unique_users || 0,
            total_traffic_gb: traffic[0].total_bytes ? 
                (traffic[0].total_bytes / (1024 * 1024 * 1024)).toFixed(2) : 0,
            avg_session_minutes: traffic[0].avg_session_seconds ? 
                Math.round(traffic[0].avg_session_seconds / 60) : 0,
            daily_stats: daily
        };
    }
    
    /**
     * Get bandwidth usage over time
     */
    static async getBandwidthUsage(hours = 24) {
        const [rows] = await pool.execute(
            `SELECT 
                DATE_FORMAT(acctstarttime, '%Y-%m-%d %H:00:00') as hour,
                SUM(acctinputoctets + acctoutputoctets) / (1024 * 1024) as total_mb
             FROM radacct
             WHERE acctstarttime >= DATE_SUB(NOW(), INTERVAL ? HOUR)
             GROUP BY DATE_FORMAT(acctstarttime, '%Y-%m-%d %H:00:00')
             ORDER BY hour ASC`,
            [hours]
        );
        return rows;
    }
    
    /**
     * Get top users by data usage
     */
    static async getTopUsers(limit = 10, days = 30) {
        const [rows] = await pool.execute(
            `SELECT 
                ra.username,
                c.fullname,
                SUM(ra.acctinputoctets + ra.acctoutputoctets) / (1024 * 1024 * 1024) as total_gb,
                COUNT(*) as session_count,
                SUM(ra.acctsessiontime) / 3600 as total_hours
             FROM radacct ra
             JOIN customers c ON ra.username = c.username
             WHERE ra.acctstarttime >= DATE_SUB(NOW(), INTERVAL ? DAY)
             GROUP BY ra.username, c.fullname
             ORDER BY total_gb DESC
             LIMIT ?`,
            [days, limit]
        );
        return rows;
    }
    
    /**
     * Clean old sessions
     */
    static async cleanOldSessions(daysToKeep = 90) {
        const [result] = await pool.execute(
            `DELETE FROM radacct 
             WHERE acctstoptime IS NOT NULL 
               AND acctstoptime < DATE_SUB(NOW(), INTERVAL ? DAY)`,
            [daysToKeep]
        );
        return result.affectedRows;
    }
}

module.exports = RadAcct;