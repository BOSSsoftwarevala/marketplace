const { pool } = require('../config/database');

class RadReply {
    /**
     * Set speed limit for a user
     */
    static async setSpeedLimit(username, uploadSpeed, downloadSpeed) {
        const rateLimit = `${uploadSpeed}/${downloadSpeed}`;
        
        // Delete existing speed limit
        await pool.execute(
            `DELETE FROM radreply WHERE username = ? AND attribute = 'Mikrotik-Rate-Limit'`,
            [username]
        );
        
        // Insert new speed limit
        const [result] = await pool.execute(
            `INSERT INTO radreply (username, attribute, op, value) 
             VALUES (?, 'Mikrotik-Rate-Limit', ':=', ?)`,
            [username, rateLimit]
        );
        
        return result.insertId;
    }
    
    /**
     * Set session timeout for a user
     */
    static async setSessionTimeout(username, timeoutSeconds) {
        // Delete existing
        await pool.execute(
            `DELETE FROM radreply WHERE username = ? AND attribute = 'Session-Timeout'`,
            [username]
        );
        
        // Insert new timeout
        const [result] = await pool.execute(
            `INSERT INTO radreply (username, attribute, op, value) 
             VALUES (?, 'Session-Timeout', ':=', ?)`,
            [username, timeoutSeconds.toString()]
        );
        
        return result.insertId;
    }
    
    /**
     * Set idle timeout for a user
     */
    static async setIdleTimeout(username, timeoutSeconds) {
        await pool.execute(
            `DELETE FROM radreply WHERE username = ? AND attribute = 'Idle-Timeout'`,
            [username]
        );
        
        const [result] = await pool.execute(
            `INSERT INTO radreply (username, attribute, op, value) 
             VALUES (?, 'Idle-Timeout', ':=', ?)`,
            [username, timeoutSeconds.toString()]
        );
        
        return result.insertId;
    }
    
    /**
     * Get customer limits from RADIUS reply
     */
    static async getCustomerLimits(username) {
        const [rows] = await pool.execute(
            `SELECT attribute, value FROM radreply WHERE username = ?`,
            [username]
        );
        
        const limits = {
            upload_speed: '1M',
            download_speed: '1M',
            session_timeout: 86400,
            idle_timeout: 300
        };
        
        for (const row of rows) {
            if (row.attribute === 'Mikrotik-Rate-Limit') {
                const [upload, download] = row.value.split('/');
                if (upload) limits.upload_speed = upload;
                if (download) limits.download_speed = download;
            } else if (row.attribute === 'Session-Timeout') {
                limits.session_timeout = parseInt(row.value);
            } else if (row.attribute === 'Idle-Timeout') {
                limits.idle_timeout = parseInt(row.value);
            }
        }
        
        return limits;
    }
    
    /**
     * Set all RADIUS reply attributes for a user
     */
    static async setAll(username, { uploadSpeed, downloadSpeed, sessionTimeout, idleTimeout }) {
        // Delete all existing reply attributes
        await pool.execute(
            `DELETE FROM radreply WHERE username = ?`,
            [username]
        );
        
        const results = [];
        
        if (uploadSpeed && downloadSpeed) {
            const rateLimit = `${uploadSpeed}/${downloadSpeed}`;
            const [result] = await pool.execute(
                `INSERT INTO radreply (username, attribute, op, value) 
                 VALUES (?, 'Mikrotik-Rate-Limit', ':=', ?)`,
                [username, rateLimit]
            );
            results.push(result.insertId);
        }
        
        if (sessionTimeout) {
            const [result] = await pool.execute(
                `INSERT INTO radreply (username, attribute, op, value) 
                 VALUES (?, 'Session-Timeout', ':=', ?)`,
                [username, sessionTimeout.toString()]
            );
            results.push(result.insertId);
        }
        
        if (idleTimeout) {
            const [result] = await pool.execute(
                `INSERT INTO radreply (username, attribute, op, value) 
                 VALUES (?, 'Idle-Timeout', ':=', ?)`,
                [username, idleTimeout.toString()]
            );
            results.push(result.insertId);
        }
        
        return results;
    }
    
    /**
     * Delete all RADIUS reply attributes for a user
     */
    static async deleteAll(username) {
        const [result] = await pool.execute(
            `DELETE FROM radreply WHERE username = ?`,
            [username]
        );
        return result.affectedRows;
    }
    
    /**
     * Get all RADIUS reply attributes for a user
     */
    static async getAll(username) {
        const [rows] = await pool.execute(
            `SELECT attribute, value FROM radreply WHERE username = ?`,
            [username]
        );
        
        const attributes = {};
        for (const row of rows) {
            attributes[row.attribute] = row.value;
        }
        
        return attributes;
    }
}

module.exports = RadReply;