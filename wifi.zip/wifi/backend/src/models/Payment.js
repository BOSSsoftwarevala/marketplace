const { pool } = require('../config/database');

class Payment {
    /**
     * Create a new payment record
     */
    static async create(paymentData) {
        const { customer_id, phone, amount, package_id, mpesa_receipt = null, status = 'pending' } = paymentData;
        
        const [result] = await pool.execute(
            `INSERT INTO payments (customer_id, phone, amount, package_id, mpesa_receipt, status)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [customer_id, phone, amount, package_id, mpesa_receipt, status]
        );
        
        return result.insertId;
    }
    
    /**
     * Update payment status
     */
    static async updateStatus(paymentId, status, mpesaReceipt = null) {
        const updates = ['status = ?'];
        const params = [status];
        
        if (mpesaReceipt) {
            updates.push('mpesa_receipt = ?');
            params.push(mpesaReceipt);
        }
        
        updates.push('transaction_date = NOW()');
        params.push(paymentId);
        
        const [result] = await pool.execute(
            `UPDATE payments SET ${updates.join(', ')} WHERE id = ?`,
            params
        );
        
        return result.affectedRows > 0;
    }
    
    /**
     * Find payment by ID
     */
    static async findById(id) {
        const [rows] = await pool.execute(
            `SELECT p.*, c.username, c.fullname, c.phone as customer_phone,
                    pk.package_name, pk.validity_days, pk.data_limit_mb
             FROM payments p
             JOIN customers c ON p.customer_id = c.id
             JOIN packages pk ON p.package_id = pk.id
             WHERE p.id = ?`,
            [id]
        );
        return rows[0];
    }
    
    /**
     * Find payment by M-Pesa receipt
     */
    static async findByMpesaReceipt(receipt) {
        const [rows] = await pool.execute(
            `SELECT p.*, c.username, c.fullname
             FROM payments p
             JOIN customers c ON p.customer_id = c.id
             WHERE p.mpesa_receipt = ?`,
            [receipt]
        );
        return rows[0];
    }
    
    /**
     * Find pending payment by checkout request ID
     */
    static async findByCheckoutRequestId(checkoutRequestId) {
        const [rows] = await pool.execute(
            `SELECT p.*, c.username, c.fullname, c.phone as customer_phone
             FROM payments p
             JOIN customers c ON p.customer_id = c.id
             WHERE p.mpesa_receipt = ? AND p.status = 'pending'`,
            [checkoutRequestId]
        );
        return rows[0];
    }
    
    /**
     * Get payments for a customer
     */
    static async getByCustomer(customerId, { limit = 50, offset = 0 }) {
        const [rows] = await pool.execute(
            `SELECT p.*, pk.package_name, pk.validity_days, pk.data_limit_mb
             FROM payments p
             JOIN packages pk ON p.package_id = pk.id
             WHERE p.customer_id = ?
             ORDER BY p.created_at DESC
             LIMIT ? OFFSET ?`,
            [customerId, limit, offset]
        );
        
        const [total] = await pool.execute(
            `SELECT COUNT(*) as total FROM payments WHERE customer_id = ?`,
            [customerId]
        );
        
        return {
            data: rows,
            pagination: {
                limit,
                offset,
                total: total[0].total
            }
        };
    }
    
    /**
     * Get all payments with filters
     */
    static async getAll({ customerId = null, status = null, startDate = null, endDate = null, limit = 50, offset = 0 }) {
        let query = `
            SELECT p.*, c.username, c.fullname, c.phone as customer_phone,
                   pk.package_name
            FROM payments p
            JOIN customers c ON p.customer_id = c.id
            JOIN packages pk ON p.package_id = pk.id
            WHERE 1=1
        `;
        const params = [];
        
        if (customerId) {
            query += ` AND p.customer_id = ?`;
            params.push(customerId);
        }
        
        if (status) {
            query += ` AND p.status = ?`;
            params.push(status);
        }
        
        if (startDate) {
            query += ` AND p.created_at >= ?`;
            params.push(startDate);
        }
        
        if (endDate) {
            query += ` AND p.created_at <= ?`;
            params.push(endDate);
        }
        
        query += ` ORDER BY p.created_at DESC LIMIT ? OFFSET ?`;
        params.push(limit, offset);
        
        const [rows] = await pool.execute(query, params);
        
        // Get total count
        let countQuery = `SELECT COUNT(*) as total FROM payments p WHERE 1=1`;
        const countParams = [];
        
        if (customerId) {
            countQuery += ` AND p.customer_id = ?`;
            countParams.push(customerId);
        }
        
        if (status) {
            countQuery += ` AND p.status = ?`;
            countParams.push(status);
        }
        
        if (startDate) {
            countQuery += ` AND p.created_at >= ?`;
            countParams.push(startDate);
        }
        
        if (endDate) {
            countQuery += ` AND p.created_at <= ?`;
            countParams.push(endDate);
        }
        
        const [total] = await pool.execute(countQuery, countParams);
        
        return {
            data: rows,
            pagination: {
                limit,
                offset,
                total: total[0].total
            }
        };
    }
    
    /**
     * Get payment statistics
     */
    static async getStats({ period = 'month' } = {}) {
        let dateCondition = '';
        
        if (period === 'today') {
            dateCondition = 'AND DATE(created_at) = CURDATE()';
        } else if (period === 'week') {
            dateCondition = 'AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)';
        } else if (period === 'month') {
            dateCondition = 'AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)';
        } else if (period === 'year') {
            dateCondition = 'AND created_at >= DATE_SUB(NOW(), INTERVAL 1 YEAR)';
        }
        
        const [stats] = await pool.execute(`
            SELECT 
                COUNT(*) as total_transactions,
                SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END) as total_amount,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_count,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_count,
                SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed_count,
                AVG(CASE WHEN status = 'completed' THEN amount ELSE NULL END) as avg_amount
            FROM payments
            WHERE status != 'pending'
            ${dateCondition}
        `);
        
        // Daily payments for chart
        const [daily] = await pool.execute(`
            SELECT 
                DATE(created_at) as date,
                COUNT(*) as count,
                SUM(amount) as total
            FROM payments
            WHERE status = 'completed'
                AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            GROUP BY DATE(created_at)
            ORDER BY date DESC
        `);
        
        // Payment methods breakdown
        const [methods] = await pool.execute(`
            SELECT 
                CASE 
                    WHEN mpesa_receipt LIKE 'VOUCHER-%' THEN 'voucher'
                    WHEN mpesa_receipt IS NOT NULL AND mpesa_receipt != '' THEN 'mpesa'
                    ELSE 'other'
                END as method,
                COUNT(*) as count,
                SUM(amount) as total
            FROM payments
            WHERE status = 'completed'
            GROUP BY method
        `);
        
        return {
            summary: stats[0],
            daily,
            methods
        };
    }
    
    /**
     * Get total revenue for a period
     */
    static async getRevenue(startDate, endDate) {
        const [result] = await pool.execute(
            `SELECT COALESCE(SUM(amount), 0) as total
             FROM payments
             WHERE status = 'completed'
               AND transaction_date >= COALESCE(?, transaction_date)
               AND transaction_date <= COALESCE(?, transaction_date)`,
            [startDate, endDate]
        );
        return parseFloat(result[0].total);
    }
}

module.exports = Payment;