const { pool } = require('../config/database');

class RadCheck {
    /**
     * Create RADIUS check entry for a user
     */
    static async create(username, password) {
        // Check if exists
        const [existing] = await pool.execute(
            `SELECT id FROM radcheck WHERE username = ? AND attribute = 'Cleartext-Password'`,
            [username]
        );
        
        if (existing.length > 0) {
            return await this.update(username, password);
        }
        
        const [result] = await pool.execute(
            `INSERT INTO radcheck (username, attribute, op, value) 
             VALUES (?, 'Cleartext-Password', ':=', ?)`,
            [username, password]
        );
        
        return result.insertId;
    }
    
    /**
     * Update RADIUS password
     */
    static async update(username, password) {
        const [result] = await pool.execute(
            `UPDATE radcheck SET value = ? 
             WHERE username = ? AND attribute = 'Cleartext-Password'`,
            [password, username]
        );
        return result.affectedRows > 0;
    }
    
    /**
     * Update user status in RADIUS
     */
    static async updateStatus(username, status) {
        // Check if status attribute exists
        const [existing] = await pool.execute(
            `SELECT id FROM radcheck WHERE username = ? AND attribute = 'User-Status'`,
            [username]
        );
        
        if (existing.length > 0) {
            const [result] = await pool.execute(
                `UPDATE radcheck SET value = ? 
                 WHERE username = ? AND attribute = 'User-Status'`,
                [status, username]
            );
            return result.affectedRows > 0;
        } else {
            const [result] = await pool.execute(
                `INSERT INTO radcheck (username, attribute, op, value) 
                 VALUES (?, 'User-Status', ':=', ?)`,
                [username, status]
            );
            return result.insertId > 0;
        }
    }
    
    /**
     * Get user status from RADIUS
     */
    static async getUserStatus(username) {
        const [rows] = await pool.execute(
            `SELECT value FROM radcheck 
             WHERE username = ? AND attribute = 'User-Status'`,
            [username]
        );
        return rows[0]?.value || 'active';
    }
    
    /**
     * Delete RADIUS check entries for a user
     */
    static async delete(username) {
        const [result] = await pool.execute(
            `DELETE FROM radcheck WHERE username = ?`,
            [username]
        );
        return result.affectedRows > 0;
    }
    
    /**
     * Check if user exists in RADIUS
     */
    static async exists(username) {
        const [rows] = await pool.execute(
            `SELECT id FROM radcheck WHERE username = ? LIMIT 1`,
            [username]
        );
        return rows.length > 0;
    }
    
    /**
     * Get all RADIUS users
     */
    static async getAll(limit = 1000, offset = 0) {
        const [rows] = await pool.execute(
            `SELECT username, attribute, value 
             FROM radcheck 
             WHERE attribute IN ('Cleartext-Password', 'User-Status')
             ORDER BY username
             LIMIT ? OFFSET ?`,
            [limit, offset]
        );
        
        // Group by username
        const users = {};
        for (const row of rows) {
            if (!users[row.username]) {
                users[row.username] = { username: row.username };
            }
            if (row.attribute === 'Cleartext-Password') {
                users[row.username].password = row.value;
            } else if (row.attribute === 'User-Status') {
                users[row.username].status = row.value;
            }
        }
        
        return Object.values(users);
    }
    
    /**
     * Get count of RADIUS users
     */
    static async getCount() {
        const [rows] = await pool.execute(
            `SELECT COUNT(DISTINCT username) as count FROM radcheck`
        );
        return rows[0].count;
    }
}

module.exports = RadCheck;