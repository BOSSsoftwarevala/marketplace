/**
 * WiFi Billing System - Server Entry Point
 * ISP-grade WiFi billing system with FreeRADIUS integration
 * @version 1.0.0
 */

// Load environment variables first
require('dotenv').config();

// Core dependencies
const express = require('express');
const path = require('path');
const fs = require('fs');

// Import application modules
const { startServer, app, httpServer, io } = require('./src/app');

// Import utilities
const { logInfo, logError, logWarning } = require('./src/utils/logger');
const { isProduction, isDevelopment, timestamp } = require('./src/utils/helpers');

// ==================== GLOBAL VARIABLES ====================

const PORT = process.env.PORT || 3000;
const NODE_ENV = process.env.NODE_ENV || 'development';
const START_TIME = Date.now();

// ==================== CREATE REQUIRED DIRECTORIES ====================

const createRequiredDirectories = () => {
    const directories = [
        'logs',
        'uploads',
        'uploads/profiles',
        'uploads/vouchers',
        'backups',
        'temp'
    ];
    
    for (const dir of directories) {
        const dirPath = path.join(__dirname, dir);
        if (!fs.existsSync(dirPath)) {
            fs.mkdirSync(dirPath, { recursive: true });
            console.log(`📁 Created directory: ${dir}`);
        }
    }
};

// ==================== CHECK ENVIRONMENT ====================

const checkEnvironment = () => {
    const requiredEnvVars = [
        'DB_HOST',
        'DB_USER',
        'DB_NAME',
        'JWT_SECRET',
        'RADIUS_SECRET'
    ];
    
    const missingVars = [];
    
    for (const envVar of requiredEnvVars) {
        if (!process.env[envVar]) {
            missingVars.push(envVar);
        }
    }
    
    if (missingVars.length > 0) {
        console.error('❌ Missing required environment variables:', missingVars.join(', '));
        console.error('Please check your .env file');
        
        if (isProduction()) {
            process.exit(1);
        } else {
            console.warn('⚠️  Running in development mode with missing env vars may cause issues');
        }
    }
    
    // Check JWT secret strength
    const jwtSecret = process.env.JWT_SECRET;
    if (jwtSecret && (jwtSecret === 'your_super_secret_jwt_key_change_this' || jwtSecret.length < 32)) {
        console.warn('⚠️  WARNING: JWT_SECRET is weak! Please use a strong secret in production.');
    }
};

// ==================== PROCESS HANDLERS ====================

/**
 * Handle uncaught exceptions
 */
process.on('uncaughtException', (error) => {
    console.error('='.repeat(80));
    console.error('💥 UNCAUGHT EXCEPTION');
    console.error('='.repeat(80));
    console.error('Error:', error.message);
    console.error('Stack:', error.stack);
    console.error('='.repeat(80));
    
    logError('Uncaught Exception:', error, {
        type: 'uncaughtException',
        timestamp: timestamp.iso()
    });
    
    // Graceful shutdown
    console.log('🔄 Attempting graceful shutdown...');
    
    setTimeout(() => {
        console.error('❌ Forceful shutdown after timeout');
        process.exit(1);
    }, 5000);
    
    // Close server and exit
    if (httpServer) {
        httpServer.close(() => {
            console.log('✅ Server closed');
            process.exit(1);
        });
    } else {
        process.exit(1);
    }
});

/**
 * Handle unhandled promise rejections
 */
process.on('unhandledRejection', (reason, promise) => {
    console.error('='.repeat(80));
    console.error('⚠️ UNHANDLED PROMISE REJECTION');
    console.error('='.repeat(80));
    console.error('Reason:', reason);
    console.error('Promise:', promise);
    console.error('='.repeat(80));
    
    logError('Unhandled Rejection:', reason, {
        type: 'unhandledRejection',
        timestamp: timestamp.iso()
    });
    
    // Don't exit immediately, let the promise rejection be handled
    console.warn('⚠️ Continuing execution...');
});

/**
 * Handle graceful shutdown
 */
const gracefulShutdown = async (signal) => {
    console.log(`\n🛑 Received ${signal}, starting graceful shutdown...`);
    logInfo(`Graceful shutdown initiated`, { signal });
    
    // Set timeout for forced shutdown
    const forceShutdownTimeout = setTimeout(() => {
        console.error('❌ Forceful shutdown after timeout');
        process.exit(1);
    }, 10000);
    
    try {
        // Close HTTP server
        if (httpServer) {
            await new Promise((resolve) => {
                httpServer.close(() => {
                    console.log('✅ HTTP server closed');
                    resolve();
                });
            });
        }
        
        // Close database connections
        const { pool } = require('./src/config/database');
        if (pool) {
            await pool.end();
            console.log('✅ Database connections closed');
        }
        
        // Close Redis connection
        const { redisClient, isRedisConnected } = require('./src/config/redis');
        if (redisClient && isRedisConnected()) {
            await redisClient.quit();
            console.log('✅ Redis connection closed');
        }
        
        clearTimeout(forceShutdownTimeout);
        console.log('✅ Graceful shutdown completed');
        process.exit(0);
        
    } catch (error) {
        console.error('❌ Error during graceful shutdown:', error);
        process.exit(1);
    }
};

// Register shutdown handlers
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// ==================== DISPLAY BANNER ====================

const displayBanner = () => {
    const uptime = process.uptime();
    const uptimeHours = Math.floor(uptime / 3600);
    const uptimeMinutes = Math.floor((uptime % 3600) / 60);
    const uptimeSeconds = Math.floor(uptime % 60);
    
    console.log('');
    console.log('='.repeat(80));
    console.log('  🌐 WiFi Billing System - ISP Grade Solution');
    console.log('='.repeat(80));
    console.log(`  📡 Version:      1.0.0`);
    console.log(`  🚀 Environment:  ${NODE_ENV}`);
    console.log(`  🔌 Port:         ${PORT}`);
    console.log(`  ⏱️  Uptime:        ${uptimeHours}h ${uptimeMinutes}m ${uptimeSeconds}s`);
    console.log(`  📅 Started:      ${new Date(START_TIME).toISOString()}`);
    console.log(`  🖥️  Node Version:  ${process.version}`);
    console.log(`  💻 Platform:     ${process.platform} ${process.arch}`);
    console.log(`  📊 PID:          ${process.pid}`);
    console.log('='.repeat(80));
    console.log('');
    console.log('  📡 API Endpoints:');
    console.log(`     Health:     http://localhost:${PORT}/health`);
    console.log(`     API Info:   http://localhost:${PORT}/api`);
    console.log(`     Metrics:    http://localhost:${PORT}/metrics`);
    console.log(`     WebSocket:  ws://localhost:${PORT}`);
    console.log('');
    console.log('  📚 Documentation:');
    console.log(`     API Docs:   http://localhost:${PORT}/api/docs`);
    console.log(`     Status:     http://localhost:${PORT}/status`);
    console.log('');
    console.log('='.repeat(80));
    console.log('  ✅ Server is ready to accept connections');
    console.log('='.repeat(80));
    console.log('');
};

// ==================== MONITORING FUNCTIONS ====================

/**
 * Log system metrics periodically
 */
let metricsInterval = null;

const startMetricsLogging = () => {
    if (metricsInterval) clearInterval(metricsInterval);
    
    // Log metrics every hour in production
    const intervalMinutes = isProduction() ? 60 : 10;
    
    metricsInterval = setInterval(async () => {
        try {
            const memoryUsage = process.memoryUsage();
            const cpuUsage = process.cpuUsage();
            
            // Get database connection count
            const { pool } = require('./src/config/database');
            let dbConnections = 0;
            try {
                const [rows] = await pool.execute('SHOW STATUS LIKE "Threads_connected"');
                dbConnections = rows[0]?.Value || 0;
            } catch (err) {
                // Ignore
            }
            
            logInfo('System metrics', {
                uptime_seconds: Math.floor(process.uptime()),
                memory: {
                    rss_mb: Math.round(memoryUsage.rss / 1024 / 1024),
                    heap_total_mb: Math.round(memoryUsage.heapTotal / 1024 / 1024),
                    heap_used_mb: Math.round(memoryUsage.heapUsed / 1024 / 1024),
                    external_mb: Math.round(memoryUsage.external / 1024 / 1024)
                },
                cpu: {
                    user_ms: cpuUsage.user,
                    system_ms: cpuUsage.system
                },
                database: {
                    connections: dbConnections
                }
            });
        } catch (error) {
            // Silently fail
        }
    }, intervalMinutes * 60 * 1000);
    
    // Ensure interval doesn't prevent process exit
    if (metricsInterval.unref) {
        metricsInterval.unref();
    }
};

/**
 * Check file permissions
 */
const checkFilePermissions = () => {
    const criticalFiles = ['.env', 'package.json', 'server.js'];
    
    for (const file of criticalFiles) {
        const filePath = path.join(__dirname, file);
        if (fs.existsSync(filePath)) {
            try {
                fs.accessSync(filePath, fs.constants.R_OK);
                console.log(`✅ Read access: ${file}`);
            } catch (err) {
                console.warn(`⚠️  Cannot read ${file}: ${err.message}`);
            }
        } else {
            console.warn(`⚠️  Missing file: ${file}`);
        }
    }
};

// ==================== START SERVER ====================

/**
 * Main function to start the server
 */
const main = async () => {
    console.log('🚀 Starting WiFi Billing System...');
    console.log('');
    
    // Create required directories
    createRequiredDirectories();
    console.log('✅ Directories created');
    
    // Check environment variables
    checkEnvironment();
    console.log('✅ Environment checked');
    
    // Check file permissions
    checkFilePermissions();
    console.log('✅ File permissions checked');
    
    // Start the server
    try {
        await startServer();
        
        // Display banner after server starts
        setTimeout(displayBanner, 1000);
        
        // Start metrics logging
        startMetricsLogging();
        
        // Log startup completion
        logInfo('Server started successfully', {
            port: PORT,
            environment: NODE_ENV,
            pid: process.pid,
            startTime: new Date(START_TIME).toISOString()
        });
        
    } catch (error) {
        console.error('❌ Failed to start server:', error.message);
        console.error(error.stack);
        logError('Failed to start server', error);
        process.exit(1);
    }
};

// ==================== HELPER ROUTES (for debugging) ====================

/**
 * Simple status endpoint (before app is fully loaded)
 */
const simpleApp = express();
simpleApp.get('/status', (req, res) => {
    res.json({
        status: 'starting',
        timestamp: new Date().toISOString(),
        pid: process.pid,
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        node_version: process.version
    });
});

simpleApp.get('/ping', (req, res) => {
    res.send('pong');
});

// Start the main server
if (require.main === module) {
    main();
}

// Export for testing
module.exports = {
    startServer: main,
    gracefulShutdown,
    PORT,
    NODE_ENV
};