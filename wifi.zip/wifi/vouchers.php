<?php include('head.php'); ?>
<body data-active="vouchers" data-crumbs="Workspace | Vouchers">
<div class="shell">
<?php include('sidebar.php'); ?>
<div class="main">
<?php include('topbar.php'); ?>
<main class="content">
<section class="hero">
<div class="hero-text">
<span class="eyebrow" id="heroDate">Voucher Management</span>
<h1 class="hero-title">Manage <span class="accent">Vouchers</span></h1>
<p class="hero-sub" id="heroSubText">Generate, track, and manage prepaid vouchers</p>
</div>
<div class="hero-actions">
<button class="btn btn--ghost" onclick="exportVouchers()"><svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/></svg> Export</button>
<button class="btn btn--primary" onclick="showGenerateModal()"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg> Generate Vouchers</button>
</div>
</section>

<!-- Voucher Statistics KPI Grid -->
<section class="kpi-grid" aria-label="Voucher metrics">
<article class="kpi-card c-success">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon success"><svg viewBox="0 0 24 24"><path d="M20 12H4M12 4v16"/></svg></div>
<div class="kpi-label">Total Vouchers</div>
</div>
</div>
<div class="kpi-value" id="totalVouchers">0</div>
<div class="kpi-compare">Generated total</div>
</article>

<article class="kpi-card c-danger">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon danger"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg></div>
<div class="kpi-label">Used</div>
</div>
</div>
<div class="kpi-value" id="usedVouchers">0</div>
<div class="kpi-compare">Already redeemed</div>
</article>

<article class="kpi-card c-purple">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon purple"><svg viewBox="0 0 24 24"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg></div>
<div class="kpi-label">Unused</div>
</div>
</div>
<div class="kpi-value" id="unusedVouchers">0</div>
<div class="kpi-compare">Available for use</div>
</article>

<article class="kpi-card c-primary">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon primary"><svg viewBox="0 0 24 24"><path d="M18 20V10M12 20V4M6 20v-4"/></svg></div>
<div class="kpi-label">Total Value</div>
</div>
</div>
<div class="kpi-value" id="totalValue"> 0</div>
<div class="kpi-compare">Voucher value</div>
</article>
</section>

<!-- Vouchers Table -->
<section class="col-12 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Voucher List</span>
<h2 class="card-title">All Vouchers</h2>
</div>
<div class="card-actions">
<input type="text" id="searchInput" placeholder="Search by voucher code..." class="search-input" style="padding: 6px 12px; border-radius: 6px; border: 1px solid var(--border); background: var(--bg);">
<select id="statusFilter" class="status-filter" style="padding: 6px 12px; border-radius: 6px; border: 1px solid var(--border); background: var(--bg);">
<option value="all">All Status</option>
<option value="unused">Unused</option>
<option value="used">Used</option>
<option value="expired">Expired</option>
</select>
</div>
</div>
<div class="table-responsive">
<table class="table">
<thead>
<tr>
<th>ID</th>
<th>Voucher Code</th>
<th>Package</th>
<th>Amount</th>
<th>Status</th>
<th>Used By</th>
<th>Created</th>
<th>Expiry Date</th>
<th>Actions</th>
</tr>
</thead>
<tbody id="vouchersTableBody">
<tr><td colspan="9" class="text-center">Loading vouchers...</td></tr>
</tbody>
</table>
</div>
<div class="pagination" style="padding: 16px; display: flex; justify-content: space-between; align-items: center;">
<div>Showing <span id="showingStart">0</span> to <span id="showingEnd">0</span> of <span id="totalRecords">0</span> vouchers</div>
<div class="pagination-buttons">
<button class="btn btn--small" id="prevPage" onclick="prevPage()" disabled>Previous</button>
<button class="btn btn--small" id="nextPage" onclick="nextPage()" disabled>Next</button>
</div>
</div>
</section>

<!-- Generate Vouchers Modal -->
<div id="generateModal" class="modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
    <div class="modal-content" style="background: white; border-radius: 12px; max-width: 500px; width: 90%; max-height: 90vh; overflow-y: auto; padding: 24px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1);">
        <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h3 style="margin: 0;">Generate Vouchers</h3>
            <button onclick="closeGenerateModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: #666;">&times;</button>
        </div>
        <form id="generateForm">
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Package *</label>
                <select id="package_id" class="input" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;">
                    <option value="">Select Package</option>
                </select>
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Quantity *</label>
                <input type="number" id="quantity" class="input" value="1" min="1" max="100" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;">
                <small style="color: #666; font-size: 11px;">Max 100 vouchers at once</small>
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Amount () <small>(Optional)</small></label>
                <input type="number" id="amount" class="input" step="0.01" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;">
                <small style="color: #666; font-size: 11px;">Leave empty to use package price</small>
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Expiry Days *</label>
                <input type="number" id="expiry_days" class="input" value="30" min="1" max="365" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;">
                <small style="color: #666; font-size: 11px;">Days until voucher expires</small>
            </div>
            <button type="submit" class="btn btn--primary" style="width: 100%; padding: 10px; background: #4f46e5; color: white; border: none; border-radius: 6px; cursor: pointer;">Generate Vouchers</button>
        </form>
    </div>
</div>

<!-- Edit Voucher Modal -->
<div id="editVoucherModal" class="modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
    <div class="modal-content" style="background: white; border-radius: 12px; max-width: 500px; width: 90%; max-height: 90vh; overflow-y: auto; padding: 24px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1);">
        <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h3 style="margin: 0;">Edit Voucher</h3>
            <button onclick="closeEditModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: #666;">&times;</button>
        </div>
        <form id="editVoucherForm">
            <input type="hidden" id="edit_voucher_id">
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Voucher Code</label>
                <input type="text" id="edit_voucher_code" class="input" readonly style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; background: #f5f5f5;">
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Package</label>
                <select id="edit_package_id" class="input" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;">
                    <option value="">Select Package</option>
                </select>
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Amount ()</label>
                <input type="number" id="edit_amount" class="input" step="0.01" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Status</label>
                <select id="edit_status" class="input" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;">
                    <option value="unused">Unused</option>
                    <option value="used">Used</option>
                    <option value="expired">Expired</option>
                </select>
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Expiry Date</label>
                <input type="date" id="edit_expiry_date" class="input" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            <button type="submit" class="btn btn--primary" style="width: 100%; padding: 10px; background: #4f46e5; color: white; border: none; border-radius: 6px; cursor: pointer;">Update Voucher</button>
        </form>
    </div>
</div>

<!-- View Voucher Modal -->
<div id="viewVoucherModal" class="modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
    <div class="modal-content" style="background: white; border-radius: 12px; max-width: 500px; width: 90%; max-height: 90vh; overflow-y: auto; padding: 24px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1);">
        <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h3 style="margin: 0;">Voucher Details</h3>
            <button onclick="closeViewModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: #666;">&times;</button>
        </div>
        <div id="voucherDetails" style="max-height: 400px; overflow-y: auto;"></div>
        <div style="margin-top: 20px; display: flex; gap: 10px; justify-content: flex-end;">
            <button onclick="closeViewModal()" class="btn btn--ghost" style="padding: 8px 16px;">Close</button>
        </div>
    </div>
</div>

<!-- Toast Container -->
<div id="toastContainer" style="position: fixed; top: 20px; right: 20px; z-index: 9999;"></div>

</main>
<?php include('footer.php'); ?>
</div>
</div>

<script>
// ============================================
// VOUCHER MANAGEMENT PAGE - WITH REAL DATA
// // ============================================

// const API_BASE_URL = 'https://shabanetech.top/wifi-api';
// let adminToken = localStorage.getItem('adminToken');
let allVouchers = [];
let currentPage = 1;
let itemsPerPage = 10;
let currentFilters = { search: '', status: 'all' };

function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '✗' : type === 'warning' ? '⚠' : 'ℹ'}</div>
        <div class="toast-message">${message}</div>
        <button class="toast-close" onclick="this.parentElement.remove()">×</button>
    `;
    
    container.appendChild(toast);
    
    setTimeout(() => {
        if (toast.parentElement) {
            toast.style.animation = 'slideOut 0.3s ease forwards';
            setTimeout(() => toast.remove(), 300);
        }
    }, 4000);
}

// Add styles
const styles = document.createElement('style');
styles.textContent = `
    .toast {
        display: flex;
        align-items: center;
        gap: 12px;
        background: white;
        border-radius: 8px;
        padding: 12px 16px;
        margin-bottom: 10px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        animation: slideIn 0.3s ease forwards;
        min-width: 280px;
        border-left: 4px solid;
    }
    .toast-success { border-left-color: #10b981; }
    .toast-error { border-left-color: #ef4444; }
    .toast-warning { border-left-color: #f59e0b; }
    .toast-info { border-left-color: #3b82f6; }
    .toast-icon {
        width: 24px;
        height: 24px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        font-size: 14px;
    }
    .toast-success .toast-icon { background: #10b98120; color: #10b981; }
    .toast-error .toast-icon { background: #ef444420; color: #ef4444; }
    .toast-warning .toast-icon { background: #f59e0b20; color: #f59e0b; }
    .toast-info .toast-icon { background: #3b82f620; color: #3b82f6; }
    .toast-message { flex: 1; font-size: 14px; color: #333; }
    .toast-close {
        background: none;
        border: none;
        font-size: 18px;
        cursor: pointer;
        color: #999;
        padding: 0;
        width: 20px;
        height: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .toast-close:hover { color: #666; }
    
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
    .text-center { text-align: center; }
    .table-responsive { overflow-x: auto; }
    .tag { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 500; }
    .t-unused { background: #dcfce7; color: #166534; }
    .t-used { background: #fef3c7; color: #92400e; }
    .t-expired { background: #fee2e2; color: #991b1b; }
    .btn-icon { background: none; border: none; cursor: pointer; font-size: 18px; padding: 4px 8px; border-radius: 4px; transition: background 0.2s; }
    .btn-icon:hover { background: #f0f0f0; }
    .search-input, .status-filter { margin-left: 8px; }
    .card-actions { display: flex; gap: 8px; }
    .voucher-code {
        font-family: monospace;
        font-weight: bold;
        letter-spacing: 1px;
    }
`;
document.head.appendChild(styles);

async function apiFetch(endpoint, options = {}) {
    if (!adminToken) {
        window.location.href = 'admin_login.html';
        return null;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            ...options,
            headers: {
                'Authorization': `Bearer ${adminToken}`,
                'Content-Type': 'application/json',
                ...options.headers
            }
        });
        
        if (response.status === 401) {
            localStorage.removeItem('adminToken');
            localStorage.removeItem('adminUser');
            window.location.href = 'admin_login.html';
            return null;
        }
        
        const data = await response.json();
        if (!response.ok) {
            throw new Error(data.error || data.message || `HTTP ${response.status}`);
        }
        return data;
    } catch (error) {
        console.error('API Error:', error);
        showToast(error.message || 'API request failed', 'error');
        return null;
    }
}

function formatCurrency(amount) {
    return ' ' + parseFloat(amount || 0).toLocaleString();
}

function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString();
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function getStatusClass(status) {
    switch(status) {
        case 'unused': return 't-unused';
        case 'used': return 't-used';
        case 'expired': return 't-expired';
        default: return 't-unused';
    }
}

// Load packages for dropdown
async function loadPackages(selectId, selectedId = null) {
    const response = await apiFetch('/api/packages');
    if (response && response.success && response.data) {
        const select = document.getElementById(selectId);
        if (select) {
            select.innerHTML = '<option value="">Select Package</option>' + 
                response.data.map(pkg => `<option value="${pkg.id}" ${selectedId == pkg.id ? 'selected' : ''}>${escapeHtml(pkg.package_name)} - ${formatCurrency(pkg.price)} (${pkg.validity_days} days)</option>`).join('');
        }
    }
}

// Load vouchers from API
async function loadVouchers() {
    const tbody = document.getElementById('vouchersTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '<tr><td colspan="9" class="text-center">Loading vouchers...</td></tr>';
    
    const response = await apiFetch('/api/vouchers');
    
    if (response && response.success && response.data) {
        allVouchers = response.data;
        
        // Also load package names for each voucher
        const packages = await apiFetch('/api/packages');
        const packageMap = {};
        if (packages && packages.success && packages.data) {
            packages.data.forEach(pkg => {
                packageMap[pkg.id] = pkg.package_name;
            });
        }
        
        // Add package names to vouchers
        allVouchers = allVouchers.map(v => ({
            ...v,
            package_name: packageMap[v.package_id] || 'Unknown'
        }));
        
        updateVoucherDisplay();
        updateStats();
    } else {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center">Failed to load vouchers</td></tr>';
    }
}

function updateVoucherDisplay() {
    const tbody = document.getElementById('vouchersTableBody');
    if (!tbody) return;
    
    // Apply filters
    let filtered = [...allVouchers];
    
    if (currentFilters.search) {
        const search = currentFilters.search.toLowerCase();
        filtered = filtered.filter(v => 
            v.voucher_code && v.voucher_code.toLowerCase().includes(search)
        );
    }
    
    if (currentFilters.status !== 'all') {
        filtered = filtered.filter(v => v.status === currentFilters.status);
    }
    
    // Pagination
    const total = filtered.length;
    const totalPages = Math.ceil(total / itemsPerPage);
    const start = (currentPage - 1) * itemsPerPage;
    const end = start + itemsPerPage;
    const paginated = filtered.slice(start, end);
    
    if (paginated.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center">No vouchers found</td></tr>';
    } else {
        tbody.innerHTML = paginated.map(voucher => `
            <tr>
                <td>${voucher.id}</td>
                <td class="voucher-code"><strong>${escapeHtml(voucher.voucher_code)}</strong></td>
                <td>${escapeHtml(voucher.package_name || '-')}</td>
                <td class="cell-price pos">${formatCurrency(voucher.amount)}</td>
                <td><span class="tag ${getStatusClass(voucher.status)}">${voucher.status}</span></td>
                <td>${escapeHtml(voucher.used_by_name || voucher.used_by_username || '-')}</td>
                <td class="cell-date">${formatDate(voucher.created_at)}</td>
                <td class="cell-date">${formatDate(voucher.expiry_date) || '-'}</td>
                <td>
                    <button class="btn-icon" onclick="viewVoucher(${voucher.id})" title="View">👁️</button>
                    <button class="btn-icon" onclick="editVoucher(${voucher.id})" title="Edit">✏️</button>
                    <button class="btn-icon" onclick="deleteVoucher(${voucher.id})" title="Delete">🗑️</button>
                </td>
            </tr>
        `).join('');
    }
    
    // Update pagination info
    document.getElementById('showingStart').innerHTML = total === 0 ? 0 : start + 1;
    document.getElementById('showingEnd').innerHTML = Math.min(end, total);
    document.getElementById('totalRecords').innerHTML = total;
    document.getElementById('prevPage').disabled = currentPage <= 1;
    document.getElementById('nextPage').disabled = currentPage >= totalPages;
}

function updateStats() {
    const total = allVouchers.length;
    const used = allVouchers.filter(v => v.status === 'used').length;
    const unused = allVouchers.filter(v => v.status === 'unused').length;
    const totalValue = allVouchers.reduce((sum, v) => sum + parseFloat(v.amount || 0), 0);
    
    document.getElementById('totalVouchers').innerHTML = total;
    document.getElementById('usedVouchers').innerHTML = used;
    document.getElementById('unusedVouchers').innerHTML = unused;
    document.getElementById('totalValue').innerHTML = formatCurrency(totalValue);
}

// Generate vouchers
document.getElementById('generateForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const packageId = document.getElementById('package_id').value;
    const quantity = parseInt(document.getElementById('quantity').value);
    const amount = document.getElementById('amount').value;
    const expiryDays = parseInt(document.getElementById('expiry_days').value);
    
    if (!packageId) {
        showToast('Please select a package', 'error');
        return;
    }
    
    const data = {
        package_id: parseInt(packageId),
        quantity: quantity,
        expiry_days: expiryDays
    };
    
    if (amount) {
        data.amount = parseFloat(amount);
    }
    
    const submitBtn = e.target.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = 'Generating...';
    submitBtn.disabled = true;
    
    const response = await apiFetch('/api/vouchers/generate', {
        method: 'POST',
        body: JSON.stringify(data)
    });
    
    submitBtn.innerHTML = originalText;
    submitBtn.disabled = false;
    
    if (response && response.success) {
        showToast(`${quantity} voucher(s) generated successfully!`, 'success');
        closeGenerateModal();
        loadVouchers();
        document.getElementById('generateForm').reset();
    } else {
        showToast(response?.error || 'Failed to generate vouchers', 'error');
    }
});

// View voucher
async function viewVoucher(id) {
    const response = await apiFetch(`/api/vouchers/${id}`);
    if (response && response.success && response.data) {
        const voucher = response.data;
        document.getElementById('voucherDetails').innerHTML = `
            <div class="voucher-info">
                <p><strong>ID:</strong> ${voucher.id}</p>
                <p><strong>Voucher Code:</strong> <code>${escapeHtml(voucher.voucher_code)}</code></p>
                <p><strong>Package ID:</strong> ${voucher.package_id}</p>
                <p><strong>Amount:</strong> ${formatCurrency(voucher.amount)}</p>
                <p><strong>Status:</strong> <span class="tag ${getStatusClass(voucher.status)}">${voucher.status}</span></p>
                <p><strong>Used By:</strong> ${escapeHtml(voucher.used_by_name || voucher.used_by_username || '-')}</p>
                <p><strong>Created:</strong> ${formatDate(voucher.created_at)}</p>
                <p><strong>Expiry Date:</strong> ${formatDate(voucher.expiry_date) || '-'}</p>
            </div>
        `;
        document.getElementById('viewVoucherModal').style.display = 'flex';
    }
}

// Edit voucher
async function editVoucher(id) {
    const response = await apiFetch(`/api/vouchers/${id}`);
    if (response && response.success && response.data) {
        const voucher = response.data;
        document.getElementById('edit_voucher_id').value = voucher.id;
        document.getElementById('edit_voucher_code').value = voucher.voucher_code;
        document.getElementById('edit_amount').value = voucher.amount;
        document.getElementById('edit_status').value = voucher.status;
        document.getElementById('edit_expiry_date').value = voucher.expiry_date ? voucher.expiry_date.split('T')[0] : '';
        
        await loadPackages('edit_package_id', voucher.package_id);
        document.getElementById('editVoucherModal').style.display = 'flex';
    }
}

// Update edit form submission
document.getElementById('editVoucherForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const id = document.getElementById('edit_voucher_id').value;
    const updateData = {
        package_id: parseInt(document.getElementById('edit_package_id').value),
        amount: parseFloat(document.getElementById('edit_amount').value),
        status: document.getElementById('edit_status').value,
        expiry_date: document.getElementById('edit_expiry_date').value
    };
    
    const response = await apiFetch(`/api/vouchers/${id}`, {
        method: 'PUT',
        body: JSON.stringify(updateData)
    });
    
    if (response && response.success) {
        showToast('Voucher updated successfully!', 'success');
        closeEditModal();
        loadVouchers();
    } else {
        showToast(response?.error || 'Failed to update voucher', 'error');
    }
});

// Delete voucher
async function deleteVoucher(id) {
    if (confirm('Are you sure you want to delete this voucher? This action cannot be undone.')) {
        const response = await apiFetch(`/api/vouchers/${id}`, { method: 'DELETE' });
        if (response && response.success) {
            showToast('Voucher deleted successfully!', 'success');
            loadVouchers();
        } else {
            showToast(response?.error || 'Failed to delete voucher', 'error');
        }
    }
}

// Pagination
function prevPage() {
    if (currentPage > 1) {
        currentPage--;
        updateVoucherDisplay();
    }
}

function nextPage() {
    const totalPages = Math.ceil(allVouchers.length / itemsPerPage);
    if (currentPage < totalPages) {
        currentPage++;
        updateVoucherDisplay();
    }
}

// Modal functions
function showGenerateModal() {
    loadPackages('package_id');
    document.getElementById('generateModal').style.display = 'flex';
}

function closeGenerateModal() {
    document.getElementById('generateModal').style.display = 'none';
}

function closeEditModal() {
    document.getElementById('editVoucherModal').style.display = 'none';
}

function closeViewModal() {
    document.getElementById('viewVoucherModal').style.display = 'none';
}

// Search and filter
const searchInput = document.getElementById('searchInput');
if (searchInput) {
    searchInput.addEventListener('input', (e) => {
        currentFilters.search = e.target.value;
        currentPage = 1;
        updateVoucherDisplay();
    });
}

const statusFilter = document.getElementById('statusFilter');
if (statusFilter) {
    statusFilter.addEventListener('change', (e) => {
        currentFilters.status = e.target.value;
        currentPage = 1;
        updateVoucherDisplay();
    });
}

function exportVouchers() {
    showToast('Export feature coming soon!', 'info');
}

// Set current date
const dateElem = document.getElementById('heroDate');
if (dateElem) {
    const date = new Date();
    dateElem.innerHTML = date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
}

// Get admin name
const user = JSON.parse(localStorage.getItem('adminUser') || '{}');
const adminNameElem = document.getElementById('adminName');
if (adminNameElem) {
    if (user.fullname) adminNameElem.innerHTML = user.fullname.split(' ')[0];
    else if (user.username) adminNameElem.innerHTML = user.username;
}

// Check authentication and load data
if (adminToken && adminToken !== 'null' && adminToken.length > 20) {
    loadVouchers();
} else {
    window.location.href = 'admin_login.html';
}

// Close modals when clicking outside
window.onclick = function(event) {
    const generateModal = document.getElementById('generateModal');
    const editModal = document.getElementById('editVoucherModal');
    const viewModal = document.getElementById('viewVoucherModal');
    if (event.target === generateModal) closeGenerateModal();
    if (event.target === editModal) closeEditModal();
    if (event.target === viewModal) closeViewModal();
}
</script>

<style>
.text-center { text-align: center; }
.voucher-code { font-family: monospace; font-weight: bold; letter-spacing: 1px; }
.cell-price.pos { color: #10b981; font-weight: 600; }
.cell-date { font-size: 12px; color: #6b7280; }
.voucher-info p { margin: 8px 0; padding: 8px 0; border-bottom: 1px solid #eee; }
.voucher-info p:last-child { border-bottom: none; }
.voucher-info code { background: #f5f5f5; padding: 4px 8px; border-radius: 4px; font-size: 14px; }
.modal-content::-webkit-scrollbar { width: 8px; }
.modal-content::-webkit-scrollbar-track { background: #f1f1f1; border-radius: 4px; }
.modal-content::-webkit-scrollbar-thumb { background: #c1c1c1; border-radius: 4px; }
</style>
</body>
</html>