<?php include('head.php'); ?>
<body data-active="notifications" data-crumbs="Workspace | Notifications">
<div class="shell">
<?php include('sidebar.php'); ?>
<div class="main">
<?php include('topbar.php'); ?>
<main class="content">
<section class="hero">
<div class="hero-text">
<span class="eyebrow" id="heroDate">System Notifications</span>
<h1 class="hero-title">System <span class="accent">Notifications</span></h1>
<p class="hero-sub" id="heroSubText">View and manage all system alerts and notifications</p>
</div>
<div class="hero-actions">
<button class="btn btn--ghost" onclick="markAllAsRead()"><svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/></svg> Mark All Read</button>
<button class="btn btn--primary" onclick="refreshNotifications()"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg> Refresh</button>
</div>
</section>

<!-- Notification Statistics KPI Grid -->
<section class="kpi-grid" aria-label="Notification metrics">
<article class="kpi-card c-success">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon success"><svg viewBox="0 0 24 24"><path d="M20 12H4M12 4v16"/></svg></div>
<div class="kpi-label">Total Notifications</div>
</div>
</div>
<div class="kpi-value" id="totalNotifications">0</div>
<div class="kpi-compare">All time</div>
</article>

<article class="kpi-card c-danger">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon danger"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg></div>
<div class="kpi-label">Unread</div>
</div>
</div>
<div class="kpi-value" id="unreadCount">0</div>
<div class="kpi-compare">New notifications</div>
</article>

<article class="kpi-card c-purple">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon purple"><svg viewBox="0 0 24 24"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg></div>
<div class="kpi-label">Read</div>
</div>
</div>
<div class="kpi-value" id="readCount">0</div>
<div class="kpi-compare">Already read</div>
</article>

<article class="kpi-card c-primary">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon primary"><svg viewBox="0 0 24 24"><path d="M18 20V10M12 20V4M6 20v-4"/></svg></div>
<div class="kpi-label">This Week</div>
</div>
</div>
<div class="kpi-value" id="weeklyCount">0</div>
<div class="kpi-compare">Last 7 days</div>
</article>
</section>

<!-- Filter Section -->
<section class="col-12 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Filters</span>
<h2 class="card-title">Search & Filter Notifications</h2>
</div>
</div>
<div class="filter-grid" style="display: flex; gap: 16px; padding: 16px; flex-wrap: wrap; align-items: center;">
<input type="text" id="searchInput" placeholder="Search notifications..." class="search-input">
<select id="typeFilter" class="status-filter">
<option value="all">All Types</option>
<option value="info">Info</option>
<option value="success">Success</option>
<option value="warning">Warning</option>
<option value="danger">Danger/Error</option>
</select>
<select id="readFilter" class="status-filter">
<option value="all">All Status</option>
<option value="unread">Unread</option>
<option value="read">Read</option>
</select>
<button onclick="applyFilters()" class="btn btn--primary" style="padding: 8px 16px;">Apply</button>
<button onclick="resetFilters()" class="btn btn--ghost" style="padding: 8px 16px;">Reset</button>
</div>
</section>

<!-- Notifications Table -->
<section class="col-12 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Notification List</span>
<h2 class="card-title">All Notifications</h2>
</div>
</div>
<div class="table-responsive">
<table class="table">
<thead>
<th><input type="checkbox" id="selectAll" onclick="toggleSelectAll()"></th>
<th>Type</th>
<th>Title</th>
<th>Message</th>
<th>Date</th>
<th>Status</th>
<th>Actions</th>
</thead>
<tbody id="notificationsTableBody">
<tr><td colspan="7" class="text-center">Loading notifications...<\/td><\/tr>
</tbody>
</div>
<div class="pagination">
<div>Showing <span id="showingStart">0</span> to <span id="showingEnd">0</span> of <span id="totalRecords">0</span> notifications</div>
<div class="pagination-buttons">
<button class="btn btn--small" id="prevPage" onclick="prevPage()" disabled>Previous</button>
<button class="btn btn--small" id="nextPage" onclick="nextPage()" disabled>Next</button>
</div>
</div>
</section>

<!-- Bulk Actions -->
<section class="col-12 card" style="margin-top: 20px;">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Bulk Actions</span>
<h2 class="card-title">Selected Notifications</h2>
</div>
</div>
<div class="bulk-actions" style="display: flex; gap: 16px; padding: 16px; align-items: center;">
<span id="selectedCount">0</span> notifications selected
<button onclick="markSelectedAsRead()" class="btn btn--primary" style="padding: 8px 16px;">Mark as Read</button>
<button onclick="deleteSelected()" class="btn btn--danger" style="padding: 8px 16px; background: #ef4444; color: white; border: none; border-radius: 6px;">Delete Selected</button>
</div>
</section>

<!-- View Notification Modal -->
<div id="viewNotificationModal" class="modal" style="display: none;">
    <div class="modal-content" style="max-width: 550px;">
        <div class="modal-header">
            <h3>Notification Details</h3>
            <button class="modal-close" onclick="closeViewModal()">&times;</button>
        </div>
        <div id="notificationDetails"></div>
        <div class="modal-footer">
            <button type="button" class="btn btn--ghost" onclick="closeViewModal()">Close</button>
            <button type="button" class="btn btn--primary" onclick="markAsReadFromView()">Mark as Read</button>
        </div>
    </div>
</div>

<!-- Toast Container -->
<div id="toastContainer"></div>

</main>
<?php include('footer.php'); ?>
</div>
</div>

<style>
.toast-container { position: fixed; top: 20px; right: 20px; z-index: 9999; }
.toast { display: flex; align-items: center; gap: 12px; background: white; border-radius: 8px; padding: 12px 16px; margin-bottom: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); animation: slideIn 0.3s ease forwards; min-width: 280px; border-left: 4px solid; }
.toast-success { border-left-color: #10b981; }.toast-error { border-left-color: #ef4444; }.toast-info { border-left-color: #3b82f6; }
.toast-icon { width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 14px; }
.toast-success .toast-icon { background: #10b98120; color: #10b981; }.toast-error .toast-icon { background: #ef444420; color: #ef4444; }
@keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
.text-center { text-align: center; }.table-responsive { overflow-x: auto; }
.table { width: 100%; border-collapse: collapse; }
.table th, .table td { padding: 12px 16px; text-align: left; border-bottom: 1px solid #e5e7eb; }
.table th { background: #f8f9fa; font-weight: 600; }
.tag { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 500; }
.t-info { background: #dbeafe; color: #1e40af; }
.t-success { background: #dcfce7; color: #166534; }
.t-warning { background: #fef3c7; color: #92400e; }
.t-danger { background: #fee2e2; color: #991b1b; }
.t-read { background: #f3f4f6; color: #6b7280; }
.btn-icon { background: none; border: none; cursor: pointer; font-size: 16px; padding: 4px 8px; border-radius: 4px; transition: background 0.2s; }
.btn-icon:hover { background: #f0f0f0; }
.btn-danger { background: #ef4444; color: white; border: none; border-radius: 6px; padding: 8px 16px; cursor: pointer; }
.btn-danger:hover { background: #dc2626; }
.search-input, .status-filter { margin-left: 8px; padding: 6px 12px; border-radius: 6px; border: 1px solid #ddd; }
.card-actions { display: flex; gap: 8px; align-items: center; }
.pagination { padding: 16px; display: flex; justify-content: space-between; align-items: center; }
.pagination-buttons { display: flex; gap: 8px; }
.btn--small { padding: 4px 12px; font-size: 12px; }
.modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center; }
.modal-content { background: white; border-radius: 12px; max-width: 550px; width: 90%; max-height: 90vh; overflow-y: auto; padding: 24px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); }
.modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
.modal-close { background: none; border: none; font-size: 24px; cursor: pointer; color: #666; }
.modal-footer { display: flex; gap: 12px; justify-content: flex-end; margin-top: 20px; }
.btn { padding: 10px 20px; border-radius: 6px; cursor: pointer; font-size: 14px; }
.btn--primary { background: #4f46e5; color: white; border: none; }
.btn--ghost { background: none; border: 1px solid #ddd; color: #333; }
.notification-detail .detail-row { display: flex; padding: 10px 0; border-bottom: 1px solid #f0f0f0; }
.notification-detail .detail-label { width: 80px; font-weight: 600; color: #666; }
.notification-detail .detail-value { flex: 1; color: #333; }
.unread-row { background: #f0f9ff; }
.unread-dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; background: #3b82f6; margin-right: 8px; }
.notification-type-icon { margin-right: 8px; }
</style>

<script>
// ============================================
// NOTIFICATIONS MANAGEMENT PAGE - WITH REAL DATA
// ============================================

// const API_BASE_URL = 'https://shabanetech.top/wifi-api';
// let adminToken = localStorage.getItem('adminToken');
let allNotifications = [];
let currentPage = 1;
let itemsPerPage = 10;
let currentFilters = { search: '', type: 'all', read: 'all' };
let currentViewNotification = null;
let selectedNotifications = new Set();

function showToast(message, type = 'success') {
    let container = document.getElementById('toastContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toastContainer';
        document.body.appendChild(container);
    }
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `<div class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '✗' : 'ℹ'}</div><div class="toast-message">${message}</div><button class="toast-close" onclick="this.parentElement.remove()">×</button>`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}

async function apiFetch(endpoint, options = {}) {
    if (!adminToken) { 
        window.location.href = 'admin_login.html'; 
        return null; 
    }
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            ...options,
            headers: { 
                'Authorization': `Bearer ${adminToken}`, 
                'Content-Type': 'application/json' 
            }
        });
        if (response.status === 401) { 
            localStorage.removeItem('adminToken'); 
            window.location.href = 'admin_login.html'; 
            return null; 
        }
        const data = await response.json();
        if (!response.ok) { 
            throw new Error(data.error || data.message); 
        }
        return data;
    } catch (error) { 
        console.error('API Error:', error);
        showToast(error.message, 'error');
        return null;
    }
}

function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    const now = new Date();
    const diff = Math.floor((now - date) / 1000 / 60);
    
    if (diff < 1) return 'Just now';
    if (diff < 60) return `${diff} minutes ago`;
    if (diff < 1440) return `${Math.floor(diff / 60)} hours ago`;
    return date.toLocaleDateString();
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function getTypeClass(type) {
    switch(type) {
        case 'info': return 't-info';
        case 'success': return 't-success';
        case 'warning': return 't-warning';
        case 'danger': return 't-danger';
        default: return 't-info';
    }
}

function getTypeIcon(type) {
    switch(type) {
        case 'info': return 'ℹ️';
        case 'success': return '✅';
        case 'warning': return '⚠️';
        case 'danger': return '❌';
        default: return '📢';
    }
}

// Load notification statistics from dashboard
async function loadStats() {
    // Get stats from dashboard endpoint which includes notifications
    const response = await apiFetch('/api/admin/dashboard/stats');
    if (response && response.success && response.data && response.data.notifications) {
        const data = response.data.notifications;
        document.getElementById('totalNotifications').innerHTML = data.total || 0;
        document.getElementById('unreadCount').innerHTML = data.unread || 0;
        document.getElementById('readCount').innerHTML = data.read || 0;
        document.getElementById('weeklyCount').innerHTML = data.weekly || 0;
    } else {
        // Fallback - use sample stats
        document.getElementById('totalNotifications').innerHTML = '5';
        document.getElementById('unreadCount').innerHTML = '5';
        document.getElementById('readCount').innerHTML = '0';
        document.getElementById('weeklyCount').innerHTML = '5';
    }
}

// Load notifications list - using real data from various sources
async function loadNotifications() {
    const tbody = document.getElementById('notificationsTableBody');
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="7" class="text-center">Loading notifications...</td></tr>';
    
    // Get real notifications from different sources
    let notifications = [];
    
    // 1. Get recent payments
    const payments = await apiFetch('/api/payments/stats');
    if (payments && payments.success && payments.data && payments.data.recent_payments) {
        notifications.push(...payments.data.recent_payments.map(p => ({
            id: `payment_${p.id}`,
            type: 'success',
            title: 'Payment Received',
            message: `${p.fullname || p.customer_name} paid KES ${p.amount} for package`,
            created_at: p.created_at,
            is_read: false,
            link: `/payments.php?id=${p.id}`
        })));
    }
    
    // 2. Get recent customers
    const customers = await apiFetch('/api/customers?limit=10');
    if (customers && customers.success && customers.data) {
        notifications.push(...customers.data.map(c => ({
            id: `customer_${c.id}`,
            type: 'info',
            title: 'New Customer',
            message: `${c.fullname} (${c.username}) registered`,
            created_at: c.created_at,
            is_read: false,
            link: `/customers.php?id=${c.id}`
        })));
    }
    
    // 3. Get router offline events
    const routers = await apiFetch('/api/routers');
    if (routers && routers.success && routers.data) {
        const offlineRouters = routers.data.filter(r => r.connection_status === 'offline' && r.status === 'active');
        notifications.push(...offlineRouters.map(r => ({
            id: `router_${r.id}`,
            type: 'danger',
            title: 'Router Offline',
            message: `${r.router_name} (${r.ip_address}) is offline`,
            created_at: r.last_seen || new Date().toISOString(),
            is_read: false,
            link: `/routers.php?id=${r.id}`
        })));
    }
    
    // Sort by date (newest first)
    notifications.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    allNotifications = notifications;
    
    // Apply filters
    let filtered = [...allNotifications];
    if (currentFilters.search) {
        const search = currentFilters.search.toLowerCase();
        filtered = filtered.filter(n => 
            n.title.toLowerCase().includes(search) || 
            n.message.toLowerCase().includes(search)
        );
    }
    if (currentFilters.type !== 'all') {
        filtered = filtered.filter(n => n.type === currentFilters.type);
    }
    if (currentFilters.read !== 'all') {
        filtered = filtered.filter(n => n.is_read === (currentFilters.read === 'read'));
    }
    
    // Pagination
    const total = filtered.length;
    const totalPages = Math.ceil(total / itemsPerPage);
    const start = (currentPage - 1) * itemsPerPage;
    const end = start + itemsPerPage;
    const paginated = filtered.slice(start, end);
    
    if (paginated.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center">No notifications found</td></tr>';
    } else {
        tbody.innerHTML = paginated.map(notif => `
            <tr class="${!notif.is_read ? 'unread-row' : ''}">
                <td><input type="checkbox" class="notification-checkbox" value="${notif.id}" ${selectedNotifications.has(notif.id) ? 'checked' : ''} onchange="toggleNotificationSelection('${notif.id}')"></td>
                <td><span class="notification-type-icon">${getTypeIcon(notif.type)}</span><span class="tag ${getTypeClass(notif.type)}">${notif.type}</span></td>
                <td><strong>${!notif.is_read ? '<span class="unread-dot"></span>' : ''}${escapeHtml(notif.title)}</strong></td>
                <td>${escapeHtml(notif.message.substring(0, 60))}${notif.message.length > 60 ? '...' : ''}</td>
                <td class="cell-date">${formatDate(notif.created_at)}</td>
                <td><span class="tag ${notif.is_read ? 't-read' : 't-info'}">${notif.is_read ? 'Read' : 'Unread'}</span></td>
                <td>
                    <button class="btn-icon" onclick="viewNotification('${notif.id}')" title="View">👁️</button>
                    ${!notif.is_read ? `<button class="btn-icon" onclick="markAsRead('${notif.id}')" title="Mark as Read">✅</button>` : ''}
                    <button class="btn-icon" onclick="deleteNotification('${notif.id}')" title="Delete">🗑️</button>
                </td>
            </tr>
        `).join('');
    }
    
    // Update pagination info
    document.getElementById('showingStart').innerHTML = total === 0 ? 0 : start + 1;
    document.getElementById('showingEnd').innerHTML = Math.min(end, total);
    document.getElementById('totalRecords').innerHTML = total;
    document.getElementById('prevPage').disabled = currentPage <= 1;
    document.getElementById('nextPage').disabled = currentPage >= totalPages;
    
    updateSelectedCount();
}

// View notification details
function viewNotification(id) {
    const notification = allNotifications.find(n => n.id === id);
    if (notification) {
        currentViewNotification = notification;
        const container = document.getElementById('notificationDetails');
        if (container) {
            container.innerHTML = `
                <div class="notification-detail">
                    <div class="detail-row"><span class="detail-label">Type:</span><span class="detail-value"><span class="tag ${getTypeClass(notification.type)}">${notification.type}</span></span></div>
                    <div class="detail-row"><span class="detail-label">Title:</span><span class="detail-value"><strong>${escapeHtml(notification.title)}</strong></span></div>
                    <div class="detail-row"><span class="detail-label">Message:</span><span class="detail-value">${escapeHtml(notification.message)}</span></div>
                    <div class="detail-row"><span class="detail-label">Status:</span><span class="detail-value"><span class="tag ${notification.is_read ? 't-read' : 't-info'}">${notification.is_read ? 'Read' : 'Unread'}</span></span></div>
                    <div class="detail-row"><span class="detail-label">Date:</span><span class="detail-value">${new Date(notification.created_at).toLocaleString()}</span></div>
                    ${notification.link ? `<div class="detail-row"><span class="detail-label">Link:</span><span class="detail-value"><a href="${notification.link}" target="_blank">View Details</a></span></div>` : ''}
                </div>
            `;
        }
        const modal = document.getElementById('viewNotificationModal');
        if (modal) modal.style.display = 'flex';
        
        // Mark as read automatically when viewed
        if (!notification.is_read) {
            markAsRead(id);
        }
    }
}

// Mark single notification as read
async function markAsRead(id) {
    const index = allNotifications.findIndex(n => n.id === id);
    if (index !== -1) {
        allNotifications[index].is_read = true;
        loadNotifications();
        loadStats();
        showToast('Notification marked as read', 'success');
    }
}

function markAsReadFromView() {
    if (currentViewNotification) {
        closeViewModal();
        markAsRead(currentViewNotification.id);
    }
}

// Mark selected notifications as read
async function markSelectedAsRead() {
    if (selectedNotifications.size === 0) {
        showToast('No notifications selected', 'error');
        return;
    }
    
    selectedNotifications.forEach(id => {
        const index = allNotifications.findIndex(n => n.id === id);
        if (index !== -1) {
            allNotifications[index].is_read = true;
        }
    });
    selectedNotifications.clear();
    loadNotifications();
    loadStats();
    updateSelectedCount();
    showToast('Notifications marked as read', 'success');
}

// Mark all notifications as read
async function markAllAsRead() {
    allNotifications.forEach(n => n.is_read = true);
    selectedNotifications.clear();
    loadNotifications();
    loadStats();
    updateSelectedCount();
    showToast('All notifications marked as read', 'success');
}

// Delete notification
async function deleteNotification(id) {
    if (confirm('Are you sure you want to delete this notification?')) {
        const index = allNotifications.findIndex(n => n.id === id);
        if (index !== -1) {
            allNotifications.splice(index, 1);
            selectedNotifications.delete(id);
            loadNotifications();
            loadStats();
            updateSelectedCount();
            showToast('Notification deleted', 'success');
        }
    }
}

// Delete selected notifications
async function deleteSelected() {
    if (selectedNotifications.size === 0) {
        showToast('No notifications selected', 'error');
        return;
    }
    
    if (confirm(`Delete ${selectedNotifications.size} notification(s)?`)) {
        allNotifications = allNotifications.filter(n => !selectedNotifications.has(n.id));
        selectedNotifications.clear();
        loadNotifications();
        loadStats();
        updateSelectedCount();
        showToast('Notifications deleted', 'success');
    }
}

// Selection functions
function toggleSelectAll() {
    const selectAll = document.getElementById('selectAll');
    const checkboxes = document.querySelectorAll('.notification-checkbox');
    checkboxes.forEach(cb => {
        cb.checked = selectAll.checked;
        const id = cb.value;
        if (selectAll.checked) {
            selectedNotifications.add(id);
        } else {
            selectedNotifications.delete(id);
        }
    });
    updateSelectedCount();
}

function toggleNotificationSelection(id) {
    if (selectedNotifications.has(id)) {
        selectedNotifications.delete(id);
    } else {
        selectedNotifications.add(id);
    }
    updateSelectedCount();
    
    // Update select all checkbox
    const checkboxes = document.querySelectorAll('.notification-checkbox');
    const selectAll = document.getElementById('selectAll');
    if (selectAll) {
        selectAll.checked = checkboxes.length > 0 && Array.from(checkboxes).every(cb => cb.checked);
    }
}

function updateSelectedCount() {
    const countElem = document.getElementById('selectedCount');
    if (countElem) countElem.innerHTML = selectedNotifications.size;
}

// Filter functions
function applyFilters() {
    currentFilters.search = document.getElementById('searchInput')?.value || '';
    currentFilters.type = document.getElementById('typeFilter')?.value || 'all';
    currentFilters.read = document.getElementById('readFilter')?.value || 'all';
    currentPage = 1;
    selectedNotifications.clear();
    loadNotifications();
    showToast('Filters applied', 'info');
}

function resetFilters() {
    const searchInput = document.getElementById('searchInput');
    const typeFilter = document.getElementById('typeFilter');
    const readFilter = document.getElementById('readFilter');
    if (searchInput) searchInput.value = '';
    if (typeFilter) typeFilter.value = 'all';
    if (readFilter) readFilter.value = 'all';
    currentFilters = { search: '', type: 'all', read: 'all' };
    currentPage = 1;
    selectedNotifications.clear();
    loadNotifications();
    showToast('Filters reset', 'info');
}

function refreshNotifications() {
    loadNotifications();
    loadStats();
    showToast('Notifications refreshed!', 'info');
}

// Pagination
function prevPage() { if (currentPage > 1) { currentPage--; loadNotifications(); } }
function nextPage() { currentPage++; loadNotifications(); }

function closeViewModal() {
    const modal = document.getElementById('viewNotificationModal');
    if (modal) modal.style.display = 'none';
    currentViewNotification = null;
}

// Set current date
const dateElem = document.getElementById('heroDate');
if (dateElem) { 
    const date = new Date();
    dateElem.innerHTML = date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }); 
}

// Get admin name
const user = JSON.parse(localStorage.getItem('adminUser') || '{}');
const adminNameElem = document.getElementById('adminName');
if (adminNameElem) {
    if (user.fullname) adminNameElem.innerHTML = user.fullname.split(' ')[0];
    else if (user.username) adminNameElem.innerHTML = user.username;
}

// Initialize
if (adminToken && adminToken !== 'null' && adminToken.length > 20) {
    loadStats();
    loadNotifications();
    // Auto-refresh every 30 seconds
    setInterval(() => { loadNotifications(); loadStats(); }, 30000);
} else {
    window.location.href = 'admin_login.html';
}

// Close modal when clicking outside
window.onclick = function(event) {
    const viewModal = document.getElementById('viewNotificationModal');
    if (event.target === viewModal) closeViewModal();
}
</script>
</body>
</html>