<?php include('head.php'); ?>
<body data-active="usage_reports" data-crumbs="Workspace | Usage Reports">
<div class="shell">
<?php include('sidebar.php'); ?>
<div class="main">
<?php include('topbar.php'); ?>
<main class="content">
<section class="hero">
<div class="hero-text">
<span class="eyebrow" id="heroDate">Network Usage Reports</span>
<h1 class="hero-title">Network <span class="accent">Usage Reports</span></h1>
<p class="hero-sub" id="heroSubText">Monitor data usage, bandwidth consumption, and network statistics</p>
</div>
<div class="hero-actions">
<button class="btn btn--ghost" onclick="exportReport()"><svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/></svg> Export</button>
<button class="btn btn--primary" onclick="refreshData()"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg> Refresh</button>
</div>
</section>

<!-- Usage Statistics KPI Grid -->
<section class="kpi-grid" aria-label="Usage metrics">
<article class="kpi-card c-success">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon success"><svg viewBox="0 0 24 24"><path d="M20 12H4M12 4v16"/></svg></div>
<div class="kpi-label">Total Customers</div>
</div>
</div>
<div class="kpi-value" id="totalCustomers">0</div>
<div class="kpi-compare">Registered users</div>
</article>

<article class="kpi-card c-danger">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon danger"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg></div>
<div class="kpi-label">Active Customers</div>
</div>
</div>
<div class="kpi-value" id="activeCustomers">0</div>
<div class="kpi-compare">Currently active</div>
</article>

<article class="kpi-card c-purple">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon purple"><svg viewBox="0 0 24 24"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg></div>
<div class="kpi-label">Active Sessions</div>
</div>
</div>
<div class="kpi-value" id="activeSessions">0</div>
<div class="kpi-compare">Online now</div>
</article>

<article class="kpi-card c-primary">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon primary"><svg viewBox="0 0 24 24"><path d="M18 20V10M12 20V4M6 20v-4"/></svg></div>
<div class="kpi-label">Inactive</div>
</div>
</div>
<div class="kpi-value" id="inactiveCustomers">0</div>
<div class="kpi-compare">Pending activation</div>
</article>
</section>

<!-- Date Range Filter -->
<section class="col-12 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Report Period</span>
<h2 class="card-title">Select Date Range</h2>
</div>
</div>
<div class="filter-grid" style="display: flex; gap: 16px; padding: 16px; flex-wrap: wrap; align-items: center;">
<input type="date" id="startDate" class="input" style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
<input type="date" id="endDate" class="input" style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
<select id="periodSelect" class="input" style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
<option value="today">Today</option>
<option value="yesterday">Yesterday</option>
<option value="week">Last 7 Days</option>
<option value="month">Last 30 Days</option>
<option value="custom">Custom Range</option>
</select>
<button onclick="applyDateRange()" class="btn btn--primary" style="padding: 8px 16px;">Apply</button>
<button onclick="resetDateRange()" class="btn btn--ghost" style="padding: 8px 16px;">Reset</button>
</div>
</section>
<br>
<!-- TWO COLUMN LAYOUT -->
<div class="grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">

<!-- Left Column -->
<div class="left-column">

<!-- Customer List Table -->
<section class="col-12 card" style="margin-bottom: 24px;">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Customers</span>
<h2 class="card-title">All Customers</h2>
</div>
</div>
<div class="table-responsive">
<table class="table">
<thead>
<th>#</th>
<th>Customer</th>
<th>Package</th>
<th>Status</th>
<th>Registered</th>
</thead>
<tbody id="customersTable">
<tr><td colspan="5" class="text-center">Loading customers...</td></tr>
</tbody>
</table>
</div>
</section>

<!-- Package Distribution - USING TABLE -->
<section class="col-12 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Packages</span>
<h2 class="card-title">Package Distribution</h2>
</div>
</div>
<div class="table-responsive">
<table class="table">
<thead>
<th>Package Name</th>
<th>Price</th>
<th>Validity</th>
<th>Speed</th>
<th>Data Limit</th>
<th>Customers</th>
</thead>
<tbody id="packagesTable">
<tr><td colspan="6" class="text-center">Loading packages...</td></tr>
</tbody>
</table>
</div>
</section>

</div>

<!-- Right Column -->
<div class="right-column">

<!-- Active Sessions Table -->
<section class="col-12 card" style="margin-bottom: 24px;">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Live</span>
<h2 class="card-title">Active Sessions</h2>
</div>
<a class="card-action" href="#" onclick="refreshSessions(); return false;">Refresh</a>
</div>
<div class="table-responsive">
<table class="table">
<thead>
<th>User</th>
<th>IP Address</th>
<th>Connected Since</th>
<th>Duration</th>
</thead>
<tbody id="activeSessionsTable">
<tr><td colspan="4" class="text-center">Loading sessions...</td></tr>
</tbody>
</table>
</div>
</section>

<!-- Customer Status Summary -->
<section class="col-12 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Summary</span>
<h2 class="card-title">Customer Status Summary</h2>
</div>
</div>
<div class="table-responsive">
<table class="table">
<thead>
<th>Status</th>
<th>Count</th>
<th>Percentage</th>
</thead>
<tbody id="customerStatusTable">
<tr><td colspan="3" class="text-center">Loading...</td></tr>
</tbody>
</table>
</div>
</section>

</div>

</div>

<!-- Toast Container -->
<div id="toastContainer" style="position: fixed; top: 20px; right: 20px; z-index: 9999;"></div>

</main>
<?php include('footer.php'); ?>
</div>
</div>

<script>
// ============================================
// USAGE REPORTS PAGE - TABLE FOR PACKAGES
// ============================================

// const API_BASE_URL = 'https://shabanetech.top/wifi-api';
// let adminToken = localStorage.getItem('adminToken');
let allCustomers = [];

function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `<div class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '✗' : 'ℹ'}</div><div class="toast-message">${message}</div><button class="toast-close" onclick="this.parentElement.remove()">×</button>`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}

// Add styles
const styles = document.createElement('style');
styles.textContent = `
    .toast { display: flex; align-items: center; gap: 12px; background: white; border-radius: 8px; padding: 12px 16px; margin-bottom: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); animation: slideIn 0.3s ease forwards; min-width: 280px; border-left: 4px solid; }
    .toast-success { border-left-color: #10b981; }
    .toast-error { border-left-color: #ef4444; }
    .toast-info { border-left-color: #3b82f6; }
    .toast-icon { width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 14px; }
    .toast-success .toast-icon { background: #10b98120; color: #10b981; }
    @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
    .text-center { text-align: center; }
    .table-responsive { overflow-x: auto; }
    .cell-name strong { display: block; }
    .cell-name small { font-size: 11px; color: #6b7280; }
    .cell-price.pos { color: #10b981; font-weight: 600; }
    .cell-date { font-size: 12px; color: #6b7280; }
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
    @media (max-width: 768px) { .grid { grid-template-columns: 1fr; } }
    .tag { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 500; }
    .t-active { background: #dcfce7; color: #166534; }
    .t-inactive { background: #fee2e2; color: #991b1b; }
    .t-suspended { background: #fef3c7; color: #92400e; }
    .customers-count { font-weight: 600; padding: 2px 8px; border-radius: 20px; font-size: 12px; }
    .customers-high { background: #dcfce7; color: #166534; }
    .customers-low { background: #fef3c7; color: #92400e; }
    .customers-none { background: #f3f4f6; color: #6b7280; }
    .progress-bar-bg { background: #e5e7eb; border-radius: 4px; height: 8px; width: 100%; overflow: hidden; }
    .progress-bar-fill { height: 8px; border-radius: 4px; }
`;
document.head.appendChild(styles);

async function apiFetch(endpoint, options = {}) {
    if (!adminToken) { window.location.href = 'admin_login.html'; return null; }
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            ...options,
            headers: { 'Authorization': `Bearer ${adminToken}`, 'Content-Type': 'application/json' }
        });
        if (response.status === 401) { localStorage.removeItem('adminToken'); window.location.href = 'admin_login.html'; return null; }
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || data.message);
        return data;
    } catch (error) { 
        console.error('API Error:', error);
        return null;
    }
}

function formatCurrency(amount) { return ' ' + parseFloat(amount || 0).toLocaleString(); }
function formatDate(dateString) { if (!dateString) return '-'; const date = new Date(dateString); return date.toLocaleDateString(); }
function formatDuration(seconds) { if (!seconds) return '0 min'; const hours = Math.floor(seconds / 3600); const minutes = Math.floor((seconds % 3600) / 60); if (hours > 0) return `${hours}h ${minutes}m`; return `${minutes}m`; }
function escapeHtml(text) { if (!text) return ''; const div = document.createElement('div'); div.textContent = text; return div.innerHTML; }
function getStatusClass(status) { if (status === 'active') return 't-active'; if (status === 'inactive') return 't-inactive'; return 't-suspended'; }
function getCustomerCountClass(count) { if (count === 0) return 'customers-none'; if (count === 1) return 'customers-low'; return 'customers-high'; }

// Set date range based on period
function setDateRange(period) {
    const today = new Date();
    const end = new Date();
    let start = new Date();
    
    switch(period) {
        case 'today':
            start.setHours(0, 0, 0, 0);
            end.setHours(23, 59, 59, 999);
            break;
        case 'yesterday':
            start.setDate(today.getDate() - 1);
            start.setHours(0, 0, 0, 0);
            end.setDate(today.getDate() - 1);
            end.setHours(23, 59, 59, 999);
            break;
        case 'week':
            start.setDate(today.getDate() - 7);
            start.setHours(0, 0, 0, 0);
            break;
        case 'month':
            start.setDate(today.getDate() - 30);
            start.setHours(0, 0, 0, 0);
            break;
        default: return;
    }
    
    const startInput = document.getElementById('startDate');
    const endInput = document.getElementById('endDate');
    if (startInput) startInput.value = start.toISOString().split('T')[0];
    if (endInput) endInput.value = end.toISOString().split('T')[0];
    
    loadAllData();
}

function applyDateRange() { loadAllData(); showToast('Date range applied', 'info'); }
function resetDateRange() {
    const periodSelect = document.getElementById('periodSelect');
    if (periodSelect) periodSelect.value = 'week';
    setDateRange('week');
}

// Period selector change
document.getElementById('periodSelect')?.addEventListener('change', function() {
    if (this.value !== 'custom') setDateRange(this.value);
});

// Load all dashboard data
async function loadAllData() {
    await loadStats();
    await loadCustomers();
    await loadPackagesTable();
    await loadActiveSessions();
}

// Load statistics from dashboard stats
async function loadStats() {
    const stats = await apiFetch('/api/admin/dashboard/stats');
    if (stats && stats.success && stats.data && stats.data.customers) {
        const data = stats.data.customers;
        document.getElementById('totalCustomers').innerHTML = data.total || 0;
        document.getElementById('activeCustomers').innerHTML = data.active || 0;
        document.getElementById('inactiveCustomers').innerHTML = data.inactive || 0;
        document.getElementById('activeSessions').innerHTML = stats.data.active_sessions || 0;
    }
}

// Load all customers
async function loadCustomers() {
    const tbody = document.getElementById('customersTable');
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="5" class="text-center">Loading customers...</td></tr>';
    
    const response = await apiFetch('/api/customers');
    if (response && response.success && response.data) {
        allCustomers = response.data;
        if (allCustomers.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center">No customers found</td></tr>';
        } else {
            tbody.innerHTML = allCustomers.map((customer, idx) => `
                <tr>
                    <td>${idx + 1}</td>
                    <td class="cell-name">
                        <strong>${escapeHtml(customer.fullname)}</strong><br>
                        <small>${escapeHtml(customer.username)}</small>
                    </td>
                    <td>${escapeHtml(customer.package_name || 'N/A')}</td>
                    <td><span class="tag ${getStatusClass(customer.status)}">${customer.status}</span></td>
                    <td class="cell-date">${formatDate(customer.created_at)}</td>
                </tr>
            `).join('');
        }
        
        // Update customer status summary
        updateCustomerStatusSummary(allCustomers);
    }
}

// Update customer status summary
function updateCustomerStatusSummary(customers) {
    const tbody = document.getElementById('customerStatusTable');
    if (!tbody) return;
    
    const total = customers.length;
    const active = customers.filter(c => c.status === 'active').length;
    const inactive = customers.filter(c => c.status === 'inactive').length;
    const suspended = customers.filter(c => c.status === 'suspended').length;
    
    tbody.innerHTML = `
        <tr>
            <td><span class="tag t-active">Active</span></td>
            <td class="text-center"><strong>${active}</strong></td>
            <td><div class="progress-bar-bg"><div class="progress-bar-fill" style="width:${(active/total)*100}%; background:#10b981;"></div></div> ${Math.round((active/total)*100)}%</td>
        </tr>
        <tr>
            <td><span class="tag t-inactive">Inactive</span></td>
            <td class="text-center"><strong>${inactive}</strong></td>
            <td><div class="progress-bar-bg"><div class="progress-bar-fill" style="width:${(inactive/total)*100}%; background:#f59e0b;"></div></div> ${Math.round((inactive/total)*100)}%</td>
        </tr>
        <tr>
            <td><span class="tag t-suspended">Suspended</span></td>
            <td class="text-center"><strong>${suspended}</strong></td>
            <td><div class="progress-bar-bg"><div class="progress-bar-fill" style="width:${(suspended/total)*100}%; background:#ef4444;"></div></div> ${Math.round((suspended/total)*100)}%</td>
        </tr>
    `;
}

// Load packages in TABLE format
async function loadPackagesTable() {
    const tbody = document.getElementById('packagesTable');
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="6" class="text-center">Loading packages...</td></tr>';
    
    const packages = await apiFetch('/api/packages');
    if (packages && packages.success && packages.data) {
        // Count customers per package
        const packageCounts = {};
        allCustomers.forEach(customer => {
            if (customer.package_id) {
                packageCounts[customer.package_id] = (packageCounts[customer.package_id] || 0) + 1;
            }
        });
        
        if (packages.data.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center">No packages found</td></tr>';
        } else {
            tbody.innerHTML = packages.data.map(pkg => {
                const customerCount = packageCounts[pkg.id] || 0;
                const countClass = getCustomerCountClass(customerCount);
                const countText = `${customerCount} customer${customerCount !== 1 ? 's' : ''}`;
                
                return `
                    <tr>
                        <td class="cell-name"><strong>${escapeHtml(pkg.package_name)}</strong></td>
                        <td class="cell-price pos">${formatCurrency(pkg.price)}</td>
                        <td>${pkg.validity_days} days</td>
                        <td>${pkg.download_speed || '1M'} / ${pkg.upload_speed || '1M'}</td>
                        <td>${pkg.data_limit_mb === 0 ? 'Unlimited' : (pkg.data_limit_mb / 1024).toFixed(0) + ' GB'}</td>
                        <td><span class="customers-count ${countClass}">${countText}</span></td>
                    </tr>
                `;
            }).join('');
        }
    } else {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center">Failed to load packages</td></tr>';
    }
}

// Load active sessions
async function loadActiveSessions() {
    const tbody = document.getElementById('activeSessionsTable');
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="4" class="text-center">Loading sessions...</td></tr>';
    
    const response = await apiFetch('/api/radius/sessions/active');
    if (response && response.success && response.data && response.data.length > 0) {
        tbody.innerHTML = response.data.map(session => `
            <tr>
                <td class="cell-name"><strong>${escapeHtml(session.fullname || session.username)}</strong><br><small>${escapeHtml(session.username)}</small></td>
                <td class="cell-date">${escapeHtml(session.framedipaddress || '-')}</td>
                <td class="cell-date">${formatDate(session.acctstarttime)}</td>
                <td class="cell-date">${formatDuration(session.session_seconds)}</td>
            </tr>
        `).join('');
    } else {
        tbody.innerHTML = '<tr><td colspan="4" class="text-center">No active sessions</td></tr>';
    }
}

function refreshData() { loadAllData(); showToast('Data refreshed!', 'success'); }
function refreshSessions() { loadActiveSessions(); showToast('Sessions refreshed!', 'success'); }
function exportReport() { showToast('Export feature coming soon!', 'info'); }

// Set current date
const dateElem = document.getElementById('heroDate');
if (dateElem) { 
    const date = new Date();
    dateElem.innerHTML = date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }); 
}

// Get admin name
const user = JSON.parse(localStorage.getItem('adminUser') || '{}');
const adminNameElem = document.getElementById('adminName');
if (adminNameElem) {
    if (user.fullname) adminNameElem.innerHTML = user.fullname.split(' ')[0];
    else if (user.username) adminNameElem.innerHTML = user.username;
}

// Initialize
if (adminToken && adminToken !== 'null' && adminToken.length > 20) {
    setDateRange('week');
    setInterval(loadAllData, 60000);
} else {
    window.location.href = 'admin_login.html';
}
</script>

<style>
.text-center { text-align: center; }
.table-responsive { overflow-x: auto; }
.cell-name strong { display: block; }
.cell-name small { font-size: 11px; color: #6b7280; }
.cell-price.pos { color: #10b981; font-weight: 600; }
.cell-date { font-size: 12px; color: #6b7280; }
.grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
@media (max-width: 768px) { .grid { grid-template-columns: 1fr; } }
.tag { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 500; }
.t-active { background: #dcfce7; color: #166534; }
.t-inactive { background: #fee2e2; color: #991b1b; }
.t-suspended { background: #fef3c7; color: #92400e; }
.customers-count { display: inline-block; padding: 2px 8px; border-radius: 20px; font-size: 12px; font-weight: 500; }
.customers-high { background: #dcfce7; color: #166534; }
.customers-low { background: #fef3c7; color: #92400e; }
.customers-none { background: #f3f4f6; color: #6b7280; }
.progress-bar-bg { background: #e5e7eb; border-radius: 4px; height: 8px; width: 100%; overflow: hidden; }
.progress-bar-fill { height: 8px; border-radius: 4px; }
</style>
</body>
</html>