<?php include('head.php'); ?>
<body data-active="customers" data-crumbs="Workspace | Customers">
<div class="shell">
<?php include('sidebar.php'); ?>
<div class="main">
<?php include('topbar.php'); ?>
<main class="content">
<section class="hero">
<div class="hero-text">
<span class="eyebrow" id="heroDate">Customer Management</span>
<h1 class="hero-title">Manage <span class="accent">Customers</span></h1>
<p class="hero-sub" id="heroSubText">View, manage, and monitor all customer accounts</p>
</div>
<div class="hero-actions">
<button class="btn btn--ghost" onclick="exportCustomers()"><svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/></svg> Export</button>
<button class="btn btn--primary" onclick="showAddCustomerModal()"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg> Add Customer</button>
</div>
</section>

<!-- Toast Container -->
<div id="toastContainer" style="position: fixed; top: 20px; right: 20px; z-index: 9999;"></div>

<!-- Customer Statistics KPI Grid -->
<section class="kpi-grid" aria-label="Customer metrics">
<article class="kpi-card c-success">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon success"><svg viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg></div>
<div class="kpi-label">Total Customers</div>
</div>
</div>
<div class="kpi-value" id="totalCustomers">0</div>
<div class="kpi-compare">All registered customers</div>
</article>

<article class="kpi-card c-danger">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon danger"><svg viewBox="0 0 24 24"><path d="M12 20V10M18 20V4M6 20v-4"/></svg></div>
<div class="kpi-label">Active Customers</div>
</div>
</div>
<div class="kpi-value" id="activeCustomers">0</div>
<div class="kpi-compare">Currently active accounts</div>
</article>

<article class="kpi-card c-purple">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon purple"><svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8"/></svg></div>
<div class="kpi-label">Inactive</div>
</div>
</div>
<div class="kpi-value" id="inactiveCustomers">0</div>
<div class="kpi-compare">Pending activation</div>
</article>

<article class="kpi-card c-primary">
<div class="kpi-top">
<div class="kpi-identity">
<div class="kpi-icon primary"><svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h8M8 9h2"/></svg></div>
<div class="kpi-label">Suspended</div>
</div>
</div>
<div class="kpi-value" id="suspendedCustomers">0</div>
<div class="kpi-compare">Suspended accounts</div>
</article>
</section>

<!-- Customers Table -->
<section class="col-12 card">
<div class="card-head">
<div class="card-title-wrap">
<span class="eyebrow">Customer List</span>
<h2 class="card-title">All Customers</h2>
</div>
<div class="card-actions">
<input type="text" id="searchInput" placeholder="Search customers..." class="search-input" style="padding: 6px 12px; border-radius: 6px; border: 1px solid var(--border); background: var(--bg);">
<select id="statusFilter" class="status-filter" style="padding: 6px 12px; border-radius: 6px; border: 1px solid var(--border); background: var(--bg);">
<option value="all">All Status</option>
<option value="active">Active</option>
<option value="inactive">Inactive</option>
<option value="suspended">Suspended</option>
</select>
</div>
</div>
<div class="table-responsive">
<table class="table">
<thead>
<tr>
<th>ID</th>
<th>Customer</th>
<th>Phone</th>
<th>Email</th>
<th>Package</th>
<th>Status</th>
<th>Created</th>
<th>Actions</th>
</tr>
</thead>
<tbody id="customersTableBody">
<tr><td colspan="8" class="text-center">Loading customers...</td></tr>
</tbody>
</table>
</div>
<div class="pagination" style="padding: 16px; display: flex; justify-content: space-between; align-items: center;">
<div>Showing <span id="showingStart">0</span> to <span id="showingEnd">0</span> of <span id="totalRecords">0</span> customers</div>
<div class="pagination-buttons">
<button class="btn btn--small" id="prevPage" onclick="prevPage()" disabled>Previous</button>
<button class="btn btn--small" id="nextPage" onclick="nextPage()" disabled>Next</button>
</div>
</div>
</section>

<!-- Add Customer Modal -->
<div id="addCustomerModal" class="modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
    <div class="modal-content" style="background: white; border-radius: 12px; max-width: 500px; width: 90%; padding: 24px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1);">
        <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h3 style="margin: 0;">Add New Customer</h3>
            <button onclick="closeModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: #666;">&times;</button>
        </div>
        <form id="addCustomerForm">
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Full Name *</label>
                <input type="text" id="fullname" class="input" required style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Phone *</label>
                <input type="tel" id="phone" class="input" required style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Email</label>
                <input type="email" id="email" class="input" style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Username *</label>
                <input type="text" id="username" class="input" required style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Password *</label>
                <input type="password" id="password" class="input" required style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Package *</label>
                <select id="package_id" class="input" required style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
                    <option value="">Select Package</option>
                </select>
            </div>
            <button type="submit" class="btn btn--primary" style="width: 100%; padding: 10px; background: #4f46e5; color: white; border: none; border-radius: 6px; cursor: pointer;">Register Customer</button>
        </form>
    </div>
</div>

<!-- View Customer Modal -->
<div id="viewCustomerModal" class="modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
    <div class="modal-content" style="background: white; border-radius: 12px; max-width: 600px; width: 90%; padding: 24px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1);">
        <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h3 style="margin: 0;">Customer Details</h3>
            <button onclick="closeViewModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: #666;">&times;</button>
        </div>
        <div id="customerDetails" style="max-height: 400px; overflow-y: auto;"></div>
        <div style="margin-top: 20px; display: flex; gap: 10px; justify-content: flex-end;">
            <button onclick="closeViewModal()" class="btn btn--ghost" style="padding: 8px 16px;">Close</button>
            <button onclick="editFromView()" class="btn btn--primary" id="editFromViewBtn" style="padding: 8px 16px;">Edit Customer</button>
        </div>
    </div>
</div>

<!-- Edit Customer Modal -->
<div id="editCustomerModal" class="modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
    <div class="modal-content" style="background: white; border-radius: 12px; max-width: 500px; width: 90%; padding: 24px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1);">
        <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h3 style="margin: 0;">Edit Customer</h3>
            <button onclick="closeEditModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: #666;">&times;</button>
        </div>
        <form id="editCustomerForm">
            <input type="hidden" id="edit_customer_id">
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Full Name *</label>
                <input type="text" id="edit_fullname" class="input" required style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Phone *</label>
                <input type="tel" id="edit_phone" class="input" required style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Email</label>
                <input type="email" id="edit_email" class="input" style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Username</label>
                <input type="text" id="edit_username" class="input" disabled style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px; background: #f5f5f5;">
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Package</label>
                <select id="edit_package_id" class="input" style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
                    <option value="">Select Package</option>
                </select>
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">Status</label>
                <select id="edit_status" class="input" style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                    <option value="suspended">Suspended</option>
                </select>
            </div>
            <div class="field" style="margin-bottom: 16px;">
                <label class="field-label" style="display: block; margin-bottom: 6px;">New Password (leave blank to keep current)</label>
                <input type="password" id="edit_password" class="input" style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            <button type="submit" class="btn btn--primary" style="width: 100%; padding: 10px; background: #4f46e5; color: white; border: none; border-radius: 6px; cursor: pointer;">Update Customer</button>
        </form>
    </div>
</div>

</main>
<?php include('footer.php'); ?>
</div>
</div>

<script>
// ============================================
// CUSTOMER MANAGEMENT PAGE WITH TOAST NOTIFICATIONS
// ============================================

// const API_BASE_URL = 'https://shabanetech.top/wifi-api';
// let adminToken = localStorage.getItem('adminToken');
let currentPage = 1;
let totalPages = 1;
let currentFilters = { search: '', status: 'all' };
let currentEditId = null;
let currentViewCustomer = null;

// ==================== TOAST NOTIFICATIONS ====================

function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '✗' : type === 'warning' ? '⚠' : 'ℹ'}</div>
        <div class="toast-message">${message}</div>
        <button class="toast-close" onclick="this.parentElement.remove()">×</button>
    `;
    
    container.appendChild(toast);
    
    // Auto remove after 4 seconds
    setTimeout(() => {
        if (toast.parentElement) {
            toast.style.animation = 'slideOut 0.3s ease forwards';
            setTimeout(() => toast.remove(), 300);
        }
    }, 4000);
}

// Add toast styles to document
const toastStyles = document.createElement('style');
toastStyles.textContent = `
    .toast {
        display: flex;
        align-items: center;
        gap: 12px;
        background: white;
        border-radius: 8px;
        padding: 12px 16px;
        margin-bottom: 10px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        animation: slideIn 0.3s ease forwards;
        min-width: 280px;
        border-left: 4px solid;
    }
    .toast-success { border-left-color: #10b981; }
    .toast-error { border-left-color: #ef4444; }
    .toast-warning { border-left-color: #f59e0b; }
    .toast-info { border-left-color: #3b82f6; }
    .toast-icon {
        width: 24px;
        height: 24px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        font-size: 14px;
    }
    .toast-success .toast-icon { background: #10b98120; color: #10b981; }
    .toast-error .toast-icon { background: #ef444420; color: #ef4444; }
    .toast-warning .toast-icon { background: #f59e0b20; color: #f59e0b; }
    .toast-info .toast-icon { background: #3b82f620; color: #3b82f6; }
    .toast-message { flex: 1; font-size: 14px; color: #333; }
    .toast-close {
        background: none;
        border: none;
        font-size: 18px;
        cursor: pointer;
        color: #999;
        padding: 0;
        width: 20px;
        height: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .toast-close:hover { color: #666; }
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
`;
document.head.appendChild(toastStyles);

// Helper function for API calls
async function apiFetch(endpoint, options = {}) {
    if (!adminToken) {
        window.location.href = 'signin.html';
        return null;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            ...options,
            headers: {
                'Authorization': `Bearer ${adminToken}`,
                'Content-Type': 'application/json',
                ...options.headers
            }
        });
        
        if (response.status === 401) {
            localStorage.removeItem('adminToken');
            localStorage.removeItem('adminUser');
            window.location.href = 'signin.html';
            return null;
        }
        
        return await response.json();
    } catch (error) {
        console.error('API Error:', error);
        return null;
    }
}

// Format helpers
function formatCurrency(amount) {
    return ' ' + parseFloat(amount || 0).toLocaleString();
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatDataUsage(mb) {
    if (!mb) return '0 GB';
    const gb = mb / 1024;
    if (gb >= 1) return gb.toFixed(2) + ' GB';
    return mb.toFixed(0) + ' MB';
}

// Load dashboard stats
async function loadStats() {
    const stats = await apiFetch('/api/admin/dashboard/stats');
    if (stats && stats.success && stats.data && stats.data.customers) {
        document.getElementById('totalCustomers').innerHTML = (stats.data.customers.total || 0).toLocaleString();
        document.getElementById('activeCustomers').innerHTML = (stats.data.customers.active || 0).toLocaleString();
        document.getElementById('inactiveCustomers').innerHTML = (stats.data.customers.inactive || 0).toLocaleString();
        document.getElementById('suspendedCustomers').innerHTML = (stats.data.customers.suspended || 0).toLocaleString();
    }
}

// Load customers list
async function loadCustomers() {
    const tbody = document.getElementById('customersTableBody');
    tbody.innerHTML = '<tr><td colspan="8" class="text-center">Loading customers...</td></tr>';
    
    let url = `/api/customers?page=${currentPage}&limit=20`;
    if (currentFilters.search) url += `&search=${encodeURIComponent(currentFilters.search)}`;
    if (currentFilters.status !== 'all') url += `&status=${currentFilters.status}`;
    
    const response = await apiFetch(url);
    
    if (response && response.success && response.data) {
        const customers = response.data;
        const pagination = response.pagination;
        
        if (customers.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" class="text-center">No customers found</td></tr>';
        } else {
            tbody.innerHTML = customers.map(customer => `
                <tr>
                    <td>${customer.id}</td>
                    <td class="cell-name">
                        <strong>${escapeHtml(customer.fullname)}</strong><br>
                        <small>${escapeHtml(customer.username)}</small>
                    </td>
                    <td>${escapeHtml(customer.phone || '-')}</td>
                    <td>${escapeHtml(customer.email || '-')}</td>
                    <td>${escapeHtml(customer.package_name || 'N/A')}</td>
                    <td><span class="tag ${customer.status === 'active' ? 't-new' : customer.status === 'inactive' ? 't-warning' : 't-unavail'}">${customer.status}</span></td>
                    <td class="cell-date">${new Date(customer.created_at).toLocaleDateString()}</td>
                    <td>
                        <button class="btn-icon" onclick="viewCustomer(${customer.id})" title="View">👁️</button>
                        <button class="btn-icon" onclick="editCustomer(${customer.id})" title="Edit">✏️</button>
                        <button class="btn-icon" onclick="deleteCustomer(${customer.id})" title="Delete">🗑️</button>
                    </td>
                </tr>
            `).join('');
        }
        
        if (pagination) {
            totalPages = pagination.pages || 1;
            document.getElementById('showingStart').innerHTML = ((currentPage - 1) * 20) + 1;
            document.getElementById('showingEnd').innerHTML = Math.min(currentPage * 20, pagination.total);
            document.getElementById('totalRecords').innerHTML = pagination.total;
            document.getElementById('prevPage').disabled = currentPage <= 1;
            document.getElementById('nextPage').disabled = currentPage >= totalPages;
        }
    } else {
        tbody.innerHTML = '<tr><td colspan="8" class="text-center">Failed to load customers</td></tr>';
    }
}

// Load packages for dropdowns
async function loadPackages(selectId, selectedId = null) {
    const response = await apiFetch('/api/packages');
    if (response && response.success && response.data) {
        const select = document.getElementById(selectId);
        select.innerHTML = '<option value="">Select Package</option>' + 
            response.data.map(pkg => `<option value="${pkg.id}" ${selectedId == pkg.id ? 'selected' : ''}>${escapeHtml(pkg.package_name)} - ${formatCurrency(pkg.price)} (${pkg.validity_days} days)</option>`).join('');
    }
}

// Add customer
document.getElementById('addCustomerForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const customerData = {
        fullname: document.getElementById('fullname').value,
        phone: document.getElementById('phone').value,
        email: document.getElementById('email').value || null,
        username: document.getElementById('username').value,
        password: document.getElementById('password').value,
        package_id: parseInt(document.getElementById('package_id').value)
    };
    
    const response = await apiFetch('/api/customers', {
        method: 'POST',
        body: JSON.stringify(customerData)
    });
    
    if (response && response.success) {
        showToast(`Customer ${customerData.fullname} added successfully!`, 'success');
        closeModal();
        loadCustomers();
        loadStats();
        document.getElementById('addCustomerForm').reset();
    } else {
        showToast(response?.error || 'Failed to add customer', 'error');
    }
});

// View customer
async function viewCustomer(id) {
    const response = await apiFetch(`/api/customers/${id}`);
    if (response && response.success && response.data) {
        currentViewCustomer = response.data;
        const customer = response.data;
        document.getElementById('customerDetails').innerHTML = `
            <div class="customer-info">
                <p><strong>ID:</strong> ${customer.id}</p>
                <p><strong>Full Name:</strong> ${escapeHtml(customer.fullname)}</p>
                <p><strong>Username:</strong> ${escapeHtml(customer.username)}</p>
                <p><strong>Phone:</strong> ${escapeHtml(customer.phone || '-')}</p>
                <p><strong>Email:</strong> ${escapeHtml(customer.email || '-')}</p>
                <p><strong>Package:</strong> ${escapeHtml(customer.package_name || 'N/A')}</p>
                <p><strong>Status:</strong> <span class="tag ${customer.status === 'active' ? 't-new' : 't-unavail'}">${customer.status}</span></p>
                <p><strong>Created:</strong> ${new Date(customer.created_at).toLocaleString()}</p>
                ${customer.usage ? `<p><strong>Data Used:</strong> ${formatDataUsage(customer.usage.total_mb)}</p>` : ''}
            </div>
        `;
        document.getElementById('viewCustomerModal').style.display = 'flex';
    }
}

function editFromView() {
    if (currentViewCustomer) {
        closeViewModal();
        editCustomer(currentViewCustomer.id);
    }
}

// Edit customer
async function editCustomer(id) {
    const response = await apiFetch(`/api/customers/${id}`);
    if (response && response.success && response.data) {
        const customer = response.data;
        currentEditId = customer.id;
        
        document.getElementById('edit_customer_id').value = customer.id;
        document.getElementById('edit_fullname').value = customer.fullname || '';
        document.getElementById('edit_phone').value = customer.phone || '';
        document.getElementById('edit_email').value = customer.email || '';
        document.getElementById('edit_username').value = customer.username || '';
        document.getElementById('edit_status').value = customer.status || 'inactive';
        document.getElementById('edit_password').value = '';
        
        await loadPackages('edit_package_id', customer.package_id);
        
        document.getElementById('editCustomerModal').style.display = 'flex';
    }
}

// Submit edit form
document.getElementById('editCustomerForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const updateData = {
        fullname: document.getElementById('edit_fullname').value,
        phone: document.getElementById('edit_phone').value,
        email: document.getElementById('edit_email').value || null,
        package_id: parseInt(document.getElementById('edit_package_id').value),
        status: document.getElementById('edit_status').value
    };
    
    const newPassword = document.getElementById('edit_password').value;
    if (newPassword) {
        updateData.password = newPassword;
    }
    
    const response = await apiFetch(`/api/customers/${currentEditId}`, {
        method: 'PUT',
        body: JSON.stringify(updateData)
    });
    
    if (response && response.success) {
        showToast(`Customer ${updateData.fullname} updated successfully!`, 'success');
        closeEditModal();
        loadCustomers();
        loadStats();
    } else {
        showToast(response?.error || 'Failed to update customer', 'error');
    }
});

// Delete customer
async function deleteCustomer(id) {
    if (confirm('Are you sure you want to delete this customer? This action cannot be undone.')) {
        const response = await apiFetch(`/api/customers/${id}`, { method: 'DELETE' });
        if (response && response.success) {
            showToast('Customer deleted successfully!', 'success');
            loadCustomers();
            loadStats();
        } else {
            showToast(response?.error || 'Failed to delete customer', 'error');
        }
    }
}

// Modal functions
function showAddCustomerModal() {
    document.getElementById('addCustomerModal').style.display = 'flex';
    loadPackages('package_id');
}

function closeModal() {
    document.getElementById('addCustomerModal').style.display = 'none';
}

function closeViewModal() {
    document.getElementById('viewCustomerModal').style.display = 'none';
    currentViewCustomer = null;
}

function closeEditModal() {
    document.getElementById('editCustomerModal').style.display = 'none';
    currentEditId = null;
}

// Pagination
function prevPage() {
    if (currentPage > 1) {
        currentPage--;
        loadCustomers();
    }
}

function nextPage() {
    if (currentPage < totalPages) {
        currentPage++;
        loadCustomers();
    }
}

// Search and filter
document.getElementById('searchInput')?.addEventListener('input', (e) => {
    currentFilters.search = e.target.value;
    currentPage = 1;
    loadCustomers();
});

document.getElementById('statusFilter')?.addEventListener('change', (e) => {
    currentFilters.status = e.target.value;
    currentPage = 1;
    loadCustomers();
});

function exportCustomers() {
    showToast('Export feature coming soon!', 'info');
}

// Set current date
const dateElem = document.getElementById('heroDate');
if (dateElem) {
    const date = new Date();
    dateElem.innerHTML = date.toLocaleDateString('en-US', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
}

// Get admin name
const user = JSON.parse(localStorage.getItem('adminUser') || '{}');
const adminNameElem = document.getElementById('adminName');
if (adminNameElem) {
    if (user.fullname) {
        adminNameElem.innerHTML = user.fullname.split(' ')[0];
    } else if (user.username) {
        adminNameElem.innerHTML = user.username;
    }
}

// Check authentication and load data
if (adminToken && adminToken !== 'null' && adminToken.length > 20) {
    loadStats();
    loadCustomers();
} else {
    window.location.href = 'signin.html';
}

// Close modals when clicking outside
window.onclick = function(event) {
    const addModal = document.getElementById('addCustomerModal');
    const viewModal = document.getElementById('viewCustomerModal');
    const editModal = document.getElementById('editCustomerModal');
    if (event.target === addModal) closeModal();
    if (event.target === viewModal) closeViewModal();
    if (event.target === editModal) closeEditModal();
}
</script>

<style>
.text-center { text-align: center; }
.table-responsive { overflow-x: auto; }
.tag { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 500; }
.t-new { background: #dcfce7; color: #166534; }
.t-warning { background: #fef3c7; color: #92400e; }
.t-unavail { background: #fee2e2; color: #991b1b; }
.cell-name strong { display: block; }
.cell-name small { font-size: 11px; color: #6b7280; }
.btn-icon { background: none; border: none; cursor: pointer; font-size: 18px; padding: 4px 8px; border-radius: 4px; transition: background 0.2s; }
.btn-icon:hover { background: #f0f0f0; }
.btn--small { padding: 4px 12px; font-size: 12px; }
.search-input, .status-filter { margin-left: 8px; }
.card-actions { display: flex; gap: 8px; }
.pagination-buttons { display: flex; gap: 8px; }
.customer-info p { margin: 8px 0; padding: 8px 0; border-bottom: 1px solid #eee; }
.customer-info p:last-child { border-bottom: none; }
</style>
</body>
</html>